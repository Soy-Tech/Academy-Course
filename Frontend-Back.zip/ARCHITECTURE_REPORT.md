
# AUDITORÍA TÉCNICA Y ARQUITECTURA DEL SISTEMA

**Fecha:** 2026-02-04
**Estado:** Prototipo Funcional Avanzado (Mock Data / LocalStorage)
**Versión:** 1.0.0

---

## SECCIÓN 1: PANEL DE ADMINISTRACIÓN

El panel de administración es una SPA (Single Page Application) anidada dentro de la aplicación principal, protegida por rutas específicas y validación de roles.

### 1.1 Ubicación y Estructura
- **Layout Principal:** `src/components/Admin/AdminLayout.jsx`
  - Actúa como contenedor principal.
  - Gestiona la responsividad (Sidebar móvil/escritorio).
  - Incluye `AdminSidebar` (navegación izquierda) y `AdminHeader` (barra superior).
- **Entrada de Rutas:** `src/App.jsx` define las rutas bajo el prefijo `/admin/*`.

### 1.2 Rutas de Acceso
Todas las rutas están protegidas por `<ProtectedAdminRoute>`:
- `/admin/dashboard`: Vista general de métricas.
- `/admin/users`: Gestión de usuarios (CRUD).
- `/admin/courses`: Catálogo y gestión de cursos.
- `/admin/events`: Gestión de webinars y eventos.
- `/admin/resources`: Biblioteca de recursos globales.
- `/admin/settings`: Configuración de la plataforma.

### 1.3 Protecciones Implementadas
- **ProtectedAdminRoute.jsx:**
  1. Verifica si el usuario está autenticado (`useAuth`).
  2. Verifica si el usuario tiene el rol `ADMIN` o el permiso `VIEW_ADMIN` a través de `useRole`.
  3. Si falla, redirige a `/access-denied`.
- **AdminLayout.jsx:** Realiza una segunda verificación de seguridad defensiva (`if (!hasPermission) return <Navigate...`).

---

## SECCIÓN 2: SISTEMA DE ROLES

El sistema utiliza un modelo RBAC (Role-Based Access Control) jerárquico simplificado.

### 2.1 Definición de Roles
Ubicación: `src/utils/rolePermissions.js`
- **ADMIN:** Acceso total al sistema. Bypasea todas las verificaciones de permisos explícitos.
- **INSTRUCTOR:** Acceso al panel de administración limitado (Cursos, Eventos, Recursos).
- **STUDENT:** Sin acceso al panel de administración. Acceso solo a `/student/*` y rutas públicas.

### 2.2 Almacenamiento y Persistencia
- **RoleContext.jsx:** Es el "cerebro" del sistema de roles.
  - Estado: `currentRole`.
  - Persistencia: `localStorage.getItem('user_role')`. Esto permite mantener el rol tras recargar la página en modo desarrollo/demo.
  - **AuthContext.jsx:** Almacena el objeto `user` básico, que contiene una propiedad `role`. `RoleContext` sincroniza o sobreescribe esto según la lógica de la sesión.

### 2.3 Validación
La función clave es `hasPermission(role, permission)` en `rolePermissions.js`.
- Si `role === 'admin'`, retorna `true` inmediatamente.
- Si no, busca en el array `ROLE_PERMISSIONS[role]`.

---

## SECCIÓN 3: PERMISOS POR ROL (Matriz)

| Funcionalidad | Permiso (Code) | ADMIN | INSTRUCTOR | STUDENT | GUEST |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **Ver Admin Panel** | `VIEW_ADMIN` | ✅ | ✅ | ❌ | ❌ |
| **Gestión Usuarios** | `MANAGE_USERS` | ✅ | ❌ | ❌ | ❌ |
| **Gestión Cursos** | `MANAGE_COURSES` | ✅ | ✅ | ❌ | ❌ |
| **Gestión Eventos** | `MANAGE_EVENTS` | ✅ | ✅ | ❌ | ❌ |
| **Gestión Recursos** | `MANAGE_RESOURCES` | ✅ | ✅ | ❌ | ❌ |
| **Configuración** | `MANAGE_SETTINGS` | ✅ | ❌ | ❌ | ❌ |
| **Ver Comunidad** | `VIEW_COMMUNITY` | ✅ | ✅ | ✅ | ❌ |
| **Ver Cursos (Front)**| N/A (Public) | ✅ | ✅ | ✅ | ✅ |
| **Ver Lecciones** | N/A (Enrollment) | ✅* | ✅* | ✅ (Si inscrito) | ❌ |

*\*Admin tiene acceso implícito a contenido protegido.*

---

## SECCIÓN 4: CREACIÓN Y GESTIÓN DE CURSOS

### 4.1 Actores
- **Admin:** Puede crear, editar y eliminar cualquier curso.
- **Instructor:** (En teoría) debería poder gestionar solo sus cursos, pero la implementación actual de `AdminCoursesPage` muestra *todos* los cursos del mock.

### 4.2 Componentes de Edición
- **CourseModal.jsx:** Contenedor modal animado.
- **CourseForm.jsx:** Formulario con los campos:
  - Nombre, Instructor, Nivel (Select), Duración, Precio.
  - Imagen (URL), Descripción.
  - Estado (Borrador/Publicado).

### 4.3 Almacenamiento Actual
- **Estado Local:** `AdminCoursesPage.jsx` inicializa su estado con `mockCourses`.
- **Persistencia:** Temporal. Si se recarga la página, los cambios se pierden (en la implementación actual de `AdminCoursesPage` no hay `useEffect` escribiendo a `localStorage` para cursos, a diferencia de `AdminResourcesPage`).
- **Estados:** 'published', 'draft', 'active', 'inactive'.

---

## SECCIÓN 5: ESTRUCTURA DE DATOS (Schemas Implícitos)

### Curso (Course)
