
# Role Management Architecture & Governance

## 1. Current State Analysis
- **Existing Roles**: Admin, Instructor, Student
- **Existing Flows**: 
  - Public student signup (self-service)
  - Public instructor application (requires admin approval)
  - Admin panel (access restricted by basic role check)
- **Current Gaps & Limitations**:
  - Lack of "Super Admin" for managing other admins and critical system settings.
  - Granularity of permissions is limited; currently relies heavily on hardcoded role checks rather than specific capabilities.
  - No detailed audit trail for permission changes.

## 2. Recommended Role Structure
**Recommendation**: Implement a 4-tier hierarchy.

1.  **Super Admin** (New)
    - **Justification**: Essential for high-level governance, security configuration, and managing the admin team itself. Prevents "admin lockout" and ensures one root of trust.
2.  **Admin**
    - **Justification**: Operational management (users, courses, content). Separates day-to-day operations from dangerous system-wide configuration.
3.  **Instructor**
    - **Justification**: Content creators. Need isolation from student data (except their own) and system settings.
4.  **Student**
    - **Justification**: Consumers. Lowest privilege level, primarily read access + transactional write (purchases, progress).

**Benefits**:
- **Separation of Concerns**: Operational admins cannot accidentally break global billing or delete the system owner.
- **Scalability**: Allows expanding the admin team without giving everyone "keys to the castle".

## 3. User Creation Flows - Detailed Specifications

### Flow 1: Public Student Registration
- **Route**: `/signup`
- **Requirements**: Email, password, name.
- **Verification**: Email confirmation required (simulated or via Auth provider).
- **Initial State**: Role = `student`, Status = `active`, Progress = 0%.
- **Permissions**: Can purchase courses immediately.
- **Approval**: None required.

### Flow 2: Manual Student Creation (Admin)
- **Route**: `/admin/users/create-student`
- **Requirements**: Email, name, password (auto-generated or custom).
- **Use Cases**: Bulk imports, corporate accounts, manual fixes.
- **Initial State**: Role = `student`, Status = `active`.
- **Permissions**: Same as public students.
- **Notification**: System sends welcome email with credentials.

### Flow 3: Public Instructor Application
- **Route**: `/instructor-application` (Authenticated students only).
- **Requirements**: Bio, experience, portfolio, teaching background.
- **Submission State**: Role = `student`, Application Status = `submitted`.
- **Admin Review**: Via `/admin/applications`.
- **Approval Action**: Role updates to `instructor`, Status = `active`.
- **Rejection Action**: Status = `rejected`, user remains `student`.
- **Permissions**: Grant course creation rights upon approval.

### Flow 4: Manual Instructor Creation (Admin)
- **Route**: `/admin/users/create-instructor`
- **Requirements**: Email, name, password, initial experience level.
- **Use Cases**: Invited partners, VIP instructors.
- **Initial State**: Role = `instructor`, Status = `active`.
- **Permissions**: Immediate course creation rights.

### Flow 5: Admin Creation (Super Admin Only)
- **Route**: `/admin/admins/create`
- **Requirements**: Email, name, password, permission scope.
- **Initial State**: Role = `admin`, Status = `active`.
- **Restrictions**: Standard Admins cannot create other Admins.
- **Notification**: Secure credential delivery.

## 4. Complete Permission Matrix

| Permission Category | Permission Key | Student | Instructor | Admin | Super Admin |
|---------------------|----------------|:-------:|:----------:|:-----:|:-----------:|
| **User Management** | `view_users` | ✗ | ✗ | ✓ | ✓ |
| | `create_student` | ✗ | ✗ | ✓ | ✓ |
| | `create_instructor` | ✗ | ✗ | ✓ | ✓ |
| | `create_admin` | ✗ | ✗ | ✗ | ✓ |
| | `edit_user` | ✗ | Self | ✓ | ✓ |
| | `delete_user` | ✗ | ✗ | ✓ | ✓ |
| **Course Management**| `view_courses` | ✓ | ✓ | ✓ | ✓ |
| | `create_course` | ✗ | ✓ | ✓ | ✓ |
| | `edit_own_course` | ✗ | ✓ | ✓ | ✓ |
| | `edit_any_course` | ✗ | ✗ | ✓ | ✓ |
| | `delete_own_course` | ✗ | ✓ | ✓ | ✓ |
| | `delete_any_course` | ✗ | ✗ | ✓ | ✓ |
| | `publish_course` | ✗ | ✓ | ✓ | ✓ |
| **Enrollment** | `purchase_course` | ✓ | ✓ | ✓ | ✓ |
| | `view_history` | ✓ | ✓ | ✓ | ✓ |
| | `view_progress` | ✓ | ✓ | ✓ | ✓ |
| **Instructor Mgmt** | `view_applications`| ✗ | ✗ | ✓ | ✓ |
| | `approve_instructor`| ✗ | ✗ | ✓ | ✓ |
| | `view_student_data`| ✗ | Own | ✓ | ✓ |
| **Reporting** | `view_basic_reports`| ✗ | ✗ | ✓ | ✓ |
| | `view_adv_reports` | ✗ | ✗ | ✗ | ✓ |
| **System Config** | `manage_settings` | ✗ | ✗ | ✗ | ✓ |
| | `manage_roles` | ✗ | ✗ | ✗ | ✓ |

## 5. Purchase, History, Progress & Certificates

- **Purchases**: Open to all roles. Admins/Instructors may need to test the flow, so purchasing is enabled for them.
- **History**: Immutable record created on successful transaction. Accessible by owner and Admins.
- **Progress**: Tracking initialized on enrollment. Granular lesson-level tracking (viewed/completed/time).
- **Certificates**:
  - Trigger: 100% Course Completion.
  - Generation: Automatic.
  - Revocation: Available to Admins/Super Admins in case of fraud/refunds.

## 6. Role Hierarchy & Governance

1.  **Super Admin (Tier 1)**
    - *Scope*: System Owner.
    - *Capabilities*: Destructive actions, Role assignment, Global config.
    - *Count*: 1-2 restricted accounts.
2.  **Admin (Tier 2)**
    - *Scope*: Platform Manager.
    - *Capabilities*: User support, Content moderation, Approvals.
    - *Count*: 2-5 operational staff.
3.  **Instructor (Tier 3)**
    - *Scope*: Content Creator.
    - *Capabilities*: Course management, Student interaction (own courses only).
    - *Count*: Unlimited.
4.  **Student (Tier 4)**
    - *Scope*: Learner.
    - *Capabilities*: Consumption, Personal progress tracking.
    - *Count*: Unlimited.

## 7. Implementation Roadmap

- **Phase 1: Core Structure (Immediate)**
  - Define `SUPER_ADMIN` constant.
  - Update permission dictionaries in `rolePermissions.js`.
  - Ensure `ProtectedAdminRoute` respects the new hierarchy.
- **Phase 2: User Management Tools**
  - Build Admin Creation interface (Super Admin only).
  - Build Manual Student/Instructor creation forms.
- **Phase 3: Deep Permission Enforcement**
  - Audit all API endpoints/Server Actions (or simulated backend logic).
  - Add conditional UI rendering based on granular permissions, not just roles.
- **Phase 4: Advanced Reporting**
  - Analytics dashboards specific to Super Admin views.

## 8. Security Considerations

- **Least Privilege**: Users start with minimum permissions (Student).
- **Escalation**: Only Super Admins can escalate a user to Admin.
- **Immutable Audit**: Critical actions (Role changes, User deletions) must be logged permanently.
- **Seed Account**: The first Super Admin must be created via database seeding or environment variable configuration, never via a public endpoint.

## 9. UX Considerations

- **Feedback**: Clear success/error messages for permission-denied actions.
- **Visibility**: Hide navigation items the user cannot access (don't show "Admin Panel" to students).
- **Safety**: "Are you sure?" confirmation modals for all destructive Admin actions (Delete Course, Ban User).

## 10. Database Schema Updates (Proposed)

**Users Table**:
- Add `role` (enum/string) - existing.
- Add `permissions` (jsonb) - optional override for specific users.
- Add `created_by` (uuid) - link to creator (for manual creates).

**Audit Logs Table** (New):
- `id`, `user_id`, `action`, `target_id`, `metadata`, `created_at`.
