
-- Netcom Academy - Comprehensive Schema
-- Compatible with PostgreSQL / Supabase

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL, -- Hashed in production
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student', -- student, instructor, admin, super_admin
  user_type TEXT NOT NULL DEFAULT 'public', -- public, corporate, invited
  status TEXT NOT NULL DEFAULT 'active', -- active, inactive, pending
  profile_image TEXT,
  bio TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  last_login TIMESTAMPTZ,
  is_email_verified BOOLEAN DEFAULT FALSE,
  email_verification_token TEXT,
  password_reset_token TEXT,
  password_reset_expiry TIMESTAMPTZ
);

-- 2. INSTRUCTOR APPLICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.instructor_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, approved, rejected
  personal_data JSONB,
  professional_profile JSONB,
  teaching_experience JSONB,
  course_proposal JSONB,
  commitment JSONB,
  policies JSONB,
  admin_notes TEXT,
  approved_by UUID REFERENCES public.users(id),
  rejection_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  approved_at TIMESTAMPTZ
);

-- 3. PURCHASES TABLE
CREATE TABLE IF NOT EXISTS public.purchases (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  course_id TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  payment_method TEXT,
  transaction_id TEXT,
  status TEXT NOT NULL DEFAULT 'completed', -- completed, refunded, failed
  purchase_date TIMESTAMPTZ DEFAULT NOW(),
  refund_date TIMESTAMPTZ,
  refund_reason TEXT
);

-- 4. PROGRESS TABLE
CREATE TABLE IF NOT EXISTS public.progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  course_id TEXT NOT NULL,
  completion_percentage INTEGER DEFAULT 0,
  lessons_completed INTEGER DEFAULT 0,
  total_lessons INTEGER DEFAULT 0,
  videos_watched INTEGER DEFAULT 0,
  total_videos INTEGER DEFAULT 0,
  time_spent INTEGER DEFAULT 0, -- in seconds
  last_access_date TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'in_progress', -- in_progress, completed
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, course_id)
);

-- 5. CERTIFICATES TABLE
CREATE TABLE IF NOT EXISTS public.certificates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  course_id TEXT NOT NULL,
  certificate_number TEXT UNIQUE NOT NULL,
  completion_date TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'active', -- active, revoked
  revoke_date TIMESTAMPTZ,
  revoke_reason TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. ADMIN PERMISSIONS TABLE
CREATE TABLE IF NOT EXISTS public.admin_permissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  admin_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  permission TEXT NOT NULL,
  granted_by UUID REFERENCES public.users(id),
  granted_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(admin_id, permission)
);

-- 7. AUDIT LOG TABLE
CREATE TABLE IF NOT EXISTS public.audit_log (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  resource TEXT,
  resource_id TEXT,
  changes JSONB,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  ip_address TEXT
);

-- Indexes
CREATE INDEX idx_users_email ON public.users(email);
CREATE INDEX idx_users_role ON public.users(role);
CREATE INDEX idx_progress_user ON public.progress(user_id);
CREATE INDEX idx_purchases_user ON public.purchases(user_id);
CREATE INDEX idx_audit_user ON public.audit_log(user_id);
