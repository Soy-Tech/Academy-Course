
# Preview Mode Guide

The application includes a special **Preview Mode** designed for demonstration and development purposes. In this mode, backend authentication is bypassed, and users can switch between different roles instantly without logging in.

## How It Works

Preview Mode replaces the standard `AuthProvider` with a `PreviewAuthProvider`. This provider:
1. Keeps the user in a persistent "Authenticated" state.
2. Serves mock user data (`src/utils/previewMockData.js`) instead of real user data.
3. Provides a `switchRole(role)` function to dynamically change the current user's role in memory.

## Activating Preview Mode

There are two ways to enable Preview Mode:

### 1. URL Parameter (Temporary)
Add `?preview=true` to the URL.
- Example: `http://localhost:3000/?preview=true`
- Note: This might need to be re-applied if you do a full hard refresh that clears URL params, though the session storage attempts to persist the active role.

### 2. Environment Variable (Permanent for Build)
Set `VITE_PREVIEW_MODE=true` in your `.env` file or build command.
- This creates a build specifically for preview/demo purposes.

## Features

### Role Selector
When active, a **Role Selector** appears in the top header (yellow badge "PREVIEW MODE").
- Click the dropdown to switch between:
  - **Student**: Default view.
  - **Instructor**: Access to course creation and student management.
  - **Admin**: Access to user and course management.
  - **Super Admin**: Full system access.

### Mock Data
The user profile is populated with mock data (e.g., "Preview Student").
- `email`: `preview.student@example.com`
- `permissions`: Automatically populated based on the selected role.

## Limitations

- **No Persistence**: Changes made (like updating a profile name) are **not saved** to any database or local storage. They disappear on refresh.
- **Mock Logic**: Authentication functions (`login`, `signup`, `logout`) are mocked. Logout simply resets the role to "Student".
- **Security**: This mode bypasses security. **NEVER** enable `VITE_PREVIEW_MODE=true` in a production environment connected to real user data.

## Troubleshooting

**Q: I don't see the Role Selector.**
A: Ensure `PREVIEW_ENABLED` is resolving to `true`. Check your URL parameters or environment variables.

**Q: I get "Access Denied" when switching roles.**
A: If you are on a page protected for a specific role (e.g., Admin Dashboard) and switch to a role with fewer permissions (e.g., Student), the `ProtectedAdminRoute` will correctly block you. Navigate back to the home page or a valid dashboard for your new role.
