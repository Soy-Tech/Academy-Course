
# AUTHENTICATION & AUTHORIZATION ARCHITECTURE

## 1. RESUMEN EJECUTIVO

El sistema de autenticación de Netcom Academy se encuentra actualmente en una fase de **Prototipo Funcional (Mock Mode)**. Aunque la infraestructura para una integración real con Supabase existe (`supabaseClient.js`), la lógica activa en los contextos y páginas principales utiliza simulaciones basadas en `localStorage` y temporizadores (`setTimeout`) para imitar el comportamiento de una API.

Esta arquitectura permite el desarrollo y prueba de la interfaz de usuario (UI) sin depender de una conexión activa a backend, pero carece de seguridad real. La autorización (roles y permisos) y las inscripciones (enrollments) son persistentes solo a nivel de navegador y pueden ser manipuladas por el usuario final.

## 2. ARQUITECTURA ACTUAL

### Diagrama de Componentes Lógicos

