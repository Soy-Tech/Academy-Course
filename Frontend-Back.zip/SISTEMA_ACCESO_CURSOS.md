
# Guía del Sistema de Acceso y Permisos - Netcom Academy

Este documento explica de forma sencilla cómo funciona la seguridad, el acceso a los cursos y qué puede hacer cada usuario en la plataforma.

---

## 1. Permisos ANTES de Registrarse (Visitante)

Un visitante es cualquier persona que entra a la web sin tener una cuenta o sin haber iniciado sesión.

**Lo que PUEDEN ver/hacer:**
*   ✅ **Ver el Catálogo:** Pueden ver la lista completa de cursos, precios y categorías.
*   ✅ **Ver Detalles del Curso:** Pueden entrar a la página de presentación de un curso ("Landing Page") y leer la descripción, qué aprenderán, quién es el instructor y el temario.
*   ✅ **Leer el Blog:** Acceso total a artículos y noticias.
*   ✅ **Ver Páginas Informativas:** "Sobre Nosotros", "Contacto", "Ayuda", "Legal".

**Lo que NO PUEDEN hacer:**
*   ❌ **Ver las Clases:** No pueden entrar al reproductor de video ni ver los materiales.
*   ❌ **Comprar:** Al intentar comprar, el sistema les pedirá registrarse primero.
*   ❌ **Ver el Panel de Control:** No tienen acceso al área personal ("Dashboard").

---

## 2. Permisos DESPUÉS de Registrarse pero SIN Login

Si un usuario ya creó su cuenta pero **no ha iniciado sesión** (o cerró la sesión), el sistema lo trata exactamente igual que a un **Visitante**.

*   **Diferencia clave:** Aunque el usuario "existe" en la base de datos, el navegador web no lo sabe en ese momento.
*   **Acción requerida:** El usuario debe ir a la página de "Login" e introducir su email y contraseña.
*   **Ejemplo:** Juan se registró ayer. Hoy entra a la web. Para el sistema, Juan es un desconocido hasta que haga clic en "Iniciar Sesión".

---

## 3. Permisos cuando INICIA SESIÓN (Estudiante Conectado)

Cuando el usuario introduce sus credenciales correctamente, obtiene una "Sesión Activa". Ahora el sistema sabe quién es.

**Lo que PUEDEN ver/hacer:**
*   ✅ **Todo lo del Visitante:** Ver catálogo, blog, etc.
*   ✅ **Acceso al Dashboard:** Puede ver su panel personal con estadísticas.
*   ✅ **Ver "Mis Cursos":** Puede ver la lista de cursos en los que está inscrito.
*   ✅ **Editar Perfil:** Cambiar su nombre, foto o contraseña.
*   ✅ **Comprar/Inscribirse:** Ahora sí puede pulsar el botón de inscripción y completar el proceso.

**Restricción Importante:**
*   ⚠️ **Estar "Logueado" NO significa tener acceso a TODO.**
*   Solo puede ver el contenido (videos/lecciones) de los cursos que **específicamente ha comprado o se ha inscrito**.

---

## 4. Cómo el sistema decide el acceso a las clases

El sistema funciona como un guardia de seguridad con dos listas de control. Sigue estos pasos exactos cada vez que intentas ver una clase:

1.  **¿Tienes una identificación? (Login):**
    *   El sistema revisa si has iniciado sesión.
    *   *Si NO:* Te envía a la página de Login.
    *   *Si SÍ:* Pasa al paso 2.

2.  **¿Estás en la lista de invitados de ESTE curso? (Inscripción):**
    *   El sistema revisa si tu usuario ha "comprado" o se ha "inscrito" en ese curso específico.
    *   *Si NO:* Te envía a la página de venta del curso para que lo compres.
    *   *Si SÍ:* **¡Acceso Concedido!** Te deja entrar al aula virtual.

---

## 5. Papel de cada componente (Analogía del Edificio)

Para entenderlo mejor, imagina que Netcom Academy es un edificio de oficinas con muchas salas de conferencias:

*   **El Registro (Sign Up):** Es cuando te haces socio del edificio y te dan tu carnet de identidad.
*   **El Login (Iniciar Sesión):** Es mostrar tu carnet al guardia de la entrada principal para entrar al vestíbulo (Dashboard).
*   **La Sesión:** Es llevar el carnet colgado al cuello mientras caminas por los pasillos. Si te lo quitas (Logout), te sacan del edificio.
*   **La Compra/Inscripción (Enrollment):** Es comprar un ticket para una conferencia específica (Curso de React).
*   **El Acceso al Curso:** Tener el carnet de socio (Login) te deja entrar al edificio, pero necesitas el ticket específico (Inscripción) para entrar a la Sala A. Si intentas entrar a la Sala B sin ticket, la puerta no abre.

---

## 6. Diagrama Visual del Flujo

