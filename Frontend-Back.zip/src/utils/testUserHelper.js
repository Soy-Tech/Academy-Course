
import { ROLES } from './rolePermissions';

/**
 * Checks if the provided user is a test user.
 * @param {Object} user - The user object to check.
 * @returns {boolean} True if the user is a test user.
 */
export const isTestUser = (user) => {
  return user?.isTestUser === true;
};

/**
 * Returns a badge color class string based on the user role.
 * @param {string} role - The user's role.
 * @returns {string} Tailwind CSS class string for background and text color.
 */
export const getTestUserBadgeColor = (role) => {
  switch (role) {
    case ROLES.SUPER_ADMIN:
      return 'bg-red-100 text-red-800 border-red-200';
    case ROLES.ADMIN:
      return 'bg-purple-100 text-purple-800 border-purple-200';
    case ROLES.INSTRUCTOR:
      return 'bg-blue-100 text-blue-800 border-blue-200';
    case ROLES.STUDENT:
      return 'bg-green-100 text-green-800 border-green-200';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-200';
  }
};

/**
 * Logs a test user action to the console for debugging purposes.
 * @param {string} action - The action being performed (e.g., 'LOGIN', 'ACCESS_ROUTE').
 * @param {string} email - The email of the test user.
 */
export const logTestUserAction = (action, email) => {
  console.log(`[TEST USER] Action: ${action} | User: ${email} | Timestamp: ${new Date().toISOString()}`);
};
