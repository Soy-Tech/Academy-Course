
import { ROLES, PERMISSIONS, ROLE_PERMISSIONS } from '@/utils/rolePermissions';

/**
 * Mock User Data Generator for Preview Mode
 * Provides complete user objects that mimic the structure of real authenticated users.
 */

// Helper to get all permissions for a "Super User" feel in preview, 
// or strictly follow role definitions if preferred. 
// For preview, we usually want the specific role's permissions to test UI correctly.
const getPermissionsForRole = (role) => {
  if (role === ROLES.SUPER_ADMIN) {
    return Object.values(PERMISSIONS);
  }
  return ROLE_PERMISSIONS[role] || [];
};

export const MOCK_USERS = {
  [ROLES.STUDENT]: {
    id: 'preview-student-id',
    email: 'preview.student@example.com',
    name: 'Preview Student',
    role: ROLES.STUDENT,
    userType: 'public',
    status: 'active',
    profileImage: null,
    bio: 'I am a preview student account.',
    avatar: 'PS',
    permissions: [], // Populated dynamically
    isAuthenticated: true,
    isEmailVerified: true,
    isPreviewUser: true,
    isTestUser: false
  },
  [ROLES.INSTRUCTOR]: {
    id: 'preview-instructor-id',
    email: 'preview.instructor@example.com',
    name: 'Preview Instructor',
    role: ROLES.INSTRUCTOR,
    userType: 'invited',
    status: 'active',
    profileImage: null,
    bio: 'I am a preview instructor account.',
    avatar: 'PI',
    permissions: [],
    isAuthenticated: true,
    isEmailVerified: true,
    isPreviewUser: true,
    isTestUser: false
  },
  [ROLES.ADMIN]: {
    id: 'preview-admin-id',
    email: 'preview.admin@example.com',
    name: 'Preview Admin',
    role: ROLES.ADMIN,
    userType: 'internal',
    status: 'active',
    profileImage: null,
    bio: 'I am a preview admin account.',
    avatar: 'PA',
    permissions: [],
    isAuthenticated: true,
    isEmailVerified: true,
    isPreviewUser: true,
    isTestUser: false
  },
  [ROLES.SUPER_ADMIN]: {
    id: 'preview-superadmin-id',
    email: 'preview.superadmin@example.com',
    name: 'Preview Super Admin',
    role: ROLES.SUPER_ADMIN,
    userType: 'internal',
    status: 'active',
    profileImage: null,
    bio: 'I am a preview super admin account.',
    avatar: 'SA',
    permissions: [],
    isAuthenticated: true,
    isEmailVerified: true,
    isPreviewUser: true,
    isTestUser: false
  }
};

/**
 * Generates a mock user object for the specified role
 */
export const getMockUserByRole = (role) => {
  const baseUser = MOCK_USERS[role];
  if (!baseUser) return null;

  return {
    ...baseUser,
    permissions: getPermissionsForRole(role)
  };
};

export const getAllPreviewPermissions = () => Object.values(PERMISSIONS);
