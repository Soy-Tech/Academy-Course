
import { ROLES } from '@/utils/rolePermissions';

/**
 * Returns the appropriate dashboard route based on the user's role.
 * @param {string} role - The user's role.
 * @returns {string} The relative path to the dashboard.
 */
export const getRoleDashboard = (role) => {
  if (!role) {
    console.warn('[RoleRedirect] No role provided, defaulting to home.');
    return '/';
  }

  switch (role) {
    case ROLES.STUDENT:
      return '/student/dashboard';
    case ROLES.INSTRUCTOR:
      return '/instructor/dashboard';
    case ROLES.ADMIN:
      return '/admin/dashboard';
    case ROLES.SUPER_ADMIN:
      return '/admin/super-admin/dashboard';
    default:
      console.warn(`[RoleRedirect] Unknown role: ${role}, defaulting to generic dashboard.`);
      return '/dashboard';
  }
};
