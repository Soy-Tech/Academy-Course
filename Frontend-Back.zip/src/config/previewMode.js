
/**
 * Preview Mode Configuration
 * 
 * Determines if the application is running in a special "Preview Mode"
 * where authentication is mocked and all roles are accessible for demonstration.
 */

// Detect preview mode from Environment Variable or URL Parameter
const getPreviewModeStatus = () => {
  // 1. Check Vite Environment Variable (set at build/start time)
  if (import.meta.env.VITE_PREVIEW_MODE === 'true') {
    return true;
  }

  // 2. Check URL Query Parameter (e.g., ?preview=true)
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    if (params.get('preview') === 'true') {
      return true;
    }
  }

  return false;
};

export const PREVIEW_ENABLED = getPreviewModeStatus();

export const isPreviewMode = () => PREVIEW_ENABLED;

export const previewConfig = {
  enabled: PREVIEW_ENABLED,
  defaultRole: 'student', // Default starting role in preview
  persistSelection: true, // Whether to remember selected role in sessionStorage
};

export default PREVIEW_ENABLED;
