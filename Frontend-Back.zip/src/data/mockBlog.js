
export const mockBlogPosts = [
  {
    id: 1,
    title: 'Las 10 tecnologías más demandadas en 2025',
    excerpt: 'Descubre qué habilidades tecnológicas están buscando las empresas y cómo puedes aprenderlas.',
    content: 'En el panorama tecnológico actual, la demanda de habilidades específicas cambia rápidamente. Este artículo analiza las tendencias del mercado laboral para 2025, destacando el auge de la IA Generativa, la computación cuántica y la ciberseguridad avanzada...',
    category: 'Tendencias',
    author: 'Elena García',
    date: '15 Enero 2025',
    readTime: '5 min',
    featured: true,
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    title: 'Cómo la IA está transformando el desarrollo web',
    excerpt: 'Explora cómo la inteligencia artificial está revolucionando la forma en que creamos aplicaciones web.',
    content: 'La inteligencia artificial no solo está escribiendo código, está redefiniendo la arquitectura de las aplicaciones web. Herramientas como GitHub Copilot son solo el principio. Veremos cómo la IA optimiza el rendimiento, personaliza la experiencia del usuario y automatiza el testing...',
    category: 'Inteligencia Artificial',
    author: 'Carlos Ruiz',
    date: '12 Enero 2025',
    readTime: '7 min',
    featured: true,
    image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 3,
    title: 'Guía completa para comenzar en ciberseguridad',
    excerpt: 'Todo lo que necesitas saber para iniciar tu carrera en el campo de la seguridad informática.',
    content: 'La ciberseguridad es una de las carreras con mayor proyección. En esta guía, desglosamos los pasos esenciales: desde aprender redes y sistemas operativos, hasta obtener certificaciones clave como CompTIA Security+ y OSCP...',
    category: 'Ciberseguridad',
    author: 'Ana Martínez',
    date: '10 Enero 2025',
    readTime: '10 min',
    featured: true,
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 4,
    title: 'Productividad digital: herramientas esenciales para 2025',
    excerpt: 'Las mejores herramientas para optimizar tu flujo de trabajo y aumentar tu productividad.',
    content: 'En un mundo hiperconectado, la gestión del tiempo es crucial. Revisamos las herramientas de gestión de proyectos, automatización personal y enfoque profundo que están marcando la diferencia este año...',
    category: 'Productividad',
    author: 'David López',
    date: '8 Enero 2025',
    readTime: '6 min',
    featured: false,
    image: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 5,
    title: 'React vs Vue vs Angular: ¿Cuál elegir en 2025?',
    excerpt: 'Comparativa detallada de los frameworks JavaScript más populares del mercado.',
    content: 'La eterna batalla de los frameworks continúa. Analizamos el estado actual de React 19, las mejoras de Vue 3 y el renacimiento de Angular. Te ayudamos a decidir cuál aprender según tus objetivos profesionales...',
    category: 'Programación',
    author: 'Sofia Rodriguez',
    date: '5 Enero 2025',
    readTime: '8 min',
    featured: false,
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 6,
    title: 'Machine Learning para principiantes: primeros pasos',
    excerpt: 'Introducción práctica al aprendizaje automático sin necesidad de conocimientos previos.',
    content: '¿Te intimida el Machine Learning? No debería. Empezamos con conceptos básicos, explicamos la diferencia entre aprendizaje supervisado y no supervisado, y te mostramos cómo crear tu primer modelo simple con Python...',
    category: 'Inteligencia Artificial',
    author: 'Miguel Sánchez',
    date: '3 Enero 2025',
    readTime: '9 min',
    featured: false,
    image: 'https://images.unsplash.com/photo-1527474305487-b87b222841cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  }
];
