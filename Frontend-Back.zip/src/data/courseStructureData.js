
export const courseStructureData = {
  'course-react-fundamentals': {
    id: 'course-react-fundamentals',
    title: 'React Fundamentals',
    description: 'Aprende los fundamentos de React, desde componentes hasta hooks.',
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
    instructor: 'Sofia García',
    totalLessons: 6,
    totalHours: 2.5,
    modules: [
      {
        id: 'mod-react-1',
        title: 'Introducción a React',
        order: 1,
        lessons: [
          {
            id: 'l-react-1',
            title: '¿Qué es React?',
            order: 1,
            type: 'video',
            duration: 10,
            videoUrl: 'https://example.com/video1.mp4',
            thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
            description: 'Conceptos básicos de la librería y su ecosistema.',
            isCompleted: false
          },
          {
            id: 'l-react-2',
            title: 'Configuración del Entorno',
            order: 2,
            type: 'resource',
            description: 'Guía paso a paso para instalar Node.js y crear tu primer proyecto con Vite.',
            resourceType: 'PDF',
            fileSize: '1.5 MB',
            resourceUrl: '#',
            isCompleted: false
          },
          {
            id: 'l-react-3',
            title: 'Tu primer componente',
            order: 3,
            type: 'video',
            duration: 15,
            videoUrl: 'https://example.com/video2.mp4',
            thumbnail: 'https://images.unsplash.com/photo-1555099962-4199c345e5dd?w=400&h=225&fit=crop',
            description: 'Creando componentes funcionales y entendiendo JSX.',
            isCompleted: false
          }
        ]
      },
      {
        id: 'mod-react-2',
        title: 'Estado y Props',
        order: 2,
        lessons: [
          {
            id: 'l-react-4',
            title: 'Entendiendo Props',
            order: 1,
            type: 'video',
            duration: 12,
            videoUrl: 'https://example.com/video3.mp4',
            thumbnail: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400&h=225&fit=crop',
            description: 'Cómo pasar datos entre componentes padres e hijos.',
            isCompleted: false
          },
          {
            id: 'l-react-5',
            title: 'El Hook useState',
            order: 2,
            type: 'video',
            duration: 18,
            videoUrl: 'https://example.com/video4.mp4',
            thumbnail: 'https://images.unsplash.com/photo-1555099962-4199c345e5dd?w=400&h=225&fit=crop',
            description: 'Manejo de estado local en componentes funcionales.',
            isCompleted: false
          },
          {
            id: 'l-react-6',
            title: 'Ejercicios de Estado',
            order: 3,
            type: 'resource',
            description: 'Serie de ejercicios prácticos para reforzar el aprendizaje de useState.',
            resourceType: 'ZIP',
            fileSize: '3.2 MB',
            resourceUrl: '#',
            isCompleted: false
          }
        ]
      }
    ]
  },
  'course-js-advanced': {
    id: 'course-js-advanced',
    title: 'JavaScript Advanced',
    description: 'Domina los conceptos avanzados de JS: Closures, Event Loop y Async/Await.',
    image: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=400&h=225&fit=crop',
    instructor: 'Carlos Rodriguez',
    totalLessons: 8,
    totalHours: 4,
    modules: [
      {
        id: 'mod-js-1',
        title: 'El Motor de JavaScript',
        order: 1,
        lessons: [
          { id: 'l-js-1', title: 'Call Stack & Memory Heap', order: 1, type: 'video', duration: 20, description: 'Cómo funciona la memoria en JS.', thumbnail: 'https://images.unsplash.com/photo-1550439062-609e1531270e' },
          { id: 'l-js-2', title: 'Event Loop Explicado', order: 2, type: 'video', duration: 25, description: 'La clave de la asincronía en JS.', thumbnail: 'https://images.unsplash.com/photo-1550439062-609e1531270e' }
        ]
      },
      {
        id: 'mod-js-2',
        title: 'Programación Funcional',
        order: 2,
        lessons: [
          { id: 'l-js-3', title: 'Pure Functions', order: 1, type: 'video', duration: 15, description: 'Escribiendo código predecible.', thumbnail: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4' },
          { id: 'l-js-4', title: 'Immutability', order: 2, type: 'resource', description: 'Guía sobre inmutabilidad.', resourceType: 'PDF', fileSize: '1.8 MB' },
          { id: 'l-js-5', title: 'Closures', order: 3, type: 'video', duration: 22, description: 'Entendiendo el alcance léxico.', thumbnail: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4' }
        ]
      },
      {
        id: 'mod-js-3',
        title: 'Asincronía Moderna',
        order: 3,
        lessons: [
          { id: 'l-js-6', title: 'Promises vs Callbacks', order: 1, type: 'video', duration: 20, description: 'Evolución del manejo asíncrono.', thumbnail: 'https://images.unsplash.com/photo-1550439062-609e1531270e' },
          { id: 'l-js-7', title: 'Async / Await', order: 2, type: 'video', duration: 18, description: 'Sintaxis moderna para promesas.', thumbnail: 'https://images.unsplash.com/photo-1550439062-609e1531270e' },
          { id: 'l-js-8', title: 'Proyecto Final Async', order: 3, type: 'resource', description: 'Código base para el proyecto.', resourceType: 'ZIP', fileSize: '5.5 MB' }
        ]
      }
    ]
  },
  'course-web-design': {
    id: 'course-web-design',
    title: 'Web Design Basics',
    description: 'Fundamentos de diseño UI/UX para desarrolladores.',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=400&h=225&fit=crop',
    instructor: 'Ana Martínez',
    totalLessons: 5,
    totalHours: 2,
    modules: [
      {
        id: 'mod-design-1',
        title: 'Fundamentos Visuales',
        order: 1,
        lessons: [
          { id: 'l-des-1', title: 'Teoría del Color', order: 1, type: 'video', duration: 15, description: 'Psicología y armonía del color.', thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8' },
          { id: 'l-des-2', title: 'Tipografía', order: 2, type: 'resource', description: 'Recursos de fuentes y pairings.', resourceType: 'PDF', fileSize: '4.1 MB' }
        ]
      },
      {
        id: 'mod-design-2',
        title: 'Layout y Composición',
        order: 2,
        lessons: [
          { id: 'l-des-3', title: 'Grid Systems', order: 1, type: 'video', duration: 20, description: 'Diseñando con retículas.', thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8' },
          { id: 'l-des-4', title: 'Espaciado y Ritmo', order: 2, type: 'video', duration: 12, description: 'La importancia del espacio en blanco.', thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8' },
          { id: 'l-des-5', title: 'Kit de UI', order: 3, type: 'resource', description: 'Archivo Figma con componentes básicos.', resourceType: 'ZIP', fileSize: '12 MB' }
        ]
      }
    ]
  }
};
