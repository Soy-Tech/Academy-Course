
import { getLessonProgress } from '@/utils/progressUtils';
import { coursesData } from '@/data/coursesData';

// Helper to generate consistent mock structure for any course not explicitly defined
const generateDefaultLessons = (courseId, title) => {
  return {
    id: courseId,
    title: title,
    description: `Contenido completo del curso ${title}.`,
    instructor: 'Instructor Expert',
    totalLessons: 3,
    sections: [
      {
        id: `${courseId}-s1`,
        title: 'Introducción y Fundamentos',
        lessons: [
          {
            id: `${courseId}-l1`,
            courseId: courseId,
            sectionId: `${courseId}-s1`,
            title: 'Bienvenida al Curso',
            description: 'Introducción a los objetivos y metodología del curso. En esta lección veremos una visión general de lo que aprenderemos.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 300,
            order: 1,
            resources: []
          },
          {
            id: `${courseId}-l2`,
            courseId: courseId,
            sectionId: `${courseId}-s1`,
            title: 'Configuración del Entorno',
            description: 'Preparando las herramientas necesarias para el desarrollo. Instalación de software clave.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 450,
            order: 2,
            resources: []
          }
        ]
      },
      {
        id: `${courseId}-s2`,
        title: 'Conceptos Principales',
        lessons: [
          {
            id: `${courseId}-l3`,
            courseId: courseId,
            sectionId: `${courseId}-s2`,
            title: 'Primera Práctica Real',
            description: 'Aplicando lo aprendido en un ejercicio real de código.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 600,
            order: 1,
            resources: [
              { type: 'pdf', title: 'Guía de Ejercicios', url: '#', size: '1.2 MB' }
            ]
          }
        ]
      }
    ]
  };
};

// Explicitly defined content for specific courses (can override default generation)
const specificCourseContent = {
  'full-stack-2025': {
    id: 'full-stack-2025',
    title: 'Full Stack Moderno 2025',
    description: 'Domina el stack MERN con las mejores prácticas de 2025.',
    instructor: 'Carlos Hernández',
    totalLessons: 4,
    sections: [
      {
        id: 'fs-s1',
        title: 'Fundamentos de React y Hooks',
        lessons: [
          {
            id: 'fs-l1',
            courseId: 'full-stack-2025',
            sectionId: 'fs-s1',
            title: 'Introducción al Stack MERN',
            description: 'Visión general de MongoDB, Express, React y Node.js.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 596,
            order: 1,
            resources: [
              { type: 'pdf', title: 'Slides de Introducción', url: '#', size: '2.4 MB' }
            ]
          },
          {
            id: 'fs-l2',
            courseId: 'full-stack-2025',
            sectionId: 'fs-s1',
            title: 'Configurando Vite y React',
            description: 'Creación del proyecto frontend con herramientas modernas.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 850,
            order: 2,
            resources: []
          }
        ]
      },
      {
        id: 'fs-s2',
        title: 'Backend con Node.js',
        lessons: [
          {
            id: 'fs-l3',
            courseId: 'full-stack-2025',
            sectionId: 'fs-s2',
            title: 'Arquitectura de API REST',
            description: 'Diseño de endpoints y estructura de carpetas en Express.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 1200,
            order: 1,
            resources: []
          },
          {
            id: 'fs-l4',
            courseId: 'full-stack-2025',
            sectionId: 'fs-s2',
            title: 'Conexión a MongoDB',
            description: 'Uso de Mongoose para modelar y persistir datos.',
            type: 'video',
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4',
            duration: 980,
            order: 2,
            resources: [
              { type: 'link', title: 'Documentación Mongoose', url: 'https://mongoosejs.com' }
            ]
          }
        ]
      }
    ]
  }
};

// Build the complete mock content object
const buildMockContent = () => {
  const content = { ...specificCourseContent };
  
  // Auto-generate content for courses that don't have specific content defined
  coursesData.forEach(course => {
    if (!content[course.id]) {
      content[course.id] = generateDefaultLessons(course.id, course.title);
    }
  });
  
  return content;
};

export const mockCourseContent = buildMockContent();

// Helper to hydrate lessons with completion status
export const getHydratedCourseData = (courseId) => {
  const course = mockCourseContent[courseId];
  if (!course) return null;

  const sections = course.sections.map(section => ({
    ...section,
    lessons: section.lessons.map(lesson => ({
      ...lesson,
      isCompleted: getLessonProgress(courseId, lesson.id)
    }))
  }));

  return { ...course, sections };
};

export const getLessonById = (courseId, lessonId) => {
  const course = mockCourseContent[courseId];
  if (!course) return null;

  for (const section of course.sections) {
    const lesson = section.lessons.find(l => l.id === lessonId);
    if (lesson) {
      return {
        ...lesson,
        isCompleted: getLessonProgress(courseId, lessonId)
      };
    }
  }
  return null;
};
