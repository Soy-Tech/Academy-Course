
export const mockSettings = {
  platformName: 'Netcom Academy',
  logo: '/logo.png', // Mock path
  description: 'La plataforma líder en educación tecnológica en español.',
  contactEmail: 'contacto@netcom.academy',
  contactPhone: '+34 900 123 456',
  address: 'Calle Tecnológica 123, Madrid, España',
  socialMedia: {
    facebook: 'https://facebook.com/netcom',
    twitter: 'https://twitter.com/netcom',
    instagram: 'https://instagram.com/netcom',
    linkedin: 'https://linkedin.com/company/netcom'
  },
  maintenanceMode: false,
  demoMode: false,
  visibleSections: {
    community: true,
    forums: true,
    events: true,
    resources: true
  },
  theme: {
    primaryColor: '#0B3D91',
    secondaryColor: '#CFAE70'
  }
};
