
export const coursesData = [
  {
    id: 'full-stack-2025',
    title: 'Full Stack Moderno 2025',
    shortDescription: 'Domina React, Node.js y MongoDB para crear apps web desde cero.',
    fullDescription: 'Este curso intensivo te guiará a través del ecosistema Full Stack moderno. Aprenderás a construir aplicaciones web robustas y escalables utilizando la pila MERN (MongoDB, Express, React, Node.js). Desde la configuración inicial del entorno hasta el despliegue en la nube, cada módulo está diseñado para proporcionarte habilidades prácticas y aplicables inmediatamente en la industria.',
    category: 'Programación',
    learningOutcomes: [
      'Desarrollar aplicaciones SPA complejas con React 18 y Vite',
      'Construir APIs RESTful seguras con Node.js y Express',
      'Diseñar y gestionar bases de datos NoSQL con MongoDB',
      'Implementar autenticación y autorización con JWT',
      'Desplegar aplicaciones completas en servicios cloud'
    ],
    targetAudience: [
      'Desarrolladores Frontend que quieren aprender Backend',
      'Estudiantes de informática buscando especialización web',
      'Emprendedores técnicos que quieren construir sus MVPs'
    ],
    prerequisites: [
      'Conocimientos básicos de HTML, CSS y JavaScript',
      'Familiaridad con la línea de comandos',
      'Entendimiento básico de programación asíncrona'
    ],
    modules: [
      'Fundamentos de React y Hooks Modernos',
      'Node.js y Arquitectura de APIs',
      'Base de Datos MongoDB y Mongoose',
      'Autenticación y Seguridad',
      'Integración Frontend-Backend',
      'Despliegue y CI/CD'
    ],
    duration: '120 horas',
    totalHours: 120,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 4,
    level: 'Intermedio',
    instructor: 'Carlos Hernández',
    price: '299€',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee',
    featured: true,
    details: 'Aprende a construir aplicaciones web completas desde cero utilizando React, Node.js, MongoDB y las mejores prácticas de la industria.'
  },
  {
    id: 'react-pro',
    title: 'React Pro+ Hooks y Next.js',
    shortDescription: 'Patrones avanzados de React, Hooks personalizados y SSR con Next.js.',
    fullDescription: 'Eleva tus habilidades de React al siguiente nivel. Este curso avanzado se centra en patrones de diseño, optimización de rendimiento y el framework Next.js. Aprenderás a escribir código React limpio, mantenible y eficiente, y a aprovechar las últimas características de Next.js para renderizado del lado del servidor y generación de sitios estáticos.',
    category: 'Programación',
    learningOutcomes: [
      'Dominar patrones de diseño avanzados en React (HOCs, Render Props)',
      'Crear y publicar Hooks personalizados reutilizables',
      'Implementar Server Side Rendering (SSR) y SSG con Next.js',
      'Gestionar estado global complejo con Context y Redux Toolkit',
      'Optimizar el rendimiento de aplicaciones grandes'
    ],
    targetAudience: [
      'Desarrolladores React con 1-2 años de experiencia',
      'Ingenieros de Software buscando modernizar su stack',
      'Tech Leads que quieren estandarizar prácticas de equipo'
    ],
    prerequisites: [
      'Experiencia sólida trabajando con React básico',
      'Conocimiento de JavaScript moderno (ES6+)',
      'Experiencia consumiendo APIs REST'
    ],
    modules: [
      'Patrones de Diseño Avanzados',
      'Gestión de Estado a Gran Escala',
      'Next.js: App Router y Server Components',
      'Testing Avanzado en React',
      'Performance y Optimización'
    ],
    duration: '80 horas',
    totalHours: 80,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 3,
    level: 'Avanzado',
    instructor: 'Elena Rodríguez',
    price: '249€',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159',
    featured: true,
    details: 'Profundiza en React con Hooks, Context API, optimización de rendimiento y desarrollo de aplicaciones con Next.js.'
  },
  {
    id: 'typescript-total',
    title: 'TypeScript Total',
    shortDescription: 'Aprende tipado estático robusto para escalar tus proyectos JavaScript.',
    fullDescription: 'TypeScript se ha convertido en el estándar de la industria para el desarrollo web a gran escala. Este curso te enseña a migrar proyectos de JS a TS y a utilizar características avanzadas del sistema de tipos para prevenir errores antes de que ocurran.',
    category: 'Programación',
    learningOutcomes: [
      'Configurar entornos de desarrollo TypeScript profesionales',
      'Dominar Interfaces, Tipos y Generics',
      'Integrar TypeScript en proyectos React y Node.js',
      'Utilizar Utility Types y Mapped Types avanzados'
    ],
    targetAudience: [
      'Desarrolladores JavaScript que quieren escribir código más seguro',
      'Equipos que migran bases de código legacy',
      'Backend developers acostumbrados a lenguajes tipados'
    ],
    prerequisites: [
      'Conocimiento intermedio de JavaScript',
      'Familiaridad con editores como VS Code'
    ],
    modules: [
      'Fundamentos y Tipos Básicos',
      'Interfaces y Clases',
      'Generics y Manipulación de Tipos',
      'TypeScript en React',
      'Configuración de Compilador y Linting'
    ],
    duration: '60 horas',
    totalHours: 60,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 2,
    level: 'Intermedio',
    instructor: 'Carlos Hernández',
    price: '199€',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea',
    featured: false,
    details: 'Domina TypeScript para escribir código JavaScript más seguro y mantenible en proyectos de cualquier escala.'
  },
  {
    id: 'backend-node',
    title: 'Backend Node y Express',
    shortDescription: 'Crea APIs REST escalables y seguras utilizando Node.js y Express.',
    fullDescription: 'Conviértete en un especialista en Backend. Aprende a diseñar, construir y asegurar APIs RESTful que puedan manejar miles de solicitudes. Exploraremos la arquitectura de software, bases de datos relacionales y no relacionales, y prácticas de seguridad esenciales.',
    category: 'Programación',
    learningOutcomes: [
      'Diseñar arquitecturas de API REST escalables',
      'Implementar autenticación JWT y OAuth2',
      'Manejar streams, buffers y sistema de archivos',
      'Integrar bases de datos SQL (PostgreSQL) y NoSQL'
    ],
    targetAudience: [
      'Frontend developers que quieren ser Full Stack',
      'Backend developers que vienen de otros lenguajes (PHP, Java)',
      'Arquitectos de software junior'
    ],
    prerequisites: [
      'JavaScript sólido (ES6+)',
      'Conceptos básicos de HTTP y redes'
    ],
    modules: [
      'Runtime de Node.js y Event Loop',
      'Express Framework Avanzado',
      'Bases de Datos y ORMs',
      'Seguridad y Autenticación',
      'Testing y Documentación de APIs'
    ],
    duration: '90 horas',
    totalHours: 90,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 3,
    level: 'Avanzado',
    instructor: 'David Kim',
    price: '279€',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479',
    featured: false,
    details: 'Construye backends profesionales con Node.js, Express, autenticación JWT, bases de datos y arquitectura escalable.'
  },
  {
    id: 'microservicios',
    title: 'Arquitectura Microservicios',
    shortDescription: 'Diseña sistemas distribuidos escalables con Docker y Kubernetes.',
    fullDescription: 'Aprende a descomponer monolitos en microservicios independientes. Este curso cubre contenedores con Docker, orquestación con Kubernetes y patrones de comunicación entre servicios.',
    category: 'Programación',
    learningOutcomes: [
      'Dockerizar aplicaciones Node.js y Python',
      'Desplegar clústeres de Kubernetes',
      'Implementar Service Mesh y API Gateways',
      'Gestionar datos distribuidos y consistencia eventual'
    ],
    targetAudience: [
      'Arquitectos de Software',
      'DevOps Engineers',
      'Backend Developers Senior'
    ],
    prerequisites: [
      'Experiencia en desarrollo Backend',
      'Conocimientos básicos de Linux y terminal'
    ],
    modules: [
      'Fundamentos de Docker',
      'Arquitectura de Microservicios',
      'Kubernetes para Desarrolladores',
      'Patrones de Comunicación (gRPC, RabbitMQ)',
      'Observabilidad y Monitoreo'
    ],
    duration: '100 horas',
    totalHours: 100,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 2,
    level: 'Avanzado',
    instructor: 'David Kim',
    price: '349€',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa',
    featured: false,
    details: 'Aprende a diseñar, implementar y desplegar aplicaciones basadas en microservicios con Docker y Kubernetes.'
  },
  {
    id: 'python-automation',
    title: 'Automatización con Python',
    shortDescription: 'Crea scripts y APIs rápidas para automatizar tareas con Python.',
    fullDescription: 'Python es el lenguaje líder para automatización. Aprende a crear scripts que hagan el trabajo aburrido por ti, desde manipulación de archivos Excel hasta web scraping y bots.',
    category: 'Programación',
    learningOutcomes: [
      'Automatizar tareas de sistema de archivos y Excel',
      'Realizar Web Scraping de datos complejos',
      'Construir bots para Telegram y Discord',
      'Crear APIs rápidas con FastAPI'
    ],
    targetAudience: [
      'Profesionales que quieren automatizar tareas repetitivas',
      'Analistas de datos',
      'Administradores de sistemas'
    ],
    prerequisites: [
      'Ninguno, se enseña Python desde cero',
      'Lógica de programación básica ayuda'
    ],
    modules: [
      'Python Básico e Intermedio',
      'Automatización de Archivos y Datos',
      'Web Scraping con BeautifulSoup y Selenium',
      'APIs con FastAPI',
      'Automatización de Navegador'
    ],
    duration: '70 horas',
    totalHours: 70,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 5,
    level: 'Intermedio',
    instructor: 'Roberto Sanchez',
    price: '229€',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5',
    featured: true,
    details: 'Domina Python para automatización de procesos y desarrollo de APIs rápidas con FastAPI.'
  },
  {
    id: 'ia-aplicada',
    title: 'Fundamentos de IA Aplicada',
    shortDescription: 'Introducción práctica a la Inteligencia Artificial con Python.',
    fullDescription: 'Entra en el mundo de la IA sin necesidad de un doctorado en matemáticas. Este curso práctico te enseña a utilizar librerías de Python para crear modelos de IA que resuelven problemas reales.',
    category: 'IA y Datos',
    learningOutcomes: [
      'Comprender los conceptos clave de IA y ML',
      'Utilizar librerías como Scikit-learn y TensorFlow',
      'Entrenar modelos de clasificación y regresión',
      'Evaluar el rendimiento de modelos predictivos'
    ],
    targetAudience: [
      'Desarrolladores curiosos por la IA',
      'Estudiantes de ciencias e ingeniería',
      'Analistas de negocio'
    ],
    prerequisites: [
      'Python básico',
      'Matemáticas de nivel bachillerato'
    ],
    modules: [
      'Introducción a la IA',
      'Preprocesamiento de Datos',
      'Algoritmos de Machine Learning Clásicos',
      'Introducción a Redes Neuronales',
      'Proyectos Prácticos de IA'
    ],
    duration: '80 horas',
    totalHours: 80,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 3,
    level: 'Principiante',
    instructor: 'Sofia Martinez',
    price: '249€',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1555255707-c07966088b7b',
    featured: true,
    details: 'Descubre los fundamentos de la IA y aprende a aplicarlos en proyectos reales con Python.'
  },
  {
    id: 'ciberseguridad-101',
    title: 'Ciberseguridad 101',
    shortDescription: 'Fundamentos esenciales de seguridad digital para todos.',
    fullDescription: 'La seguridad es responsabilidad de todos. Aprende a identificar amenazas, proteger tus dispositivos y entender cómo piensan los atacantes para defenderte mejor en el mundo digital.',
    category: 'Ciberseguridad',
    learningOutcomes: [
      'Identificar phishing y ataques de ingeniería social',
      'Asegurar redes domésticas y dispositivos personales',
      'Gestionar contraseñas y autenticación multifactor',
      'Entender los fundamentos de criptografía básica'
    ],
    targetAudience: [
      'Cualquier persona interesada en seguridad digital',
      'Personal administrativo',
      'Estudiantes de TI'
    ],
    prerequisites: [
      'Uso básico de computadoras e internet'
    ],
    modules: [
      'Panorama de Amenazas Actuales',
      'Seguridad en Dispositivos y S.O.',
      'Seguridad en Redes y Wifi',
      'Privacidad y Navegación Segura',
      'Respuesta ante Incidentes Básica'
    ],
    duration: '60 horas',
    totalHours: 60,
    hasCertificate: true,
    hasProjects: false,
    projectCount: 0,
    level: 'Principiante',
    instructor: 'Marcos Security',
    price: '199€',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1563206767-5b1d972d9fb4',
    featured: false,
    details: 'Aprende los conceptos básicos de seguridad informática, amenazas comunes y cómo proteger sistemas.'
  },
  {
    id: 'power-bi',
    title: 'Power BI Profesional',
    shortDescription: 'Business Intelligence y Dashboards de alto impacto.',
    fullDescription: 'Domina la herramienta líder en Business Intelligence. Aprende a conectar fuentes de datos, modelar información y crear visualizaciones impactantes que ayuden a la toma de decisiones empresariales.',
    category: 'Productividad',
    learningOutcomes: [
      'Importar y transformar datos con Power Query',
      'Modelar datos y relaciones complejas',
      'Utilizar DAX para cálculos avanzados',
      'Diseñar dashboards interactivos y storytelling'
    ],
    targetAudience: [
      'Analistas de Negocio',
      'Contadores y Financieros',
      'Gerentes que necesitan reportes visuales'
    ],
    prerequisites: [
      'Conocimientos intermedios de Excel',
      'Entendimiento básico de bases de datos ayuda'
    ],
    modules: [
      'Introducción a Power BI y Conexión de Datos',
      'Transformación de Datos (ETL)',
      'Modelado de Datos y Relaciones',
      'Lenguaje DAX: Medidas y Columnas',
      'Visualización y Publicación de Reportes'
    ],
    duration: '60 horas',
    totalHours: 60,
    hasCertificate: true,
    hasProjects: true,
    projectCount: 3,
    level: 'Intermedio',
    instructor: 'Ana Productivity',
    price: '199€',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
    featured: true,
    details: 'Domina Power BI para crear visualizaciones de datos impactantes y tomar decisiones basadas en datos.'
  }
];

export const categories = [
  {
    id: 'programacion',
    name: 'Programación',
    description: 'Aprende a desarrollar aplicaciones web y móviles con las tecnologías más demandadas.',
    icon: 'Code'
  },
  {
    id: 'ia-datos',
    name: 'Inteligencia Artificial y Datos',
    description: 'Domina el análisis de datos, machine learning y la IA aplicada.',
    icon: 'Brain'
  },
  {
    id: 'ciberseguridad',
    name: 'Ciberseguridad y Redes',
    description: 'Protege sistemas y gestiona redes empresariales de forma profesional.',
    icon: 'Shield'
  },
  {
    id: 'productividad',
    name: 'Productividad Digital',
    description: 'Optimiza tu trabajo con herramientas digitales y automatización.',
    icon: 'Zap'
  }
];
