
export const mockLearningPaths = [
  {
    id: 1,
    name: 'Backend Development',
    description: 'Domina el desarrollo backend con Node.js, Python y arquitecturas escalables. Aprende a construir APIs robustas, gestionar bases de datos y desplegar aplicaciones.',
    level: 'Intermedio',
    duration: '120 horas',
    course_count: 8,
    progress: 50,
    icon: 'Server',
    courses: [
      { id: 'backend-1', title: 'Introducción a Node.js', description: 'Fundamentos de Node.js y JavaScript en el servidor.', duration: '15h', lessons: 12 },
      { id: 'backend-2', title: 'Express.js Avanzado', description: 'Creación de APIs RESTful con Express y middleware.', duration: '20h', lessons: 18 },
      { id: 'backend-3', title: 'Bases de Datos SQL', description: 'Diseño y gestión de bases de datos relacionales con PostgreSQL.', duration: '25h', lessons: 22 },
      { id: 'backend-4', title: 'Arquitectura de Microservicios', description: 'Patrones de diseño para sistemas distribuidos y escalables.', duration: '30h', lessons: 25 },
      { id: 'backend-5', title: 'Seguridad en APIs', description: 'Autenticación, autorización y protección contra ataques comunes.', duration: '15h', lessons: 14 },
      { id: 'backend-6', title: 'Despliegue y CI/CD', description: 'Pipelines de integración continua y despliegue en la nube.', duration: '15h', lessons: 10 }
    ]
  },
  {
    id: 2,
    name: 'Data Science & AI',
    description: 'Aprende ciencia de datos, machine learning e inteligencia artificial. Desde el análisis de datos hasta la implementación de modelos predictivos avanzados.',
    level: 'Avanzado',
    duration: '150 horas',
    course_count: 10,
    progress: 10,
    icon: 'Brain',
    courses: [
      { id: 'data-1', title: 'Python para Data Science', description: 'Librerías fundamentales: NumPy, Pandas y Jupyter.', duration: '20h', lessons: 15 },
      { id: 'data-2', title: 'Visualización de Datos', description: 'Creación de gráficos impactantes con Matplotlib y Seaborn.', duration: '15h', lessons: 10 },
      { id: 'data-3', title: 'Estadística Aplicada', description: 'Conceptos estadísticos clave para el análisis de datos.', duration: '20h', lessons: 18 },
      { id: 'data-4', title: 'Machine Learning Básico', description: 'Algoritmos supervisados y no supervisados.', duration: '35h', lessons: 28 },
      { id: 'data-5', title: 'Deep Learning con TensorFlow', description: 'Redes neuronales y aprendizaje profundo.', duration: '40h', lessons: 32 },
      { id: 'data-6', title: 'Procesamiento de Lenguaje Natural', description: 'Análisis de texto y modelos de lenguaje (NLP).', duration: '20h', lessons: 16 }
    ]
  },
  {
    id: 3,
    name: 'Cloud Computing',
    description: 'Conviértete en experto en AWS, Azure y arquitecturas cloud. Despliega aplicaciones escalables y seguras utilizando las mejores prácticas de la industria.',
    level: 'Intermedio',
    duration: '90 horas',
    course_count: 6,
    progress: 0,
    icon: 'Cloud',
    courses: [
      { id: 'cloud-1', title: 'Fundamentos de Cloud', description: 'Conceptos básicos de la computación en la nube.', duration: '10h', lessons: 8 },
      { id: 'cloud-2', title: 'AWS Essentials', description: 'Servicios principales de Amazon Web Services (EC2, S3, RDS).', duration: '25h', lessons: 20 },
      { id: 'cloud-3', title: 'Docker y Contenedores', description: 'Empaquetado y despliegue de aplicaciones con Docker.', duration: '20h', lessons: 16 },
      { id: 'cloud-4', title: 'Kubernetes', description: 'Orquestación de contenedores a escala en producción.', duration: '35h', lessons: 30 }
    ]
  },
  {
    id: 4,
    name: 'Frontend Development',
    description: 'Crea interfaces modernas con React, Vue y las últimas tecnologías frontend. Domina el diseño responsive y la experiencia de usuario.',
    level: 'Principiante',
    duration: '100 horas',
    course_count: 12,
    progress: 100,
    icon: 'Code',
    courses: [
      { id: 'front-1', title: 'HTML5 y CSS3 Moderno', description: 'Estructura semántica y estilos avanzados para la web actual.', duration: '20h', lessons: 18 },
      { id: 'front-2', title: 'JavaScript ES6+', description: 'Programación moderna, asincronía y manipulación del DOM.', duration: '25h', lessons: 24 },
      { id: 'front-3', title: 'React desde Cero', description: 'Construcción de interfaces interactivas con componentes.', duration: '30h', lessons: 28 },
      { id: 'front-4', title: 'Tailwind CSS', description: 'Estilizado rápido y eficiente con clases de utilidad.', duration: '15h', lessons: 12 },
      { id: 'front-5', title: 'Gestión de Estado', description: 'Redux, Context API y gestión de estado global.', duration: '10h', lessons: 10 }
    ]
  }
];
