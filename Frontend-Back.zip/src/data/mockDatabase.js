
import { ROLES } from '@/utils/rolePermissions';

// Keys for localStorage
const DB_KEYS = {
  USERS: 'db_users',
  APPLICATIONS: 'db_applications',
  PURCHASES: 'db_purchases',
  PROGRESS: 'db_progress',
  CERTIFICATES: 'db_certificates',
  ADMIN_PERMISSIONS: 'db_admin_permissions',
  AUDIT_LOG: 'db_audit_log'
};

// Initial Data
const initialUsers = [
  {
    id: 'u1',
    email: 'admin@netcom.com',
    password: 'password',
    name: 'Admin User',
    role: ROLES.ADMIN,
    userType: 'internal',
    status: 'active',
    avatar: 'AD',
    bio: 'System Administrator',
    createdAt: new Date().toISOString()
  },
  {
    id: 'u2',
    email: 'student@netcom.com',
    password: 'password',
    name: 'Student User',
    role: ROLES.STUDENT,
    userType: 'public',
    status: 'active',
    avatar: 'ST',
    bio: 'Learning new things',
    createdAt: new Date().toISOString()
  },
  {
    id: 'u3',
    email: 'instructor@netcom.com',
    password: 'password',
    name: 'Instructor User',
    role: ROLES.INSTRUCTOR,
    userType: 'invited',
    status: 'active',
    avatar: 'IN',
    bio: 'Expert Instructor',
    createdAt: new Date().toISOString()
  },
  {
    id: 'u4',
    email: 'super@netcom.com',
    password: 'password',
    name: 'Super Admin',
    role: ROLES.SUPER_ADMIN,
    userType: 'internal',
    status: 'active',
    avatar: 'SA',
    bio: 'Platform Owner',
    createdAt: new Date().toISOString()
  }
];

// Helper to get data
const getData = (key, defaultData = []) => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultData;
  } catch (e) {
    console.error(`Error reading ${key}`, e);
    return defaultData;
  }
};

// Helper to save data
const saveData = (key, data) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error saving ${key}`, e);
  }
};

// Initialize DB if empty
if (!localStorage.getItem(DB_KEYS.USERS)) {
  saveData(DB_KEYS.USERS, initialUsers);
}

// --- CRUD Operations ---

export const mockDb = {
  users: {
    getAll: () => getData(DB_KEYS.USERS),
    getById: (id) => getData(DB_KEYS.USERS).find(u => u.id === id),
    getByEmail: (email) => getData(DB_KEYS.USERS).find(u => u.email === email),
    create: (user) => {
      const users = getData(DB_KEYS.USERS);
      const newUser = { 
        ...user, 
        id: `u${Date.now()}`, 
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      users.push(newUser);
      saveData(DB_KEYS.USERS, users);
      return newUser;
    },
    update: (id, updates) => {
      const users = getData(DB_KEYS.USERS);
      const index = users.findIndex(u => u.id === id);
      if (index !== -1) {
        users[index] = { ...users[index], ...updates, updatedAt: new Date().toISOString() };
        saveData(DB_KEYS.USERS, users);
        return users[index];
      }
      return null;
    },
    delete: (id) => {
      const users = getData(DB_KEYS.USERS).filter(u => u.id !== id);
      saveData(DB_KEYS.USERS, users);
    }
  },
  applications: {
    getAll: () => getData(DB_KEYS.APPLICATIONS),
    create: (app) => {
      const apps = getData(DB_KEYS.APPLICATIONS);
      const newApp = { ...app, id: `app${Date.now()}`, createdAt: new Date().toISOString(), status: 'pending' };
      apps.push(newApp);
      saveData(DB_KEYS.APPLICATIONS, apps);
      return newApp;
    }
  },
  // Add other collections as needed for future tasks
  auditLog: {
    log: (action, userId, details) => {
      const logs = getData(DB_KEYS.AUDIT_LOG);
      logs.push({
        id: `log${Date.now()}`,
        action,
        userId,
        details,
        timestamp: new Date().toISOString()
      });
      saveData(DB_KEYS.AUDIT_LOG, logs);
    }
  }
};
