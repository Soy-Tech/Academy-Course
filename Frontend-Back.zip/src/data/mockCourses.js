
export const mockCourses = [
  {
    id: 1,
    title: 'Desarrollo Web Full Stack con React y Node.js',
    description: 'Aprende a construir aplicaciones web modernas desde cero.',
    instructor: 'Sarah Instructor',
    status: 'active',
    studentCount: 156,
    category: 'Desarrollo',
    price: 99.99
  },
  {
    id: 2,
    title: 'Introducción a Python para Data Science',
    description: 'Domina los fundamentos de Python y el análisis de datos.',
    instructor: 'Jane Smith',
    status: 'active',
    studentCount: 89,
    category: 'Data Science',
    price: 79.99
  },
  {
    id: 3,
    title: 'Diseño UX/UI Avanzado',
    description: 'Crea interfaces de usuario intuitivas y atractivas.',
    instructor: 'Jessica Brown',
    status: 'draft',
    studentCount: 0,
    category: 'Diseño',
    price: 69.99
  },
  {
    id: 4,
    title: 'AWS Cloud Practitioner Essentials',
    description: 'Prepárate para la certificación de AWS.',
    instructor: 'David Miller',
    status: 'active',
    studentCount: 210,
    category: 'Cloud',
    price: 119.99
  },
  {
    id: 5,
    title: 'Docker y Kubernetes para DevOps',
    description: 'Domina la contenedorización y orquestación.',
    instructor: 'David Miller',
    status: 'inactive',
    studentCount: 45,
    category: 'DevOps',
    price: 89.99
  },
  {
    id: 6,
    title: 'Marketing Digital 360',
    description: 'Estrategias completas para el crecimiento online.',
    instructor: 'Sarah Instructor',
    status: 'active',
    studentCount: 320,
    category: 'Marketing',
    price: 49.99
  },
  {
    id: 7,
    title: 'Gestión Ágil de Proyectos con Scrum',
    description: 'Aprende las metodologías ágiles más demandadas.',
    instructor: 'Jessica Brown',
    status: 'active',
    studentCount: 112,
    category: 'Negocios',
    price: 59.99
  },
  {
    id: 8,
    title: 'Ciberseguridad: Hacking Ético',
    description: 'Protege sistemas y redes contra amenazas.',
    instructor: 'David Miller',
    status: 'draft',
    studentCount: 0,
    category: 'Seguridad',
    price: 129.99
  },
  {
    id: 9,
    title: 'Flutter: Desarrollo de Apps Móviles',
    description: 'Crea apps para iOS y Android con una sola base de código.',
    instructor: 'Jane Smith',
    status: 'active',
    studentCount: 78,
    category: 'Móvil',
    price: 89.99
  },
  {
    id: 10,
    title: 'Inteligencia Artificial con TensorFlow',
    description: 'Implementa modelos de Deep Learning.',
    instructor: 'Jane Smith',
    status: 'inactive',
    studentCount: 34,
    category: 'IA',
    price: 149.99
  }
];
