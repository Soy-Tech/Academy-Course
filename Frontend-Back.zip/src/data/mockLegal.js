
export const mockLegal = {
  terms: {
    title: 'Términos y Condiciones',
    sections: [
      { heading: 'Uso del Servicio', content: 'Al acceder a Netcom Academy, aceptas cumplir con estos términos de servicio, todas las leyes y regulaciones aplicables...' },
      { heading: 'Propiedad Intelectual', content: 'Todo el contenido incluido en este sitio, como texto, gráficos, logotipos, imágenes y software, es propiedad de Netcom Academy...' },
      { heading: 'Licencia de Uso', content: 'Se concede permiso para descargar temporalmente una copia de los materiales para visualización transitoria personal y no comercial...' }
    ]
  },
  privacy: {
    title: 'Política de Privacidad',
    sections: [
      { heading: 'Recopilación de Datos', content: 'Recopilamos información personal que nos proporcionas voluntariamente al registrarte, comprar un curso o contactarnos...' },
      { heading: 'Uso de la Información', content: 'Usamos la información que recopilamos para operar, mantener y proporcionar las características y funcionalidad del servicio...' },
      { heading: 'Cookies', content: 'Utilizamos cookies y tecnologías similares para rastrear la actividad en nuestro servicio y mantener cierta información...' }
    ]
  }
};
