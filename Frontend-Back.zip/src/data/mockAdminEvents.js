
export const mockAdminEvents = [
  {
    id: 1,
    nombre: 'Workshop de React 19',
    descripcion: 'Taller práctico sobre las nuevas características de React 19.',
    fecha: '2026-05-15',
    hora: '18:00',
    ubicacion: 'Online (Zoom)',
    instructor: 'Carlos Hernández',
    asistentes: 150,
    estado: 'scheduled'
  },
  {
    id: 2,
    nombre: 'Webinar: IA en el Desarrollo',
    descripcion: 'Cómo integrar herramientas de IA en tu flujo de trabajo diario.',
    fecha: '2026-04-20',
    hora: '17:00',
    ubicacion: 'Online (Youtube Live)',
    instructor: 'David Kim',
    asistentes: 300,
    estado: 'completed'
  },
  {
    id: 3,
    nombre: 'Hackathon Netcom 2026',
    descripcion: 'Competencia de 48 horas para construir soluciones innovadoras.',
    fecha: '2026-06-10',
    hora: '09:00',
    ubicacion: 'Madrid, Campus Netcom',
    instructor: 'Admin User',
    asistentes: 50,
    estado: 'scheduled'
  },
  {
    id: 4,
    nombre: 'Q&A con Expertos en UX',
    descripcion: 'Sesión de preguntas y respuestas con diseñadores senior.',
    fecha: '2026-05-01',
    hora: '19:00',
    ubicacion: 'Online (Discord)',
    instructor: 'Laura Martínez',
    asistentes: 80,
    estado: 'cancelled'
  },
  {
    id: 5,
    nombre: 'Masterclass de Seguridad',
    descripcion: 'Aprende a asegurar tus aplicaciones web contra vulnerabilidades comunes.',
    fecha: '2026-05-25',
    hora: '16:00',
    ubicacion: 'Online (Zoom)',
    instructor: 'Robert Taylor',
    asistentes: 120,
    estado: 'scheduled'
  },
  {
    id: 6,
    nombre: 'Python para Data Science - Inicio',
    descripcion: 'Clase inaugural del bootcamp de Data Science.',
    fecha: '2026-02-01',
    hora: '10:00',
    ubicacion: 'Barcelona, Hub Tech',
    instructor: 'Michael Chen',
    asistentes: 25,
    estado: 'ongoing'
  },
  {
    id: 7,
    nombre: 'DevOps Night',
    descripcion: 'Networking y charlas sobre cultura DevOps.',
    fecha: '2026-03-15',
    hora: '20:00',
    ubicacion: 'Online (Meet)',
    instructor: 'James Wilson',
    asistentes: 95,
    estado: 'completed'
  },
  {
    id: 8,
    nombre: 'Lanzamiento Nuevos Cursos',
    descripcion: 'Presentación de la nueva ruta de aprendizaje de Cloud Computing.',
    fecha: '2026-07-01',
    hora: '11:00',
    ubicacion: 'Online (Youtube)',
    instructor: 'Admin User',
    asistentes: 500,
    estado: 'scheduled'
  },
  {
    id: 9,
    nombre: 'Tech Career Fair',
    descripcion: 'Feria de empleo virtual para desarrolladores junior.',
    fecha: '2026-08-10',
    hora: '10:00',
    ubicacion: 'Virtual Venue',
    instructor: 'Admin User',
    asistentes: 1200,
    estado: 'scheduled'
  },
  {
    id: 10,
    nombre: 'Rust Programming Basics',
    descripcion: 'Introducción al lenguaje Rust para desarrolladores de sistemas.',
    fecha: '2026-06-20',
    hora: '18:30',
    ubicacion: 'Online (Zoom)',
    instructor: 'David Kim',
    asistentes: 60,
    estado: 'scheduled'
  }
];
