
export const mockCommunityPosts = [
  {
    id: 1,
    title: '¿Cuáles son las mejores prácticas para React Hooks?',
    content: 'Estoy aprendiendo React y me gustaría conocer las mejores prácticas para usar useEffect y useState correctamente. ¿Alguien tiene recursos o consejos?',
    category: 'Programación',
    created_at: '2025-10-15T10:30:00Z',
    likes_count: 24,
    comments_count: 3,
    users: {
      name: 'Laura Mateo',
      profile_photo_url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      specialty: 'Frontend Dev'
    },
    comments: [
      {
        id: 101,
        author: 'Carlos Ruiz',
        content: 'Siempre define tus dependencias correctamente en el array de dependencias.',
        created_at: '2025-10-15T11:00:00Z',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
      }
    ]
  },
  {
    id: 2,
    title: 'Nueva librería de IA lanzada hoy',
    content: 'Acabo de ver que OpenAI lanzó una nueva API. ¿Alguien la ha probado ya para proyectos de NLP?',
    category: 'IA y Datos',
    created_at: '2025-10-14T15:45:00Z',
    likes_count: 56,
    comments_count: 12,
    users: {
      name: 'David Chen',
      profile_photo_url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      specialty: 'Data Scientist'
    },
    comments: []
  },
  {
    id: 3,
    title: 'Tips para mejorar la productividad en VS Code',
    content: 'Comparto mis atajos de teclado favoritos para Visual Studio Code. Ctrl+P para archivos, Ctrl+Shift+F para buscar en todo el proyecto.',
    category: 'Productividad',
    created_at: '2025-10-13T09:20:00Z',
    likes_count: 89,
    comments_count: 5,
    users: {
      name: 'Ana García',
      profile_photo_url: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      specialty: 'Full Stack'
    },
    comments: []
  }
];
