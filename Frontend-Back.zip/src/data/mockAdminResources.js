
export const mockAdminResources = [
  {
    id: 1,
    nombre: 'Guía de Instalación React',
    tipo: 'pdf',
    tamaño: '2.5 MB',
    fechaSubida: '2024-01-15',
    instructor: 'Carlos Hernández',
    estado: 'published',
    descripcion: 'Pasos detallados para configurar un entorno de desarrollo React desde cero.'
  },
  {
    id: 2,
    nombre: 'Intro a Docker - Video',
    tipo: 'video',
    tamaño: '150 MB',
    fechaSubida: '2024-02-10',
    instructor: 'James Wilson',
    estado: 'published',
    descripcion: 'Video introductorio sobre los conceptos básicos de contenedores y Docker.'
  },
  {
    id: 3,
    nombre: 'Plantilla de Diseño UI',
    tipo: 'documento',
    tamaño: '15 MB',
    fechaSubida: '2024-03-05',
    instructor: 'Laura Martínez',
    estado: 'draft',
    descripcion: 'Archivo fuente de Figma con componentes básicos de UI.'
  },
  {
    id: 4,
    nombre: 'Cheatsheet Python',
    tipo: 'pdf',
    tamaño: '1.2 MB',
    fechaSubida: '2024-01-20',
    instructor: 'Michael Chen',
    estado: 'published',
    descripcion: 'Hoja de trucos rápida con la sintaxis y funciones más comunes de Python.'
  },
  {
    id: 5,
    nombre: 'Arquitectura Hexagonal',
    tipo: 'pdf',
    tamaño: '3.8 MB',
    fechaSubida: '2024-04-12',
    instructor: 'David Kim',
    estado: 'draft',
    descripcion: 'Documento explicativo sobre patrones de arquitectura hexagonal.'
  },
  {
    id: 6,
    nombre: 'Ethical Hacking Tools',
    tipo: 'documento',
    tamaño: '45 KB',
    fechaSubida: '2024-05-01',
    instructor: 'Robert Taylor',
    estado: 'published',
    descripcion: 'Lista de herramientas recomendadas para pruebas de penetración.'
  },
  {
    id: 7,
    nombre: 'Marketing Plan Template',
    tipo: 'documento',
    tamaño: '500 KB',
    fechaSubida: '2024-02-28',
    instructor: 'Emily Davis',
    estado: 'published',
    descripcion: 'Plantilla editable para crear planes de marketing digital.'
  },
  {
    id: 8,
    nombre: 'Next.js SSR vs CSR',
    tipo: 'video',
    tamaño: '200 MB',
    fechaSubida: '2024-03-15',
    instructor: 'Elena Rodríguez',
    estado: 'draft',
    descripcion: 'Comparativa en video sobre renderizado del lado del servidor vs cliente.'
  },
  {
    id: 9,
    nombre: 'Advanced Kubernetes patterns',
    tipo: 'pdf',
    tamaño: '5.1 MB',
    fechaSubida: '2024-06-10',
    instructor: 'James Wilson',
    estado: 'published',
    descripcion: 'Patrones avanzados para orquestación de contenedores.'
  },
  {
    id: 10,
    nombre: 'UI Animation Guide',
    tipo: 'video',
    tamaño: '320 MB',
    fechaSubida: '2024-07-01',
    instructor: 'Laura Martínez',
    estado: 'draft',
    descripcion: 'Tutorial sobre cómo animar interfaces de usuario.'
  }
];
