
export const mockHelpGuides = [
  {
    id: 'h1',
    title: 'Cómo empezar tu primer curso',
    description: 'Guía paso a paso para navegar la plataforma y comenzar a aprender.',
    category: 'Plataforma',
    content: 'Bienvenido a Netcom Academy. Para empezar tu primer curso, dirígete a "Mis Cursos" en el menú...'
  },
  {
    id: 'h2',
    title: 'Configuración de entorno de desarrollo',
    description: 'Instala Node.js, VS Code y Git en tu máquina local.',
    category: 'Técnico',
    content: 'Antes de empezar a programar, necesitas las herramientas adecuadas. Sigue estos pasos para instalar VS Code...'
  },
  {
    id: 'h3',
    title: 'Solución de problemas de reproducción de video',
    description: 'Qué hacer si los videos no cargan o se cortan.',
    category: 'Soporte Técnico',
    content: 'Si experimentas problemas con el reproductor, intenta limpiar la caché de tu navegador o probar en modo incógnito...'
  },
  {
    id: 'h4',
    title: 'Cómo obtener tu certificado',
    description: 'Pasos para descargar y compartir tu certificado de finalización.',
    category: 'Certificaciones',
    content: 'Una vez completado el 100% de las lecciones, aparecerá un botón de "Descargar Certificado" en el dashboard del curso...'
  }
];
