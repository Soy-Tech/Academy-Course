
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, AlertTriangle, Clock, ChevronRight, Save, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

// Components
import InstructorFormSection from '@/components/InstructorFormSection';
import InstructorFormField from '@/components/InstructorFormField';
import InstructorFileUpload from '@/components/InstructorFileUpload';
import InstructorSelectField from '@/components/InstructorSelectField';
import InstructorCheckboxGroup from '@/components/InstructorCheckboxGroup';
import InstructorProgressBar from '@/components/InstructorProgressBar';

// Validation
import * as Validators from '@/utils/instructorValidation';

const InstructorApplicationPage = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [submissionId, setSubmissionId] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    personal: {
      fullName: currentUser?.name || '',
      email: currentUser?.email || '',
      phone: '',
      country: '',
      bio: '',
      photo: null
    },
    professional: {
      years: '',
      specialty: '',
      company: '',
      position: '',
      portfolio: '',
      certifications: null,
      description: ''
    },
    teaching: {
      hasTaught: 'no', // yes/no
      whereWhen: '',
      students: '',
      methodology: '',
      achievements: ''
    },
    course: {
      topic: '',
      description: '',
      level: '',
      duration: '',
      target: '',
      resources: {}, // {videos: true, pdfs: false...}
      differentiator: ''
    },
    commitment: {
      weekly: '',
      response: '',
      policies: {} // {pol1: true...}
    }
  });

  const [errors, setErrors] = useState({});

  // Computed Progress
  const calculateProgress = () => {
    let filledFields = 0;
    const totalFields = 20; // Approximation of key required fields
    
    // Simple heuristic for progress
    if (formData.personal.fullName) filledFields++;
    if (formData.personal.email) filledFields++;
    if (formData.personal.phone) filledFields++;
    if (formData.personal.country) filledFields++;
    if (formData.personal.bio.length > 50) filledFields++;
    
    if (formData.professional.years) filledFields++;
    if (formData.professional.specialty) filledFields++;
    if (formData.professional.description.length > 50) filledFields++;
    
    if (formData.course.topic) filledFields++;
    if (formData.course.description.length > 50) filledFields++;
    if (formData.course.level) filledFields++;
    if (formData.course.target) filledFields++;
    if (formData.course.differentiator) filledFields++;
    
    if (formData.commitment.weekly) filledFields++;
    if (formData.commitment.response) filledFields++;
    
    const policiesCount = Object.values(formData.commitment.policies).filter(Boolean).length;
    if (policiesCount >= 4) filledFields += 5;

    return Math.min(100, (filledFields / totalFields) * 100);
  };

  const progress = useMemo(calculateProgress, [formData]);

  // Handlers
  const handleChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: { ...prev[section], [field]: value }
    }));
    
    // Clear specific error on change
    if (errors[`${section}.${field}`]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[`${section}.${field}`];
        return newErrors;
      });
    }
  };

  const handleCheckboxChange = (section, groupField, itemId, checked) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [groupField]: {
          ...prev[section][groupField],
          [itemId]: checked
        }
      }
    }));
  };

  // Validation Logic
  const validateForm = () => {
    const newErrors = {};
    let isValid = true;

    // Personal
    const vName = Validators.validateFullName(formData.personal.fullName);
    if (!vName.isValid) newErrors['personal.fullName'] = vName.errors[0];

    const vEmail = Validators.validateEmail(formData.personal.email);
    if (!vEmail.isValid) newErrors['personal.email'] = vEmail.errors[0];

    const vPhone = Validators.validatePhone(formData.personal.phone);
    if (!vPhone.isValid) newErrors['personal.phone'] = vPhone.errors[0];
    
    if (!formData.personal.country) newErrors['personal.country'] = 'Selecciona un país';
    
    const vBio = Validators.validateBio(formData.personal.bio);
    if (!vBio.isValid) newErrors['personal.bio'] = vBio.errors[0];

    // Professional
    const vYears = Validators.validateYearsExperience(formData.professional.years);
    if (!vYears.isValid) newErrors['professional.years'] = vYears.errors[0];
    
    if (!formData.professional.specialty) newErrors['professional.specialty'] = 'Requerido';
    
    const vDesc = Validators.validateCharacterRange(formData.professional.description, 150, 1000);
    if (!vDesc.isValid) newErrors['professional.description'] = vDesc.errors[0];

    if (formData.professional.portfolio) {
      const vUrl = Validators.validateURL(formData.professional.portfolio);
      if (!vUrl.isValid) newErrors['professional.portfolio'] = vUrl.errors[0];
    }

    // Teaching
    if (formData.teaching.hasTaught === 'yes') {
      const vTeach = Validators.validateTeachingExperience('yes', formData.teaching);
      if (!vTeach.isValid) {
        if (!formData.teaching.whereWhen) newErrors['teaching.whereWhen'] = 'Requerido';
        if (!formData.teaching.methodology) newErrors['teaching.methodology'] = 'Requerido (min 100 caracteres)';
      }
    }

    // Course
    const vTopic = Validators.validateCharacterRange(formData.course.topic, 5, 100);
    if (!vTopic.isValid) newErrors['course.topic'] = vTopic.errors[0];

    const vCourseDesc = Validators.validateCourseDescription(formData.course.description);
    if (!vCourseDesc.isValid) newErrors['course.description'] = vCourseDesc.errors[0];

    if (!formData.course.level) newErrors['course.level'] = 'Requerido';
    if (!formData.course.duration) newErrors['course.duration'] = 'Requerido';
    
    const vTarget = Validators.validateCharacterRange(formData.course.target, 50, 500);
    if (!vTarget.isValid) newErrors['course.target'] = vTarget.errors[0];

    const vDiff = Validators.validateDifferentiator(formData.course.differentiator);
    if (!vDiff.isValid) newErrors['course.differentiator'] = vDiff.errors[0];

    // Commitment
    if (!formData.commitment.weekly) newErrors['commitment.weekly'] = 'Requerido';
    if (!formData.commitment.response) newErrors['commitment.response'] = 'Requerido';

    // Checkboxes
    const requiredPolicies = ['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8'];
    const vPol = Validators.validateCheckboxes(formData.commitment.policies, requiredPolicies);
    if (!vPol.isValid) newErrors['commitment.policies'] = vPol.errors[0];

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) {
      toast({ 
        title: "Formulario incompleto", 
        description: "Por favor revisa los errores marcados en rojo.", 
        variant: "destructive" 
      });
      // Scroll to first error?
      window.scrollTo(0, 0);
      return;
    }

    setLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const newId = `APP-2026-${Math.floor(10000 + Math.random() * 90000)}`;
      setSubmissionId(newId);
      
      // Save to localStorage
      const submission = {
        id: newId,
        submittedAt: new Date().toISOString(),
        userId: currentUser?.id,
        status: 'submitted',
        ...formData
      };
      
      const apps = JSON.parse(localStorage.getItem('instructorApplications') || '[]');
      apps.push(submission);
      localStorage.setItem('instructorApplications', JSON.stringify(apps));
      
      setLoading(false);
      setShowSuccessModal(true);
    }, 2000);
  };

  if (showSuccessModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center"
        >
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 size={40} />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">¡Solicitud Enviada!</h2>
          <p className="text-gray-500 mb-4">Número de confirmación:</p>
          <div className="bg-gray-100 py-2 px-4 rounded-lg font-mono text-lg font-bold text-gray-800 mb-6 inline-block">
            #{submissionId}
          </div>
          <p className="text-sm text-gray-600 mb-8 leading-relaxed">
            Hemos recibido tu solicitud correctamente. Nuestro equipo revisará tu perfil en los próximos <strong>3-5 días hábiles</strong>. Te notificaremos por correo electrónico sobre el siguiente paso.
          </p>
          <div className="space-y-3">
             <Button onClick={() => navigate('/instructor-application-status')} className="w-full bg-[#0B3D91] hover:bg-[#092c69]">
               Ver Estado de Solicitud
             </Button>
             <Button onClick={() => navigate('/dashboard')} variant="outline" className="w-full">
               Volver al Dashboard
             </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* SECTION 1: Header */}
      <div className="bg-[#0B3D91] text-white pt-12 pb-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-10">
           <Save size={200} />
        </div>
        <div className="container mx-auto px-4 relative z-10 max-w-4xl">
          <Button variant="ghost" className="text-blue-200 hover:text-white hover:bg-white/10 p-0 mb-6" onClick={() => navigate(-1)}>
            <ArrowLeft size={18} className="mr-2" /> Cancelar y Salir
          </Button>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Solicitud para Convertirse en Instructor</h1>
          <p className="text-blue-100 text-lg mb-8 max-w-2xl">
            Únete a la comunidad de instructores de élite de Netcom. Comparte tu conocimiento, construye tu marca personal y genera ingresos.
          </p>
          
          <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 flex items-center gap-4">
            <div className="bg-blue-500/20 p-2 rounded-lg">
              <Clock className="text-blue-200" />
            </div>
            <div>
              <p className="text-sm text-blue-200 font-medium">Tiempo estimado</p>
              <p className="font-bold">15-20 minutos</p>
            </div>
            <div className="ml-auto w-1/3 md:w-64">
               <InstructorProgressBar percentage={progress} />
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-3xl -mt-16 relative z-20">
        
        {/* SECTION 2: Personal Data */}
        <InstructorFormSection title="Datos Personales" description="Información básica para tu perfil de instructor." sectionNumber={1} totalSections={6}>
          <div className="grid md:grid-cols-2 gap-6">
            <InstructorFormField 
              label="Nombre Completo" 
              value={formData.personal.fullName}
              onChange={(e) => handleChange('personal', 'fullName', e.target.value)}
              error={errors['personal.fullName']}
              isValid={!errors['personal.fullName']}
              required
            />
            <InstructorFormField 
              label="Email" 
              type="email"
              value={formData.personal.email}
              onChange={(e) => handleChange('personal', 'email', e.target.value)}
              error={errors['personal.email']}
              isValid={!errors['personal.email']}
              required
            />
          </div>
          <div className="grid md:grid-cols-2 gap-6">
             <InstructorFormField 
              label="Teléfono" 
              value={formData.personal.phone}
              onChange={(e) => handleChange('personal', 'phone', e.target.value)}
              error={errors['personal.phone']}
              isValid={!errors['personal.phone']}
              placeholder="+52 ..."
              required
            />
            <InstructorSelectField 
              label="País de Residencia"
              value={formData.personal.country}
              onChange={(e) => handleChange('personal', 'country', e.target.value)}
              error={errors['personal.country']}
              required
              options={[
                { value: 'mx', label: 'México' },
                { value: 'co', label: 'Colombia' },
                { value: 'ar', label: 'Argentina' },
                { value: 'es', label: 'España' },
                { value: 'cl', label: 'Chile' },
                { value: 'pe', label: 'Perú' },
                { value: 'other', label: 'Otro' }
              ]}
            />
          </div>
          <InstructorFormField 
            label="Biografía Profesional" 
            type="textarea"
            value={formData.personal.bio}
            onChange={(e) => handleChange('personal', 'bio', e.target.value)}
            error={errors['personal.bio']}
            isValid={!errors['personal.bio']}
            required
            maxLength={500}
            helperText="Resumen breve que aparecerá en tu perfil (100-500 caracteres)."
          />
          <InstructorFileUpload 
            label="Foto de Perfil"
            acceptedTypes={['image/jpeg', 'image/png']}
            maxSizeMB={5}
            onFileSelect={(file) => handleChange('personal', 'photo', file)}
            currentFile={formData.personal.photo}
            error={errors['personal.photo']}
            isValid={!!formData.personal.photo}
            required
          />
        </InstructorFormSection>

        {/* SECTION 3: Professional Profile */}
        <InstructorFormSection title="Perfil Profesional" description="Tu experiencia y credenciales." sectionNumber={2} totalSections={6}>
          <div className="grid md:grid-cols-2 gap-6">
            <InstructorFormField 
              label="Años de Experiencia" 
              type="number"
              value={formData.professional.years}
              onChange={(e) => handleChange('professional', 'years', e.target.value)}
              error={errors['professional.years']}
              isValid={!errors['professional.years']}
              required
            />
            <InstructorSelectField 
              label="Especialidad Principal"
              value={formData.professional.specialty}
              onChange={(e) => handleChange('professional', 'specialty', e.target.value)}
              error={errors['professional.specialty']}
              required
              options={[
                { value: 'dev', label: 'Desarrollo Web/Mobile' },
                { value: 'data', label: 'Data Science / IA' },
                { value: 'design', label: 'Diseño UX/UI' },
                { value: 'marketing', label: 'Marketing Digital' },
                { value: 'business', label: 'Negocios / Emprendimiento' },
                { value: 'cyber', label: 'Ciberseguridad' }
              ]}
            />
          </div>
           <div className="grid md:grid-cols-2 gap-6">
            <InstructorFormField 
              label="Empresa Actual" 
              value={formData.professional.company}
              onChange={(e) => handleChange('professional', 'company', e.target.value)}
              placeholder="Opcional"
            />
            <InstructorFormField 
              label="Cargo Actual" 
              value={formData.professional.position}
              onChange={(e) => handleChange('professional', 'position', e.target.value)}
              placeholder="Opcional"
            />
          </div>
          <InstructorFormField 
            label="Portfolio / LinkedIn / GitHub" 
            value={formData.professional.portfolio}
            onChange={(e) => handleChange('professional', 'portfolio', e.target.value)}
            error={errors['professional.portfolio']}
            isValid={formData.professional.portfolio && !errors['professional.portfolio']}
            placeholder="https://..."
          />
          <InstructorFileUpload 
            label="Certificaciones (Opcional)"
            acceptedTypes={['application/pdf']}
            maxSizeMB={10}
            onFileSelect={(file) => handleChange('professional', 'certifications', file)}
            currentFile={formData.professional.certifications}
          />
          <InstructorFormField 
            label="Descripción de Experiencia" 
            type="textarea"
            value={formData.professional.description}
            onChange={(e) => handleChange('professional', 'description', e.target.value)}
            error={errors['professional.description']}
            isValid={!errors['professional.description']}
            required
            maxLength={1000}
            helperText="Detalla tus logros, tecnologías y responsabilidades clave (mín. 150 caracteres)."
          />
        </InstructorFormSection>

        {/* SECTION 4: Teaching Experience */}
        <InstructorFormSection title="Experiencia Docente" description="¿Has enseñado antes? Cuéntanos." sectionNumber={3} totalSections={6}>
           <div className="mb-6">
             <label className="block text-sm font-semibold text-gray-700 mb-2">¿Has impartido clases o cursos anteriormente?</label>
             <div className="flex gap-4">
               {['yes', 'no'].map(opt => (
                 <label key={opt} className={`flex-1 border rounded-lg p-4 cursor-pointer text-center transition-all ${formData.teaching.hasTaught === opt ? 'bg-blue-50 border-[#0B3D91] text-[#0B3D91] font-bold' : 'hover:bg-gray-50'}`}>
                   <input 
                     type="radio" 
                     name="hasTaught" 
                     value={opt} 
                     checked={formData.teaching.hasTaught === opt}
                     onChange={(e) => handleChange('teaching', 'hasTaught', e.target.value)}
                     className="sr-only"
                   />
                   {opt === 'yes' ? 'Sí, tengo experiencia' : 'No, es mi primera vez'}
                 </label>
               ))}
             </div>
           </div>

           <AnimatePresence>
             {formData.teaching.hasTaught === 'yes' && (
               <motion.div 
                 initial={{ height: 0, opacity: 0 }} 
                 animate={{ height: 'auto', opacity: 1 }} 
                 exit={{ height: 0, opacity: 0 }}
                 className="space-y-6 overflow-hidden"
               >
                 <InstructorFormField 
                    label="¿Dónde y Cuándo?" 
                    value={formData.teaching.whereWhen}
                    onChange={(e) => handleChange('teaching', 'whereWhen', e.target.value)}
                    error={errors['teaching.whereWhen']}
                    isValid={!errors['teaching.whereWhen']}
                    required
                    placeholder="Ej. Universidad X (2019-2022), Bootcamps online..."
                  />
                  <div className="grid md:grid-cols-2 gap-6">
                    <InstructorFormField 
                      label="Número aprox. de estudiantes" 
                      type="number"
                      value={formData.teaching.students}
                      onChange={(e) => handleChange('teaching', 'students', e.target.value)}
                      placeholder="Ej. 500"
                    />
                     <InstructorFormField 
                      label="Logros destacados (Opcional)" 
                      value={formData.teaching.achievements}
                      onChange={(e) => handleChange('teaching', 'achievements', e.target.value)}
                      placeholder="Ej. Mejor profesor 2021"
                    />
                  </div>
                  <InstructorFormField 
                    label="Metodología de Enseñanza" 
                    type="textarea"
                    value={formData.teaching.methodology}
                    onChange={(e) => handleChange('teaching', 'methodology', e.target.value)}
                    error={errors['teaching.methodology']}
                    isValid={!errors['teaching.methodology']}
                    required
                    helperText="Describe cómo estructuras tus clases y mantienes a los alumnos enganchados (mín. 100 chars)."
                  />
               </motion.div>
             )}
           </AnimatePresence>
        </InstructorFormSection>

        {/* SECTION 5: Value Proposition */}
        <InstructorFormSection title="Propuesta de Valor" description="Tu primer curso en Netcom." sectionNumber={4} totalSections={6}>
          <InstructorFormField 
            label="Tema del Primer Curso" 
            value={formData.course.topic}
            onChange={(e) => handleChange('course', 'topic', e.target.value)}
            error={errors['course.topic']}
            isValid={!errors['course.topic']}
            required
            placeholder="Ej. Master en React Native: De Cero a Experto"
          />
          <InstructorFormField 
            label="Descripción del Curso" 
            type="textarea"
            value={formData.course.description}
            onChange={(e) => handleChange('course', 'description', e.target.value)}
            error={errors['course.description']}
            isValid={!errors['course.description']}
            required
            helperText="¿Qué aprenderán los estudiantes? ¿Qué problemas resuelve? (mín. 200 chars)"
          />
          <div className="grid md:grid-cols-2 gap-6">
             <InstructorSelectField 
              label="Nivel"
              value={formData.course.level}
              onChange={(e) => handleChange('course', 'level', e.target.value)}
              error={errors['course.level']}
              required
              options={[
                { value: 'beginner', label: 'Principiante' },
                { value: 'intermediate', label: 'Intermedio' },
                { value: 'advanced', label: 'Avanzado' },
                { value: 'all', label: 'Todos los niveles' }
              ]}
            />
             <InstructorSelectField 
              label="Duración Estimada"
              value={formData.course.duration}
              onChange={(e) => handleChange('course', 'duration', e.target.value)}
              error={errors['course.duration']}
              required
              options={[
                { value: 'short', label: 'Corto (2-5 horas)' },
                { value: 'medium', label: 'Medio (5-10 horas)' },
                { value: 'long', label: 'Largo (10-20 horas)' },
                { value: 'bootcamp', label: 'Intensivo (20+ horas)' }
              ]}
            />
          </div>
          <InstructorFormField 
            label="Público Objetivo" 
            type="textarea"
            rows={2}
            value={formData.course.target}
            onChange={(e) => handleChange('course', 'target', e.target.value)}
            error={errors['course.target']}
            isValid={!errors['course.target']}
            required
            helperText="Define quién es el estudiante ideal (mín. 50 chars)."
          />
          
          <div className="space-y-3">
             <label className="block text-sm font-semibold text-gray-700">Recursos Incluidos</label>
             <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
               {[
                 {id: 'r_videos', label: 'Videos HD'},
                 {id: 'r_pdfs', label: 'Guías PDF'},
                 {id: 'r_code', label: 'Código Fuente'},
                 {id: 'r_exercises', label: 'Ejercicios'},
                 {id: 'r_projects', label: 'Proyectos Reales'},
                 {id: 'r_webinars', label: 'Sesiones en Vivo'}
               ].map(r => (
                 <label key={r.id} className="flex items-center gap-2 p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                    <input 
                      type="checkbox" 
                      checked={formData.course.resources[r.id] || false}
                      onChange={(e) => handleCheckboxChange('course', 'resources', r.id, e.target.checked)}
                      className="rounded text-[#0B3D91] focus:ring-[#0B3D91]"
                    />
                    <span className="text-sm">{r.label}</span>
                 </label>
               ))}
             </div>
          </div>

          <InstructorFormField 
            label="Diferenciador Clave" 
            type="textarea"
            value={formData.course.differentiator}
            onChange={(e) => handleChange('course', 'differentiator', e.target.value)}
            error={errors['course.differentiator']}
            isValid={!errors['course.differentiator']}
            required
            helperText="¿Por qué este curso es diferente a los que ya existen? (mín. 100 chars)"
          />
        </InstructorFormSection>

        {/* SECTION 6: Commitment & Policies */}
        <InstructorFormSection title="Compromiso y Políticas" description="Acuerdos finales." sectionNumber={5} totalSections={6}>
          <div className="grid md:grid-cols-2 gap-6 mb-6">
             <InstructorSelectField 
              label="Disponibilidad Semanal"
              value={formData.commitment.weekly}
              onChange={(e) => handleChange('commitment', 'weekly', e.target.value)}
              error={errors['commitment.weekly']}
              required
              options={[
                { value: 'low', label: '1-5 horas' },
                { value: 'med', label: '5-10 horas' },
                { value: 'high', label: '10+ horas' }
              ]}
            />
             <InstructorSelectField 
              label="Tiempo de Respuesta a Alumnos"
              value={formData.commitment.response}
              onChange={(e) => handleChange('commitment', 'response', e.target.value)}
              error={errors['commitment.response']}
              required
              options={[
                { value: '24h', label: 'Menos de 24 horas' },
                { value: '48h', label: '24-48 horas' },
                { value: 'week', label: 'Fines de semana' }
              ]}
            />
          </div>

          <InstructorCheckboxGroup 
            items={[
              { id: 'p1', label: 'Certifico que toda la información proporcionada es verdadera.', required: true },
              { id: 'p2', label: 'Soy el autor original del contenido que planeo subir.', required: true },
              { id: 'p3', label: 'Acepto los Términos y Condiciones de Instructores de Netcom.', required: true },
              { id: 'p4', label: 'Me comprometo a mantener una calidad de audio y video profesional.', required: true },
              { id: 'p5', label: 'Entiendo que el pago se realiza mensualmente basado en minutos vistos.', required: true },
              { id: 'p6', label: 'Me comprometo a actualizar mis cursos al menos una vez al año.', required: true },
              { id: 'p7', label: 'Acepto la Política de Privacidad y manejo de datos.', required: true },
              { id: 'p8', label: 'No promocionaré productos o servicios externos no autorizados.', required: true },
            ]}
            checkedItems={formData.commitment.policies}
            onChange={(id, checked) => handleCheckboxChange('commitment', 'policies', id, checked)}
            errors={errors['commitment.policies']}
          />
        </InstructorFormSection>

        {/* Submit Button */}
        <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 flex items-center justify-between sticky bottom-4 z-30">
           <div className="hidden md:block text-sm text-gray-500">
             Revisa todos los campos antes de enviar.
           </div>
           <Button 
             size="lg" 
             onClick={handleSubmit} 
             disabled={loading}
             className="w-full md:w-auto bg-[#0B3D91] hover:bg-[#092c69] text-white px-8 h-14 text-lg font-bold shadow-md"
           >
             {loading ? (
               <span className="flex items-center gap-2">
                 <Clock className="animate-spin" /> Procesando...
               </span>
             ) : (
               <span className="flex items-center gap-2">
                 Enviar Solicitud <ChevronRight />
               </span>
             )}
           </Button>
        </div>

      </div>
    </div>
  );
};

export default InstructorApplicationPage;
