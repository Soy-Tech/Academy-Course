
import React from 'react';
import { Helmet } from 'react-helmet';
import { mockLegal } from '@/data/mockLegal';

const PrivacyPage = () => {
  return (
    <>
      <Helmet>
        <title>Política de Privacidad - Netcom</title>
      </Helmet>
      <div className="container mx-auto px-4 max-w-3xl py-16">
        <h1 className="text-3xl font-bold text-[#0B3D91] mb-8">{mockLegal.privacy.title}</h1>
        <div className="space-y-8">
            {mockLegal.privacy.sections.map((section, i) => (
                <div key={i}>
                    <h2 className="text-xl font-bold text-gray-900 mb-2">{section.heading}</h2>
                    <p className="text-gray-700 leading-relaxed">{section.content}</p>
                </div>
            ))}
        </div>
      </div>
    </>
  );
};
export default PrivacyPage;
