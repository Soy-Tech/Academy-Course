
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useInstructorRequest } from '@/contexts/InstructorRequestContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, RefreshCw, Mail, CheckCircle2 } from 'lucide-react';
import ApplicationStatusBadge from '@/components/ApplicationStatusBadge';
import FormSection from '@/components/FormSection';

const ApplicationStatusPage = () => {
  const { currentApplication, loading } = useInstructorRequest();
  const navigate = useNavigate();

  if (loading) return <div className="p-8 text-center">Cargando...</div>;

  if (!currentApplication) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <h2 className="text-xl font-bold text-gray-900 mb-2">No se encontró ninguna solicitud</h2>
        <Button onClick={() => navigate('/become-instructor')}>Aplicar Ahora</Button>
      </div>
    );
  }

  const steps = [
    { status: 'submitted', label: 'Solicitud Enviada', date: currentApplication.submittedAt },
    { status: 'under_review', label: 'En Revisión', date: null },
    { status: 'approved', label: 'Aprobación Final', date: null }
  ];

  const currentStepIndex = steps.findIndex(s => s.status === currentApplication.status);
  // Default to step 0 if status not found in linear flow (e.g. rejected)
  const activeIndex = currentStepIndex === -1 ? (currentApplication.status === 'rejected' ? 2 : 0) : currentStepIndex;

  return (
    <div className="min-h-screen bg-gray-50 pt-8 pb-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <Button variant="ghost" onClick={() => navigate('/dashboard')} className="mb-6 pl-0">
          <ArrowLeft className="mr-2" size={18} /> Volver al Dashboard
        </Button>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
          <div className="bg-[#0B3D91] p-8 text-white">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-2xl font-bold mb-2">Estado de Solicitud</h1>
                <p className="text-blue-100">ID: <span className="font-mono bg-blue-800 px-2 py-0.5 rounded">{currentApplication.id}</span></p>
              </div>
              <ApplicationStatusBadge status={currentApplication.status} className="bg-white/20 text-white border-white/20 px-4 py-2" />
            </div>
          </div>

          <div className="p-8">
            {/* Timeline */}
            <div className="mb-12 relative">
               <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-gray-100 -z-10"></div>
               <div className="flex justify-between">
                 {steps.map((step, index) => {
                   const isCompleted = index <= activeIndex;
                   const isCurrent = index === activeIndex;
                   return (
                     <div key={step.status} className="flex flex-col items-center bg-white px-2">
                       <div className={`w-10 h-10 rounded-full flex items-center justify-center border-4 transition-colors ${
                         isCompleted 
                           ? (currentApplication.status === 'rejected' && index === 2 ? 'border-red-500 bg-red-50 text-red-600' : 'border-green-500 bg-green-50 text-green-600')
                           : 'border-gray-200 bg-white text-gray-300'
                       }`}>
                         {isCompleted ? <CheckCircle2 size={20} /> : <span>{index + 1}</span>}
                       </div>
                       <span className={`mt-2 text-sm font-medium ${isCurrent ? 'text-[#0B3D91]' : 'text-gray-500'}`}>
                         {step.label}
                       </span>
                     </div>
                   );
                 })}
               </div>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="md:col-span-2 space-y-6">
                <FormSection title="Detalles" className="shadow-none border-gray-200">
                   <div className="space-y-4">
                     <div>
                       <span className="text-sm text-gray-500 block">Nombre del Solicitante</span>
                       <span className="font-medium text-gray-900">{currentApplication.personalData.fullName}</span>
                     </div>
                     <div>
                       <span className="text-sm text-gray-500 block">Tema del Curso</span>
                       <span className="font-medium text-gray-900">{currentApplication.courseProposal.topic}</span>
                     </div>
                     <div>
                       <span className="text-sm text-gray-500 block">Email de Contacto</span>
                       <span className="font-medium text-gray-900">{currentApplication.personalData.email}</span>
                     </div>
                   </div>
                </FormSection>

                {currentApplication.status === 'rejected' && (
                  <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                    <h3 className="text-red-800 font-bold mb-2">Motivo del Rechazo</h3>
                    <p className="text-red-700">{currentApplication.adminNotes || "No se especificó una razón. Por favor contacta a soporte."}</p>
                    <Button variant="outline" className="mt-4 border-red-200 text-red-700 hover:bg-red-100">Apelar Decisión</Button>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="bg-gray-50 p-6 rounded-xl border border-gray-100">
                  <h3 className="font-bold text-gray-900 mb-4">Siguientes Pasos</h3>
                  <ul className="space-y-3 text-sm text-gray-600">
                    <li className="flex gap-2">
                      <span className="text-[#0B3D91] font-bold">•</span>
                      Revisión de perfil (24-48h)
                    </li>
                    <li className="flex gap-2">
                      <span className="text-[#0B3D91] font-bold">•</span>
                      Verificación de antecedentes
                    </li>
                    <li className="flex gap-2">
                      <span className="text-[#0B3D91] font-bold">•</span>
                      Entrevista final (si es necesario)
                    </li>
                  </ul>
                </div>

                <Button variant="outline" className="w-full gap-2">
                  <Mail size={16} /> Contactar Soporte
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationStatusPage;
