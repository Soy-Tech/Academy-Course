
import React, { useState } from 'react';
import { Search, Filter, Plus, MoreHorizontal, Edit, Trash2, Eye, Users, FileText } from 'lucide-react';
import AdminLayout from '@/components/Admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { mockCourses } from '@/data/mockCourses';
import { useToast } from '@/components/ui/use-toast';
import CourseModal from '@/components/Admin/CourseModal';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const AdminCoursesPage = () => {
  const [courses, setCourses] = useState(mockCourses);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showCourseForm, setShowCourseForm] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const { toast } = useToast();

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || course.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleDelete = (id) => {
    if (window.confirm('¿Estás seguro de eliminar este curso?')) {
      setCourses(courses.filter(c => c.id !== id));
      toast({
        title: "Curso eliminado",
        description: "El curso ha sido eliminado correctamente.",
        variant: "destructive"
      });
    }
  };

  const handleStatusToggle = (id) => {
    setCourses(courses.map(c => {
      if (c.id === id) {
        let newStatus = c.status;
        if (c.status === 'active') newStatus = 'inactive';
        else if (c.status === 'inactive') newStatus = 'active';
        else if (c.status === 'draft') newStatus = 'active';
        
        return { ...c, status: newStatus };
      }
      return c;
    }));
    toast({
      title: "Estado actualizado",
      description: "El estado del curso ha sido modificado.",
    });
  };

  const handleSaveCourse = (courseData) => {
    if (selectedCourse) {
      setCourses(courses.map(c => c.id === selectedCourse.id ? { ...c, ...courseData } : c));
      toast({
        title: "Curso actualizado",
        description: "Los cambios han sido guardados.",
      });
    } else {
      const newCourse = {
        id: Math.max(...courses.map(c => c.id), 0) + 1,
        ...courseData,
        studentCount: 0,
        rating: 0,
        // Ensure other required fields exist
      };
      setCourses([...courses, newCourse]);
      toast({
        title: "Curso creado",
        description: "El curso ha sido añadido al catálogo.",
      });
    }
    setShowCourseForm(false);
    setSelectedCourse(null);
  };

  const openCreateModal = () => {
    setSelectedCourse(null);
    setShowCourseForm(true);
  };

  const openEditModal = (course) => {
    setSelectedCourse(course);
    setShowCourseForm(true);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'active': return <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">Activo</span>;
      case 'inactive': return <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-red-50 text-red-700 border border-red-100">Inactivo</span>;
      case 'draft': return <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-gray-100 text-gray-700 border border-gray-200">Borrador</span>;
      default: return null;
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Catálogo de Cursos</h1>
            <p className="text-gray-500 mt-1">
              Gestiona el contenido educativo, estados y asignaciones.
            </p>
          </div>
          <Button 
            onClick={openCreateModal}
            className="bg-blue-600 hover:bg-blue-700 shadow-sm transition-all"
          >
            <Plus size={18} className="mr-2" />
            Nuevo Curso
          </Button>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="relative w-full md:w-96 group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={18} />
            <input
              type="text"
              placeholder="Buscar por título..."
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2 w-full md:w-auto">
            <Filter size={16} className="text-gray-400" />
            <select
              className="bg-gray-50 border border-gray-200 rounded-lg text-sm px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer flex-1 hover:bg-gray-100 transition-colors"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="all">Todos los estados</option>
              <option value="active">Activos</option>
              <option value="inactive">Inactivos</option>
              <option value="draft">Borradores</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-gray-50/80 border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Curso</th>
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Instructor</th>
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Estudiantes</th>
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Categoría</th>
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Estado</th>
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredCourses.map((course) => (
                  <tr key={course.id} className="hover:bg-gray-50/80 transition-colors group">
                    <td className="px-6 py-4 max-w-[300px]">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-blue-50 rounded-lg text-blue-600 shrink-0">
                          <FileText size={18} />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 line-clamp-1">{course.title}</p>
                          <p className="text-xs text-gray-500 line-clamp-1 mt-0.5">{course.description}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      {course.instructor}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                      <div className="flex items-center gap-1.5">
                        <Users size={14} className="text-gray-400" />
                        {course.studentCount}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-xs font-medium text-blue-700 bg-blue-50 border border-blue-100 px-2 py-1 rounded-md">
                        {course.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(course.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                            <MoreHorizontal className="h-4 w-4 text-gray-500" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="cursor-pointer">
                            <Eye className="mr-2 h-4 w-4 text-gray-500" /> Ver contenido
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openEditModal(course)} className="cursor-pointer">
                            <Edit className="mr-2 h-4 w-4 text-gray-500" /> Editar info
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleStatusToggle(course.id)} className="cursor-pointer">
                            <Users className="mr-2 h-4 w-4 text-gray-500" /> 
                            {course.status === 'active' ? 'Desactivar' : 'Activar'}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDelete(course.id)} className="text-red-600 cursor-pointer focus:text-red-600 focus:bg-red-50">
                            <Trash2 className="mr-2 h-4 w-4" /> Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredCourses.length === 0 && (
            <div className="p-12 text-center">
              <div className="mx-auto w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <Search className="text-gray-400" />
              </div>
              <h3 className="text-gray-900 font-medium">No se encontraron cursos</h3>
              <p className="text-gray-500 text-sm mt-1">Intenta cambiar los filtros de búsqueda.</p>
            </div>
          )}
        </div>
      </div>

      {showCourseForm && (
        <CourseModal 
          isOpen={showCourseForm} 
          onClose={() => setShowCourseForm(false)} 
          initialData={selectedCourse}
          onSave={handleSaveCourse}
          title={selectedCourse ? 'Editar Curso' : 'Nuevo Curso'}
        />
      )}
    </AdminLayout>
  );
};

export default AdminCoursesPage;
