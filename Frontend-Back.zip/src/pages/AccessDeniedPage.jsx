
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useRole } from '@/contexts/RoleContext';
import { getRoleLabel } from '@/utils/rolePermissions';

const AccessDeniedPage = () => {
  const { currentRole } = useRole();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 md:p-12 max-w-md w-full text-center">
        <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShieldAlert size={40} className="text-red-500" />
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Acceso Denegado</h1>
        <p className="text-gray-600 mb-6">
          No tienes los permisos necesarios para acceder a esta página.
        </p>

        <div className="bg-gray-50 p-4 rounded-lg border border-gray-100 mb-8 inline-block w-full">
          <span className="text-xs text-gray-500 uppercase tracking-wide font-bold block mb-1">
            Tu Rol Actual
          </span>
          <span className="text-lg font-semibold text-gray-800 flex items-center justify-center gap-2">
            {getRoleLabel(currentRole)}
          </span>
        </div>

        <div className="space-y-3">
          <Button 
            onClick={() => navigate('/')} 
            className="w-full bg-[#0B3D91] hover:bg-[#082d6b]"
          >
            <Home size={16} className="mr-2" />
            Volver al Inicio
          </Button>
          
          {/* Back button for history navigation */}
          <Button 
            variant="outline" 
            onClick={() => navigate(-1)} 
            className="w-full"
          >
            <ArrowLeft size={16} className="mr-2" />
            Regresar
          </Button>

          <p className="text-xs text-gray-400 mt-4">
            Puedes cambiar tu rol usando el selector en el menú superior para acceder.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AccessDeniedPage;
