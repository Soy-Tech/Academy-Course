
import React, { useEffect, useState } from 'react';
import { useInstructorRequest } from '@/contexts/InstructorRequestContext';
import { Button } from '@/components/ui/button';
import { Search, Filter, Eye, CheckCircle, XCircle } from 'lucide-react';
import ApplicationStatusBadge from '@/components/ApplicationStatusBadge';
import { motion } from 'framer-motion';

const AdminApplicationReview = () => {
  const { fetchAllApplications, updateStatus, loading } = useInstructorRequest();
  const [applications, setApplications] = useState([]);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const data = await fetchAllApplications();
    setApplications(data || []);
  };

  const handleAction = async (id, action) => {
    if (action === 'approve') {
      if (window.confirm('¿Aprobar este instructor?')) {
        await updateStatus(id, 'approved', 'Approved by Admin');
        loadData();
      }
    } else if (action === 'reject') {
      const reason = window.prompt('Razón del rechazo:');
      if (reason) {
        await updateStatus(id, 'rejected', reason);
        loadData();
      }
    }
  };

  const filteredApps = applications.filter(app => {
    const matchFilter = filter === 'all' || app.status === filter;
    const matchSearch = app.personalData?.fullName.toLowerCase().includes(search.toLowerCase()) || 
                        app.personalData?.email.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Solicitudes de Instructores</h1>
        <Button onClick={loadData}>Actualizar</Button>
      </div>

      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-6 flex flex-wrap gap-4 justify-between">
        <div className="flex gap-2">
          {['all', 'submitted', 'under_review', 'approved', 'rejected'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                filter === f ? 'bg-blue-100 text-blue-800' : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              {f.replace('_', ' ').toUpperCase()}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Buscar..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 pr-4 py-2 border border-gray-200 rounded-md text-sm outline-none focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-200 text-xs uppercase text-gray-500">
            <tr>
              <th className="px-6 py-4">Candidato</th>
              <th className="px-6 py-4">Especialidad</th>
              <th className="px-6 py-4">Fecha</th>
              <th className="px-6 py-4">Estado</th>
              <th className="px-6 py-4 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filteredApps.map((app) => (
              <motion.tr 
                key={app.id} 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="hover:bg-gray-50"
              >
                <td className="px-6 py-4">
                  <div>
                    <div className="font-semibold text-gray-900">{app.personalData.fullName}</div>
                    <div className="text-sm text-gray-500">{app.personalData.email}</div>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{app.experience?.specialty || 'N/A'}</td>
                <td className="px-6 py-4 text-sm text-gray-600">{new Date(app.submittedAt).toLocaleDateString()}</td>
                <td className="px-6 py-4">
                  <ApplicationStatusBadge status={app.status} />
                </td>
                <td className="px-6 py-4 text-right flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => alert(JSON.stringify(app, null, 2))}>
                    <Eye size={16} />
                  </Button>
                  {app.status === 'submitted' && (
                    <>
                      <Button variant="ghost" size="sm" className="text-green-600 hover:bg-green-50" onClick={() => handleAction(app.id, 'approve')}>
                        <CheckCircle size={16} />
                      </Button>
                      <Button variant="ghost" size="sm" className="text-red-600 hover:bg-red-50" onClick={() => handleAction(app.id, 'reject')}>
                        <XCircle size={16} />
                      </Button>
                    </>
                  )}
                </td>
              </motion.tr>
            ))}
            {filteredApps.length === 0 && (
              <tr>
                <td colSpan="5" className="px-6 py-8 text-center text-gray-500">No hay solicitudes encontradas.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminApplicationReview;
