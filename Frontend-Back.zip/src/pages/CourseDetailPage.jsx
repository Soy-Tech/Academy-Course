
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Clock, ArrowLeft, CheckCircle, 
  Target, AlertCircle, BookOpen, Award, 
  Code, Infinity as InfinityIcon, Star
} from 'lucide-react';
import { coursesData } from '@/data/coursesData';
import { generateModulesForCourse } from '@/data/mockCourseModules';
import ModulesList from '@/components/ModulesList';
import { useAuth } from '@/hooks/useAuth';
import { useEnrollment } from '@/hooks/useEnrollment';
import EnrollButton from '@/components/EnrollButton';
import EnrollmentConfirmation from '@/components/EnrollmentConfirmation';

const CourseDetailPage = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { enrollCourse, isEnrolled } = useEnrollment();
  
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [modules, setModules] = useState([]);
  const [totalResources, setTotalResources] = useState(0);
  
  const course = coursesData.find(c => c.id === id);

  // Generate dynamic modules for this course
  useEffect(() => {
    if (course) {
      const generatedModules = generateModulesForCourse(course.id);
      setModules(generatedModules);
      
      // Calculate total resources
      const count = generatedModules.reduce((acc, m) => {
        return acc + 
          (m.resources.videos?.length || 0) + 
          (m.resources.pdfs?.length || 0) + 
          (m.resources.docs?.length || 0) + 
          (m.resources.files?.length || 0) + 
          (m.resources.activities?.length || 0);
      }, 0);
      setTotalResources(count);
    }
  }, [course]);

  useEffect(() => {
    const redirectParam = searchParams.get('redirect');
    if (currentUser && redirectParam && !isEnrolled(id)) {
      enrollCourse(id);
      setShowConfirmation(true);
      navigate(`/cursos/${id}`, { replace: true });
    }
  }, [currentUser, id, isEnrolled, enrollCourse, searchParams, navigate]);

  if (!course) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-[#0B3D91] mb-4">Curso no encontrado</h2>
        <Link to="/cursos" className="inline-block bg-[#0B3D91] text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition">
            Volver a cursos
        </Link>
      </div>
    );
  }

  const handleEnrollSuccess = () => {
    setShowConfirmation(true);
  };

  const handleNavigateToContent = () => {
    navigate('/dashboard'); 
  };

  return (
    <>
      <Helmet>
        <title>{course.title} - Netcom Academy</title>
        <meta name="description" content={course.shortDescription} />
      </Helmet>

      <EnrollmentConfirmation 
        isOpen={showConfirmation}
        courseName={course.title}
        onClose={() => setShowConfirmation(false)}
        onNavigate={handleNavigateToContent}
      />

      {/* Hero Banner */}
      <section className="relative bg-[#0B3D91] text-white pt-10 pb-16 md:py-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
            <img 
                src={course.image} 
                alt="Course background" 
                className="w-full h-full object-cover opacity-20 mix-blend-overlay"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B3D91] via-[#0B3D91]/90 to-transparent"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <Link to="/cursos" className="inline-flex items-center text-gray-300 hover:text-[#CFAE70] mb-8 transition-colors text-sm font-medium">
            <ArrowLeft size={18} className="mr-2" />
            Volver al catálogo
          </Link>

          <div className="max-w-4xl">
             <div className="flex flex-wrap gap-3 mb-6">
                <span className="bg-[#CFAE70] text-[#0B3D91] px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                    {course.category}
                </span>
                <span className="bg-white/10 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-sm border border-white/20">
                    {course.level}
                </span>
             </div>
             
             <h1 className="text-3xl md:text-5xl font-extrabold mb-6 leading-tight">
                {course.title}
             </h1>
             
             <p className="text-lg md:text-xl text-gray-200 mb-8 max-w-2xl font-light leading-relaxed">
                {course.shortDescription}
             </p>

             <div className="flex flex-wrap items-center gap-6 text-sm font-medium text-gray-300">
                <div className="flex items-center gap-2">
                    <img 
                        src={`https://api.dicebear.com/7.x/initials/svg?seed=${course.instructor}`} 
                        alt={course.instructor}
                        className="w-8 h-8 rounded-full border-2 border-[#CFAE70]" 
                    />
                    <span>Por <span className="text-white">{course.instructor}</span></span>
                </div>
                <div className="flex items-center gap-1 text-[#CFAE70]">
                    <Star className="fill-current" size={16} />
                    <span className="text-white font-bold">{course.rating}</span>
                    <span className="text-gray-400 font-normal">(450+ reseñas)</span>
                </div>
                <div className="flex items-center gap-2">
                    <Clock size={16} />
                    <span>Actualizado: Octubre 2025</span>
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="bg-gray-50 py-12 md:py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            
            {/* Left Column - Content */}
            <div className="lg:col-span-2 space-y-12">
                
                {/* Mobile Enroll Button */}
                <div className="block lg:hidden bg-white p-6 rounded-xl shadow-md border border-gray-100">
                     <div className="text-3xl font-bold text-[#0B3D91] mb-2">{course.price}</div>
                     <EnrollButton 
                        courseId={course.id} 
                        courseName={course.title}
                        onEnrollSuccess={handleEnrollSuccess}
                        className="mb-4"
                     />
                     <p className="text-xs text-center text-gray-500">Garantía de devolución de 30 días</p>
                </div>

                {/* Description */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="bg-white p-8 rounded-xl shadow-sm border border-gray-100"
                >
                    <h2 className="text-2xl font-bold text-[#1C1C1C] mb-4">Descripción del curso</h2>
                    <p className="text-gray-700 leading-relaxed text-lg">
                        {course.fullDescription || course.description}
                    </p>
                </motion.div>

                {/* Modules / Curriculum List */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                >
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-8">
                     <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                        <h2 className="text-2xl font-bold text-[#1C1C1C] flex items-center gap-2">
                           <BookOpen className="text-[#0B3D91]" />
                           Contenido del curso
                        </h2>
                        <span className="text-sm font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                           {totalResources} Recursos
                        </span>
                     </div>

                     <div className="p-6 bg-gray-50">
                        {modules.length > 0 ? (
                           <ModulesList modules={modules} courseId={course.id} />
                        ) : (
                           <div className="text-center py-4 text-gray-500">Cargando contenido...</div>
                        )}
                     </div>
                  </div>
                </motion.div>

                {/* Learning Outcomes */}
                <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="bg-white p-8 rounded-xl shadow-sm border border-gray-100"
                >
                    <h2 className="text-2xl font-bold text-[#1C1C1C] mb-6 flex items-center gap-2">
                        <CheckCircle className="text-[#0B3D91]" />
                        Lo que aprenderás
                    </h2>
                    <div className="grid md:grid-cols-2 gap-4">
                        {course.learningOutcomes?.map((outcome, idx) => (
                            <div key={idx} className="flex items-start gap-3">
                                <CheckCircle size={20} className="text-green-500 flex-shrink-0 mt-1" />
                                <span className="text-gray-700">{outcome}</span>
                            </div>
                        )) || (
                            <p className="text-gray-500 italic">Detalles de aprendizaje no disponibles.</p>
                        )}
                    </div>
                </motion.div>

                {/* Target Audience & Prerequisites */}
                <div className="grid md:grid-cols-2 gap-6">
                    <motion.div 
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="bg-white p-8 rounded-xl shadow-sm border border-gray-100"
                    >
                        <h3 className="text-xl font-bold text-[#1C1C1C] mb-4 flex items-center gap-2">
                            <Target className="text-[#CFAE70]" />
                            ¿Para quién es?
                        </h3>
                        <ul className="space-y-3">
                            {course.targetAudience?.map((audience, idx) => (
                                <li key={idx} className="flex items-start gap-3 text-gray-700 text-sm">
                                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></span>
                                    {audience}
                                </li>
                            ))}
                        </ul>
                    </motion.div>

                    <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="bg-white p-8 rounded-xl shadow-sm border border-gray-100"
                    >
                        <h3 className="text-xl font-bold text-[#1C1C1C] mb-4 flex items-center gap-2">
                            <AlertCircle className="text-[#CFAE70]" />
                            Requisitos previos
                        </h3>
                        <ul className="space-y-3">
                            {course.prerequisites?.map((req, idx) => (
                                <li key={idx} className="flex items-start gap-3 text-gray-700 text-sm">
                                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0"></span>
                                    {req}
                                </li>
                            ))}
                        </ul>
                    </motion.div>
                </div>
            </div>

            {/* Right Column - Sticky Sidebar */}
            <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-6">
                    {/* Enrollment Card */}
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="bg-white rounded-xl shadow-xl overflow-hidden border border-gray-100"
                    >
                        <div className="p-6 md:p-8">
                             <div className="flex items-end gap-2 mb-6">
                                <span className="text-4xl font-extrabold text-[#0B3D91]">{course.price}</span>
                                <span className="text-gray-500 line-through mb-1 text-lg">{(parseInt(course.price) * 1.5)}€</span>
                                <span className="text-green-600 font-bold text-sm mb-2 ml-auto">33% DTO</span>
                             </div>

                             <EnrollButton 
                                courseId={course.id} 
                                courseName={course.title}
                                onEnrollSuccess={handleEnrollSuccess}
                                className="mb-6"
                             />
                             
                             <div className="text-center text-xs text-gray-500 mb-6">
                                Acceso inmediato y garantía de satisfacción
                             </div>

                             <div className="space-y-4 pt-6 border-t border-gray-100">
                                <h4 className="font-bold text-gray-900 mb-2">Este curso incluye:</h4>
                                
                                <div className="flex items-center gap-3 text-sm text-gray-700">
                                    <Clock size={18} className="text-gray-400" />
                                    <span>{course.totalHours || course.duration} de video bajo demanda</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm text-gray-700">
                                    <Code size={18} className="text-gray-400" />
                                    <span>{course.projectCount || 2} proyectos prácticos</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm text-gray-700">
                                    <InfinityIcon size={18} className="text-gray-400" />
                                    <span>Acceso de por vida</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm text-gray-700">
                                    <Award size={18} className="text-gray-400" />
                                    <span>Certificado de finalización</span>
                                </div>
                             </div>
                        </div>
                    </motion.div>

                    {/* Corporate Training CTA */}
                    <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                        <h4 className="font-bold text-[#0B3D91] mb-2">¿Entrenamiento para equipos?</h4>
                        <p className="text-sm text-gray-600 mb-3">Obtén acceso para 5 o más personas con descuentos especiales.</p>
                        <Link to="/contact" className="text-sm font-semibold text-[#CFAE70] hover:text-[#b89a5f] hover:underline">
                            Contactar ventas corporativas
                        </Link>
                    </div>
                </div>
            </div>

          </div>
        </div>
      </section>
    </>
  );
};

export default CourseDetailPage;
