
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, MessageSquare, Calendar, Eye, Flag, Share2, ThumbsUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useForums } from '@/hooks/useForums';
import ForumReplyCard from '@/components/ForumReplyCard';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const ForumTopicDetailPage = () => {
  const { topicId } = useParams();
  const { getTopic, getReplies, getUsers, getCategories, createReply, incrementViews } = useForums();
  const { toast } = useToast();
  
  const [topic, setTopic] = useState(null);
  const [replyContent, setReplyContent] = useState('');
  
  useEffect(() => {
    const fetchedTopic = getTopic(topicId);
    if (fetchedTopic) {
      setTopic(fetchedTopic);
      incrementViews(topicId);
    }
  }, [topicId, getTopic, incrementViews]);

  if (!topic) return <div className="p-10 text-center">Cargando tema...</div>;

  const replies = getReplies(topicId);
  const author = getUsers().find(u => u.id === topic.authorId);
  const category = getCategories().find(c => c.id === topic.categoryId);

  const handleSubmitReply = (e) => {
    e.preventDefault();
    if (replyContent.length < 10) {
      toast({ title: "Error", description: "Tu respuesta es muy corta.", variant: "destructive" });
      return;
    }
    createReply(topicId, replyContent);
    setReplyContent('');
    toast({ title: "Respuesta publicada", description: "Gracias por contribuir." });
  };

  return (
    <>
      <Helmet>
        <title>{topic.title} | Foro Netcom</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link to="/forums" className="inline-flex items-center text-gray-500 hover:text-[#0B3D91] mb-6 transition-colors">
            <ArrowLeft size={18} className="mr-2" /> Volver a los foros
          </Link>

          {/* Topic Header */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mb-6">
            <div className="p-6 md:p-8">
              <div className="flex flex-wrap gap-2 mb-4">
                <span className={cn("text-xs font-bold px-2 py-1 rounded-full uppercase", category?.color)}>
                  {category?.name}
                </span>
                {topic.tags.map(tag => (
                  <span key={tag} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded border border-gray-200">
                    #{tag}
                  </span>
                ))}
              </div>

              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-6">{topic.title}</h1>

              <div className="flex items-center justify-between border-b border-gray-100 pb-6 mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#082d6b] flex items-center justify-center text-white font-bold">
                    {author?.avatar || 'U'}
                  </div>
                  <div>
                    <p className="font-bold text-gray-900 text-sm">{author?.name}</p>
                    <p className="text-xs text-gray-500">{new Date(topic.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
                
                <div className="flex gap-4 text-gray-400 text-sm">
                  <span className="flex items-center gap-1.5"><Eye size={16}/> {topic.views}</span>
                  <span className="flex items-center gap-1.5"><MessageSquare size={16}/> {replies.length}</span>
                </div>
              </div>

              <div className="prose max-w-none text-gray-700 leading-relaxed mb-8">
                {topic.content}
              </div>

              <div className="flex gap-3">
                <Button variant="outline" size="sm" className="gap-2">
                  <ThumbsUp size={16} /> Me gusta
                </Button>
                <Button variant="ghost" size="sm" className="gap-2 text-gray-500 ml-auto">
                  <Flag size={16} /> Reportar
                </Button>
                <Button variant="ghost" size="sm" className="gap-2 text-gray-500">
                  <Share2 size={16} /> Compartir
                </Button>
              </div>
            </div>
          </div>

          {/* Replies Section */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <MessageSquare className="text-[#0B3D91]" /> 
              {replies.length} Respuestas
            </h3>

            {replies.length > 0 ? (
              replies.map(reply => (
                <ForumReplyCard 
                  key={reply.id} 
                  reply={reply} 
                  isTopicAuthor={reply.authorId === topic.authorId}
                  isAccepted={reply.isAccepted}
                />
              ))
            ) : (
              <div className="text-center p-12 bg-white rounded-xl border border-dashed border-gray-300">
                <p className="text-gray-500">No hay respuestas aún. ¡Sé el primero en ayudar!</p>
              </div>
            )}

            {/* Reply Form */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 mt-8">
              <h4 className="font-bold text-gray-900 mb-4">Publicar tu respuesta</h4>
              <form onSubmit={handleSubmitReply}>
                <textarea
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg p-4 focus:ring-2 focus:ring-[#0B3D91]/20 outline-none resize-y min-h-[120px]"
                  placeholder="Escribe tu respuesta aquí. Sé amable y detallado..."
                  value={replyContent}
                  onChange={(e) => setReplyContent(e.target.value)}
                ></textarea>
                <div className="flex justify-end mt-4">
                  <Button type="submit" className="bg-[#0B3D91] hover:bg-[#082d6b]">
                    Publicar Respuesta
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForumTopicDetailPage;
