
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';
import { coursesData } from '@/data/coursesData';
import CourseCard from '@/components/CourseCard';
import PageBanner from '@/components/PageBanner';

const CoursesPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');

  const filteredCourses = coursesData.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || course.category === selectedCategory;
    const matchesLevel = selectedLevel === 'all' || course.level === selectedLevel;
    
    return matchesSearch && matchesCategory && matchesLevel;
  });

  const scrollToFilters = () => {
    document.getElementById('courses-filters').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Todos los Cursos - Netcom Academy</title>
        <meta name="description" content="Explora nuestro catálogo completo de cursos online de tecnología." />
      </Helmet>

      <PageBanner 
        title="Todos nuestros cursos"
        subtitle="Elige entre cientos de cursos para mejorar tus habilidades y transformar tu carrera profesional."
        cta={{ label: "Filtrar cursos", onClick: scrollToFilters }}
        backgroundImage="https://images.unsplash.com/photo-1695480497603-381a2bee1c05"
      />

      <section id="courses-filters" className="py-10 bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4">
          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-8 sticky top-20 z-10">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="text"
                    placeholder="Buscar cursos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:border-[#0B3D91] focus:ring-1 focus:ring-[#0B3D91]"
                  />
                </div>
              </div>

              <div>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:border-[#0B3D91]"
                >
                  <option value="all">Todas las categorías</option>
                  <option value="Programación">Programación</option>
                  <option value="IA y Datos">IA y Datos</option>
                  <option value="Ciberseguridad">Ciberseguridad</option>
                  <option value="Productividad">Productividad</option>
                </select>
              </div>

              <div>
                <select
                  value={selectedLevel}
                  onChange={(e) => setSelectedLevel(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:border-[#0B3D91]"
                >
                  <option value="all">Todos los niveles</option>
                  <option value="Principiante">Principiante</option>
                  <option value="Intermedio">Intermedio</option>
                  <option value="Avanzado">Avanzado</option>
                </select>
              </div>
            </div>

            <div className="mt-3 text-xs text-gray-500">
              Mostrando <span className="font-bold text-gray-900">{filteredCourses.length}</span> cursos
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredCourses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.5) }}
              >
                <CourseCard course={course} />
              </motion.div>
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-16">
              <p className="text-gray-500">
                No se encontraron cursos con los filtros seleccionados
              </p>
              <button 
                onClick={() => {setSearchTerm(''); setSelectedCategory('all'); setSelectedLevel('all');}}
                className="mt-4 text-[#0B3D91] font-semibold hover:underline"
              >
                Limpiar filtros
              </button>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default CoursesPage;
