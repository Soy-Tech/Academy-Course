
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import CommentSection from '@/components/CommentSection';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Heart, MessageCircle, User, Edit, Trash2 } from 'lucide-react';

const PostDetailPage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasLiked, setHasLiked] = useState(false);

  useEffect(() => {
    fetchPost();
  }, [id]);

  const fetchPost = async () => {
    try {
      const { data, error } = await supabase
        .from('community_posts')
        .select(`
          *,
          users (name, profile_photo_url, specialty)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      setPost(data);

      // Check if user has liked this post
      if (user) {
        const { data: likeData } = await supabase
          .from('post_likes')
          .select('*')
          .eq('post_id', id)
          .eq('user_id', user.id)
          .single();
        
        setHasLiked(!!likeData);
      }
    } catch (error) {
      console.error('Error fetching post:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLike = async () => {
    if (!user) {
      toast({
        title: 'Inicia sesión',
        description: 'Debes iniciar sesión para dar me gusta.',
        variant: 'destructive'
      });
      return;
    }

    try {
      if (hasLiked) {
        await supabase
          .from('post_likes')
          .delete()
          .eq('post_id', id)
          .eq('user_id', user.id);

        await supabase
          .from('community_posts')
          .update({ likes_count: (post.likes_count || 0) - 1 })
          .eq('id', id);

        setHasLiked(false);
        setPost(prev => ({ ...prev, likes_count: (prev.likes_count || 0) - 1 }));
      } else {
        await supabase
          .from('post_likes')
          .insert({ post_id: id, user_id: user.id });

        await supabase
          .from('community_posts')
          .update({ likes_count: (post.likes_count || 0) + 1 })
          .eq('id', id);

        setHasLiked(true);
        setPost(prev => ({ ...prev, likes_count: (prev.likes_count || 0) + 1 }));
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudo actualizar el me gusta.',
        variant: 'destructive'
      });
    }
  };

  const handleDelete = async () => {
    if (!confirm('¿Estás seguro de que quieres eliminar esta publicación?')) return;

    try {
      const { error } = await supabase
        .from('community_posts')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Publicación eliminada',
        description: 'La publicación se ha eliminado correctamente.'
      });

      navigate('/community');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudo eliminar la publicación.',
        variant: 'destructive'
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0B3D91]"></div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Publicación no encontrada</h2>
          <Link to="/community">
            <Button className="btn-primary">Volver a la comunidad</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{post.title} - Comunidad - Netcom Academy</title>
        <meta name="description" content={post.content.substring(0, 160)} />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link to="/community" className="inline-flex items-center text-[#0B3D91] hover:text-[#CFAE70] mb-8 transition-colors">
            <ArrowLeft size={20} className="mr-2" />
            Volver a la comunidad
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-lg p-8 mb-6"
          >
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#CFAE70] flex items-center justify-center text-white font-bold">
                  {post.users?.profile_photo_url ? (
                    <img src={post.users.profile_photo_url} alt="" className="w-full h-full rounded-full object-cover" />
                  ) : (
                    <User size={28} />
                  )}
                </div>
                <div>
                  <Link to={`/student/${post.user_id}`} className="font-semibold text-gray-900 hover:text-[#0B3D91]">
                    {post.users?.name || 'Usuario'}
                  </Link>
                  <p className="text-sm text-gray-600">{post.users?.specialty || 'Estudiante'}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(post.created_at).toLocaleDateString('es-ES', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              {user?.id === post.user_id && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Edit size={16} className="mr-2" />
                    Editar
                  </Button>
                  <Button variant="destructive" size="sm" onClick={handleDelete}>
                    <Trash2 size={16} className="mr-2" />
                    Eliminar
                  </Button>
                </div>
              )}
            </div>

            <span className="inline-block px-3 py-1 bg-[#0B3D91] bg-opacity-10 text-[#0B3D91] rounded-full text-sm font-medium mb-4">
              {post.category}
            </span>

            <h1 className="text-3xl font-bold text-gray-900 mb-4">{post.title}</h1>
            
            <div className="prose max-w-none text-gray-700 mb-6">
              {post.content}
            </div>

            <div className="flex items-center gap-6 pt-6 border-t">
              <button
                onClick={handleLike}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                  hasLiked
                    ? 'bg-red-50 text-red-600'
                    : 'hover:bg-gray-100 text-gray-600'
                }`}
              >
                <Heart size={20} fill={hasLiked ? 'currentColor' : 'none'} />
                <span className="font-semibold">{post.likes_count || 0}</span>
              </button>
              
              <div className="flex items-center gap-2 text-gray-600">
                <MessageCircle size={20} />
                <span className="font-semibold">{post.comment_count || 0} comentarios</span>
              </div>
            </div>
          </motion.div>

          <CommentSection postId={id} />
        </div>
      </div>
    </>
  );
};

export default PostDetailPage;
