
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Search, Plus, MessageSquare, Filter, TrendingUp, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useForums } from '@/hooks/useForums';
import { useToast } from '@/components/ui/use-toast';
import ForumTopicCard from '@/components/ForumTopicCard';
import ForumTopicForm from '@/components/ForumTopicForm';
import { mockForumUsers } from '@/data/forumsData';
import { cn } from '@/lib/utils';
import PageBanner from '@/components/PageBanner';

const ForumsPage = () => {
  const { getTopics, createTopic, getCategories } = useForums();
  const { toast } = useToast();
  const categories = getCategories();

  // State
  const [activeCategory, setActiveCategory] = useState(null);
  const [sortBy, setSortBy] = useState('recent');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch filtered topics
  const topics = getTopics(activeCategory, sortBy, searchTerm);
  
  // Fetch popular topics for sidebar (independent of filters)
  const popularTopics = getTopics(null, 'popular').slice(0, 5);

  const handleCreateTopic = (data) => {
    createTopic(data.title, data.content, data.categoryId, data.tags);
    setIsModalOpen(false);
    toast({
      title: "¡Tema publicado!",
      description: "Tu tema ha sido creado exitosamente y ya es visible para la comunidad.",
      variant: "default",
      className: "bg-green-50 border-green-200 text-green-800"
    });
  };

  return (
    <>
      <Helmet>
        <title>Foros de la Comunidad | Netcom Academy</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen pb-20">
        
        {/* Unified Page Banner */}
        <PageBanner 
          title="Foros de la comunidad"
          subtitle="Haz preguntas, comparte conocimiento y conecta con otros estudiantes y expertos."
          backgroundImage="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
          height="h-[350px] md:h-[400px]"
        />

        <div className="container mx-auto px-4 -mt-10 relative z-20">
          
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-5 md:p-6 mb-8 flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative w-full md:w-96 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0B3D91] transition-colors" size={20} />
              <input 
                type="text" 
                placeholder="Buscar temas, dudas o etiquetas..." 
                className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0B3D91]/20 focus:border-[#0B3D91] transition-all text-sm font-medium"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <div className="relative">
                 <select 
                   className="w-full sm:w-auto appearance-none bg-gray-50 border border-gray-200 rounded-lg pl-4 pr-10 py-3 text-sm font-medium text-gray-700 outline-none focus:ring-2 focus:ring-[#0B3D91]/20 cursor-pointer hover:bg-gray-100 transition-colors"
                   value={sortBy}
                   onChange={(e) => setSortBy(e.target.value)}
                 >
                   <option value="recent">Más Recientes</option>
                   <option value="popular">Más Populares</option>
                   <option value="unanswered">Sin Responder</option>
                   <option value="solved">Resueltos</option>
                 </select>
                 <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <Filter size={16} />
                 </div>
              </div>
              
              <Button 
                onClick={() => setIsModalOpen(true)}
                className="bg-[#CFAE70] hover:bg-[#b5955a] text-white gap-2 flex-1 md:flex-none whitespace-nowrap py-6 shadow-md font-bold"
              >
                <Plus size={20} /> Nuevo Tema
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3 space-y-6 order-2 lg:order-1">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 sticky top-24">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 pb-3 border-b border-gray-50 text-sm uppercase tracking-wide">
                  <Filter size={18} className="text-[#0B3D91]" /> Categorías
                </h3>
                <div className="space-y-1">
                  <button
                    onClick={() => setActiveCategory(null)}
                    className={cn(
                      "w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-all flex items-center justify-between group",
                      activeCategory === null 
                        ? "bg-[#0B3D91]/10 text-[#0B3D91] shadow-sm" 
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    )}
                  >
                    <span>Todas las categorías</span>
                  </button>
                  {categories.map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id)}
                      className={cn(
                        "w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-all flex items-center justify-between group",
                        activeCategory === cat.id 
                          ? "bg-[#0B3D91]/10 text-[#0B3D91] shadow-sm" 
                          : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                      )}
                    >
                      <span className="flex items-center gap-2">
                        <span className="text-base">{cat.icon}</span> {cat.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 space-y-4 order-1 lg:order-2">
               <div className="flex items-center justify-between mb-2 px-1">
                  <h2 className="font-bold text-gray-800 text-lg">
                    {activeCategory ? categories.find(c => c.id === activeCategory)?.name : 'Discusiones Recientes'}
                  </h2>
                  <span className="text-xs font-semibold text-gray-500 bg-white border border-gray-200 px-3 py-1 rounded-full shadow-sm">{topics.length} resultados</span>
               </div>

              {topics.length > 0 ? (
                topics.map(topic => (
                  <ForumTopicCard key={topic.id} topic={topic} />
                ))
              ) : (
                <div className="bg-white rounded-xl border border-dashed border-gray-300 p-12 text-center shadow-sm">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
                    <MessageSquare size={32} />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">No se encontraron temas</h3>
                  <p className="text-gray-500 mb-6 max-w-xs mx-auto">
                    {searchTerm 
                      ? `No hay resultados para "${searchTerm}". Intenta con otros términos.` 
                      : "Sé el primero en iniciar una conversación en esta categoría."}
                  </p>
                  <Button onClick={() => setIsModalOpen(true)} variant="outline" className="border-[#0B3D91] text-[#0B3D91] hover:bg-[#0B3D91]/5">
                    Crear nuevo tema
                  </Button>
                </div>
              )}
            </div>

            <div className="lg:col-span-3 space-y-6 order-3">
               <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 sticky top-24">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 pb-3 border-b border-gray-50 text-sm uppercase tracking-wide">
                     <TrendingUp size={18} className="text-[#CFAE70]" /> Destacados
                  </h3>
                  <div className="space-y-4">
                     {popularTopics.map((topic, index) => (
                        <div key={topic.id} className="group cursor-pointer border-b border-gray-50 last:border-0 pb-3 last:pb-0">
                           <Link to={`/forums/${topic.id}`}>
                              <h4 className="text-sm font-semibold text-gray-800 group-hover:text-[#0B3D91] transition-colors line-clamp-2 mb-1">
                                 {index + 1}. {topic.title}
                              </h4>
                              <div className="flex items-center gap-3 text-xs text-gray-400">
                                 <span>{topic.views} vistas</span>
                                 <span>•</span>
                                 <span>{new Date(topic.createdAt).toLocaleDateString()}</span>
                              </div>
                           </Link>
                        </div>
                     ))}
                  </div>
                  
                  <div className="mt-8 pt-6 border-t border-gray-100">
                     <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-sm uppercase tracking-wide">
                        <Users size={18} className="text-blue-500" /> Estadísticas
                     </h3>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="bg-gray-50 p-3 rounded-lg text-center border border-gray-100">
                           <span className="block text-xl font-bold text-[#0B3D91]">{topics.length}</span>
                           <span className="text-xs text-gray-500 font-medium uppercase">Temas</span>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-lg text-center border border-gray-100">
                           <span className="block text-xl font-bold text-[#0B3D91]">{mockForumUsers.length}</span>
                           <span className="text-xs text-gray-500 font-medium uppercase">Usuarios</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>

      <ForumTopicForm 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSubmit={handleCreateTopic} 
      />
    </>
  );
};

export default ForumsPage;
