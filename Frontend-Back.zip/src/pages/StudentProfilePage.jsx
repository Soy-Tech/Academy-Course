
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { ArrowLeft, User, Award, BookOpen, MessageCircle, Calendar } from 'lucide-react';

const StudentProfilePage = () => {
  const { userId } = useParams();
  const [student, setStudent] = useState(null);
  const [stats, setStats] = useState({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStudentProfile();
  }, [userId]);

  const fetchStudentProfile = async () => {
    try {
      const [profileData, rankingData, postsData, commentsData, eventsData] = await Promise.all([
        supabase.from('users').select('*').eq('id', userId).single(),
        supabase.from('user_rankings').select('*').eq('user_id', userId).single(),
        supabase.from('community_posts').select('id').eq('user_id', userId),
        supabase.from('community_comments').select('id').eq('user_id', userId),
        supabase.from('event_registrations').select('id').eq('user_id', userId)
      ]);

      setStudent(profileData.data);
      setStats({
        rank: rankingData.data?.rank || 0,
        points: rankingData.data?.points || 0,
        posts: postsData.data?.length || 0,
        comments: commentsData.data?.length || 0,
        events: eventsData.data?.length || 0
      });
    } catch (error) {
      console.error('Error fetching student profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0B3D91]"></div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Perfil no encontrado</h2>
          <Link to="/rankings">
            <button className="btn-primary">Volver al ranking</button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{student.name} - Perfil de Estudiante - Netcom Academy</title>
        <meta name="description" content={`Perfil de ${student.name} en Netcom Academy`} />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-5xl">
          <Link to="/rankings" className="inline-flex items-center text-[#0B3D91] hover:text-[#CFAE70] mb-8 transition-colors">
            <ArrowLeft size={20} className="mr-2" />
            Volver al ranking
          </Link>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8"
          >
            <div className="bg-gradient-to-r from-[#0B3D91] to-[#082d6b] p-8 text-white">
              <div className="flex items-start gap-6">
                <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center text-4xl font-bold">
                  {student.profile_photo_url ? (
                    <img src={student.profile_photo_url} alt="" className="w-full h-full rounded-full object-cover" />
                  ) : (
                    student.name?.charAt(0) || 'U'
                  )}
                </div>
                <div className="flex-grow">
                  <h1 className="text-4xl font-bold mb-2">{student.name}</h1>
                  <p className="text-xl text-gray-200 mb-4">{student.specialty || 'Estudiante'}</p>
                  {student.bio && (
                    <p className="text-gray-200 max-w-2xl">{student.bio}</p>
                  )}
                </div>
              </div>
            </div>

            <div className="p-8">
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Award className="mx-auto text-[#CFAE70] mb-2" size={32} />
                  <p className="text-2xl font-bold text-gray-900">{stats.points}</p>
                  <p className="text-sm text-gray-600">Puntos</p>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <MessageCircle className="mx-auto text-[#0B3D91] mb-2" size={32} />
                  <p className="text-2xl font-bold text-gray-900">{stats.posts}</p>
                  <p className="text-sm text-gray-600">Publicaciones</p>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <BookOpen className="mx-auto text-green-600 mb-2" size={32} />
                  <p className="text-2xl font-bold text-gray-900">{stats.comments}</p>
                  <p className="text-sm text-gray-600">Comentarios</p>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <Calendar className="mx-auto text-orange-600 mb-2" size={32} />
                  <p className="text-2xl font-bold text-gray-900">{stats.events}</p>
                  <p className="text-sm text-gray-600">Eventos</p>
                </div>

                <div className="text-center p-4 bg-gray-50 rounded-lg">
                  <User className="mx-auto text-purple-600 mb-2" size={32} />
                  <p className="text-2xl font-bold text-gray-900">#{stats.rank || 'N/A'}</p>
                  <p className="text-sm text-gray-600">Ranking</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl shadow-lg p-8"
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Actividad reciente</h2>
            <div className="text-center py-12 text-gray-500">
              La actividad detallada estará disponible próximamente
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default StudentProfilePage;
