
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, PlayCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProgressBar from '@/components/ProgressBar';
import PageBanner from '@/components/PageBanner';
import { useStudentCourses } from '@/hooks/useStudentCourses';

const StudentCoursesListPage = () => {
  const { studentCourses, loading } = useStudentCourses();

  if (loading) {
     return <div className="min-h-screen bg-gray-50 flex items-center justify-center">Cargando...</div>;
  }

  return (
    <>
      <Helmet>
        <title>Mis Cursos - Netcom Academy</title>
      </Helmet>

      <PageBanner 
        title="Mi Aprendizaje"
        subtitle="Continúa donde lo dejaste y alcanza tus metas profesionales."
        backgroundImage="https://images.unsplash.com/photo-1516321318423-f06f85e504b3"
        height="h-[250px]"
      />

      <section className="py-12 bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Cursos en progreso</h2>
          
          {studentCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {studentCourses.map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow border border-gray-100 overflow-hidden flex flex-col h-full"
                >
                  <div className="relative h-48 overflow-hidden group">
                    <img 
                      src={course.image} 
                      alt={course.title} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                       <Link to={`/student/courses/${course.id}`}>
                          <Button className="rounded-full w-14 h-14 bg-white/20 backdrop-blur-sm hover:bg-white/40 border-2 border-white text-white p-0">
                             <PlayCircle size={32} fill="currentColor" className="opacity-100" />
                          </Button>
                       </Link>
                    </div>
                  </div>

                  <div className="p-6 flex flex-col flex-1">
                    <div className="mb-2">
                       <h3 className="text-xl font-bold text-gray-900 line-clamp-2">
                          {course.title}
                       </h3>
                       <p className="text-sm text-gray-500 mt-1">{course.instructor}</p>
                    </div>
                    
                    <div className="mt-auto pt-6 space-y-4">
                       <div className="flex justify-between text-xs text-gray-600 mb-1">
                          <span>{course.completedLessons} de {course.totalLessons} lecciones</span>
                          <span>{course.progress}%</span>
                       </div>
                       <ProgressBar percentage={course.progress} showText={false} size="sm" />
                       
                       <div className="flex gap-3 pt-2">
                          <Link to={`/student/courses/${course.id}`} className="flex-1">
                             <Button className="w-full bg-[#0B3D91] hover:bg-[#082d6b]">
                                {course.progress > 0 ? 'Continuar curso' : 'Comenzar curso'}
                             </Button>
                          </Link>
                       </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white rounded-2xl shadow-sm border border-gray-100">
               <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-400">
                  <BookOpen size={40} />
               </div>
               <h2 className="text-2xl font-bold text-gray-900 mb-2">No tienes cursos activos</h2>
               <p className="text-gray-500 mb-8 max-w-md mx-auto">Explora nuestro catálogo y comienza tu viaje de aprendizaje hoy mismo.</p>
               <Link to="/cursos">
                  <Button size="lg" className="bg-[#0B3D91] hover:bg-[#082d6b]">
                     Explorar Cursos
                  </Button>
               </Link>
            </div>
          )}
        </div>
      </section>
    </>
  );
};

export default StudentCoursesListPage;
