
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { PlayCircle, Award, Clock, BookOpen, CheckCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { getHydratedCourseData } from '@/data/mockLessons';
import { getCourseProgress, getLastAccessedLesson } from '@/utils/progressUtils';
import { useEnrollment } from '@/contexts/EnrollmentContext';

const StudentCoursePage = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { isEnrolled } = useEnrollment();
  const [courseData, setCourseData] = useState(null);
  const [progress, setProgress] = useState({ completedCount: 0, percentage: 0 });
  
  useEffect(() => {
    // Basic enrollment check
    if (!isEnrolled(courseId)) {
      navigate(`/cursos/${courseId}`);
      return;
    }

    const data = getHydratedCourseData(courseId);
    if (data) {
      setCourseData(data);
      const prog = getCourseProgress(courseId, data.totalLessons);
      setProgress(prog);
    }
  }, [courseId, isEnrolled, navigate]);

  const handleStartLearning = () => {
    const lastLessonId = getLastAccessedLesson(courseId);
    const firstLessonId = courseData?.sections[0]?.lessons[0]?.id;
    const targetId = lastLessonId || firstLessonId;
    
    if (targetId) {
      navigate(`/course/${courseId}/lesson/${targetId}`);
    }
  };

  if (!courseData) return null;

  return (
    <>
      <Helmet>
        <title>{courseData.title} | Dashboard</title>
      </Helmet>

      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Course Header Banner */}
        <div className="bg-[#0B3D91] text-white py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <span className="inline-block px-3 py-1 bg-white/10 rounded-full text-xs font-medium backdrop-blur-sm mb-4">
                Curso Enrolado
              </span>
              <h1 className="text-3xl md:text-4xl font-bold mb-4">{courseData.title}</h1>
              <p className="text-blue-100 text-lg mb-8 max-w-2xl">{courseData.description}</p>
              
              <div className="flex flex-wrap items-center gap-6 text-sm font-medium text-blue-200">
                <div className="flex items-center gap-2">
                  <Award size={18} />
                  <span>Instructor: {courseData.instructor}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock size={18} />
                  <span>Duración estimada: 10h 30m</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen size={18} />
                  <span>{courseData.totalLessons} Lecciones</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 -mt-8">
          <div className="max-w-4xl mx-auto">
            {/* Progress Card */}
            <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 mb-8">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
                <div>
                  <h2 className="text-xl font-bold text-gray-900 mb-1">Tu Progreso</h2>
                  <p className="text-gray-500 text-sm">
                    Has completado {progress.completedCount} de {courseData.totalLessons} lecciones
                  </p>
                </div>
                <Button 
                  onClick={handleStartLearning}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-md hover:shadow-lg transition-all text-base px-8 py-6 h-auto"
                >
                  <PlayCircle className="mr-2 h-5 w-5" />
                  {progress.percentage > 0 ? 'Continuar Aprendiendo' : 'Comenzar Curso'}
                </Button>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm font-semibold mb-1">
                  <span className={progress.percentage === 100 ? "text-emerald-600" : "text-blue-600"}>
                    {progress.percentage}% Completado
                  </span>
                </div>
                <Progress value={progress.percentage} className="h-3" />
              </div>
            </div>

            {/* Course Content List */}
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-900">Contenido del Curso</h3>
              
              <div className="space-y-4">
                {courseData.sections.map((section, idx) => (
                  <div key={section.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                    <div className="bg-gray-50 px-6 py-4 border-b border-gray-100">
                      <h4 className="font-semibold text-gray-800">Módulo {idx + 1}: {section.title}</h4>
                    </div>
                    <div className="divide-y divide-gray-100">
                      {section.lessons.map((lesson) => (
                        <div 
                          key={lesson.id} 
                          className="px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors group cursor-pointer"
                          onClick={() => navigate(`/course/${courseId}/lesson/${lesson.id}`)}
                        >
                          <div className="flex items-center gap-4">
                            <div className={`
                              w-8 h-8 rounded-full flex items-center justify-center shrink-0
                              ${lesson.isCompleted ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}
                            `}>
                              {lesson.isCompleted ? <CheckCircle size={16} /> : <PlayCircle size={16} />}
                            </div>
                            <div>
                              <p className={`font-medium ${lesson.isCompleted ? 'text-gray-500' : 'text-gray-900'}`}>
                                {lesson.title}
                              </p>
                              <p className="text-xs text-gray-400 mt-0.5">{Math.floor(lesson.duration / 60)} min • {lesson.type}</p>
                            </div>
                          </div>
                          <ArrowRight size={16} className="text-gray-300 group-hover:text-blue-500 transition-colors" />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default StudentCoursePage;
