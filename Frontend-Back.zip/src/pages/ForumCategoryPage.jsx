
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { mockForumTopics, mockForumCategories } from '@/data/mockForum';
import { ArrowLeft, MessageCircle, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ForumCategoryPage = () => {
  const { categoryId } = useParams();
  const category = mockForumCategories.find(c => c.id === categoryId);
  const topics = mockForumTopics.filter(t => t.categoryId === categoryId);

  if (!category) return <div className="text-center py-20">Categoría no encontrada</div>;

  return (
    <>
      <Helmet>
        <title>{category.title} - Foro Netcom</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-5xl">
          <Link to="/forum" className="inline-flex items-center text-[#0B3D91] mb-6 hover:underline">
            <ArrowLeft size={16} className="mr-2" /> Volver al foro
          </Link>

          <div className="flex justify-between items-center mb-8">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">{category.title}</h1>
                <p className="text-gray-600">{category.description}</p>
            </div>
            <Button className="btn-primary">Crear Tema</Button>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
             {topics.length > 0 ? (
                 topics.map((topic, i) => (
                    <div key={topic.id} className={`p-6 flex items-center justify-between hover:bg-gray-50 transition-colors ${i !== topics.length -1 ? 'border-b border-gray-100' : ''}`}>
                        <div>
                            <Link to={`/forum/${categoryId}/${topic.id}`} className="text-lg font-semibold text-gray-900 hover:text-[#0B3D91]">
                                {topic.title}
                            </Link>
                            <div className="text-sm text-gray-500 mt-1">
                                Por <span className="font-medium text-gray-700">{topic.author}</span> • {topic.date}
                            </div>
                        </div>
                        <div className="flex gap-6 text-sm text-gray-400">
                            <div className="text-center">
                                <span className="block font-bold text-gray-600">{topic.replies.length}</span>
                                <span className="flex items-center gap-1"><MessageCircle size={12}/> Resp.</span>
                            </div>
                            <div className="text-center">
                                <span className="block font-bold text-gray-600">{topic.views}</span>
                                <span className="flex items-center gap-1"><Eye size={12}/> Vistas</span>
                            </div>
                        </div>
                    </div>
                 ))
             ) : (
                 <div className="p-8 text-center text-gray-500">No hay temas en esta categoría aún.</div>
             )}
          </div>
        </div>
      </div>
    </>
  );
};

export default ForumCategoryPage;
