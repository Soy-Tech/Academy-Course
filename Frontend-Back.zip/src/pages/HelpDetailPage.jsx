
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { mockHelpGuides } from '@/data/mockHelp';
import { ArrowLeft, BookOpen } from 'lucide-react';

const HelpDetailPage = () => {
  const { guideId } = useParams();
  const guide = mockHelpGuides.find(g => g.id === guideId);

  if (!guide) return <div className="text-center py-20">Guía no encontrada</div>;

  return (
    <>
      <Helmet>
        <title>{guide.title} - Ayuda Netcom</title>
      </Helmet>

      <div className="bg-white min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-3xl">
           <Link to="/help" className="inline-flex items-center text-[#0B3D91] mb-8 hover:underline">
            <ArrowLeft size={16} className="mr-2" /> Volver al centro de ayuda
          </Link>

          <h1 className="text-3xl font-bold text-gray-900 mb-4">{guide.title}</h1>
          <div className="flex items-center gap-2 mb-8">
             <BookOpen size={16} className="text-gray-400"/>
             <span className="text-sm text-gray-500">{guide.category}</span>
          </div>

          <div className="prose prose-blue max-w-none text-gray-700 bg-gray-50 p-8 rounded-xl">
             <p className="lead">{guide.description}</p>
             <hr className="my-6 border-gray-200"/>
             <p>{guide.content}</p>
             <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default HelpDetailPage;
