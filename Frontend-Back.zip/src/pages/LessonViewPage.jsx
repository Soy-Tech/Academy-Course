
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Menu, ChevronRight, FileText, AlertCircle, PlayCircle, Download, File, Beaker } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import CourseSidebar from '@/components/CourseSidebar';
import VideoPlayer from '@/components/VideoPlayer';
import { getResourceById, generateModulesForCourse } from '@/data/mockCourseModules';
import { coursesData } from '@/data/coursesData';
import { saveLessonProgress } from '@/utils/progressUtils';
import { cn } from '@/lib/utils';

const LessonViewPage = () => {
  const { courseId, lessonId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [course, setCourse] = useState(null);
  const [currentResource, setCurrentResource] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [resourceNotFound, setResourceNotFound] = useState(false);
  const [modules, setModules] = useState([]);

  // Load Course and Modules Data
  useEffect(() => {
    if (courseId) {
      // Find course basic info (title etc)
      const foundCourse = coursesData.find(c => c.id === courseId);
      
      // Generate dynamic modules for the course
      const generatedModules = generateModulesForCourse(courseId);
      
      if (generatedModules.length > 0) {
         setModules(generatedModules);
         
         // Set course info - use found course or synthetic if not found in catalog
         setCourse({
            id: courseId,
            title: foundCourse?.title || "Curso", 
            sections: [] // Backward compatibility for any old sidebar logic
         });
      } else {
        // Should rarely happen with dynamic generation, but fallback to catalog
        navigate('/student/courses');
      }
    }
  }, [courseId, navigate]);

  // Load Lesson/Resource Data
  useEffect(() => {
    if (courseId && lessonId) {
      // Find resource in generated modules
      const resource = getResourceById(courseId, lessonId);
      
      if (resource) {
        setCurrentResource(resource);
        setResourceNotFound(false);
      } else {
        setResourceNotFound(true);
        setCurrentResource(null);
      }
    }
  }, [courseId, lessonId]);

  const handleResourceComplete = () => {
    if (currentResource) {
      saveLessonProgress(courseId, currentResource.id, true);
      
      toast({
        title: "¡Recurso completado!",
        description: "Progreso guardado correctamente.",
        className: "bg-green-50 border-green-200 text-green-800",
      });
    }
  };

  const navigateToNext = () => {
    toast({
        title: "Navegación",
        description: "Esta funcionalidad se implementará completamente pronto.",
    });
  };

  // Render content based on resource type
  const renderContent = () => {
    if (!currentResource) return null;

    switch (currentResource.type) {
      case 'video':
        return (
          <div className="mb-8">
             <VideoPlayer 
                videoUrl={currentResource.videoUrl}
                title={currentResource.title}
                lessonId={currentResource.id}
                onEnded={handleResourceComplete}
             />
          </div>
        );
      
      case 'pdf':
        return (
          <div className="bg-white p-8 rounded-xl border border-gray-200 text-center mb-8">
            <FileText size={64} className="mx-auto text-orange-500 mb-4" />
            <h2 className="text-xl font-bold mb-2">{currentResource.title}</h2>
            <p className="text-gray-500 mb-6">Documento PDF disponible para lectura.</p>
            <Button className="gap-2" onClick={() => window.open(currentResource.url, '_blank')}>
              <Download size={16} /> Abrir PDF
            </Button>
          </div>
        );

      case 'doc':
        return (
          <div className="bg-white p-8 rounded-xl border border-gray-200 text-center mb-8">
            <File size={64} className="mx-auto text-blue-500 mb-4" />
            <h2 className="text-xl font-bold mb-2">{currentResource.title}</h2>
            <p className="text-gray-500 mb-6">Documentación de referencia externa.</p>
            <Button variant="outline" className="gap-2" onClick={() => window.open(currentResource.url, '_blank')}>
              <FileText size={16} /> Ver Documentación
            </Button>
          </div>
        );

      case 'file':
        return (
          <div className="bg-white p-8 rounded-xl border border-gray-200 text-center mb-8">
            <Download size={64} className="mx-auto text-green-500 mb-4" />
            <h2 className="text-xl font-bold mb-2">{currentResource.title}</h2>
            <p className="text-gray-500 mb-6">Archivo listo para descargar.</p>
            <Button className="gap-2 bg-green-600 hover:bg-green-700" onClick={() => window.open(currentResource.url, '_blank')}>
              <Download size={16} /> Descargar Archivo
            </Button>
          </div>
        );

      case 'activity':
        return (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden mb-8">
            <div className="bg-purple-600 p-6 text-white">
               <div className="flex items-center gap-3 mb-2">
                  <Beaker size={24} />
                  <span className="font-bold uppercase tracking-wider text-sm">Actividad Práctica</span>
               </div>
               <h2 className="text-2xl font-bold">{currentResource.title}</h2>
            </div>
            <div className="p-8">
               <h3 className="font-bold text-gray-900 mb-4">Instrucciones:</h3>
               <div className="prose max-w-none text-gray-700 bg-gray-50 p-6 rounded-lg border border-gray-100">
                  {currentResource.instructions}
               </div>
               <div className="mt-8 flex justify-end">
                  <Button onClick={handleResourceComplete}>
                     Marcar como Completada
                  </Button>
               </div>
            </div>
          </div>
        );

      default:
        return (
           <div className="p-8 text-center text-gray-500">
              Tipo de recurso no soportado: {currentResource.type}
           </div>
        );
    }
  };

  // Fallback UI for missing lesson
  if (resourceNotFound) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center p-8 bg-white rounded-xl shadow-sm border border-gray-200 max-w-md">
          <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle size={32} />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Recurso no encontrado</h2>
          <p className="text-gray-500 mb-6">No pudimos encontrar el recurso solicitado.</p>
          <Button onClick={() => navigate(`/student/courses/${courseId}`)}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Volver al Curso
          </Button>
        </div>
      </div>
    );
  }

  // Loading State
  if (!course || !currentResource) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-8 w-64 bg-gray-200 rounded mb-4"></div>
          <div className="h-4 w-48 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{currentResource.title} | {course.title}</title>
      </Helmet>

      <div className="flex h-screen bg-white overflow-hidden">
        {/* Mobile Sidebar Overlay */}
        {isSidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-20 md:hidden"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <div className={cn(
          "fixed md:relative inset-y-0 left-0 z-30 w-80 bg-white shadow-xl md:shadow-none transform transition-transform duration-300 ease-in-out border-r border-gray-200",
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 md:w-0 md:border-none'
        )}>
          <div className="h-full w-80 overflow-hidden">
             {/* Pass generated modules to Sidebar */}
             <CourseSidebar 
               course={course}
               modules={modules}
               currentLessonId={lessonId}
               isOpen={isSidebarOpen}
               onClose={() => setIsSidebarOpen(false)}
             />
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
          {/* Top Bar */}
          <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 shrink-0 z-10">
            <div className="flex items-center gap-3">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="text-gray-500 hover:text-gray-900"
              >
                <Menu size={20} />
              </Button>
              <div className="flex items-center gap-2 text-sm">
                <Button 
                  variant="ghost" 
                  className="text-gray-500 hover:text-gray-900 px-2 h-8"
                  onClick={() => navigate(`/course/${courseId}`)}
                >
                  <ArrowLeft size={16} className="mr-2" />
                  Volver al curso
                </Button>
                <span className="text-gray-300">|</span>
                <span className="font-semibold text-gray-900 truncate max-w-[200px] md:max-w-md">
                  {currentResource.title}
                </span>
              </div>
            </div>
            
            <div className="hidden sm:block">
              <Button 
                variant="outline"
                size="sm"
                className="text-xs"
                onClick={navigateToNext}
              >
                Siguiente <ChevronRight size={14} className="ml-1" />
              </Button>
            </div>
          </header>

          {/* Lesson Content */}
          <main className="flex-1 overflow-y-auto bg-gray-50">
            <div className="max-w-5xl mx-auto p-4 md:p-8">
              {renderContent()}

              {/* Resource Info / Details */}
              {(currentResource.description || currentResource.instructions) && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8">
                    <h1 className="text-2xl font-bold text-gray-900 mb-4">{currentResource.title}</h1>
                    {currentResource.description && (
                      <p className="text-gray-600 leading-relaxed mb-4">
                        {currentResource.description}
                      </p>
                    )}
                     {currentResource.instructions && (
                      <div className="text-gray-600 leading-relaxed">
                        <h4 className="font-semibold mb-2">Instrucciones:</h4>
                        <p>{currentResource.instructions}</p>
                      </div>
                    )}
                  </div>
              )}
            </div>
          </main>
        </div>
      </div>
    </>
  );
};

export default LessonViewPage;
