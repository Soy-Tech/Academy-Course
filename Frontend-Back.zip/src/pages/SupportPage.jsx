
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Mail, MessageCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';

const SupportPage = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem('support_tickets') || '[]');
    setTickets(stored);
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    const newTicket = {
        id: `TICK-${Date.now().toString().slice(-6)}`,
        ...formData,
        status: 'open',
        date: new Date().toLocaleDateString()
    };

    const updated = [newTicket, ...tickets];
    setTickets(updated);
    localStorage.setItem('support_tickets', JSON.stringify(updated));
    setFormData({ name: '', email: '', subject: '', message: '' });
    
    toast({ title: 'Ticket creado', description: `Ticket #${newTicket.id} recibido. Te contactaremos pronto.` });
  };

  return (
    <>
      <Helmet>
        <title>Soporte - Netcom Academy</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-6xl">
            <div className="text-center mb-12">
                <h1 className="text-4xl font-bold text-[#0B3D91] mb-4">Centro de Soporte</h1>
                <p className="text-gray-600">¿Tienes problemas técnicos? Estamos aquí para ayudarte.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
                {/* Contact Form */}
                <div className="bg-white p-8 rounded-xl shadow-md">
                    <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                        <Mail className="text-[#0B3D91]"/> Nuevo Ticket
                    </h2>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <input 
                            type="text" 
                            placeholder="Nombre" 
                            className="w-full p-3 border rounded-lg"
                            value={formData.name}
                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                        />
                        <input 
                            type="email" 
                            placeholder="Email" 
                            className="w-full p-3 border rounded-lg"
                            value={formData.email}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                        />
                        <input 
                            type="text" 
                            placeholder="Asunto" 
                            className="w-full p-3 border rounded-lg"
                            value={formData.subject}
                            onChange={(e) => setFormData({...formData, subject: e.target.value})}
                        />
                        <textarea 
                            placeholder="Describe tu problema..." 
                            rows="5" 
                            className="w-full p-3 border rounded-lg"
                            value={formData.message}
                            onChange={(e) => setFormData({...formData, message: e.target.value})}
                        ></textarea>
                        <Button type="submit" className="w-full btn-primary">Enviar Ticket</Button>
                    </form>
                </div>

                {/* Ticket List & Info */}
                <div className="space-y-8">
                    <div className="bg-white p-8 rounded-xl shadow-md">
                        <h2 className="text-xl font-bold mb-4">Mis Tickets Recientes</h2>
                        {tickets.length > 0 ? (
                            <div className="space-y-3">
                                {tickets.slice(0, 3).map(ticket => (
                                    <div key={ticket.id} className="p-3 border rounded-lg flex justify-between items-center">
                                        <div>
                                            <p className="font-semibold text-sm">#{ticket.id} - {ticket.subject}</p>
                                            <p className="text-xs text-gray-500">{ticket.date}</p>
                                        </div>
                                        <span className={`text-xs px-2 py-1 rounded-full ${ticket.status === 'open' ? 'bg-green-100 text-green-700' : 'bg-gray-100'}`}>
                                            {ticket.status.toUpperCase()}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-500 text-sm">No tienes tickets recientes.</p>
                        )}
                    </div>

                    <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                        <h3 className="font-bold text-[#0B3D91] mb-2 flex items-center gap-2"><AlertCircle size={20}/> Antes de preguntar</h3>
                        <p className="text-sm text-gray-700 mb-4">Muchas dudas ya están resueltas en nuestras Preguntas Frecuentes.</p>
                        <Link to="/faq">
                            <Button variant="outline" className="w-full">Ver FAQ</Button>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};

export default SupportPage;
