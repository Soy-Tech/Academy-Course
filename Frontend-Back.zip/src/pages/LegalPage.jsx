
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Scale, Shield, FileText } from 'lucide-react';

const LegalPage = () => {
  return (
    <>
      <Helmet>
        <title>Legal - Netcom Academy</title>
      </Helmet>
      <div className="bg-gray-50 min-h-screen py-16">
        <div className="container mx-auto px-4 max-w-4xl text-center">
            <h1 className="text-4xl font-bold text-[#0B3D91] mb-12">Información Legal</h1>
            <div className="grid md:grid-cols-2 gap-8">
                <Link to="/terms" className="bg-white p-8 rounded-xl shadow hover:shadow-lg transition">
                    <Scale size={48} className="mx-auto text-[#0B3D91] mb-4"/>
                    <h2 className="text-xl font-bold mb-2">Términos y Condiciones</h2>
                    <p className="text-gray-600">Reglas y regulaciones para el uso de nuestra plataforma.</p>
                </Link>
                <Link to="/privacy" className="bg-white p-8 rounded-xl shadow hover:shadow-lg transition">
                    <Shield size={48} className="mx-auto text-[#CFAE70] mb-4"/>
                    <h2 className="text-xl font-bold mb-2">Política de Privacidad</h2>
                    <p className="text-gray-600">Cómo recopilamos y protegemos tus datos personales.</p>
                </Link>
            </div>
        </div>
      </div>
    </>
  );
};
export default LegalPage;
