
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const { toast } = useToast();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos",
        variant: "destructive"
      });
      return;
    }

    const contacts = JSON.parse(localStorage.getItem('contact_messages') || '[]');
    contacts.push({ ...formData, date: new Date().toISOString() });
    localStorage.setItem('contact_messages', JSON.stringify(contacts));

    toast({
      title: "¡Mensaje enviado!",
      description: "Nos pondremos en contacto contigo pronto."
    });

    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const contactInfo = [
    {
      icon: Mail,
      title: 'Email',
      content: 'info@netcom.academy',
      link: 'mailto:info@netcom.academy'
    },
    {
      icon: Phone,
      title: 'Teléfono',
      content: '+34 900 123 456',
      link: 'tel:+34900123456'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      content: '+34 600 123 456',
      link: 'https://wa.me/34600123456'
    },
    {
      icon: MapPin,
      title: 'Ubicación',
      content: 'Madrid, España',
      link: null
    }
  ];

  return (
    <>
      <Helmet>
        <title>Contacto - Netcom Academy</title>
        <meta name="description" content="Ponte en contacto con Netcom Academy. Estamos aquí para ayudarte con cualquier pregunta sobre nuestros cursos y servicios." />
      </Helmet>

      <PageBanner 
        title="Contacto"
        subtitle="¿Tienes preguntas? Nos encantaría escucharte. Envíanos un mensaje y te responderemos pronto."
        backgroundImage="https://images.unsplash.com/photo-1681917800123-e9a2bcd9c46c"
        height="h-[350px] md:h-[450px]"
      />

      <section id="contact-form" className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4 max-w-[1200px]">
          <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
            
            {/* Left Column - Contact Information (30%) */}
            <motion.div 
              className="w-full lg:w-[30%]"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl md:text-[32px] font-bold text-[#1a1a1a] mb-8">
                Información de contacto
              </h2>
              
              <div className="flex flex-col gap-6">
                {contactInfo.map((info, index) => {
                  const Icon = info.icon;
                  return (
                    <a
                      key={index}
                      href={info.link}
                      className={`block bg-white p-6 rounded-[10px] shadow-[0_2px_8px_rgba(0,0,0,0.1)] hover:shadow-[0_4px_16px_rgba(0,0,0,0.15)] transition-all duration-300 group ${!info.link ? 'cursor-default' : 'cursor-pointer'}`}
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-full bg-[#0B3D91]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#0B3D91] transition-colors duration-300">
                          <Icon size={20} className="text-[#0B3D91] group-hover:text-white transition-colors duration-300" />
                        </div>
                        <div>
                          <h3 className="text-base font-semibold text-[#1a1a1a] mb-1">{info.title}</h3>
                          <p className="text-sm text-gray-500">{info.content}</p>
                        </div>
                      </div>
                    </a>
                  );
                })}
              </div>

              <div className="bg-[#f9f9f9] p-6 rounded-[10px] mt-8 border border-[#e0e0e0]">
                <h3 className="font-bold text-[#0B3D91] mb-3 text-lg">Horario de atención</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <p><span className="font-semibold text-gray-900">Lunes a Viernes:</span> 9:00 - 18:00</p>
                  <p><span className="font-semibold text-gray-900">Sábados:</span> 10:00 - 14:00</p>
                  <p><span className="font-semibold text-gray-900">Domingos:</span> Cerrado</p>
                </div>
              </div>
            </motion.div>

            {/* Right Column - Contact Form (70%) */}
            <motion.div 
              className="w-full lg:w-[70%]"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-white rounded-xl">
                <h2 className="text-2xl md:text-[32px] font-bold text-[#1a1a1a] mb-8">
                  Envíanos un mensaje
                </h2>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Nombre completo
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3.5 bg-white border border-[#e0e0e0] rounded-lg text-[15px] focus:outline-none focus:border-[#0B3D91] focus:ring-1 focus:ring-[#0B3D91]/20 transition-all duration-200 placeholder-gray-400"
                        placeholder="Ej. Juan Pérez"
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Correo electrónico
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3.5 bg-white border border-[#e0e0e0] rounded-lg text-[15px] focus:outline-none focus:border-[#0B3D91] focus:ring-1 focus:ring-[#0B3D91]/20 transition-all duration-200 placeholder-gray-400"
                        placeholder="Ej. juan@correo.com"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                      Asunto
                    </label>
                    <input
                      type="text"
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full px-4 py-3.5 bg-white border border-[#e0e0e0] rounded-lg text-[15px] focus:outline-none focus:border-[#0B3D91] focus:ring-1 focus:ring-[#0B3D91]/20 transition-all duration-200 placeholder-gray-400"
                      placeholder="¿En qué podemos ayudarte?"
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Mensaje
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows="8"
                      className="w-full px-4 py-3.5 bg-white border border-[#e0e0e0] rounded-lg text-[15px] focus:outline-none focus:border-[#0B3D91] focus:ring-1 focus:ring-[#0B3D91]/20 transition-all duration-200 placeholder-gray-400 resize-y min-h-[180px]"
                      placeholder="Escribe tu mensaje aquí..."
                    ></textarea>
                  </div>

                  <div className="pt-2">
                    <Button 
                      type="submit" 
                      className="w-full md:w-auto px-8 py-3.5 bg-[#0B3D91] hover:bg-[#082d6b] text-white font-semibold rounded-lg text-[15px] shadow-[0_4px_12px_rgba(11,61,145,0.3)] hover:shadow-[0_6px_16px_rgba(11,61,145,0.4)] transition-all duration-300"
                    >
                      <Send size={18} className="mr-2" />
                      Enviar mensaje
                    </Button>
                  </div>
                </form>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;
