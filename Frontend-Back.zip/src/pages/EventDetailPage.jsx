
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Calendar, MapPin, Users, User as UserIcon, Check } from 'lucide-react';
import { mockEvents } from '@/data/mockEvents';

const EventDetailPage = () => {
  const { id } = useParams();
  const { toast } = useToast();
  const [event, setEvent] = useState(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // Simulated current user from local storage
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));

  useEffect(() => {
    // Find event locally
    const foundEvent = mockEvents.find(e => e.id.toString() === id);
    
    const timer = setTimeout(() => {
      setEvent(foundEvent);
      setIsLoading(false);
      
      // Check if "registered" locally (mock logic)
      if (currentUser) {
        const registrations = JSON.parse(localStorage.getItem('eventRegistrations') || '{}');
        if (registrations[id]) {
          setIsRegistered(true);
        }
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [id, currentUser]);

  const handleRegister = () => {
    if (!currentUser) {
      toast({
        title: 'Inicia sesión',
        description: 'Debes iniciar sesión para registrarte en eventos.',
        variant: 'destructive'
      });
      return;
    }

    // Mock registration logic
    const registrations = JSON.parse(localStorage.getItem('eventRegistrations') || '{}');
    registrations[id] = true;
    localStorage.setItem('eventRegistrations', JSON.stringify(registrations));

    setIsRegistered(true);
    toast({
      title: '¡Registro exitoso!',
      description: 'Te has registrado en el evento (Simulación local).'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0B3D91]"></div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Evento no encontrado</h2>
          <Link to="/events">
            <Button className="btn-primary">Volver a eventos</Button>
          </Link>
        </div>
      </div>
    );
  }

  const eventDate = new Date(event.date);
  const spotsLeft = event.max_attendees - (event.current_attendees || 0);

  return (
    <>
      <Helmet>
        <title>{event.title} - Eventos - Netcom Academy</title>
        <meta name="description" content={event.description} />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-5xl">
          <Link to="/events" className="inline-flex items-center text-[#0B3D91] hover:text-[#CFAE70] mb-8 transition-colors">
            <ArrowLeft size={20} className="mr-2" />
            Volver a eventos
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="lg:col-span-2"
            >
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                {event.image && (
                    <div className="h-64 w-full overflow-hidden">
                        <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                    </div>
                )}
                <div className="bg-gradient-to-r from-[#0B3D91] to-[#082d6b] p-8 text-white">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center">
                      <span className="text-3xl font-bold">{eventDate.getDate()}</span>
                      <span className="text-sm">
                        {eventDate.toLocaleDateString('es-ES', { month: 'short' })}
                      </span>
                    </div>
                    <div className="flex-grow">
                      <h1 className="text-3xl font-bold mb-2">{event.title}</h1>
                      <p className="text-lg text-gray-200">
                        {eventDate.toLocaleDateString('es-ES', { 
                          weekday: 'long',
                          day: 'numeric',
                          month: 'long',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-8">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Descripción</h2>
                  <p className="text-gray-700 mb-6">{event.description}</p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      <Calendar className="text-[#0B3D91]" size={24} />
                      <div>
                        <p className="text-sm text-gray-600">Fecha y hora</p>
                        <p className="font-semibold text-gray-900">
                          {eventDate.toLocaleDateString('es-ES')} • {eventDate.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      <MapPin className="text-[#0B3D91]" size={24} />
                      <div>
                        <p className="text-sm text-gray-600">Ubicación</p>
                        <p className="font-semibold text-gray-900">{event.location}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      <UserIcon className="text-[#0B3D91]" size={24} />
                      <div>
                        <p className="text-sm text-gray-600">Ponente</p>
                        <p className="font-semibold text-gray-900">{event.speaker}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      <Users className="text-[#0B3D91]" size={24} />
                      <div>
                        <p className="text-sm text-gray-600">Asistentes</p>
                        <p className="font-semibold text-gray-900">
                          {event.current_attendees + (isRegistered ? 1 : 0)} / {event.max_attendees}
                        </p>
                      </div>
                    </div>
                  </div>

                  {isRegistered ? (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3 text-green-700">
                      <Check size={24} />
                      <div>
                        <p className="font-semibold">Ya estás registrado</p>
                        <p className="text-sm">Te esperamos en el evento</p>
                      </div>
                    </div>
                  ) : spotsLeft > 0 ? (
                    <Button onClick={handleRegister} className="w-full btn-primary py-4 text-lg">
                      Registrarse en el evento
                    </Button>
                  ) : (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center text-red-700">
                      <p className="font-semibold">Evento completo</p>
                      <p className="text-sm">No hay plazas disponibles</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="lg:col-span-1"
            >
              <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-24">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Asistentes destacados
                </h3>
                <p className="text-sm text-gray-500 mb-4">
                    Únete a otros estudiantes en este evento.
                </p>
                {/* Simplified attendees list for mock version */}
                <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 rounded-lg bg-gray-50">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold">
                            JD
                        </div>
                        <div>
                            <p className="font-medium">John Doe</p>
                            <p className="text-xs text-gray-500">Estudiante</p>
                        </div>
                    </div>
                    {isRegistered && currentUser && (
                         <div className="flex items-center gap-3 p-3 rounded-lg bg-green-50 border border-green-100">
                            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold">
                                Tú
                            </div>
                            <div>
                                <p className="font-medium">{currentUser.name}</p>
                                <p className="text-xs text-gray-500">¡Registrado!</p>
                            </div>
                         </div>
                    )}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EventDetailPage;
