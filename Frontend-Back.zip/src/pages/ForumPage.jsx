
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { mockForumCategories } from '@/data/mockForum';
import { MessageSquare, Clock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ForumPage = () => {
  return (
    <>
      <Helmet>
        <title>Foro - Netcom Academy</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Foro de la Comunidad</h1>
            <Button className="btn-primary">Nuevo Tema</Button>
          </div>

          <div className="grid gap-6">
            {mockForumCategories.map((cat) => (
              <div key={cat.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <Link to={`/forum/${cat.id}`} className="text-xl font-bold text-[#0B3D91] hover:underline">
                      {cat.title}
                    </Link>
                    <p className="text-gray-600 mt-1">{cat.description}</p>
                  </div>
                  <Link to={`/forum/${cat.id}`}>
                    <Button variant="ghost" size="sm"><ArrowRight size={18} /></Button>
                  </Link>
                </div>
                <div className="flex gap-6 mt-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1"><MessageSquare size={16}/> {cat.topicCount} temas</span>
                    <span className="flex items-center gap-1"><Clock size={16}/> Activo {cat.latestActivity}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default ForumPage;
