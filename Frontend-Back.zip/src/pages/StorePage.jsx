
import React from 'react';
import { Helmet } from 'react-helmet';
import ProductsList from '@/components/ProductsList';
import StorePageBanner from '@/components/StorePageBanner';

const StorePage = () => {
  const scrollToProducts = () => {
    document.getElementById('products-list').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Tienda - Netcom Academy</title>
        <meta name="description" content="Explora la tienda de Netcom Academy. Encuentra productos exclusivos, material de estudio y más." />
      </Helmet>

      <StorePageBanner onClickCTA={scrollToProducts} />

      <section id="products-list" className="py-16 bg-[#F5F5F5]">
        <div className="container mx-auto px-4">
          <ProductsList />
        </div>
      </section>
    </>
  );
};

export default StorePage;
