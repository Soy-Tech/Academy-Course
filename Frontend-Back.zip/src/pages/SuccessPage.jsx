import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight } from 'lucide-react';

const SuccessPage = () => {
  return (
    <>
      <Helmet>
        <title>¡Compra Exitosa! - Netcom Academy</title>
        <meta name="description" content="Tu compra en Netcom Academy se ha completado con éxito." />
      </Helmet>
      <div className="container mx-auto px-4 py-20 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="bg-white p-12 rounded-2xl shadow-2xl text-center max-w-2xl"
        >
          <CheckCircle className="w-24 h-24 text-green-500 mx-auto mb-6" />
          <h1 className="text-4xl font-bold text-[#0B3D91] mb-4">
            ¡Gracias por tu compra!
          </h1>
          <p className="text-gray-600 text-lg mb-8">
            Tu pedido se ha procesado correctamente. Recibirás un correo electrónico de confirmación en breve con los detalles de tu compra.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/store" className="btn-secondary inline-flex items-center justify-center space-x-2">
              <span>Seguir comprando</span>
              <ArrowRight size={20} />
            </Link>
            <Link to="/" className="btn-primary inline-flex items-center justify-center space-x-2">
              <span>Volver al inicio</span>
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default SuccessPage;