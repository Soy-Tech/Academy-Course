
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft } from 'lucide-react';
import VideoPlayer from '@/components/VideoPlayer';
import VideoList from '@/components/VideoList';
import { useVideos } from '@/hooks/useVideos';
import { coursesData } from '@/data/coursesData';
import { Button } from '@/components/ui/button';

const VideoViewerPage = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { getVideosByCourse } = useVideos();
  const [videos, setVideos] = useState([]);
  const [currentVideo, setCurrentVideo] = useState(null);
  
  const course = coursesData.find(c => c.id === courseId);

  useEffect(() => {
    const courseVideos = getVideosByCourse(courseId);
    setVideos(courseVideos);
    if (courseVideos.length > 0) {
      setCurrentVideo(courseVideos[0]);
    }
  }, [courseId]);

  if (!course) {
    return <div className="p-8 text-center">Curso no encontrado</div>;
  }

  const handleNextVideo = () => {
    const currentIndex = videos.findIndex(v => v.id === currentVideo.id);
    if (currentIndex < videos.length - 1) {
      setCurrentVideo(videos[currentIndex + 1]);
    }
  };

  const handlePrevVideo = () => {
    const currentIndex = videos.findIndex(v => v.id === currentVideo.id);
    if (currentIndex > 0) {
      setCurrentVideo(videos[currentIndex - 1]);
    }
  };

  return (
    <>
      <Helmet>
        <title>{currentVideo ? `${currentVideo.title} | ${course.title}` : course.title}</title>
      </Helmet>

      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Simplified Header for Focus Mode */}
        <header className="bg-[#0B3D91] text-white py-4 px-6 shadow-md z-10">
            <div className="container mx-auto flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link to={`/cursos/${courseId}`} className="text-gray-300 hover:text-white transition-colors">
                        <ArrowLeft size={24} />
                    </Link>
                    <div>
                        <h1 className="font-bold text-lg leading-tight">{course.title}</h1>
                        <p className="text-xs text-gray-300">Progreso: 25% completado</p>
                    </div>
                </div>
                <Button 
                    variant="outline" 
                    className="border-white text-[#0B3D91] hover:bg-white/10 hover:text-white hidden md:flex"
                    onClick={() => navigate('/dashboard')}
                >
                    Volver al Dashboard
                </Button>
            </div>
        </header>

        <main className="flex-1 container mx-auto p-4 lg:p-6">
            <div className="grid lg:grid-cols-12 gap-6 h-full">
                {/* Main Player Area (Left/Top) */}
                <div className="lg:col-span-8 xl:col-span-9 flex flex-col gap-6">
                    <VideoPlayer 
                        video={currentVideo} 
                        onNext={handleNextVideo}
                        onPrev={handlePrevVideo}
                    />
                </div>

                {/* Sidebar Playlist (Right/Bottom) */}
                <div className="lg:col-span-4 xl:col-span-3">
                    <div className="sticky top-6">
                        <VideoList 
                            videos={videos} 
                            currentVideoId={currentVideo?.id}
                            onVideoSelect={setCurrentVideo}
                        />
                    </div>
                </div>
            </div>
        </main>
      </div>
    </>
  );
};

export default VideoViewerPage;
