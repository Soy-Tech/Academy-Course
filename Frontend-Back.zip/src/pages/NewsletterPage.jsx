import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, CheckCircle } from 'lucide-react';
import NewsletterForm from '@/components/NewsletterForm';

const NewsletterPage = () => {
  const benefits = [
    'Acceso anticipado a nuevos cursos',
    'Descuentos exclusivos para suscriptores',
    'Recursos gratuitos y guías descargables',
    'Artículos semanales sobre tecnología',
    'Consejos para impulsar tu carrera',
    'Invitaciones a webinars y eventos'
  ];

  return (
    <>
      <Helmet>
        <title>Newsletter - Netcom Academy</title>
        <meta name="description" content="Suscríbete al newsletter de Netcom y recibe contenido exclusivo, recursos gratuitos y ofertas especiales directamente en tu correo." />
      </Helmet>

      <section className="bg-gradient-to-br from-[#0B3D91] to-[#082d6b] text-white py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <Mail size={64} className="mx-auto mb-6 text-[#CFAE70]" />
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Únete a nuestra comunidad
            </h1>
            <p className="text-xl text-gray-200 max-w-2xl mx-auto">
              Recibe contenido exclusivo, recursos gratuitos y las últimas novedades del mundo tech
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl font-bold text-[#0B3D91] mb-6">
                  ¿Qué recibirás?
                </h2>
                <ul className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle size={24} className="text-[#CFAE70] flex-shrink-0 mt-1" />
                      <span className="text-gray-700 text-lg">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="bg-white p-8 rounded-xl shadow-xl"
              >
                <h3 className="text-2xl font-bold text-[#0B3D91] mb-6 text-center">
                  Suscríbete ahora
                </h3>
                <NewsletterForm />
                <p className="text-gray-600 text-sm text-center mt-6">
                  No spam. Puedes cancelar tu suscripción en cualquier momento.
                </p>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-[#F5F5F5] p-8 rounded-xl"
            >
              <h3 className="text-2xl font-bold text-[#0B3D91] mb-4 text-center">
                Únete a más de 10,000 profesionales
              </h3>
              <p className="text-gray-700 text-center max-w-2xl mx-auto">
                Nuestra comunidad de suscriptores recibe contenido exclusivo cada semana. 
                Desde tutoriales avanzados hasta ofertas especiales en cursos, 
                mantente siempre un paso adelante en tu carrera tecnológica.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default NewsletterPage;