
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Settings, Database, Activity } from 'lucide-react';
import AdminLayout from '@/components/Admin/AdminLayout';
import { useAuth } from '@/contexts/AuthContext';

const SuperAdminDashboard = () => {
  const { currentUser } = useAuth();

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 text-white shadow-xl">
          <h1 className="text-3xl font-bold mb-2">Super Admin Console</h1>
          <p className="text-gray-400">Acceso total al sistema. Ten cuidado.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
             <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-red-100 text-red-600 rounded-lg"><Shield size={20}/></div>
                <h3 className="font-bold text-gray-900">Gestión de Admins</h3>
             </div>
             <p className="text-sm text-gray-500 mb-4">Crear, editar o eliminar cuentas de administrador.</p>
             <button className="text-sm font-bold text-red-600 hover:underline">Gestionar &rarr;</button>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
             <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><Settings size={20}/></div>
                <h3 className="font-bold text-gray-900">Configuración Global</h3>
             </div>
             <p className="text-sm text-gray-500 mb-4">Ajustes del sitio, correos, pasarelas de pago.</p>
             <button className="text-sm font-bold text-blue-600 hover:underline">Configurar &rarr;</button>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
             <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-green-100 text-green-600 rounded-lg"><Database size={20}/></div>
                <h3 className="font-bold text-gray-900">Base de Datos</h3>
             </div>
             <p className="text-sm text-gray-500 mb-4">Backups, logs de auditoría y mantenimiento.</p>
             <button className="text-sm font-bold text-green-600 hover:underline">Ver Logs &rarr;</button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default SuperAdminDashboard;
