
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Eye, Heart, Users, Award, Rocket, Linkedin, Twitter, Mail } from 'lucide-react';
import PageBanner from '@/components/PageBanner';

const AboutPage = () => {
  const values = [
    {
      icon: Target,
      title: 'Excelencia',
      description: 'Nos comprometemos a ofrecer contenido de la más alta calidad, actualizado con las últimas tendencias tecnológicas.'
    },
    {
      icon: Users,
      title: 'Comunidad',
      description: 'Creemos en el poder del aprendizaje colaborativo y fomentamos una comunidad activa de estudiantes.'
    },
    {
      icon: Heart,
      title: 'Pasión',
      description: 'Amamos la tecnología y nos apasiona compartir conocimiento para transformar vidas.'
    },
    {
      icon: Award,
      title: 'Calidad',
      description: 'Cada curso está diseñado por expertos con años de experiencia en la industria tecnológica.'
    },
    {
      icon: Rocket,
      title: 'Innovación',
      description: 'Nos mantenemos a la vanguardia, incorporando las tecnologías más demandadas del mercado.'
    }
  ];

  const stats = [
    { number: '10k+', label: 'Estudiantes activos' },
    { number: '150+', label: 'Cursos disponibles' },
    { number: '98%', label: 'Satisfacción' },
    { number: '24/7', label: 'Soporte' }
  ];

  const team = [
    {
      name: "Elena Rodríguez",
      role: "Fundadora & CEO",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      bio: "Ingeniera de software con más de 15 años de experiencia liderando equipos tecnológicos en Silicon Valley."
    },
    {
      name: "Carlos Méndez",
      role: "Director Académico",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      bio: "Doctor en Ciencias de la Computación, apasionado por crear metodologías de enseñanza efectivas."
    },
    {
      name: "Sarah Johnson",
      role: "Head of Community",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      bio: "Especialista en construcción de comunidades digitales y experiencia del estudiante."
    },
    {
      name: "David Chen",
      role: "Lead Tech Instructor",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      bio: "Full Stack Developer y mentor premiado, experto en arquitecturas escalables y React."
    }
  ];

  return (
    <>
      <Helmet>
        <title>Sobre Nosotros - Netcom Academy</title>
        <meta name="description" content="Conoce la misión, visión y el equipo detrás de Netcom Academy. Somos una plataforma educativa comprometida con tu desarrollo profesional." />
      </Helmet>

      <PageBanner 
        title="Sobre Nosotros"
        subtitle="Conoce nuestra misión, visión y el equipo detrás de esta plataforma educativa."
        backgroundImage="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
        height="h-[350px] md:h-[450px]"
      />

      <div className="bg-white">
        {/* Mission & Vision Section */}
        <section className="py-16 md:py-24 overflow-hidden">
          <div className="container mx-auto px-4 max-w-[1200px]">
            {/* Mission */}
            <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center mb-20 md:mb-32">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-2 md:order-1"
              >
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-[#0B3D91]/10 flex items-center justify-center">
                    <Target size={28} className="text-[#0B3D91]" />
                  </div>
                  <h2 className="text-3xl font-bold text-[#1a1a1a]">Nuestra Misión</h2>
                </div>
                <p className="text-[#555] text-lg leading-relaxed mb-6">
                  Democratizar el acceso a la educación tecnológica de calidad, proporcionando 
                  cursos prácticos y actualizados que permitan a cualquier persona, sin importar 
                  su ubicación o experiencia previa, desarrollar las habilidades necesarias para 
                  prosperar en la economía digital global.
                </p>
                <ul className="space-y-3">
                  {['Acceso universal', 'Calidad premium', 'Enfoque práctico'].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-gray-700 font-medium">
                      <div className="w-2 h-2 rounded-full bg-[#CFAE70]" />
                      {item}
                    </li>
                  ))}
                </ul>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="order-1 md:order-2 relative group"
              >
                <div className="absolute inset-0 bg-[#0B3D91] rounded-2xl rotate-3 opacity-10 group-hover:rotate-6 transition-transform duration-500" />
                <img 
                  alt="Equipo de Netcom trabajando" 
                  className="rounded-2xl shadow-lg relative z-10 w-full h-[400px] object-cover" 
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                />
              </motion.div>
            </div>

            {/* Vision */}
            <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="relative group"
              >
                <div className="absolute inset-0 bg-[#CFAE70] rounded-2xl -rotate-3 opacity-10 group-hover:-rotate-6 transition-transform duration-500" />
                <img 
                  alt="Futuro de la educación" 
                  className="rounded-2xl shadow-lg relative z-10 w-full h-[400px] object-cover" 
                  src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 rounded-lg bg-[#CFAE70]/10 flex items-center justify-center">
                    <Eye size={28} className="text-[#CFAE70]" />
                  </div>
                  <h2 className="text-3xl font-bold text-[#1a1a1a]">Nuestra Visión</h2>
                </div>
                <p className="text-[#555] text-lg leading-relaxed mb-6">
                  Ser la academia online de referencia en el mundo hispanohablante para la formación 
                  tecnológica, reconocida por la excelencia de nuestros contenidos, la efectividad 
                  de nuestros métodos de enseñanza y el éxito profesional medible de nuestros estudiantes.
                </p>
                <div className="grid grid-cols-2 gap-6 mt-8">
                  {stats.map((stat, idx) => (
                    <div key={idx} className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                      <div className="text-2xl font-bold text-[#0B3D91] mb-1">{stat.number}</div>
                      <div className="text-sm text-gray-600 font-medium">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16 md:py-24 bg-gray-50">
          <div className="container mx-auto px-4 max-w-[1200px]">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mb-4">
                Nuestros Valores
              </h2>
              <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                Los principios fundamentales que guían cada decisión y acción en Netcom Academy.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {values.map((value, index) => {
                const Icon = value.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="bg-white p-8 rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.06)] hover:shadow-[0_10px_25px_-5px_rgba(0,0,0,0.1)] transition-all duration-300 border border-transparent hover:border-gray-100 group"
                  >
                    <div className="w-16 h-16 bg-[#0B3D91]/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-[#0B3D91] transition-colors duration-300">
                      <Icon size={32} className="text-[#0B3D91] group-hover:text-white transition-colors duration-300" />
                    </div>
                    <h3 className="text-xl font-bold text-[#1a1a1a] mb-3">{value.title}</h3>
                    <p className="text-[#555] leading-relaxed">{value.description}</p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-16 md:py-24 bg-white">
          <div className="container mx-auto px-4 max-w-[1200px]">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mb-4">
                Nuestro Equipo
              </h2>
              <p className="text-gray-600 text-lg max-w-2xl mx-auto">
                Conoce a los expertos apasionados que hacen posible nuestra misión educativa.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {team.map((member, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.08)] hover:shadow-[0_8px_20px_rgba(0,0,0,0.12)] p-6 transition-all duration-300 border border-gray-100 flex flex-col items-center text-center group"
                >
                  <div className="relative mb-6">
                    <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-gray-50 shadow-inner group-hover:scale-105 transition-transform duration-300">
                      <img src={member.image} alt={member.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="absolute bottom-0 right-0 bg-[#CFAE70] p-2 rounded-full text-white shadow-sm border-2 border-white">
                      <Rocket size={14} />
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-bold text-[#1a1a1a] mb-1">{member.name}</h3>
                  <span className="text-sm font-semibold text-[#0B3D91] mb-3 uppercase tracking-wide">{member.role}</span>
                  <p className="text-[#666] text-sm leading-relaxed mb-6">
                    {member.bio}
                  </p>
                  
                  <div className="flex gap-4 mt-auto">
                    <a href="#" className="text-gray-400 hover:text-[#0077b5] transition-colors"><Linkedin size={18} /></a>
                    <a href="#" className="text-gray-400 hover:text-[#1DA1F2] transition-colors"><Twitter size={18} /></a>
                    <a href="#" className="text-gray-400 hover:text-[#EA4335] transition-colors"><Mail size={18} /></a>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-20 bg-gradient-to-r from-[#0B3D91] to-[#0F172A] text-white overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-20">
             <div className="absolute -top-[50%] -left-[20%] w-[1000px] h-[1000px] rounded-full bg-blue-500 blur-3xl" />
             <div className="absolute top-[20%] right-[10%] w-[600px] h-[600px] rounded-full bg-purple-500 blur-3xl" />
          </div>
          
          <div className="container mx-auto px-4 max-w-[800px] text-center relative z-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              ¿Listo para comenzar tu transformación?
            </h2>
            <p className="text-xl text-gray-200 mb-8 font-light">
              Únete a miles de estudiantes que ya están construyendo su futuro profesional con Netcom Academy.
            </p>
            <a 
              href="/cursos" 
              className="inline-flex items-center justify-center bg-[#CFAE70] text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-[#b89a5f] transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1"
            >
              Explorar Cursos <Rocket className="ml-2" size={20} />
            </a>
          </div>
        </section>
      </div>
    </>
  );
};

export default AboutPage;
