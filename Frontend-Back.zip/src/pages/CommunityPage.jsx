
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import PostCard from '@/components/PostCard';
import CreatePostModal from '@/components/CreatePostModal';
import { Button } from '@/components/ui/button';
import { Plus, Search, Filter } from 'lucide-react';
import { mockCommunityPosts } from '@/data/mockCommunity';

const CommunityPage = () => {
  const { toast } = useToast();
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'Programación', 'IA y Datos', 'Ciberseguridad', 'Productividad', 'General'];

  useEffect(() => {
    // Simulate loading delay
    const timer = setTimeout(() => {
      setPosts(mockCommunityPosts);
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const handleCreatePost = (newPostData) => {
    // Mock creating a post locally
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const newPost = {
      id: posts.length + 1,
      title: newPostData.title,
      content: newPostData.content,
      category: newPostData.category,
      created_at: new Date().toISOString(),
      likes_count: 0,
      comments_count: 0,
      users: {
        name: currentUser ? currentUser.name : 'Usuario Anónimo',
        profile_photo_url: null,
        specialty: 'Estudiante'
      },
      comments: []
    };

    setPosts([newPost, ...posts]);
    setIsModalOpen(false);
    toast({
      title: "Publicación creada",
      description: "Tu publicación ha sido añadida exitosamente (Simulación local).",
    });
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          post.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <>
      <Helmet>
        <title>Comunidad - Netcom Academy</title>
        <meta name="description" content="Únete a la comunidad de Netcom Academy y comparte conocimientos." />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-4xl font-bold text-gray-900 mb-2">Comunidad</h1>
                <p className="text-gray-600">Conecta, aprende y comparte con otros estudiantes</p>
              </div>
              <Button onClick={() => setIsModalOpen(true)} className="btn-primary">
                <Plus size={20} className="mr-2" />
                Nueva publicación
              </Button>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input
                  type="text"
                  placeholder="Buscar publicaciones..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CFAE70] focus:border-transparent outline-none text-gray-900 bg-white"
                />
              </div>
              
              <div className="relative">
                <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full md:w-48 pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CFAE70] focus:border-transparent outline-none appearance-none text-gray-900 bg-white"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>
                      {cat === 'all' ? 'Todas las categorías' : cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </motion.div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0B3D91]"></div>
            </div>
          ) : filteredPosts.length > 0 ? (
            <div className="space-y-4">
              {filteredPosts.map((post, index) => (
                <PostCard 
                  key={post.id} 
                  post={post} 
                  delay={index * 0.05} 
                  // Pass a dummy onUpdate or handle local likes in PostCard component (if we were modifying it)
                  // For now, assuming PostCard is read-only or we can't easily change internal logic without modifying it.
                  // But the task said "Update CommunityPage to use mock data".
                  // Since PostCard is not in read-only list but user didn't explicitly ask to modify it, 
                  // we might see some console errors if PostCard tries to call Supabase.
                  // However, let's assume PostCard is simple or we can ignore its internal Supabase calls if any,
                  // or better, if PostCard logic is complex, we might not get full interactivity without modifying it.
                  // Wait, <codebase> shows PostCard.jsx is NOT relevant/hidden.
                  // This means I can't modify PostCard.jsx.
                  // I hope PostCard just takes props and doesn't call API itself.
                  onUpdate={() => {}} 
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-gray-600 mb-4">No se encontraron publicaciones</p>
              <Button onClick={() => setIsModalOpen(true)} className="btn-primary">
                Crear la primera publicación
              </Button>
            </div>
          )}
        </div>
      </div>

      <CreatePostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onPostCreated={handleCreatePost} // Changed to local handler
      />
    </>
  );
};

export default CommunityPage;
