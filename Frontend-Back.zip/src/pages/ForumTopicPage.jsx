
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { mockForumTopics } from '@/data/mockForum';
import { ArrowLeft, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ForumTopicPage = () => {
  const { categoryId, topicId } = useParams();
  const { toast } = useToast();
  const topic = mockForumTopics.find(t => t.id === topicId);
  
  // Local state for replies (mocking persistence within session)
  const [replies, setReplies] = useState(topic ? topic.replies : []);
  const [newReply, setNewReply] = useState('');

  if (!topic) return <div className="text-center py-20">Tema no encontrado</div>;

  const handleReplySubmit = (e) => {
    e.preventDefault();
    if (!newReply.trim()) return;

    const reply = {
        id: `r-new-${Date.now()}`,
        author: 'Yo (Estudiante)',
        date: new Date().toISOString().split('T')[0],
        content: newReply
    };
    
    setReplies([...replies, reply]);
    setNewReply('');
    toast({ title: 'Respuesta enviada', description: 'Tu respuesta ha sido publicada.' });
  };

  return (
    <>
      <Helmet>
        <title>{topic.title} - Foro Netcom</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-4xl">
           <Link to={`/forum/${categoryId}`} className="inline-flex items-center text-[#0B3D91] mb-6 hover:underline">
            <ArrowLeft size={16} className="mr-2" /> Volver a temas
          </Link>

          {/* Original Post */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
             <h1 className="text-2xl font-bold text-gray-900 mb-4">{topic.title}</h1>
             <div className="flex items-center gap-3 mb-6 pb-6 border-b border-gray-100">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-[#0B3D91] font-bold">
                    {topic.author.charAt(0)}
                </div>
                <div>
                    <p className="font-semibold text-gray-900">{topic.author}</p>
                    <p className="text-xs text-gray-500">{topic.date}</p>
                </div>
             </div>
             <div className="prose text-gray-700">{topic.content}</div>
          </div>

          {/* Replies */}
          <div className="space-y-4 mb-8">
             {replies.map(reply => (
                 <div key={reply.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 ml-4 md:ml-8 border-l-4 border-l-gray-300">
                    <div className="flex items-center gap-2 mb-3">
                        <User size={16} className="text-gray-400" />
                        <span className="font-semibold text-sm">{reply.author}</span>
                        <span className="text-gray-400 text-sm">• {reply.date}</span>
                    </div>
                    <p className="text-gray-700">{reply.content}</p>
                 </div>
             ))}
          </div>

          {/* Reply Form */}
          <div className="bg-white rounded-xl shadow p-6">
            <h3 className="font-bold mb-4">Responder</h3>
            <form onSubmit={handleReplySubmit}>
                <textarea 
                    value={newReply}
                    onChange={(e) => setNewReply(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-[#0B3D91] outline-none" 
                    rows="4" 
                    placeholder="Escribe tu respuesta aquí..."
                ></textarea>
                <div className="mt-4 flex justify-end">
                    <Button type="submit" disabled={!newReply.trim()} className="btn-primary">Publicar Respuesta</Button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForumTopicPage;
