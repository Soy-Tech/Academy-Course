
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import RankingCard from '@/components/RankingCard';
import { Trophy, TrendingUp, Award } from 'lucide-react';
import { mockRankings } from '@/data/mockRankings';

const RankingsPage = () => {
  const [rankings, setRankings] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [sortBy, setSortBy] = useState('points');
  const currentUser = JSON.parse(localStorage.getItem('currentUser'));

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      let data = [...mockRankings];
      
      // Add current user to rankings if logged in and not present
      if (currentUser) {
          // Check if already in mock data to avoid dupes in this simple logic
          const exists = data.find(r => r.users.name === currentUser.name);
          if (!exists) {
              data.push({
                  id: 999,
                  points: 50, // Starter points
                  contributions_count: 1,
                  users: {
                      name: currentUser.name,
                      specialty: 'Estudiante Nuevo',
                      profile_photo_url: null,
                      achievements: ['Newcomer']
                  }
              });
          }
      }

      // Sort
      data.sort((a, b) => b[sortBy] - a[sortBy]);
      setRankings(data);
      setIsLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [sortBy, currentUser]);

  return (
    <>
      <Helmet>
        <title>Rankings - Netcom Academy</title>
        <meta name="description" content="Descubre los estudiantes más activos y comprometidos de Netcom Academy." />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-5xl">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#CFAE70] to-yellow-600 rounded-2xl mb-6">
              <Trophy className="text-white" size={32} />
            </div>
            <h1 className="text-5xl font-bold text-gray-900 mb-4">Rankings</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Los estudiantes más destacados de nuestra comunidad
            </p>
          </motion.div>

          <div className="bg-white rounded-xl shadow-md p-6 mb-8">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Ordenar por:</h2>
              <div className="flex gap-3">
                <button
                  onClick={() => setSortBy('points')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    sortBy === 'points'
                      ? 'bg-[#CFAE70] text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Award size={18} className="inline mr-2" />
                  Puntos
                </button>
                <button
                  onClick={() => setSortBy('contributions_count')}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    sortBy === 'contributions_count'
                      ? 'bg-[#CFAE70] text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <TrendingUp size={18} className="inline mr-2" />
                  Contribuciones
                </button>
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0B3D91]"></div>
            </div>
          ) : (
            <div className="space-y-3">
              {rankings.map((ranking, index) => {
                const isMe = currentUser && ranking.users.name === currentUser.name;
                return (
                    <div key={index} className={isMe ? "ring-2 ring-[#0B3D91] rounded-xl" : ""}>
                        <RankingCard ranking={{ ...ranking, rank: index + 1 }} delay={index * 0.02} />
                    </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default RankingsPage;
