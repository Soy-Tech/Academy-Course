
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Award, Users, FileText, TrendingUp, Calendar, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const DashboardPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentUser, setCurrentUser] = useState(null);
  
  // Mock stats
  const stats = {
    coursesInProgress: 2,
    coursesCompleted: 4,
    points: 150,
    rank: 42
  };

  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (!storedUser) {
        navigate('/login');
    } else {
        setCurrentUser(JSON.parse(storedUser));
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    toast({
        title: "Sesión cerrada",
        description: "Has salido de tu cuenta."
    });
    navigate('/');
    // Reload to refresh header state
    window.location.reload();
  };

  if (!currentUser) return null;

  const quickActions = [
    { title: 'Explorar Rutas', icon: TrendingUp, link: '/learning-paths', color: 'bg-blue-500' },
    { title: 'Comunidad', icon: Users, link: '/community', color: 'bg-green-500' },
    { title: 'Recursos', icon: FileText, link: '/resources', color: 'bg-purple-500' },
    { title: 'Eventos', icon: Calendar, link: '/events', color: 'bg-orange-500' }
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard - Netcom Academy</title>
        <meta name="description" content="Tu panel de control personalizado." />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 flex flex-col md:flex-row justify-between items-center"
          >
            <div>
                <h1 className="text-4xl font-bold text-gray-900 mb-2">
                ¡Hola, {currentUser.name}! 👋
                </h1>
                <p className="text-gray-600">Continúa tu viaje de aprendizaje</p>
            </div>
            <Button variant="outline" onClick={handleLogout} className="mt-4 md:mt-0 text-red-600 hover:bg-red-50">
                <LogOut className="mr-2" size={18} />
                Cerrar Sesión
            </Button>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white rounded-xl shadow-md p-6 border-l-4 border-blue-500"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">En progreso</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.coursesInProgress}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <BookOpen className="text-blue-600" size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-xl shadow-md p-6 border-l-4 border-green-500"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Completados</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.coursesCompleted}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Award className="text-green-600" size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white rounded-xl shadow-md p-6 border-l-4 border-yellow-500"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Puntos totales</p>
                  <p className="text-3xl font-bold text-gray-900">{stats.points}</p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="text-yellow-600" size={24} />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-xl shadow-md p-6 border-l-4 border-purple-500"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Ranking</p>
                  <p className="text-3xl font-bold text-gray-900">#{stats.rank}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Users className="text-purple-600" size={24} />
                </div>
              </div>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="bg-white rounded-xl shadow-md p-6"
              >
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Accesos rápidos</h2>
                <div className="grid grid-cols-2 gap-4">
                  {quickActions.map((action, index) => (
                    <Link
                      key={index}
                      to={action.link}
                      className="group p-6 border-2 border-gray-200 rounded-xl hover:border-[#CFAE70] transition-all duration-300 hover:shadow-lg"
                    >
                      <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <action.icon className="text-white" size={24} />
                      </div>
                      <h3 className="font-semibold text-gray-900">{action.title}</h3>
                    </Link>
                  ))}
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
              className="space-y-6"
            >
              <div className="bg-gradient-to-br from-[#0B3D91] to-[#082d6b] rounded-xl shadow-md p-6 text-white">
                <h3 className="text-xl font-bold mb-4">🎯 Tu progreso</h3>
                <p className="text-gray-200 mb-6">
                  ¡Sigue así! Has completado {stats.coursesCompleted} cursos y acumulado {stats.points} puntos.
                </p>
                <Link to="/learning-paths">
                  <Button className="w-full bg-[#CFAE70] hover:bg-[#b89a5f] text-white">
                    Ver rutas de aprendizaje
                  </Button>
                </Link>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">🏆 Próxima meta</h3>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Nivel {Math.floor(stats.points / 100) + 1}</span>
                      <span className="text-gray-900 font-semibold">{stats.points % 100}/100 pts</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className="bg-[#CFAE70] h-3 rounded-full transition-all duration-500"
                        style={{ width: `${(stats.points % 100)}%` }}
                      ></div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">
                    {100 - (stats.points % 100)} puntos más para el siguiente nivel
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DashboardPage;
