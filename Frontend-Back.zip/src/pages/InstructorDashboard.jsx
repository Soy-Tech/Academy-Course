
import React from 'react';
import { motion } from 'framer-motion';
import { Users, DollarSign, BookOpen, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

const InstructorDashboard = () => {
  const { currentUser } = useAuth();

  const stats = [
    { label: 'Estudiantes Totales', value: 128, icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Ingresos (Mes)', value: '$1,240', icon: DollarSign, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Cursos Activos', value: 4, icon: BookOpen, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'Valoración Media', value: '4.8', icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-100' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      <div className="bg-white border-b border-gray-200 pt-8 pb-8 px-6">
        <div className="container mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Panel de Instructor</h1>
            <p className="text-gray-500">Bienvenido de nuevo, {currentUser?.name}.</p>
          </div>
          <Button className="bg-[#0B3D91] hover:bg-[#092c69]">
            + Crear Nuevo Curso
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
               <div className="flex justify-between items-start mb-4">
                  <div className={`p-3 rounded-xl ${stat.bg}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
               </div>
               <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
               <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50">
                <h3 className="font-bold text-gray-900">Mis Cursos</h3>
            </div>
            <div className="p-12 text-center">
                <p className="text-gray-500">Aquí aparecerá la lista de tus cursos creados.</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default InstructorDashboard;
