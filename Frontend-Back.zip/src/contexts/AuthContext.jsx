
import React, { createContext, useState, useEffect, useContext } from 'react';
import { ROLE_PERMISSIONS, ROLES } from '@/utils/rolePermissions';
import { mockDb } from '@/data/mockDatabase';
import { testUsers } from '@/data/testUsers';
import { logTestUserAction } from '@/utils/testUserHelper';

export const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  // 1. Inicialización de usuario
  // Usamos lazy initialization para leer de localStorage síncronamente en el primer render
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('auth_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        console.log('[AuthContext] Initialized from localStorage:', parsed.email, '| Role:', parsed.role);
        return parsed;
      }
    } catch (e) {
      console.error("[AuthContext] Error loading auth_user from localStorage", e);
    }
    return null;
  });

  const [loading, setLoading] = useState(false);
  const isSupabaseConfigured = true; 

  // DIAGNOSTIC LOGS
  useEffect(() => {
    console.log('[AuthContext] State Updated - User:', currentUser?.email, 'Role:', currentUser?.role, 'IsAuthenticated:', !!currentUser);
  }, [currentUser]);

  // Persistencia
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('auth_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('auth_user');
    }
  }, [currentUser]);

  // Auth Functions
  const login = async (email, password) => {
    setLoading(true);
    console.log(`[AuthContext] Login attempt for: ${email}`);
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // 1. Check Test Users
        const testUser = testUsers.find(u => u.email === email && u.password === password);
        
        if (testUser) {
          logTestUserAction('LOGIN', testUser.email);
          const permissions = ROLE_PERMISSIONS[testUser.role] || [];
          // Aseguramos estructura correcta del usuario
          const sessionUser = {
            ...testUser,
            permissions,
            isAuthenticated: true // Flag explícito
          };
          
          console.log(`[AuthContext] Test user success: ${testUser.email} | Role: ${testUser.role}`);
          setCurrentUser(sessionUser);
          resolve(sessionUser);
          setLoading(false);
          return;
        }

        // 2. Mock Database Fallback
        let user;
        if (password === 'demo') {
             const allUsers = mockDb.users.getAll();
             user = allUsers.find(u => u.role === email) || allUsers.find(u => u.email === email);
        } else {
             user = mockDb.users.getByEmail(email);
             if (user && user.password !== password) user = null;
        }

        if (user) {
          const permissions = ROLE_PERMISSIONS[user.role] || [];
          const sessionUser = {
            ...user,
            permissions,
            isAuthenticated: true
          };
          
          mockDb.auditLog.log('LOGIN', user.id, { email });
          console.log(`[AuthContext] Mock user success: ${user.email} | Role: ${user.role}`);
          setCurrentUser(sessionUser);
          resolve(sessionUser);
        } else {
          console.warn(`[AuthContext] Login failed for: ${email}`);
          reject(new Error('Credenciales inválidas'));
        }
        setLoading(false);
      }, 600);
    });
  };

  const signup = async (userData) => {
    setLoading(true);
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const existing = mockDb.users.getByEmail(userData.email);
        const existingTest = testUsers.find(u => u.email === userData.email);

        if (existing || existingTest) {
          reject(new Error('El email ya está registrado'));
          setLoading(false);
          return;
        }

        const newUser = mockDb.users.create({
          ...userData,
          role: ROLES.STUDENT,
          userType: 'public',
          status: 'active',
          avatar: userData.name.charAt(0).toUpperCase()
        });

        const sessionUser = {
          ...newUser,
          permissions: ROLE_PERMISSIONS[ROLES.STUDENT],
          isAuthenticated: true
        };
        setCurrentUser(sessionUser);
        mockDb.auditLog.log('SIGNUP', newUser.id, { email: newUser.email });
        resolve(sessionUser);
        setLoading(false);
      }, 800);
    });
  };

  const logout = () => {
    console.log(`[AuthContext] Logging out: ${currentUser?.email}`);
    if (currentUser) {
      if (currentUser.isTestUser) {
        logTestUserAction('LOGOUT', currentUser.email);
      } else {
        mockDb.auditLog.log('LOGOUT', currentUser.id, {});
      }
    }
    setCurrentUser(null);
  };

  const hasPermission = (permission) => {
    if (!currentUser) return false;
    if (currentUser.role === ROLES.SUPER_ADMIN) return true;
    return currentUser.permissions && currentUser.permissions.includes(permission);
  };

  const hasRole = (role) => {
    if (!currentUser) return false;
    return currentUser.role === role;
  };

  const refreshUser = () => {
     // Lógica de refresh simplificada para mantener consistencia
     if(currentUser) {
         console.log('[AuthContext] Refreshing user data');
         // ... (lógica existente mantenida)
     }
  };

  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      isAuthenticated: !!currentUser,
      isLoading: loading,
      isSupabaseConfigured,
      isAdmin: currentUser?.role === ROLES.ADMIN || currentUser?.role === ROLES.SUPER_ADMIN,
      isPreviewMode: false,
      login, 
      signup, 
      logout, 
      hasPermission,
      hasRole,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
