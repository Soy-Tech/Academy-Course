
import React, { createContext, useContext, useState, useEffect } from 'react';
import { ROLES, ROLE_PERMISSIONS, hasPermission as checkPermission } from '@/utils/rolePermissions';
import { mockSettings } from '@/data/mockSettings';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const RoleContext = createContext();

export const RoleProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  
  // State
  const [currentRole, setCurrentRole] = useState(ROLES.STUDENT);
  const [permissions, setPermissions] = useState(ROLE_PERMISSIONS[ROLES.STUDENT]);
  const [platformSettings, setPlatformSettings] = useState(mockSettings);

  // Initialize role from localStorage or currentUser on mount
  useEffect(() => {
    const savedRole = localStorage.getItem('user_role');
    const savedSettings = localStorage.getItem('platform_settings');

    if (savedRole && Object.values(ROLES).includes(savedRole)) {
      setCurrentRole(savedRole);
      setPermissions(ROLE_PERMISSIONS[savedRole]);
    } else if (currentUser?.role) {
      // Fallback to auth user role if no local override
      setRole(currentUser.role);
    }

    if (savedSettings) {
      try {
        setPlatformSettings(JSON.parse(savedSettings));
      } catch (e) {
        console.error('Error parsing settings', e);
      }
    }
  }, [currentUser]);

  // Update permissions whenever role changes
  useEffect(() => {
    setPermissions(ROLE_PERMISSIONS[currentRole]);
  }, [currentRole]);

  // Method to set role (persists to localStorage)
  const setRole = (role) => {
    if (!Object.values(ROLES).includes(role)) {
      console.error(`Invalid role: ${role}`);
      return;
    }
    setCurrentRole(role);
    localStorage.setItem('user_role', role);
    setPermissions(ROLE_PERMISSIONS[role]);
  };

  // Check specific permission
  const hasPermission = (permission) => {
    return checkPermission(currentRole, permission);
  };

  // Check route access
  const canAccess = (route) => {
    // Admin always has access
    if (currentRole === ROLES.ADMIN) return true;

    if (route.startsWith('/admin')) {
      return hasPermission('view_admin');
    }
    
    // Default to true for non-admin routes managed by this context
    // (Actual auth protection is handled by AuthContext/ProtectedRoute)
    return true;
  };

  // Update platform settings
  const updateSettings = (newSettings) => {
    const updated = { ...platformSettings, ...newSettings };
    setPlatformSettings(updated);
    localStorage.setItem('platform_settings', JSON.stringify(updated));
    toast({
      title: "Configuración actualizada",
      description: "Los cambios han sido guardados correctamente."
    });
  };

  const value = {
    currentRole,
    currentUser,
    permissions,
    platformSettings,
    setRole,
    hasPermission,
    canAccess,
    updateSettings
  };

  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>;
};

export const useRole = () => {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
};
