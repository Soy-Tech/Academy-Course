
import React, { createContext, useState, useEffect, useContext } from 'react';

export const EnrollmentContext = createContext(null);

export const EnrollmentProvider = ({ children }) => {
  const [enrolledCourses, setEnrolledCourses] = useState(() => {
    try {
      const saved = localStorage.getItem('enrolledCourses');
      // Initialize with our mock student courses if empty for demo purposes
      if (!saved || JSON.parse(saved).length === 0) {
        return ['course-react-fundamentals', 'course-js-advanced', 'course-web-design'];
      }
      return JSON.parse(saved);
    } catch (error) {
      console.error('Error reading enrolled courses from localStorage:', error);
      return ['course-react-fundamentals', 'course-js-advanced', 'course-web-design'];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('enrolledCourses', JSON.stringify(enrolledCourses));
    } catch (error) {
      console.error('Error saving enrolled courses to localStorage:', error);
    }
  }, [enrolledCourses]);

  const enrollCourse = (courseId) => {
    if (!enrolledCourses.includes(courseId)) {
      setEnrolledCourses((prev) => [...prev, courseId]);
    }
  };

  const isEnrolled = (courseId) => {
    return enrolledCourses.includes(courseId);
  };

  const getEnrolledCourses = () => {
    return enrolledCourses;
  };

  return (
    <EnrollmentContext.Provider value={{ enrolledCourses, enrollCourse, isEnrolled, getEnrolledCourses }}>
      {children}
    </EnrollmentContext.Provider>
  );
};

// Hook created directly in context file as requested
export const useEnrollment = () => {
  const context = useContext(EnrollmentContext);
  if (!context) {
    throw new Error('useEnrollment must be used within an EnrollmentProvider');
  }
  return context;
};

export default EnrollmentContext;
