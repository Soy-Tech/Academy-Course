
import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '@/contexts/AuthContext';
import { ROLES, ROLE_PERMISSIONS } from '@/utils/rolePermissions';
import { MOCK_USERS } from '@/utils/previewMockData';

// Re-export context hook for consistency
export const usePreviewAuth = () => {
    const context = useContext(AuthContext);
    if (!context) throw new Error('usePreviewAuth must be used within PreviewAuthProvider');
    return context;
};

export const PreviewAuthProvider = ({ children }) => {
  // Inicialización síncrona del rol
  const [currentRole, setCurrentRole] = useState(() => {
    try {
        return sessionStorage.getItem('preview_role') || ROLES.STUDENT;
    } catch {
        return ROLES.STUDENT;
    }
  });

  // CORRECCIÓN CRÍTICA (Task 9): Inicialización Síncrona del User
  // Evita que currentUser sea null en el primer render, eliminando race conditions
  const getInitialUser = (role) => {
    const baseUser = MOCK_USERS[role];
    if (!baseUser) return null;
    
    const permissions = ROLE_PERMISSIONS[role] || [];
    return {
      ...baseUser,
      permissions,
      isAuthenticated: true 
    };
  };

  const [currentUser, setCurrentUser] = useState(() => getInitialUser(currentRole));

  // Efecto solo para cambios posteriores de rol
  useEffect(() => {
    const newUser = getInitialUser(currentRole);
    console.log(`[PreviewAuthContext] Role switched to: ${currentRole}`, newUser);
    setCurrentUser(newUser);
    sessionStorage.setItem('preview_role', currentRole);
  }, [currentRole]);

  const login = async () => currentUser;
  const signup = async () => currentUser;
  const logout = () => { switchRole(ROLES.STUDENT); };

  const switchRole = (newRole) => {
    if (Object.values(ROLES).includes(newRole)) {
      setCurrentRole(newRole);
    }
  };

  const hasPermission = (permission) => {
    if (!currentUser) return false;
    if (currentUser.role === ROLES.SUPER_ADMIN) return true;
    return currentUser.permissions && currentUser.permissions.includes(permission);
  };

  const hasRole = (role) => {
    if (!currentUser) return false;
    return currentUser.role === role;
  };

  const refreshUser = () => {};

  // Log diagnóstico inicial
  useEffect(() => {
      console.log('PreviewAuthContext initialized with user:', currentUser);
  }, []);

  const value = { 
    currentUser, 
    isAuthenticated: true,
    isLoading: false, // Siempre false porque inicializamos síncronamente
    isSupabaseConfigured: false,
    isAdmin: currentUser?.role === ROLES.ADMIN || currentUser?.role === ROLES.SUPER_ADMIN,
    isPreviewMode: true,
    login, 
    signup, 
    logout, 
    hasPermission,
    hasRole,
    refreshUser,
    switchRole,
    currentRole
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default PreviewAuthProvider;
