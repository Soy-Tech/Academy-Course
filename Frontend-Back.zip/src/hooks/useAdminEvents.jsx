
import { useState, useEffect } from 'react';
import { mockAdminEvents } from '@/data/mockAdminEvents';
import { useToast } from '@/components/ui/use-toast';

export const useAdminEvents = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    const storedEvents = localStorage.getItem('adminEvents');
    if (storedEvents) {
      setEvents(JSON.parse(storedEvents));
    } else {
      setEvents(mockAdminEvents);
      localStorage.setItem('adminEvents', JSON.stringify(mockAdminEvents));
    }
    setLoading(false);
  }, []);

  const saveEvents = (newEvents) => {
    setEvents(newEvents);
    localStorage.setItem('adminEvents', JSON.stringify(newEvents));
  };

  const addEvent = (eventData) => {
    const newEvent = {
      id: Math.max(...events.map(e => e.id), 0) + 1,
      asistentes: 0,
      ...eventData
    };
    saveEvents([newEvent, ...events]);
    toast({ title: "Evento creado", description: "El evento ha sido programado exitosamente." });
  };

  const updateEvent = (id, updates) => {
    const updatedEvents = events.map(evt => evt.id === id ? { ...evt, ...updates } : evt);
    saveEvents(updatedEvents);
    toast({ title: "Evento actualizado", description: "Los detalles del evento han sido guardados." });
  };

  const deleteEvent = (id) => {
    const filteredEvents = events.filter(evt => evt.id !== id);
    saveEvents(filteredEvents);
    toast({ title: "Evento cancelado", description: "El evento ha sido eliminado del calendario.", variant: "destructive" });
  };

  return {
    events,
    loading,
    addEvent,
    updateEvent,
    deleteEvent
  };
};

export default useAdminEvents;
