
import { useState, useEffect } from 'react';
import { useEnrollment } from '@/contexts/EnrollmentContext'; // Fixed import source
import { courseStructureData } from '@/data/courseStructureData';
import { useCourseProgress } from '@/hooks/useCourseProgress';

export const useStudentCourses = () => {
  const { enrolledCourses, isEnrolled } = useEnrollment();
  const { getCourseProgress } = useCourseProgress();
  const [studentCourses, setStudentCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Map enrolled IDs to full course structure data
    const courses = enrolledCourses.map(id => {
      const course = courseStructureData[id];
      if (!course) return null;
      
      const progressStats = getCourseProgress(id);
      
      return {
        ...course,
        progress: progressStats.percentage,
        completedLessons: progressStats.completed,
        totalLessons: progressStats.total,
        isCompleted: progressStats.percentage === 100,
        lastAccessed: new Date().toISOString() // Mock data
      };
    }).filter(Boolean);

    setStudentCourses(courses);
    setLoading(false);
  }, [enrolledCourses, getCourseProgress]);

  const getStudentCourse = (courseId) => {
    return courseStructureData[courseId] || null;
  };

  const getStudentCourseProgress = (courseId) => {
    return getCourseProgress(courseId);
  };

  return {
    studentCourses,
    getStudentCourse,
    getStudentCourseProgress,
    isEnrolled,
    loading
  };
};

export default useStudentCourses;
