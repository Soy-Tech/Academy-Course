
import { useState, useEffect } from 'react';
import { videosData as initialVideos } from '@/data/videosData';

export const useVideos = () => {
  const [videos, setVideos] = useState(() => {
    try {
      const saved = localStorage.getItem('videos_data');
      return saved ? JSON.parse(saved) : initialVideos;
    } catch (error) {
      console.error('Error loading videos from localStorage', error);
      return initialVideos;
    }
  });

  // Persistence
  useEffect(() => {
    try {
      localStorage.setItem('videos_data', JSON.stringify(videos));
    } catch (error) {
      console.error('Error saving videos to localStorage', error);
    }
  }, [videos]);

  // Methods
  const getVideosByCourse = (courseId) => {
    return videos
      .filter(v => v.courseId === courseId)
      .sort((a, b) => a.order - b.order);
  };

  const getVideo = (videoId) => {
    return videos.find(v => v.id === videoId);
  };

  const addVideo = (videoData) => {
    const newVideo = {
      ...videoData,
      id: `v${Date.now()}`,
      uploadedDate: new Date().toISOString()
    };
    setVideos(prev => [...prev, newVideo]);
    return newVideo;
  };

  const updateVideo = (videoId, updates) => {
    setVideos(prev => prev.map(v => v.id === videoId ? { ...v, ...updates } : v));
  };

  const deleteVideo = (videoId) => {
    setVideos(prev => prev.filter(v => v.id !== videoId));
  };

  const reorderVideos = (courseId, newOrder) => {
    // newOrder is an array of video IDs in the desired order
    setVideos(prev => {
      const courseVideos = prev.filter(v => v.courseId === courseId);
      const otherVideos = prev.filter(v => v.courseId !== courseId);
      
      const updatedCourseVideos = courseVideos.map(v => {
        const index = newOrder.indexOf(v.id);
        if (index !== -1) {
          return { ...v, order: index + 1 };
        }
        return v;
      });

      return [...otherVideos, ...updatedCourseVideos];
    });
  };

  // Supabase Integration Note:
  // When switching to Supabase, replace these methods with async calls to the 'videos' table.
  // e.g., const { data, error } = await supabase.from('videos').select('*').eq('course_id', courseId);

  return {
    videos,
    getVideosByCourse,
    getVideo,
    addVideo,
    updateVideo,
    deleteVideo,
    reorderVideos
  };
};

export default useVideos;
