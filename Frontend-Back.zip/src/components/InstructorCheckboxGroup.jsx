
import React from 'react';
import { cn } from '@/lib/utils';
import { Check, AlertCircle } from 'lucide-react';

const InstructorCheckboxGroup = ({ items, checkedItems, onChange, errors }) => {
  return (
    <div className="space-y-3">
      {items.map((item) => {
        const isChecked = checkedItems[item.id] || false;
        const hasError = errors && !isChecked && item.required; // Note: usually errors passed as object/boolean
        
        return (
          <label 
            key={item.id}
            className={cn(
              "flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all duration-200 group",
              isChecked 
                ? "bg-blue-50 border-[#0B3D91]/30 shadow-sm" 
                : "bg-white border-gray-200 hover:border-gray-300 hover:bg-gray-50"
            )}
          >
            <div className="relative flex items-center mt-0.5">
              <input
                type="checkbox"
                className="peer sr-only" // hidden checkbox
                checked={isChecked}
                onChange={(e) => onChange(item.id, e.target.checked)}
              />
              <div className={cn(
                "w-6 h-6 rounded-md border-2 transition-all flex items-center justify-center",
                isChecked 
                  ? "bg-[#0B3D91] border-[#0B3D91]" 
                  : "bg-white border-gray-300 group-hover:border-gray-400"
              )}>
                <Check size={14} className="text-white" strokeWidth={3} />
              </div>
            </div>
            
            <div className="flex-1">
               <span className={cn(
                 "text-sm font-medium transition-colors",
                 isChecked ? "text-[#0B3D91]" : "text-gray-700"
               )}>
                 {item.label} {item.required && <span className="text-red-500">*</span>}
               </span>
            </div>
          </label>
        );
      })}
      
      {errors && typeof errors === 'string' && (
        <div className="flex items-center gap-2 p-3 bg-red-50 text-red-700 rounded-lg text-sm border border-red-100">
          <AlertCircle size={16} />
          {errors}
        </div>
      )}
    </div>
  );
};

export default InstructorCheckboxGroup;
