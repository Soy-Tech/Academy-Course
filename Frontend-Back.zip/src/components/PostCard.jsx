
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, User } from 'lucide-react';

const PostCard = ({ post, delay }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Link to={`/community/post/${post.id}`}>
        <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-all duration-300 group">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#CFAE70] flex items-center justify-center text-white font-bold flex-shrink-0">
              {post.users?.profile_photo_url ? (
                <img src={post.users.profile_photo_url} alt="" className="w-full h-full rounded-full object-cover" />
              ) : (
                <User size={24} />
              )}
            </div>
            
            <div className="flex-grow">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-semibold text-gray-900">{post.users?.name || 'Usuario'}</span>
                <span className="text-gray-500">•</span>
                <span className="text-sm text-gray-500">
                  {new Date(post.created_at).toLocaleDateString('es-ES', { 
                    day: 'numeric',
                    month: 'short'
                  })}
                </span>
                <span className="ml-auto px-3 py-1 bg-[#0B3D91] bg-opacity-10 text-[#0B3D91] rounded-full text-xs font-medium">
                  {post.category}
                </span>
              </div>
              
              <h2 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-[#0B3D91] transition-colors">
                {post.title}
              </h2>
              
              <p className="text-gray-600 mb-4 line-clamp-2">
                {post.content}
              </p>
              
              <div className="flex items-center gap-6 text-gray-500">
                <div className="flex items-center gap-2 hover:text-red-500 transition-colors">
                  <Heart size={18} />
                  <span className="text-sm">{post.likes_count || 0}</span>
                </div>
                <div className="flex items-center gap-2 hover:text-[#0B3D91] transition-colors">
                  <MessageCircle size={18} />
                  <span className="text-sm">{post.comment_count || 0}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default PostCard;
