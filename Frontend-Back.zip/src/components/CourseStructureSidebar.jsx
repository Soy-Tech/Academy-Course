
import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import LessonProgressIndicator from './LessonProgressIndicator';

const CourseStructureSidebar = ({ 
  structure, 
  currentLessonId, 
  progressData, 
  onSelectLesson, 
  isOpen, 
  onClose 
}) => {
  // Initialize with all modules expanded
  const [expandedModules, setExpandedModules] = useState(
    structure?.modules.reduce((acc, mod) => ({ ...acc, [mod.id]: true }), {}) || {}
  );

  const toggleModule = (moduleId) => {
    setExpandedModules(prev => ({
      ...prev,
      [moduleId]: !prev[moduleId]
    }));
  };

  if (!isOpen || !structure) return null;

  return (
    <div className="h-full flex flex-col bg-white border-r border-gray-200 w-full md:w-80 lg:w-96 overflow-hidden">
      
      {/* Mobile Header */}
      <div className="md:hidden p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
        <h3 className="font-bold text-gray-800">Contenido del curso</h3>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-800 text-sm font-medium">
          Cerrar
        </button>
      </div>

      {/* Course Progress Header */}
      <div className="p-6 border-b border-gray-100 bg-gray-50/50">
         <h2 className="font-bold text-gray-900 text-lg mb-2 line-clamp-1" title={structure.title}>
             {structure.title}
         </h2>
         <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
             <span className="font-medium">{structure.modules.length} Módulos</span>
             <span>•</span>
             <span>{structure.modules.reduce((acc, m) => acc + m.lessons.length, 0)} Lecciones</span>
         </div>
      </div>

      {/* Modules List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {structure.modules.map((module) => {
          const completedLessons = module.lessons.filter(l => progressData[l.id]).length;
          const totalLessons = module.lessons.length;
          const progress = totalLessons === 0 ? 0 : Math.round((completedLessons / totalLessons) * 100);
          const isExpanded = expandedModules[module.id];

          return (
            <div key={module.id} className="border border-gray-100 rounded-lg overflow-hidden bg-white shadow-sm">
              {/* Module Header */}
              <button 
                onClick={() => toggleModule(module.id)}
                className="w-full p-4 flex items-center justify-between hover:bg-gray-50 transition-colors text-left"
              >
                <div className="flex-1 min-w-0 pr-2">
                  <h4 className="font-bold text-gray-800 text-sm mb-1">{module.title}</h4>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <div className="w-16 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-green-500" style={{ width: `${progress}%` }} />
                    </div>
                    <span>{progress}%</span>
                  </div>
                </div>
                {isExpanded ? <ChevronDown size={18} className="text-gray-400" /> : <ChevronRight size={18} className="text-gray-400" />}
              </button>

              {/* Lessons List */}
              {isExpanded && (
                <div className="border-t border-gray-100 bg-gray-50/30">
                  {module.lessons.map((lesson) => {
                    const isActive = currentLessonId === lesson.id;
                    const isCompleted = progressData[lesson.id];

                    return (
                      <button
                        key={lesson.id}
                        onClick={() => {
                          onSelectLesson(lesson);
                          if(window.innerWidth < 768) onClose();
                        }}
                        className={cn(
                          "w-full flex items-center gap-3 p-3 pl-4 transition-colors border-l-4 text-left group hover:bg-white",
                          isActive 
                            ? "bg-white border-[#0B3D91]" 
                            : "border-transparent"
                        )}
                      >
                        <LessonProgressIndicator 
                          isCompleted={isCompleted} 
                          type={lesson.type} 
                          className={isCompleted ? "" : (isActive ? "text-[#0B3D91]" : "")}
                        />
                        
                        <div className="flex-1 min-w-0">
                           <p className={cn(
                             "text-sm font-medium leading-tight mb-0.5 group-hover:text-[#0B3D91] truncate",
                             isActive ? "text-[#0B3D91]" : "text-gray-700",
                             isCompleted && !isActive && "text-gray-500"
                           )}>
                             {lesson.title}
                           </p>
                           <div className="flex items-center gap-2 text-xs text-gray-400">
                             {lesson.type === 'video' ? (
                               <span>{lesson.duration} min</span>
                             ) : (
                               <span>{lesson.resourceType}</span>
                             )}
                           </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CourseStructureSidebar;
