
import React from 'react';
import ProtectedRoute from '@/components/ProtectedRoute';
import { ROLES } from '@/utils/rolePermissions';

/**
 * Wrapper for ProtectedRoute specifically for Admin/SuperAdmin access.
 * Simplifies usage in App.jsx by pre-defining the allowed roles.
 */
const ProtectedAdminRoute = ({ children }) => {
  return (
    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
      {children}
    </ProtectedRoute>
  );
};

export default ProtectedAdminRoute;
