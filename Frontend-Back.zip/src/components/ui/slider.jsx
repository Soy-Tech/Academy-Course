
import React, { forwardRef } from 'react';
import { cn } from '@/lib/utils';

const Slider = forwardRef(({ className, min = 0, max = 100, step = 1, value = [0], onValueChange, ...props }, ref) => {
  const val = value[0];
  const percentage = ((val - min) / (max - min)) * 100;

  const handleChange = (e) => {
    const newValue = parseFloat(e.target.value);
    onValueChange?.([newValue]);
  };

  return (
    <div ref={ref} className={cn("relative flex w-full touch-none select-none items-center", className)} {...props}>
      {/* Track */}
      <div className="relative h-2 w-full grow overflow-hidden rounded-full bg-secondary">
        <div 
          className="absolute h-full bg-primary transition-all" 
          style={{ width: `${percentage}%` }} 
        />
      </div>
      
      {/* Thumb - Visual Only */}
      <div 
        className="absolute h-5 w-5 rounded-full border-2 border-primary bg-background ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 shadow-sm"
        style={{ 
          left: `${percentage}%`,
          transform: 'translateX(-50%)', // Center the thumb on the point
          pointerEvents: 'none'
        }}
      />

      {/* Native Input - Interaction Layer */}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={val}
        onChange={handleChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
      />
    </div>
  );
});

Slider.displayName = "Slider";

export { Slider };
