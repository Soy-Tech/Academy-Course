
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, BookOpen, ArrowRight, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

const LearningPathCard = ({ path, delay = 0 }) => {
  const difficultyColors = {
    Principiante: 'bg-green-100 text-green-700 border-green-200',
    Intermedio: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    Avanzado: 'bg-red-100 text-red-700 border-red-200'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay, duration: 0.4 }}
      className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full group"
    >
      {/* Image Header */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src={path.image} 
          alt={path.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4">
          <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide border backdrop-blur-md ${difficultyColors[path.level] || 'bg-gray-100 text-gray-700'}`}>
            {path.level}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-[#0B3D91] transition-colors">
          {path.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-6 line-clamp-2 flex-grow">
          {path.shortDescription}
        </p>

        <div className="flex items-center justify-between text-sm text-gray-500 mb-6 pt-4 border-t border-gray-100">
          <div className="flex items-center gap-1.5">
            <BookOpen size={16} className="text-[#CFAE70]" />
            <span>{path.courses.length} Cursos</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock size={16} className="text-[#CFAE70]" />
            <span>{path.duration}</span>
          </div>
        </div>

        <Link to={`/learning-paths/${path.id}`} className="mt-auto">
          <Button className="w-full bg-gray-50 hover:bg-[#0B3D91] text-[#0B3D91] hover:text-white border border-[#0B3D91] transition-all duration-300 font-semibold group-hover:shadow-md">
            Ver Ruta
            <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </div>
    </motion.div>
  );
};

export default LearningPathCard;
