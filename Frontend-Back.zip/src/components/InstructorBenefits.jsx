
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, DollarSign, Layout, Users, Award, MessageCircle, Heart, ChevronDown, ChevronUp } from 'lucide-react';

const BenefitItem = ({ icon: Icon, title, description }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border border-green-100 rounded-lg mb-3 overflow-hidden bg-white hover:shadow-md transition-shadow">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 bg-green-50/50 hover:bg-green-50 transition-colors text-left"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-green-100 rounded-full text-green-700">
            <Icon size={20} />
          </div>
          <span className="font-semibold text-gray-800">{title}</span>
        </div>
        {isOpen ? <ChevronUp size={18} className="text-gray-500" /> : <ChevronDown size={18} className="text-gray-500" />}
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-4 text-gray-600 text-sm leading-relaxed border-t border-green-100">
              {description}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const InstructorBenefits = () => {
  const benefits = [
    {
      icon: TrendingUp,
      title: "Publica y Crece",
      description: "Acceso ilimitado para publicar cursos en nuestra plataforma. Llega a miles de estudiantes en todo el mundo y expande tu marca personal."
    },
    {
      icon: DollarSign,
      title: "Monetización Atractiva",
      description: "Gana hasta el 70% de los ingresos por cada venta de tus cursos. Pagos mensuales puntuales y transparentes a través de PayPal o transferencia."
    },
    {
      icon: Layout,
      title: "Panel de Instructor Pro",
      description: "Herramientas avanzadas para gestionar tus cursos, crear cupones, ver analíticas detalladas y gestionar tus recursos educativos."
    },
    {
      icon: Users,
      title: "Estadísticas de Estudiantes",
      description: "Conoce a tu audiencia. Visualiza el progreso de tus estudiantes, tasas de finalización y feedback directo para mejorar tu contenido."
    },
    {
      icon: Award,
      title: "Posicionamiento como Experto",
      description: "Establece tu autoridad en tu campo. Los instructores destacados reciben insignias especiales y promoción adicional en nuestras redes."
    },
    {
      icon: MessageCircle,
      title: "Comunidad Exclusiva",
      description: "Acceso a foros privados de instructores para compartir consejos, estrategias y colaborar con otros expertos."
    },
    {
      icon: Heart,
      title: "Soporte Dedicado",
      description: "Equipo de soporte prioritario para ayudarte con problemas técnicos, dudas sobre contenido o gestión de tu cuenta."
    }
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 h-full">
      <h3 className="text-xl font-bold text-green-700 mb-2 flex items-center gap-2">
        <Award className="text-[#CFAE70]" /> Beneficios del Programa
      </h3>
      <p className="text-gray-500 text-sm mb-6">Descubre lo que ganas al unirte a nuestra comunidad.</p>
      
      <div className="space-y-1">
        {benefits.map((benefit, index) => (
          <BenefitItem key={index} {...benefit} />
        ))}
      </div>
    </div>
  );
};

export default InstructorBenefits;
