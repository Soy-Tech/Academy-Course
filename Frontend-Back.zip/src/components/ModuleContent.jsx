
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { PlayCircle, FileText, File, Download, Beaker } from 'lucide-react';

const ModuleContent = ({ module, courseId }) => {
  const navigate = useNavigate();

  const handleResourceClick = (resourceId) => {
    navigate(`/course/${courseId}/lesson/${resourceId}`);
  };

  const ResourceItem = ({ icon: Icon, resource, colorClass }) => (
    <button
      onClick={() => handleResourceClick(resource.id)}
      className="w-full flex items-center gap-3 p-3 bg-white border border-gray-100 rounded-lg hover:shadow-md hover:border-blue-100 transition-all text-left group"
    >
      <div className={`p-2 rounded-full ${colorClass} bg-opacity-10 group-hover:bg-opacity-20 transition-colors`}>
        <Icon size={18} className={colorClass.replace('bg-', 'text-')} />
      </div>
      <span className="text-sm font-medium text-gray-700 group-hover:text-gray-900">
        {resource.title}
      </span>
    </button>
  );

  return (
    <div className="space-y-4 py-2 px-1">
      {/* Videos */}
      {module.resources.videos?.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-1">Videos</h4>
          <div className="grid gap-2">
            {module.resources.videos.map(video => (
              <ResourceItem 
                key={video.id} 
                icon={PlayCircle} 
                resource={video} 
                colorClass="bg-red-500 text-red-500" 
              />
            ))}
          </div>
        </div>
      )}

      {/* PDFs */}
      {module.resources.pdfs?.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-1">Documentos PDF</h4>
          <div className="grid gap-2">
            {module.resources.pdfs.map(pdf => (
              <ResourceItem 
                key={pdf.id} 
                icon={FileText} 
                resource={pdf} 
                colorClass="bg-orange-500 text-orange-500" 
              />
            ))}
          </div>
        </div>
      )}

      {/* Docs */}
      {module.resources.docs?.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-1">Lecturas</h4>
          <div className="grid gap-2">
            {module.resources.docs.map(doc => (
              <ResourceItem 
                key={doc.id} 
                icon={File} 
                resource={doc} 
                colorClass="bg-blue-500 text-blue-500" 
              />
            ))}
          </div>
        </div>
      )}

      {/* Files */}
      {module.resources.files?.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-1">Archivos Descargables</h4>
          <div className="grid gap-2">
            {module.resources.files.map(file => (
              <ResourceItem 
                key={file.id} 
                icon={Download} 
                resource={file} 
                colorClass="bg-green-500 text-green-500" 
              />
            ))}
          </div>
        </div>
      )}

      {/* Activities */}
      {module.resources.activities?.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-1">Actividades Prácticas</h4>
          <div className="grid gap-2">
            {module.resources.activities.map(activity => (
              <ResourceItem 
                key={activity.id} 
                icon={Beaker} 
                resource={activity} 
                colorClass="bg-purple-500 text-purple-500" 
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ModuleContent;
