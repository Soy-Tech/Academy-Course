
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Loader2 } from 'lucide-react';

const ProtectedRoute = ({ children, allowedRoles = [] }) => {
  // 1. Cómo se obtiene el user
  const { currentUser, isLoading, isAuthenticated, isPreviewMode } = useAuth();
  const location = useLocation();

  // DIAGNOSTIC LOGS
  console.group('ProtectedRoute Diagnostics');
  console.log('Path:', location.pathname);
  console.log('Is Loading:', isLoading);
  console.log('Is Preview Mode:', isPreviewMode);
  console.log('Is Authenticated:', isAuthenticated);
  console.log('Current User:', currentUser);
  console.log('User Role:', currentUser?.role);
  console.log('Allowed Roles:', allowedRoles);
  console.groupEnd();

  // 2. Loading State
  // Si está cargando, mostramos spinner para evitar redirecciones prematuras
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-10 w-10 animate-spin text-[#0B3D91]" />
          <p className="text-sm text-gray-500 font-medium">Verificando permisos...</p>
        </div>
      </div>
    );
  }

  // 3. Preview Mode Bypass
  // En modo preview, confiamos en el contexto de preview.
  // IMPORTANTE: Incluso en preview, si el usuario es null (por error de inicialización), no deberíamos renderizar.
  // Pero PreviewAuthContext corregido ahora garantiza usuario síncrono.
  if (isPreviewMode) {
    // Si por alguna razón el usuario es null en preview, forzamos login o renderizamos children si la política es laxa
    if (!currentUser) {
       console.warn('[ProtectedRoute] Preview Mode active but User is NULL. This indicates an initialization race condition.');
       // Fallback seguro: permitimos renderizar porque es preview, o mostramos loading
       return children; 
    }
    // Check de roles en preview para simular comportamiento real
    if (allowedRoles.length > 0 && !allowedRoles.includes(currentUser.role)) {
       console.warn(`[ProtectedRoute:Preview] Access Denied. Role '${currentUser.role}' not in allowed list.`);
       // En preview podríamos querer mostrar la página de "Acceso Denegado" real
       return <Navigate to="/access-denied" replace />;
    }
    return children;
  }

  // 4. Authentication Check (Normal Mode)
  if (!isAuthenticated || !currentUser) {
    console.log('[ProtectedRoute] User not authenticated. Redirecting to login.');
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  // 5. Role Validation
  if (allowedRoles.length > 0) {
    // Validación defensiva: asegurar que user.role existe
    if (!currentUser.role) {
       console.error('[ProtectedRoute] User exists but has NO ROLE. Redirecting to login for safety.');
       return <Navigate to="/login" replace />;
    }

    // Comparación directa (case-sensitive estricta según constantes)
    const hasAllowedRole = allowedRoles.includes(currentUser.role);
    
    console.log(`[ProtectedRoute] Role Check: User=${currentUser.role} vs Allowed=[${allowedRoles.join(', ')}] -> Result: ${hasAllowedRole}`);

    if (!hasAllowedRole) {
      console.warn(`[ProtectedRoute] Access Denied. Redirecting to /access-denied.`);
      return <Navigate to="/access-denied" replace />;
    }
  }

  // 6. Access Granted
  return children;
};

export default ProtectedRoute;
