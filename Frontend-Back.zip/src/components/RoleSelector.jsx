
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { ROLES, getRoleLabel } from '@/utils/rolePermissions';
import { Shield, GraduationCap, User, ChevronDown } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

// Note: This component is currently used for visual demonstrations or legacy role switching.
// For the actual Test User implementation, we use real authentications via AuthContext.
// This component should ideally be hidden or disabled if a Test User is logged in,
// as Test Users have fixed roles that shouldn't be casually switched in the UI.

const RoleSelector = () => {
  const { currentUser, switchRole, isAuthenticated } = useAuth();
  const { toast } = useToast();

  if (!isAuthenticated) return null;

  // Don't show role selector if user is a Test User (their role is fixed by the test account)
  if (currentUser?.isTestUser) {
    return null; 
  }

  // Only show for Super Admin or Admin (optional, based on requirements) to switch views
  // For now, we allow it for demonstration purposes as per original implementation
  const currentRole = currentUser?.role || ROLES.STUDENT;

  const handleRoleChange = (newRole) => {
    if (newRole === currentRole) return;
    
    switchRole(newRole);
    
    const label = getRoleLabel(newRole);
    toast({
      title: "Vista cambiada",
      description: `Ahora estás visualizando la plataforma como: ${label}`,
      className: "bg-blue-50 border-blue-200"
    });
  };

  const getIcon = (role) => {
    switch (role) {
      case ROLES.ADMIN: return <Shield size={16} className="text-purple-600" />;
      case ROLES.INSTRUCTOR: return <GraduationCap size={16} className="text-blue-600" />;
      default: return <User size={16} className="text-gray-600" />;
    }
  };

  const getBadgeStyle = (role) => {
    switch (role) {
      case ROLES.ADMIN: return "bg-purple-100 text-purple-700 border-purple-200";
      case ROLES.INSTRUCTOR: return "bg-blue-100 text-blue-700 border-blue-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const RoleIcon = getIcon(currentRole);
  const badgeStyle = getBadgeStyle(currentRole);

  return (
    <div className="flex items-center">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm"
            className={`flex items-center gap-2 h-9 px-3 rounded-lg border transition-all ${badgeStyle} hover:bg-opacity-80`}
          >
            {RoleIcon}
            <span className="hidden sm:inline-block font-medium text-xs uppercase tracking-wide">
              {getRoleLabel(currentRole)}
            </span>
            <ChevronDown size={14} className="opacity-50" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56 bg-white z-50 p-1">
          <DropdownMenuLabel className="text-xs text-gray-500 font-normal uppercase tracking-wider px-2 py-1.5">
            Cambiar Vista (Demo)
          </DropdownMenuLabel>
          <DropdownMenuSeparator className="my-1" />
          
          <DropdownMenuItem 
            onClick={() => handleRoleChange(ROLES.ADMIN)}
            className={`flex items-center gap-2 cursor-pointer p-2 rounded-md ${currentRole === ROLES.ADMIN ? 'bg-purple-50' : ''}`}
          >
            <div className="p-1.5 bg-purple-100 rounded-md text-purple-600">
              <Shield size={16} />
            </div>
            <div className="flex flex-col">
              <span className="font-medium text-sm text-gray-900">Administrador</span>
              <span className="text-xs text-gray-500">Acceso total al sistema</span>
            </div>
            {currentRole === ROLES.ADMIN && <div className="ml-auto w-2 h-2 rounded-full bg-purple-600" />}
          </DropdownMenuItem>
          
          <DropdownMenuItem 
            onClick={() => handleRoleChange(ROLES.INSTRUCTOR)}
            className={`flex items-center gap-2 cursor-pointer p-2 rounded-md ${currentRole === ROLES.INSTRUCTOR ? 'bg-blue-50' : ''}`}
          >
            <div className="p-1.5 bg-blue-100 rounded-md text-blue-600">
              <GraduationCap size={16} />
            </div>
            <div className="flex flex-col">
              <span className="font-medium text-sm text-gray-900">Instructor</span>
              <span className="text-xs text-gray-500">Gestión de cursos</span>
            </div>
            {currentRole === ROLES.INSTRUCTOR && <div className="ml-auto w-2 h-2 rounded-full bg-blue-600" />}
          </DropdownMenuItem>
          
          <DropdownMenuItem 
            onClick={() => handleRoleChange(ROLES.STUDENT)}
            className={`flex items-center gap-2 cursor-pointer p-2 rounded-md ${currentRole === ROLES.STUDENT ? 'bg-gray-50' : ''}`}
          >
            <div className="p-1.5 bg-gray-100 rounded-md text-gray-600">
              <User size={16} />
            </div>
            <div className="flex flex-col">
              <span className="font-medium text-sm text-gray-900">Estudiante</span>
              <span className="text-xs text-gray-500">Vista de aprendizaje</span>
            </div>
            {currentRole === ROLES.STUDENT && <div className="ml-auto w-2 h-2 rounded-full bg-gray-600" />}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default RoleSelector;
