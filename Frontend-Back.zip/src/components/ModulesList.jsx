
import React, { useState } from 'react';
import { ChevronDown, ChevronRight, BookOpen } from 'lucide-react';
import ModuleContent from './ModuleContent';
import { cn } from '@/lib/utils';

const ModulesList = ({ courseId, modules }) => {
  const [expandedModules, setExpandedModules] = useState([]);

  const toggleModule = (moduleId) => {
    setExpandedModules(prev => 
      prev.includes(moduleId)
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  if (!modules || modules.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        No hay módulos disponibles para este curso.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {modules.map((module, index) => {
        const isExpanded = expandedModules.includes(module.id);
        
        return (
          <div 
            key={module.id} 
            className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-sm transition-all hover:shadow-md"
          >
            <button
              onClick={() => toggleModule(module.id)}
              className={cn(
                "w-full flex items-center justify-between p-5 text-left transition-colors",
                isExpanded ? "bg-gray-50 border-b border-gray-100" : "hover:bg-gray-50"
              )}
            >
              <div className="flex items-center gap-4">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors",
                  isExpanded ? "bg-blue-600 text-white" : "bg-blue-100 text-blue-700"
                )}>
                  {index + 1}
                </div>
                <div>
                  <h3 className={cn(
                    "font-bold text-lg",
                    isExpanded ? "text-blue-900" : "text-gray-800"
                  )}>
                    {module.title}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                    <BookOpen size={12} />
                    <span>Recursos disponibles</span>
                  </div>
                </div>
              </div>
              
              <div className="text-gray-400">
                {isExpanded ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
              </div>
            </button>

            {isExpanded && (
              <div className="p-4 bg-gray-50/50">
                <ModuleContent module={module} courseId={courseId} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default ModulesList;
