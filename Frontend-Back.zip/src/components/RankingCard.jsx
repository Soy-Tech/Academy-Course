
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Trophy, Award, TrendingUp, User } from 'lucide-react';

const RankingCard = ({ ranking, delay }) => {
  const getMedalColor = (rank) => {
    if (rank === 1) return 'from-yellow-400 to-yellow-600';
    if (rank === 2) return 'from-gray-300 to-gray-500';
    if (rank === 3) return 'from-orange-400 to-orange-600';
    return 'from-[#0B3D91] to-[#CFAE70]';
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
      className={`bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 ${
        ranking.rank <= 3 ? 'border-2 border-[#CFAE70]' : ''
      }`}
    >
      <div className="flex items-center p-6 gap-6">
        <div className={`w-16 h-16 bg-gradient-to-br ${getMedalColor(ranking.rank)} rounded-full flex items-center justify-center flex-shrink-0 shadow-lg`}>
          {ranking.rank <= 3 ? (
            <Trophy className="text-white" size={28} />
          ) : (
            <span className="text-white font-bold text-xl">#{ranking.rank}</span>
          )}
        </div>

        <Link to={`/student/${ranking.user_id}`} className="flex items-center gap-4 flex-grow group">
          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#CFAE70] flex items-center justify-center text-white font-bold">
            {ranking.users?.profile_photo_url ? (
              <img src={ranking.users.profile_photo_url} alt="" className="w-full h-full rounded-full object-cover" />
            ) : (
              <User size={24} />
            )}
          </div>

          <div className="flex-grow">
            <h3 className="text-lg font-bold text-gray-900 group-hover:text-[#0B3D91] transition-colors">
              {ranking.users?.name || 'Usuario'}
            </h3>
            <p className="text-sm text-gray-600">{ranking.users?.specialty || 'Estudiante'}</p>
          </div>
        </Link>

        <div className="flex items-center gap-8">
          <div className="text-center">
            <div className="flex items-center gap-2 text-[#CFAE70] mb-1">
              <Award size={20} />
              <span className="text-2xl font-bold">{ranking.points}</span>
            </div>
            <p className="text-xs text-gray-600">Puntos</p>
          </div>

          <div className="text-center">
            <div className="flex items-center gap-2 text-[#0B3D91] mb-1">
              <TrendingUp size={20} />
              <span className="text-2xl font-bold">{ranking.contributions_count}</span>
            </div>
            <p className="text-xs text-gray-600">Contribuciones</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default RankingCard;
