
import React from 'react';
import { Menu, Bell, Search, Shield, ChevronDown } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { useRole } from '@/contexts/RoleContext';
import { getRoleLabel } from '@/utils/rolePermissions';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const AdminHeader = ({ toggleSidebar }) => {
  const location = useLocation();
  const { currentRole, logout } = useRole();

  // Helper to get current page title
  const getPageTitle = () => {
    const path = location.pathname;
    if (path.includes('/dashboard')) return 'Dashboard General';
    if (path.includes('/users')) return 'Gestión de Usuarios';
    if (path.includes('/courses')) return 'Catálogo de Cursos';
    if (path.includes('/settings')) return 'Configuración';
    if (path.includes('/events')) return 'Eventos y Webinars';
    if (path.includes('/resources')) return 'Biblioteca de Recursos';
    return 'Panel de Administración';
  };

  return (
    <header className="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-30 shadow-sm">
      <div className="flex items-center gap-4">
        <button 
          onClick={toggleSidebar}
          className="lg:hidden p-2 rounded-md hover:bg-gray-100 text-gray-600 transition-colors"
          aria-label="Toggle Menu"
        >
          <Menu size={20} />
        </button>
        
        <h1 className="text-lg font-bold text-gray-800 hidden sm:block">
          {getPageTitle()}
        </h1>
      </div>

      <div className="flex items-center gap-4 lg:gap-6">
        {/* Search Bar - Hidden on small mobile */}
        <div className="hidden md:flex relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input 
            type="text" 
            placeholder="Buscar..." 
            className="pl-9 pr-4 py-1.5 bg-gray-50 border border-gray-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-48 lg:w-64 transition-all"
          />
        </div>

        <div className="flex items-center gap-3">
          <button className="p-2 relative rounded-full hover:bg-gray-100 text-gray-500 transition-colors">
            <Bell size={20} />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
          </button>
          
          <div className="h-8 w-px bg-gray-200 mx-1 hidden sm:block"></div>
          
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-3 outline-none group">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-gray-800 leading-none">Admin User</p>
                <p className="text-xs text-blue-600 font-medium mt-1">{getRoleLabel(currentRole)}</p>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-white shadow-md ring-2 ring-white group-hover:ring-blue-100 transition-all">
                <Shield size={18} />
              </div>
              <ChevronDown size={16} className="text-gray-400 hidden sm:block" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 mt-2">
              <DropdownMenuItem onClick={logout} className="text-red-600 cursor-pointer">
                Cerrar Sesión
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};

export default AdminHeader;
