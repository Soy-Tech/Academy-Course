
import React from 'react';
import { Edit, Trash2, Calendar, MapPin, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

const EventsList = ({ events, onEdit, onDelete, onStatusChange }) => {
  if (!events || events.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-12 text-center border border-gray-100">
        <Calendar className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-1">No hay eventos programados</h3>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="px-6 py-4 font-semibold text-gray-700">Evento</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Fecha y Hora</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Ubicación</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Instructor</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Asistentes</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Estado</th>
              <th className="px-6 py-4 font-semibold text-gray-700 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {events.map((event) => (
              <tr key={event.id} className="hover:bg-gray-50/80 transition-colors">
                <td className="px-6 py-4">
                  <div className="font-medium text-gray-900">{event.nombre}</div>
                  <div className="text-xs text-gray-500 truncate max-w-[200px]">{event.descripcion}</div>
                </td>
                <td className="px-6 py-4 text-gray-600">
                  <div className="flex flex-col">
                    <span>{event.fecha}</span>
                    <span className="text-xs text-gray-400">{event.hora}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-gray-600">
                  <div className="flex items-center gap-1">
                    <MapPin size={14} className="text-gray-400" />
                    {event.ubicacion}
                  </div>
                </td>
                <td className="px-6 py-4 text-gray-600">{event.instructor}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1.5">
                    <Users size={14} className="text-gray-400" />
                    <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full text-xs font-semibold">
                      {event.asistentes}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize border
                    ${event.estado === 'scheduled' ? 'bg-blue-50 text-blue-700 border-blue-200' : 
                      event.estado === 'completed' ? 'bg-green-50 text-green-700 border-green-200' : 
                      event.estado === 'ongoing' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                      'bg-red-50 text-red-700 border-red-200'}`}>
                    {event.estado === 'scheduled' ? 'Programado' : 
                     event.estado === 'completed' ? 'Completado' :
                     event.estado === 'ongoing' ? 'En Curso' : 'Cancelado'}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="ghost" size="icon" onClick={() => onEdit(event)} className="h-8 w-8 text-blue-600 hover:bg-blue-50">
                      <Edit size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(event.id)} className="h-8 w-8 text-red-500 hover:bg-red-50">
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EventsList;
