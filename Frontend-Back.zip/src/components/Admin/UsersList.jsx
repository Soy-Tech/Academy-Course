
import React from 'react';
import { Edit, Trash2, Shield, User, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const UsersList = ({ users, onEdit, onDelete, onToggleStatus }) => {
  if (!users || users.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-12 text-center border border-gray-100">
        <User className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-1">No hay usuarios encontrados</h3>
        <p className="text-gray-500">Intenta ajustar los filtros de búsqueda.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="px-6 py-4 font-semibold text-gray-700">Usuario</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Rol</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Estado</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Fecha Registro</th>
              <th className="px-6 py-4 font-semibold text-gray-700 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-gray-50/80 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold shrink-0">
                      {user.nombre.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{user.nombre}</p>
                      <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize border
                    ${user.rol === 'admin' ? 'bg-purple-50 text-purple-700 border-purple-200' : 
                      user.rol === 'instructor' ? 'bg-blue-50 text-blue-700 border-blue-200' : 
                      'bg-gray-50 text-gray-700 border-gray-200'}`}>
                    {user.rol === 'admin' && <Shield className="w-3 h-3 mr-1" />}
                    {user.rol}
                  </span>
                </td>
                <td className="px-6 py-4">
                   <button 
                     onClick={() => onToggleStatus(user.id)}
                     className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors
                       ${user.estado === 'active' 
                         ? 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100' 
                         : 'bg-red-50 text-red-700 border-red-200 hover:bg-red-100'}`}
                   >
                     {user.estado === 'active' ? <CheckCircle className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                     {user.estado === 'active' ? 'Activo' : 'Inactivo'}
                   </button>
                </td>
                <td className="px-6 py-4 text-gray-500">
                  {user.fechaRegistro}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="ghost" size="icon" onClick={() => onEdit(user)} className="h-8 w-8 text-blue-600 hover:bg-blue-50">
                      <Edit size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(user.id)} className="h-8 w-8 text-red-500 hover:bg-red-50">
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersList;
