
import React, { useState, useEffect } from 'react';
import { Save, X, Upload, AlertCircle, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ResourceForm = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    tipo: 'pdf',
    instructor: '',
    estado: 'published',
    file: null
  });
  const [fileName, setFileName] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
      setFileName(initialData.fileName || 'Archivo actual');
    } else {
      setFormData({
        nombre: '',
        descripcion: '',
        tipo: 'pdf',
        instructor: '',
        estado: 'published',
        file: null
      });
      setFileName('');
    }
    setErrors({});
  }, [initialData]);

  const validate = () => {
    const newErrors = {};
    if (!formData.nombre.trim()) newErrors.nombre = 'El nombre es obligatorio.';
    if (!formData.instructor.trim()) newErrors.instructor = 'El instructor es obligatorio.';
    
    // Simulate file validation logic
    if (!initialData && !fileName) {
       // Only require file on creation if we want to be strict, but for mock update we might skip
       // newErrors.file = 'Debes subir un archivo.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        setErrors(prev => ({ ...prev, file: 'El archivo no debe superar los 50MB.' }));
        return;
      }
      setFileName(file.name);
      setFormData(prev => ({ ...prev, file: file }));
      setErrors(prev => ({ ...prev, file: null }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSave({ ...formData, fileName });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Nombre del Recurso *</label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.nombre ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.nombre && <p className="mt-1 text-xs text-red-500">{errors.nombre}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Archivo</label>
          <select
            name="tipo"
            value={formData.tipo}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-white"
          >
            <option value="pdf">PDF</option>
            <option value="video">Video</option>
            <option value="documento">Documento</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Estado</label>
          <select
            name="estado"
            value={formData.estado}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-white"
          >
            <option value="published">Publicado</option>
            <option value="draft">Borrador</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Instructor *</label>
          <input
            type="text"
            name="instructor"
            value={formData.instructor}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.instructor ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.instructor && <p className="mt-1 text-xs text-red-500">{errors.instructor}</p>}
        </div>

        <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Archivo</label>
            <div className={`border-2 border-dashed rounded-md px-3 py-2 flex flex-col items-center justify-center text-gray-400 bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer relative ${errors.file ? 'border-red-300 bg-red-50' : 'border-gray-300'}`}>
                <input 
                  type="file" 
                  onChange={handleFileChange} 
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                  accept=".pdf,.doc,.docx,.mp4,.mov"
                />
                {fileName ? (
                  <div className="flex items-center text-blue-600 font-medium">
                    <FileText size={18} className="mr-2" />
                    <span className="text-sm truncate max-w-[150px]">{fileName}</span>
                  </div>
                ) : (
                  <>
                    <Upload size={18} className="mb-1" />
                    <span className="text-xs">Seleccionar archivo (Max 50MB)</span>
                  </>
                )}
            </div>
            {errors.file && <p className="mt-1 text-xs text-red-500">{errors.file}</p>}
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
          <textarea
            name="descripcion"
            value={formData.descripcion}
            onChange={handleChange}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 mt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex items-center gap-2">
          <X size={16} /> Cancelar
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2">
          <Save size={16} /> Guardar Recurso
        </Button>
      </div>
    </form>
  );
};

export default ResourceForm;
