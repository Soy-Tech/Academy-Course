
import React from 'react';
import { Edit, Trash2, BookOpen, Eye, EyeOff, Video } from 'lucide-react';
import { Link } from 'react-router-dom';

const CoursesList = ({ courses, onEdit, onDelete, onToggleStatus }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-gray-50 text-gray-500 uppercase font-medium">
            <tr>
              <th className="px-6 py-4">Curso</th>
              <th className="px-6 py-4">Categoría</th>
              <th className="px-6 py-4">Precio</th>
              <th className="px-6 py-4">Estado</th>
              <th className="px-6 py-4">Contenido</th>
              <th className="px-6 py-4 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {courses.length > 0 ? (
              courses.map((course) => (
                <tr key={course.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-gray-100 overflow-hidden flex-shrink-0">
                        <img 
                          src={course.image || 'https://via.placeholder.com/40'} 
                          alt="" 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="font-bold text-gray-900">{course.title || course.nombre}</div>
                        <div className="text-xs text-gray-500">{course.instructor}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-600">
                    <span className="px-2 py-1 bg-gray-100 rounded text-xs">{course.category}</span>
                  </td>
                  <td className="px-6 py-4 font-medium text-gray-900">
                    {course.price}
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => onToggleStatus(course.id)}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border transition-colors ${
                        course.estado === 'published' || course.estado === 'Publicado'
                          ? 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100'
                          : 'bg-yellow-50 text-yellow-700 border-yellow-200 hover:bg-yellow-100'
                      }`}
                    >
                      {course.estado === 'published' || course.estado === 'Publicado' ? (
                        <>
                          <Eye size={12} /> Publicado
                        </>
                      ) : (
                        <>
                          <EyeOff size={12} /> Borrador
                        </>
                      )}
                    </button>
                  </td>
                  <td className="px-6 py-4">
                    <Link to={`/admin/courses/${course.id}/videos`}>
                        <button className="flex items-center gap-2 text-[#0B3D91] hover:text-[#082d6b] font-medium text-xs border border-[#0B3D91]/20 px-3 py-1.5 rounded hover:bg-[#0B3D91]/5 transition-colors">
                            <Video size={14} />
                            Gestionar Videos
                        </button>
                    </Link>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => onEdit(course)}
                        className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        title="Editar información"
                      >
                        <Edit size={18} />
                      </button>
                      <button 
                        onClick={() => onDelete(course.id)}
                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Eliminar curso"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="px-6 py-12 text-center text-gray-500">
                  <BookOpen size={48} className="mx-auto mb-3 text-gray-300" />
                  <p>No se encontraron cursos que coincidan con tu búsqueda.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CoursesList;
