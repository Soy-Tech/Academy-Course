
import React from 'react';

const InstructorFormSection = ({ title, description, children, sectionNumber, totalSections }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8 mb-8 relative overflow-hidden transition-all hover:shadow-md">
      <div className="flex items-start gap-4 mb-6 border-b border-gray-100 pb-4">
        <div className="flex-shrink-0 w-10 h-10 bg-[#0B3D91] text-white rounded-full flex items-center justify-center font-bold text-lg shadow-sm">
          {sectionNumber}
        </div>
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-gray-900">{title}</h2>
          {description && <p className="text-gray-500 mt-1 text-sm md:text-base">{description}</p>}
        </div>
        <div className="ml-auto text-xs font-semibold text-gray-400 uppercase tracking-wider hidden sm:block">
          Sección {sectionNumber} de {totalSections}
        </div>
      </div>
      <div className="space-y-6">
        {children}
      </div>
    </div>
  );
};

export default InstructorFormSection;
