
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronDown, ChevronRight, PlayCircle, CheckCircle, FileText, Download, File, Beaker } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from "@/components/ui/scroll-area"
import { generateModulesForCourse } from '@/data/mockCourseModules';

const CourseSidebar = ({ course, modules, currentLessonId, isOpen, onClose }) => {
  const navigate = useNavigate();
  const { id: paramId, courseId: paramCourseId } = useParams();
  
  // Use modules passed in prop, or generate them if missing (robustness)
  const [displayModules, setDisplayModules] = useState([]);
  
  useEffect(() => {
    if (modules && modules.length > 0) {
      setDisplayModules(modules);
    } else {
      // If no modules prop, try to generate using route params
      const targetId = course?.id || paramCourseId || paramId;
      if (targetId) {
        setDisplayModules(generateModulesForCourse(targetId));
      }
    }
  }, [modules, course, paramCourseId, paramId]);

  // Initialize with all sections/modules open once modules are loaded
  const [openItems, setOpenItems] = useState([]);

  useEffect(() => {
    if (displayModules.length > 0) {
      setOpenItems(prev => {
         // Only set defaults if empty to preserve user toggle state during updates
         if (prev.length === 0) return displayModules.map(m => m.id);
         return prev;
      });
    }
  }, [displayModules]);

  const toggleItem = (itemId) => {
    setOpenItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const getIconForType = (type) => {
      switch(type) {
          case 'video': return PlayCircle;
          case 'pdf': return FileText;
          case 'doc': return File;
          case 'file': return Download;
          case 'activity': return Beaker;
          default: return FileText;
      }
  };

  if (displayModules.length === 0 && !course?.sections) return null;

  // Render logic for new Module structure (Dynamic)
  if (displayModules.length > 0) {
      return (
        <div className="h-full bg-white flex flex-col border-r border-gray-200">
          <div className="p-4 border-b border-gray-200 bg-gray-50/50">
            <h2 className="font-bold text-gray-900 line-clamp-2 leading-tight">
              {course?.title || "Contenido del Curso"}
            </h2>
            <div className="mt-2 text-xs text-gray-500 font-medium">
              <span>{displayModules.length} módulos</span>
            </div>
          </div>

          <ScrollArea className="flex-1">
            <div className="py-2">
               {displayModules.map((module, index) => {
                  const isOpen = openItems.includes(module.id);
                  const allResources = [
                      ...(module.resources.videos || []).map(r => ({ ...r, type: 'video' })),
                      ...(module.resources.pdfs || []).map(r => ({ ...r, type: 'pdf' })),
                      ...(module.resources.docs || []).map(r => ({ ...r, type: 'doc' })),
                      ...(module.resources.files || []).map(r => ({ ...r, type: 'file' })),
                      ...(module.resources.activities || []).map(r => ({ ...r, type: 'activity' }))
                  ];

                  return (
                      <div key={module.id} className="mb-1">
                          <button
                              onClick={() => toggleItem(module.id)}
                              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors text-left group"
                          >
                              <div className="flex-1 pr-2">
                                  <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">
                                      Módulo {index + 1}
                                  </p>
                                  <h3 className="text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                                      {module.title}
                                  </h3>
                              </div>
                              <div className="flex items-center text-gray-400">
                                  {isOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                              </div>
                          </button>

                          {isOpen && (
                              <div className="bg-gray-50/30 border-y border-gray-100/50">
                                  {allResources.map((resource) => {
                                      const isActive = resource.id === currentLessonId;
                                      const Icon = getIconForType(resource.type);

                                      return (
                                          <button
                                              key={resource.id}
                                              onClick={() => {
                                                  navigate(`/course/${module.courseId}/lesson/${resource.id}`);
                                                  if (window.innerWidth < 768 && onClose) onClose();
                                              }}
                                              className={cn(
                                                  "w-full flex gap-3 p-3 pl-6 text-left transition-all relative border-l-4",
                                                  isActive 
                                                      ? "bg-blue-50 border-blue-600" 
                                                      : "border-transparent hover:bg-gray-50"
                                              )}
                                          >
                                              <div className="mt-0.5 shrink-0 text-gray-400">
                                                  <Icon size={16} className={isActive ? "text-blue-600" : ""} />
                                              </div>
                                              <div className="flex-1 min-w-0">
                                                  <p className={cn(
                                                      "text-sm font-medium leading-snug mb-0.5 truncate",
                                                      isActive ? "text-blue-700" : "text-gray-700"
                                                  )}>
                                                      {resource.title}
                                                  </p>
                                                  <span className="text-[10px] uppercase text-gray-400 font-bold">{resource.type}</span>
                                              </div>
                                          </button>
                                      );
                                  })}
                              </div>
                          )}
                      </div>
                  );
               })}
            </div>
          </ScrollArea>
        </div>
      );
  }

  // Fallback to legacy structure (if sections present but no modules generated yet?)
  // This part is kept just in case but likely unreachable if generator works
  return null;
};

export default CourseSidebar;
