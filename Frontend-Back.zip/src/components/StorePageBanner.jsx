
import React from 'react';
import PageBanner from '@/components/PageBanner';

const StorePageBanner = ({ onClickCTA }) => {
  return (
    <PageBanner 
      title="Tienda Oficial"
      subtitle="Acceso a recursos exclusivos, herramientas profesionales y cursos premium para acelerar tu carrera."
      badges={['Nuevos Productos', 'Ofertas Especiales', 'Recursos Premium']}
      cta={{ 
        label: "Explorar tienda", 
        onClick: onClickCTA 
      }}
      backgroundImage="https://images.unsplash.com/photo-1556742049-0cfed4f7a07d"
    />
  );
};

export default StorePageBanner;
