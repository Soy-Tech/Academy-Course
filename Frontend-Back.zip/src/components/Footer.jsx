
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Github, Mail, MapPin, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  return (
    <footer className="bg-slate-900 text-slate-300 font-sans">
      <div className="container mx-auto px-6 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand Column */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#CFAE70] rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">N</span>
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">Netcom</span>
            </Link>
            <p className="text-sm leading-relaxed text-slate-400">
              Transformando el futuro a través de la educación tecnológica de calidad. Únete a nuestra comunidad de expertos y aprendices.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((social) => (
                <a 
                  key={social.label}
                  href={social.href}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:bg-[#CFAE70] hover:text-white transition-all duration-300"
                  aria-label={social.label}
                >
                  <social.icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Links Column 1: Academia */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Academia</h3>
            <ul className="space-y-3">
              <li><Link to="/cursos" className="text-sm hover:text-[#CFAE70] transition-colors">Todos los Cursos</Link></li>
              <li><Link to="/learning-paths" className="text-sm hover:text-[#CFAE70] transition-colors">Rutas de Aprendizaje</Link></li>
              <li><Link to="/store" className="text-sm hover:text-[#CFAE70] transition-colors">Tienda Oficial</Link></li>
              <li><Link to="/resources" className="text-sm hover:text-[#CFAE70] transition-colors">Recursos Gratuitos</Link></li>
            </ul>
          </div>

          {/* Links Column 2: Comunidad & Empresa */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Comunidad</h3>
            <ul className="space-y-3">
              <li><Link to="/forums" className="text-sm hover:text-[#CFAE70] transition-colors">Foros de Discusión</Link></li>
              <li><Link to="/blog" className="text-sm hover:text-[#CFAE70] transition-colors">Blog Tech</Link></li>
              <li><Link to="/events" className="text-sm hover:text-[#CFAE70] transition-colors">Eventos y Webinars</Link></li>
              <li><Link to="/about" className="text-sm hover:text-[#CFAE70] transition-colors">Sobre Nosotros</Link></li>
              <li><Link to="/contact" className="text-sm hover:text-[#CFAE70] transition-colors">Contacto</Link></li>
            </ul>
          </div>

          {/* Contact & Support */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Soporte</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm">
                <Mail size={18} className="text-[#CFAE70] mt-0.5" />
                <span>soporte@netcom.academy</span>
              </li>
              <li className="flex items-start gap-3 text-sm">
                <Phone size={18} className="text-[#CFAE70] mt-0.5" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-start gap-3 text-sm">
                <MapPin size={18} className="text-[#CFAE70] mt-0.5" />
                <span>Ciudad Tecnológica, Edificio Innovation, Piso 4</span>
              </li>
              <li className="pt-2">
                <Link to="/help">
                  <Button variant="outline" size="sm" className="border-slate-700 text-slate-300 hover:bg-[#CFAE70] hover:text-white hover:border-[#CFAE70] transition-all">
                    Centro de Ayuda
                  </Button>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 pt-8 mt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© 2026 Netcom Academy. Todos los derechos reservados.</p>
          <div className="flex gap-6">
            <Link to="/privacy" className="hover:text-white transition-colors">Política de Privacidad</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Términos de Servicio</Link>
            <Link to="/legal" className="hover:text-white transition-colors">Legal</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
