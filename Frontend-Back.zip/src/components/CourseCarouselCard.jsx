
import React from 'react';
import CourseCardPreview from '@/components/CourseCardPreview';

// This component now serves as a compatibility wrapper for CourseCardPreview
// to ensure no breaking changes in components that import CourseCarouselCard
const CourseCarouselCard = ({ course }) => {
  return <CourseCardPreview course={course} />;
};

export default CourseCarouselCard;
