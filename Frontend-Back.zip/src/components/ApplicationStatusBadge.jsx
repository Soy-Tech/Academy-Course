
import React from 'react';
import { cn } from '@/lib/utils';
import { CheckCircle2, Clock, XCircle, FileText } from 'lucide-react';

const ApplicationStatusBadge = ({ status, className }) => {
  const config = {
    submitted: { color: "bg-blue-100 text-blue-800 border-blue-200", icon: FileText, label: "Enviada" },
    under_review: { color: "bg-yellow-100 text-yellow-800 border-yellow-200", icon: Clock, label: "En Revisión" },
    approved: { color: "bg-green-100 text-green-800 border-green-200", icon: CheckCircle2, label: "Aprobada" },
    rejected: { color: "bg-red-100 text-red-800 border-red-200", icon: XCircle, label: "Rechazada" }
  };

  const style = config[status] || config.submitted;
  const Icon = style.icon;

  return (
    <div className={cn("inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border", style.color, className)}>
      <Icon size={12} />
      <span>{style.label}</span>
    </div>
  );
};

export default ApplicationStatusBadge;
