
import React from 'react';
import { cn } from '@/lib/utils';

const ProgressBar = ({ currentStep, totalSteps, className }) => {
  const progress = Math.min(100, Math.max(0, ((currentStep) / totalSteps) * 100));
  
  return (
    <div className={cn("w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700 overflow-hidden", className)}>
      <div 
        className="bg-[#0B3D91] h-2.5 rounded-full transition-all duration-500 ease-out" 
        style={{ width: `${progress}%` }}
      ></div>
    </div>
  );
};

export default ProgressBar;
