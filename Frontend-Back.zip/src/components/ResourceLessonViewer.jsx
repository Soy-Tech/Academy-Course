
import React from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle, ArrowRight, ArrowLeft, Download, ExternalLink, FileText, FileCode, FileImage } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/components/ui/use-toast';

const ResourceLessonViewer = ({ 
  lesson, 
  moduleTitle, 
  isCompleted, 
  onLessonComplete, 
  onNavigate,
  nextLessonId,
  prevLessonId 
}) => {
  const { toast } = useToast();

  if (!lesson) return null;

  const getFileIcon = (type) => {
    if (type?.includes('PDF')) return FileText;
    if (type?.includes('ZIP') || type?.includes('CODE')) return FileCode;
    return FileImage;
  };

  const handleDownload = () => {
    toast({
      title: "Descarga iniciada",
      description: `Descargando ${lesson.title}...`,
    });
  };

  const handleOpen = () => {
    toast({
      title: "Abriendo recurso",
      description: "Abriendo archivo en una nueva pestaña...",
    });
  };

  const FileIcon = getFileIcon(lesson.resourceType);

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto w-full py-8">
      <div className="bg-white p-8 md:p-12 rounded-xl border border-gray-200 shadow-sm text-center">
         <div className="w-20 h-20 bg-[#0B3D91]/5 rounded-full flex items-center justify-center mx-auto mb-6">
            <FileIcon size={40} className="text-[#0B3D91]" />
         </div>
         <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{lesson.title}</h1>
         <p className="text-gray-500 mb-8">{moduleTitle}</p>

         <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Button onClick={handleDownload} className="bg-[#0B3D91] hover:bg-[#082d6b] text-white px-8 h-12">
               <Download size={18} className="mr-2" /> Descargar {lesson.resourceType}
               {lesson.fileSize && <span className="ml-2 text-white/60 text-xs">({lesson.fileSize})</span>}
            </Button>
            <Button onClick={handleOpen} variant="outline" className="border-gray-300 text-gray-700 h-12">
               <ExternalLink size={18} className="mr-2" /> Abrir en nueva pestaña
            </Button>
         </div>

         <div className="max-w-2xl mx-auto bg-gray-50 p-6 rounded-lg border border-gray-100 text-left">
            <h3 className="font-bold text-gray-900 mb-2 text-sm uppercase">Instrucciones</h3>
            <p className="text-gray-600 text-sm leading-relaxed">
               {lesson.description || "Descarga el archivo adjunto para completar esta lección."}
            </p>
         </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
         <div className="flex items-center gap-4 text-center sm:text-left">
             <div>
                 <p className="text-sm font-medium text-gray-900">¿Terminaste de revisar este recurso?</p>
                 <p className="text-xs text-gray-500">Marca la lección como completada para avanzar.</p>
             </div>
         </div>
         <Button
            onClick={() => onLessonComplete(!isCompleted)}
            variant={isCompleted ? "outline" : "default"}
            className={cn(
              "transition-all w-full sm:w-auto",
              isCompleted 
                ? "border-green-600 text-green-700 bg-green-50 hover:bg-green-100" 
                : "bg-green-600 text-white hover:bg-green-700"
            )}
         >
            {isCompleted ? (
               <>
                 <CheckCircle size={18} className="mr-2" /> Completada
               </>
            ) : "Marcar como completada"}
         </Button>
      </div>

       {/* Navigation Footer */}
       <div className="flex items-center justify-between mt-4">
           <Button 
             variant="ghost" 
             onClick={() => onNavigate(prevLessonId)} 
             disabled={!prevLessonId}
             className="text-gray-500 hover:text-[#0B3D91] hover:bg-white"
           >
             <ArrowLeft size={18} className="mr-2" /> Lección Anterior
           </Button>

           <Button 
             variant="ghost" 
             onClick={() => onNavigate(nextLessonId)} 
             disabled={!nextLessonId}
             className="text-gray-500 hover:text-[#0B3D91] hover:bg-white"
           >
             Siguiente Lección <ArrowRight size={18} className="ml-2" />
           </Button>
        </div>
    </div>
  );
};

export default ResourceLessonViewer;
