
import React from 'react';
import { motion } from 'framer-motion';
import { Download, FileText, Video, ExternalLink, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ResourceCard = ({ resource, delay }) => {
  const { toast } = useToast();

  const handleDownload = () => {
    toast({
      title: 'Descarga iniciada',
      description: `Estás descargando: ${resource.title}`,
      className: "bg-green-50 border-green-200 text-green-800"
    });
  };

  // Determine icon based on file type
  const getIcon = (type) => {
    const lowerType = type?.toLowerCase() || '';
    if (lowerType.includes('pdf') || lowerType.includes('doc')) return FileText;
    if (lowerType.includes('video') || lowerType.includes('mp4')) return Video;
    if (lowerType.includes('link') || lowerType.includes('url')) return ExternalLink;
    return BookOpen;
  };

  const Icon = getIcon(resource.file_type);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.06)] hover:shadow-[0_12px_24px_rgba(0,0,0,0.12)] transition-all duration-300 border border-gray-100 flex flex-col h-full group overflow-hidden"
    >
      <div className="p-8 flex flex-col h-full relative">
        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-gray-50 to-transparent rounded-bl-full -mr-8 -mt-8 z-0"></div>
        
        <div className="flex justify-between items-start mb-6 relative z-10">
          <div className="w-12 h-12 rounded-lg bg-[#0B3D91]/5 flex items-center justify-center group-hover:bg-[#0B3D91] transition-colors duration-300">
            <Icon size={24} className="text-[#0B3D91] group-hover:text-white transition-colors duration-300" />
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-gray-500 bg-gray-100 px-2 py-1 rounded-md">
            {resource.category || 'General'}
          </span>
        </div>

        <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-3 group-hover:text-[#0B3D91] transition-colors leading-tight">
          {resource.title}
        </h3>
        
        <p className="text-[#666] text-[15px] mb-6 line-clamp-3 flex-grow leading-relaxed">
          {resource.description}
        </p>

        <div className="flex items-center justify-between text-xs text-gray-400 mb-6 font-medium border-t border-gray-50 pt-4">
          <span>{resource.file_type || 'PDF'}</span>
          <span>{new Date(resource.created_at).toLocaleDateString('es-ES')}</span>
        </div>

        <Button 
          onClick={handleDownload} 
          className="w-full bg-white text-[#0B3D91] border border-[#0B3D91] hover:bg-[#0B3D91] hover:text-white font-semibold shadow-none hover:shadow-md transition-all h-10 rounded-lg text-sm"
        >
          <Download size={16} className="mr-2" />
          Descargar Recurso
        </Button>
      </div>
    </motion.div>
  );
};

export default ResourceCard;
