
import React from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const FormSection = ({ title, description, children, className, isActive = true }) => {
  if (!isActive) return null;
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className={cn("bg-white p-6 rounded-xl shadow-lg border border-gray-100", className)}
    >
      <div className="mb-6 border-b border-gray-100 pb-4">
        <h3 className="text-xl font-bold text-[#0B3D91]">{title}</h3>
        {description && <p className="text-gray-500 text-sm mt-1">{description}</p>}
      </div>
      <div className="space-y-6">
        {children}
      </div>
    </motion.div>
  );
};

export default FormSection;
