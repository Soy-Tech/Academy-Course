
import React, { useState, useMemo, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingCart as ShoppingCartIcon, LayoutDashboard, Shield, LogOut, Briefcase, Bug, BookOpen, Users, PlusCircle, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '@/hooks/useCart';
import ShoppingCart from '@/components/ShoppingCart';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { ROLES } from '@/utils/rolePermissions';
import { isTestUser, getTestUserBadgeColor } from '@/utils/testUserHelper';
import { getRoleDashboard } from '@/utils/roleRedirect';

import PREVIEW_ENABLED from '@/config/previewMode';
import PreviewRoleSelector from '@/components/PreviewRoleSelector';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { cartItems } = useCart();
  const { toast } = useToast();
  
  // 1. Obtener User del Hook
  const { currentUser, logout: authLogout, isAuthenticated } = useAuth();

  // DIAGNOSTIC LOGS
  useEffect(() => {
     // Solo loguear si hay un cambio significativo para no inundar la consola
     if (currentUser) {
         console.log('[Header] Rendered with user:', currentUser.email, 'Role:', currentUser.role);
     } else {
         console.log('[Header] Rendered guest view');
     }
  }, [currentUser]);

  const totalItems = useMemo(() => cartItems.reduce((sum, item) => sum + item.quantity, 0), [cartItems]);

  const navLinks = [
    { name: 'Cursos', path: '/cursos' },
    { name: 'Foros', path: '/forums' },
    { name: 'Academia', path: '/learning-paths' },
    { name: 'Tienda', path: '/store' },
    { name: 'Comunidad', path: '/community' },
  ];

  const handleLogout = () => {
    authLogout();
    toast({
      title: 'Sesión cerrada',
      description: 'Has cerrado sesión correctamente.'
    });
    navigate('/');
    setIsUserMenuOpen(false);
    setIsMenuOpen(false);
  };

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const showBecomeInstructor = isAuthenticated && currentUser?.role === ROLES.STUDENT;

  const testUserBadge = currentUser && isTestUser(currentUser) && !PREVIEW_ENABLED ? (
    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 ${getTestUserBadgeColor(currentUser.role)}`}>
      <Bug size={10} />
      TEST USER
    </span>
  ) : null;

  // Role Specific Menu Items
  const renderRoleMenuItems = () => {
    if (!currentUser) return null;

    switch(currentUser.role) {
      case ROLES.STUDENT:
        return (
          <>
            <Link to="/student/courses" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <BookOpen size={16} className="text-blue-600"/> Mis Cursos
            </Link>
            <Link to="/community" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <Users size={16} className="text-green-600"/> Comunidad
            </Link>
            <Link to="/instructor-application" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <Briefcase size={16} className="text-orange-600"/> Ser Instructor
            </Link>
          </>
        );
      case ROLES.INSTRUCTOR:
         return (
          <>
            <Link to="/instructor/courses" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <BookOpen size={16} className="text-blue-600"/> Mis Cursos
            </Link>
            <Link to="/instructor/create-course" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <PlusCircle size={16} className="text-green-600"/> Crear Curso
            </Link>
          </>
        );
      case ROLES.ADMIN:
        return (
          <>
            <Link to="/admin/users" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <Users size={16} className="text-purple-600"/> Gestionar Usuarios
            </Link>
            <Link to="/admin/courses" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <BookOpen size={16} className="text-purple-600"/> Gestionar Cursos
            </Link>
          </>
        );
      case ROLES.SUPER_ADMIN:
        return (
          <>
             <Link to="/admin/users" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <Shield size={16} className="text-red-600"/> Gestionar Admins
            </Link>
            <Link to="/admin/settings" onClick={() => setIsUserMenuOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
              <Settings size={16} className="text-red-600"/> Gestionar Sistema
            </Link>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <>
      <header className="bg-white border-b border-gray-100 shadow-sm sticky top-0 z-40 font-sans">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between gap-6">
            
            {/* Logo Section */}
            <Link to="/" className="flex items-center gap-3 group flex-shrink-0">
              <div className="w-10 h-10 bg-[#0B3D91] rounded-lg flex items-center justify-center shadow-md group-hover:bg-[#092c69] transition-colors">
                <span className="text-white font-bold text-xl">N</span>
              </div>
              <span className="text-2xl font-bold text-[#0B3D91] tracking-tight">Netcom</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-2">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-2 rounded-md text-sm font-semibold transition-all duration-200 ${
                    isActive(link.path)
                      ? 'text-[#0B3D91] bg-blue-50'
                      : 'text-gray-600 hover:text-[#0B3D91] hover:bg-gray-50'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Right Side Actions */}
            <div className="hidden lg:flex items-center gap-4 flex-shrink-0 ml-auto">
              
              {/* Preview Mode Selector */}
              {PREVIEW_ENABLED && <PreviewRoleSelector />}

              {/* Become Instructor Button */}
              {showBecomeInstructor && (
                <Link to="/instructor-application">
                  <Button 
                    variant="ghost"
                    className="flex items-center gap-2 text-green-600 hover:text-green-700 hover:bg-green-50 font-semibold px-3"
                  >
                    <Briefcase size={18} />
                    Ser Instructor
                  </Button>
                </Link>
              )}

              {/* Cart */}
              <button 
                onClick={() => setIsCartOpen(true)} 
                className="relative text-gray-600 hover:text-[#0B3D91] transition-colors p-2 rounded-full hover:bg-gray-50"
              >
                <ShoppingCartIcon size={22} />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-[#CFAE70] text-white text-xs font-bold rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                    {totalItems}
                  </span>
                )}
              </button>

              {/* User Menu */}
              {currentUser ? (
                <div className="relative">
                  <div className="flex items-center gap-2">
                    {testUserBadge}
                    <button
                      onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                      className="flex items-center gap-3 pl-2 pr-1 py-1 rounded-full hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-200"
                    >
                      <div className="w-9 h-9 bg-gradient-to-br from-[#0B3D91] to-[#082d6b] rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm ring-2 ring-white">
                        {currentUser.avatar || currentUser.name?.charAt(0) || 'U'}
                      </div>
                      <div className="hidden xl:block text-left">
                         <p className="text-xs font-bold text-gray-700">{currentUser.name}</p>
                         <p className="text-[10px] text-gray-500 uppercase tracking-wide">{currentUser.role}</p>
                      </div>
                    </button>
                  </div>

                  <AnimatePresence>
                    {isUserMenuOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 10, scale: 0.95 }}
                        className="absolute right-0 mt-3 w-64 bg-white rounded-xl shadow-xl py-2 border border-gray-100 z-50"
                      >
                        <div className="px-4 py-3 border-b border-gray-100 mb-1 bg-gray-50/50">
                          <p className="text-sm font-bold text-gray-900 truncate">{currentUser.name}</p>
                          <p className="text-xs text-gray-500">{currentUser.email}</p>
                          <div className="mt-2 flex gap-2">
                             <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700 uppercase">
                               {currentUser.role}
                             </span>
                          </div>
                        </div>
                        
                        {/* Common Dashboard Link */}
                        <Link
                          to={getRoleDashboard(currentUser.role)}
                          onClick={() => setIsUserMenuOpen(false)}
                          className="flex items-center gap-2 px-4 py-2.5 text-sm font-bold text-gray-800 hover:bg-gray-50"
                        >
                          <LayoutDashboard size={16} />
                          Mi Dashboard
                        </Link>
                        
                        <div className="border-t border-gray-100 my-1"></div>

                        {/* Role Specific Items */}
                        {renderRoleMenuItems()}

                        <div className="border-t border-gray-100 mt-1 pt-1">
                          <button
                            onClick={handleLogout}
                            className="flex items-center gap-2 w-full px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50"
                          >
                            <LogOut size={16} />
                            Cerrar sesión
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <Link to="/login">
                    <Button variant="ghost" className="text-gray-700 font-semibold">Ingresar</Button>
                  </Link>
                  <Link to="/signup">
                    <Button className="bg-[#0B3D91] hover:bg-[#082d6b] text-white font-bold">
                      Regístrate
                    </Button>
                  </Link>
                </div>
              )}
            </div>

            {/* Mobile Actions */}
            <div className="flex lg:hidden items-center gap-3">
              <button onClick={() => setIsCartOpen(true)} className="relative text-gray-600 p-2">
                <ShoppingCartIcon size={24} />
              </button>
              <button
                className="text-gray-700 hover:text-[#0B3D91] transition-colors p-1"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </nav>
      </header>
      <ShoppingCart isCartOpen={isCartOpen} setIsCartOpen={setIsCartOpen} />
    </>
  );
};

export default Header;
