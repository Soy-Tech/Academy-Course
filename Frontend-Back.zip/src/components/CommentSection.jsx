
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { User, Heart } from 'lucide-react';

const CommentSection = ({ postId }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchComments();
  }, [postId]);

  const fetchComments = async () => {
    try {
      const { data, error } = await supabase
        .from('community_comments')
        .select(`
          *,
          users (name, profile_photo_url)
        `)
        .eq('post_id', postId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setComments(data || []);
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('community_comments')
        .insert({
          post_id: postId,
          user_id: user.id,
          content: newComment,
          likes_count: 0
        });

      if (error) throw error;

      // Update comment count
      await supabase.rpc('increment_comment_count', { p_post_id: postId });

      // Add points
      await supabase.rpc('add_user_points', {
        p_user_id: user.id,
        p_points: 5
      });

      // Log activity
      await supabase.from('activity_log').insert({
        user_id: user.id,
        action_type: 'comment_created',
        points: 5
      });

      toast({
        title: 'Comentario publicado',
        description: '¡Has ganado 5 puntos!'
      });

      setNewComment('');
      fetchComments();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'No se pudo publicar el comentario.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Comentarios</h2>

      {user && (
        <form onSubmit={handleSubmit} className="mb-8">
          <textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="Escribe un comentario..."
            rows={3}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CFAE70] focus:border-transparent outline-none resize-none mb-3 text-gray-900 bg-white"
          />
          <Button type="submit" disabled={isLoading || !newComment.trim()} className="btn-primary">
            {isLoading ? 'Publicando...' : 'Comentar'}
          </Button>
        </form>
      )}

      <div className="space-y-4">
        {comments.length > 0 ? (
          comments.map((comment) => (
            <div key={comment.id} className="flex gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#CFAE70] flex items-center justify-center text-white font-bold flex-shrink-0">
                {comment.users?.profile_photo_url ? (
                  <img src={comment.users.profile_photo_url} alt="" className="w-full h-full rounded-full object-cover" />
                ) : (
                  <User size={20} />
                )}
              </div>
              <div className="flex-grow">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-semibold text-gray-900">{comment.users?.name || 'Usuario'}</span>
                  <span className="text-gray-500">•</span>
                  <span className="text-sm text-gray-500">
                    {new Date(comment.created_at).toLocaleDateString('es-ES', {
                      day: 'numeric',
                      month: 'short'
                    })}
                  </span>
                </div>
                <p className="text-gray-700 mb-2">{comment.content}</p>
                <button className="flex items-center gap-1 text-sm text-gray-500 hover:text-red-500 transition-colors">
                  <Heart size={16} />
                  <span>{comment.likes_count || 0}</span>
                </button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500 py-8">
            No hay comentarios aún. ¡Sé el primero en comentar!
          </p>
        )}
      </div>
    </div>
  );
};

export default CommentSection;
