
import React from 'react';
import { Link } from 'react-router-dom';
import { Star } from 'lucide-react';

const CourseCard = ({ course }) => {
  const getLevelBadgeClass = (level) => {
    switch (level) {
      case 'Principiante':
      case 'Beginner':
        return 'bg-badge-beginner';
      case 'Intermedio':
      case 'Intermediate':
        return 'bg-badge-intermediate';
      case 'Avanzado':
      case 'Advanced':
        return 'bg-badge-advanced';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <Link to={`/cursos/${course.id}`} className="block h-full">
      <div className="course-card group">
        <div className="course-image-container">
          <img
            src={course.image}
            alt={course.title}
            className="course-image"
            loading="lazy"
          />
        </div>

        <div className="course-content">
          <h3 className="course-title" title={course.title}>
            {course.title}
          </h3>

          <p className="course-instructor">
            {course.instructor || 'Instructor Netcom'}
          </p>
          
          <div className="flex items-center gap-1 mb-2">
             <span className="course-rating">
               {course.rating || '4.5'}
               <Star size={12} className="fill-current" />
             </span>
             <span className="text-xs text-gray-400">({Math.floor(Math.random() * 500) + 50})</span>
          </div>

          <div className="mt-auto">
             <div className="flex flex-wrap gap-1.5 mb-2">
                <span className="course-badge bg-badge-category">
                  {course.category}
                </span>
                <span className={`course-badge ${getLevelBadgeClass(course.level)}`}>
                  {course.level}
                </span>
             </div>
             
             <div className="flex items-center justify-between">
                <span className="course-price">{course.price}</span>
             </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CourseCard;
