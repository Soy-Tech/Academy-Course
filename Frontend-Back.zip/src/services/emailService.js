
export const sendConfirmationEmail = async (userEmail, userName, applicationId) => {
  const html = `
    <div style="font-family: Arial, sans-serif; color: #333;">
      <h1 style="color: #0B3D91;">Solicitud Recibida</h1>
      <p>Hola ${userName},</p>
      <p>Hemos recibido tu solicitud para ser instructor en Netcom Academy.</p>
      <p><strong>ID de Solicitud:</strong> ${applicationId}</p>
      <p>Nuestro equipo revisará tu perfil en las próximas 48 horas.</p>
      <hr />
      <p style="font-size: 12px; color: #666;">Netcom Academy Team</p>
    </div>
  `;
  console.log(`[EMAIL SERVICE] Sending Confirmation to ${userEmail}:`, html);
  return true;
};

export const sendAdminNotificationEmail = async (adminEmail, applicantData) => {
  const html = `
    <div style="font-family: Arial, sans-serif; color: #333;">
      <h1 style="color: #0B3D91;">Nueva Solicitud de Instructor</h1>
      <p>Un nuevo candidato ha aplicado:</p>
      <ul>
        <li><strong>Nombre:</strong> ${applicantData.fullName}</li>
        <li><strong>Email:</strong> ${applicantData.email}</li>
        <li><strong>Especialidad:</strong> ${applicantData.specialty}</li>
      </ul>
      <p>Revisa el panel de administración para más detalles.</p>
    </div>
  `;
  console.log(`[EMAIL SERVICE] Sending Admin Notification to ${adminEmail}:`, html);
  return true;
};

export const sendApprovalEmail = async (userEmail, userName) => {
  const html = `
    <div style="font-family: Arial, sans-serif; color: #333;">
      <h1 style="color: #28a745;">¡Felicidades! Solicitud Aprobada</h1>
      <p>Hola ${userName},</p>
      <p>Nos complace informarte que tu solicitud ha sido aprobada. Ahora eres instructor oficial de Netcom Academy.</p>
      <p>Inicia sesión para acceder a tu panel de instructor.</p>
    </div>
  `;
  console.log(`[EMAIL SERVICE] Sending Approval to ${userEmail}:`, html);
  return true;
};

export const sendRejectionEmail = async (userEmail, userName, rejectionReason) => {
  const html = `
    <div style="font-family: Arial, sans-serif; color: #333;">
      <h1 style="color: #dc3545;">Actualización de tu Solicitud</h1>
      <p>Hola ${userName},</p>
      <p>Gracias por tu interés en Netcom Academy. Después de revisar tu perfil, hemos decidido no proceder con tu solicitud en este momento.</p>
      <p><strong>Razón:</strong> ${rejectionReason}</p>
      <p>Te invitamos a mejorar tu perfil y aplicar nuevamente en el futuro.</p>
    </div>
  `;
  console.log(`[EMAIL SERVICE] Sending Rejection to ${userEmail}:`, html);
  return true;
};
