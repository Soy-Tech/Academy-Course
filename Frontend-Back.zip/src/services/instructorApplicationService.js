
import { mockInstructorApplications } from '@/data/mockInstructorApplications';

// Simulate DB
let applicationsStore = [...mockInstructorApplications];

export const submitApplication = async (formData) => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  const newApp = {
    id: `app_${Date.now()}`,
    submittedAt: new Date().toISOString(),
    status: 'submitted', // submitted, under_review, approved, rejected
    ...formData
  };

  applicationsStore.push(newApp);
  return newApp;
};

export const getApplicationByUserId = async (userId) => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return applicationsStore.find(app => app.userId === userId) || null;
};

export const getApplicationByEmail = async (email) => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return applicationsStore.find(app => app.personalData?.email === email) || null;
};

export const updateApplicationStatus = async (applicationId, status, adminNotes = '') => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const index = applicationsStore.findIndex(app => app.id === applicationId);
  if (index === -1) throw new Error('Application not found');

  applicationsStore[index] = {
    ...applicationsStore[index],
    status,
    adminNotes,
    updatedAt: new Date().toISOString()
  };

  return applicationsStore[index];
};

export const getAllApplications = async () => {
  await new Promise(resolve => setTimeout(resolve, 800));
  return [...applicationsStore];
};
