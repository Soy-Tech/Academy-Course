
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ChatbotWidget from '@/components/ChatbotWidget';
import ScrollToTopButton from '@/components/ScrollToTopButton';
import ProtectedRoute from '@/components/ProtectedRoute';
import ScrollToTop from '@/components/ScrollToTop';
import { CartProvider } from '@/hooks/useCart';
import { ROLES } from '@/utils/rolePermissions';

// Global Context Providers
import { EnrollmentProvider } from '@/contexts/EnrollmentContext';
import { RoleProvider } from '@/contexts/RoleContext';
import { InstructorRequestProvider } from '@/contexts/InstructorRequestContext';

// Auth Providers
import { AuthProvider } from '@/contexts/AuthContext';
import PreviewAuthProvider from '@/contexts/PreviewAuthContext';
import PREVIEW_ENABLED from '@/config/previewMode';

// Pages
import HomePage from '@/pages/HomePage';
import CoursesPage from '@/pages/CoursesPage';
import CategoriesPage from '@/pages/CategoriesPage';
import TestimonialsPage from '@/pages/TestimonialsPage';
import BlogPage from '@/pages/BlogPage';
import BlogDetailPage from '@/pages/BlogDetailPage';
import NewsletterPage from '@/pages/NewsletterPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import CourseDetailPage from '@/pages/CourseDetailPage';
import StorePage from '@/pages/StorePage';
import ProductDetailPage from '@/pages/ProductDetailPage';
import SuccessPage from '@/pages/SuccessPage';
import LearningPathsPage from '@/pages/LearningPathsPage';
import LearningPathDetailPage from '@/pages/LearningPathDetailPage';
import CommunityPage from '@/pages/CommunityPage';
import EventsPage from '@/pages/EventsPage';
import EventDetailPage from '@/pages/EventDetailPage';
import RankingsPage from '@/pages/RankingsPage';
import ResourcesPage from '@/pages/ResourcesPage';
import LoginPage from '@/pages/LoginPage';
import SignupPage from '@/pages/SignupPage';
import VideoViewerPage from '@/pages/VideoViewerPage'; 

// Dashboards
import StudentDashboard from '@/pages/StudentDashboard';
import InstructorDashboard from '@/pages/InstructorDashboard';
import AdminDashboard from '@/pages/AdminDashboard';
import SuperAdminDashboard from '@/pages/SuperAdminDashboard';
// Legacy Dashboard Redirector
import DashboardPage from '@/pages/DashboardPage';

// New Pages
import BecomeInstructorPage from '@/pages/BecomeInstructorPage';
import AdminInstructorRequests from '@/pages/AdminInstructorRequests';
import ApplicationStatusPage from '@/pages/ApplicationStatusPage';
import AdminApplicationReview from '@/pages/AdminApplicationReview';
import InstructorApplicationPage from '@/pages/InstructorApplicationPage';

// New Student Pages
import StudentCoursesListPage from '@/pages/StudentCoursesListPage';
import StudentCoursePage from '@/pages/StudentCoursePage';
import LessonViewPage from '@/pages/LessonViewPage';

// Forum Pages
import ForumsPage from '@/pages/ForumsPage';
import ForumTopicDetailPage from '@/pages/ForumTopicDetailPage';

// Admin Pages
import AdminCoursesPage from '@/pages/AdminCoursesPage';
import AdminUsersPage from '@/pages/AdminUsersPage';
import AdminResourcesPage from '@/pages/AdminResourcesPage';
import AdminEventsPage from '@/pages/AdminEventsPage';
import AdminSettingsPage from '@/pages/AdminSettingsPage';
import AccessDeniedPage from '@/pages/AccessDeniedPage';

// New Admin User Management Pages
import AdminCreateStudentPage from '@/pages/AdminCreateStudentPage';
import AdminCreateInstructorPage from '@/pages/AdminCreateInstructorPage';

// Other Pages
import SupportPage from '@/pages/SupportPage';
import FAQPage from '@/pages/FAQPage';
import HelpPage from '@/pages/HelpPage';
import HelpDetailPage from '@/pages/HelpDetailPage';
import LegalPage from '@/pages/LegalPage';
import TermsPage from '@/pages/TermsPage';
import PrivacyPage from '@/pages/PrivacyPage';

function App() {
  const AuthProviderComponent = PREVIEW_ENABLED ? PreviewAuthProvider : AuthProvider;

  if (PREVIEW_ENABLED) {
    console.warn('⚠️ Application is running in PREVIEW MODE. Authentication is mocked.');
  }

  return (
    <AuthProviderComponent>
      <RoleProvider>
        <EnrollmentProvider>
          <InstructorRequestProvider>
            <CartProvider>
              <div className="min-h-screen flex flex-col bg-white">
                <ScrollToTop />
                <Routes>
                  {/* ========================================================
                      DASHBOARD ROUTES - Strict Role Protection
                      ======================================================== */}
                  
                  <Route 
                    path="/student/dashboard" 
                    element={
                      <ProtectedRoute allowedRoles={[ROLES.STUDENT]}>
                        <Header />
                        <StudentDashboard />
                        <Footer />
                      </ProtectedRoute>
                    } 
                  />

                  <Route 
                    path="/instructor/dashboard" 
                    element={
                      <ProtectedRoute allowedRoles={[ROLES.INSTRUCTOR]}>
                        <Header />
                        <InstructorDashboard />
                        <Footer />
                      </ProtectedRoute>
                    } 
                  />

                  {/* Admin Dashboard - Accessible by ADMIN and SUPER_ADMIN */}
                  <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
                  <Route path="/admin/dashboard" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                      <Header />
                      <AdminDashboard />
                      <Footer />
                    </ProtectedRoute>
                  } />

                  {/* Super Admin Dashboard - STRICTLY SUPER_ADMIN */}
                  <Route path="/admin/super-admin/dashboard" element={
                    <ProtectedRoute allowedRoles={[ROLES.SUPER_ADMIN]}>
                      <Header />
                      <SuperAdminDashboard />
                      <Footer />
                    </ProtectedRoute>
                  } />
                  
                  {/* Fallback generic dashboard for any authenticated user */}
                  <Route path="/dashboard" element={
                    <ProtectedRoute>
                      <Header />
                      <DashboardPage />
                      <Footer />
                    </ProtectedRoute>
                  } />

                  {/* ========================================================
                      STUDENT ROUTES
                      ======================================================== */}
                  <Route 
                    path="/student/courses" 
                    element={
                      <ProtectedRoute allowedRoles={[ROLES.STUDENT]}>
                        <Header />
                        <StudentCoursesListPage />
                        <Footer />
                      </ProtectedRoute>
                    } 
                  />
                  
                  <Route 
                    path="/student/courses/:courseId" 
                    element={
                      <ProtectedRoute allowedRoles={[ROLES.STUDENT]}>
                        <Header />
                        <StudentCoursePage />
                        <Footer />
                      </ProtectedRoute>
                    } 
                  />

                  <Route 
                    path="/instructor-application" 
                    element={
                      <ProtectedRoute allowedRoles={[ROLES.STUDENT]}>
                        <Header />
                        <InstructorApplicationPage />
                        <Footer />
                      </ProtectedRoute>
                    } 
                  />

                  {/* ========================================================
                      INSTRUCTOR ROUTES
                      ======================================================== */}
                  
                  <Route 
                    path="/instructor-application-status" 
                    element={
                      <ProtectedRoute allowedRoles={[ROLES.STUDENT, ROLES.INSTRUCTOR]}>
                        <Header />
                        <ApplicationStatusPage />
                        <Footer />
                      </ProtectedRoute>
                    } 
                  />

                  {/* ========================================================
                      ADMIN ROUTES
                      ======================================================== */}
                  <Route path="/admin/courses" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminCoursesPage />
                       <Footer />
                    </ProtectedRoute>
                  } />
                  
                  <Route path="/admin/users" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminUsersPage />
                       <Footer />
                    </ProtectedRoute>
                  } />

                  <Route path="/admin/users/create-student" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                       <AdminCreateStudentPage />
                       <Footer />
                    </ProtectedRoute>
                  } />

                  <Route path="/admin/users/create-instructor" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                       <AdminCreateInstructorPage />
                       <Footer />
                    </ProtectedRoute>
                  } />
                  
                  <Route path="/admin/resources" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminResourcesPage />
                       <Footer />
                    </ProtectedRoute>
                  } />
                  
                  <Route path="/admin/events" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminEventsPage />
                       <Footer />
                    </ProtectedRoute>
                  } />
                  
                  <Route path="/admin/instructor-requests" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminInstructorRequests />
                       <Footer />
                    </ProtectedRoute>
                  } />

                  <Route path="/admin/instructor-applications" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminApplicationReview />
                       <Footer />
                    </ProtectedRoute>
                  } />

                  {/* Settings - Both Admin and Super Admin per prompt requirement */}
                  <Route path="/admin/settings" element={
                    <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                       <Header />
                      <AdminSettingsPage />
                       <Footer />
                    </ProtectedRoute>
                  } />

                  {/* ========================================================
                      COMMON & PUBLIC ROUTES
                      ======================================================== */}

                  <Route path="/access-denied" element={
                     <>
                       <Header />
                       <AccessDeniedPage />
                       <Footer />
                     </>
                  } />

                  {/* Lesson Viewer Route (Immersive) */}
                  <Route 
                    path="/course/:courseId/lesson/:lessonId" 
                    element={
                      <ProtectedRoute>
                        <LessonViewPage />
                      </ProtectedRoute>
                    } 
                  />

                  {/* Legacy Video Viewer Route */}
                  <Route path="/courses/:courseId/videos" element={<VideoViewerPage />} />

                  {/* Become Instructor (General Info Page) */}
                  <Route 
                    path="/become-instructor" 
                    element={
                      <>
                        <Header />
                        <BecomeInstructorPage />
                        <Footer />
                      </>
                    } 
                  />

                  <Route path="*" element={
                    <>
                      <Header />
                      <main className="flex-grow">
                        <Routes>
                          {/* Public Routes */}
                          <Route path="/" element={<HomePage />} />
                          <Route path="/cursos" element={<CoursesPage />} />
                          <Route path="/cursos/:id" element={<CourseDetailPage />} />
                          <Route path="/categorias" element={<CategoriesPage />} />
                          <Route path="/testimonios" element={<TestimonialsPage />} />
                          
                          {/* Blog */}
                          <Route path="/blog" element={<BlogPage />} />
                          <Route path="/blog/:id" element={<BlogDetailPage />} />

                          <Route path="/newsletter" element={<NewsletterPage />} />
                          <Route path="/sobre-nosotros" element={<AboutPage />} />
                          <Route path="/contact" element={<ContactPage />} />
                          <Route path="/contacto" element={<ContactPage />} />
                          
                          {/* Store */}
                          <Route path="/store" element={<StorePage />} />
                          <Route path="/product/:id" element={<ProductDetailPage />} />
                          <Route path="/success" element={<SuccessPage />} />
                          
                          {/* Learning Paths */}
                          <Route path="/learning-paths" element={<LearningPathsPage />} />
                          <Route path="/learning-paths/:id" element={<LearningPathDetailPage />} />

                          {/* Community & Events */}
                          <Route path="/community" element={<CommunityPage />} />
                          <Route path="/events" element={<EventsPage />} />
                          <Route path="/events/:id" element={<EventDetailPage />} />
                          <Route path="/rankings" element={<RankingsPage />} />
                          <Route path="/resources" element={<ResourcesPage />} />

                          {/* Forum Routes */}
                          <Route path="/forums" element={<ForumsPage />} />
                          <Route path="/forums/:topicId" element={<ForumTopicDetailPage />} />

                          {/* Support & Legal */}
                          <Route path="/support" element={<SupportPage />} />
                          <Route path="/faq" element={<FAQPage />} />
                          <Route path="/help" element={<HelpPage />} />
                          <Route path="/help/:guideId" element={<HelpDetailPage />} />
                          <Route path="/legal" element={<LegalPage />} />
                          <Route path="/terms" element={<TermsPage />} />
                          <Route path="/privacy" element={<PrivacyPage />} />
                          <Route path="/about" element={<AboutPage />} />

                          {/* Auth Routes */}
                          <Route path="/login" element={<LoginPage />} />
                          <Route path="/signup" element={<SignupPage />} />
                        </Routes>
                      </main>
                      <Footer />
                      <ChatbotWidget />
                      <ScrollToTopButton />
                    </>
                  } />
                </Routes>
                <Toaster />
              </div>
            </CartProvider>
          </InstructorRequestProvider>
        </EnrollmentProvider>
      </RoleProvider>
    </AuthProviderComponent>
  );
}

export default App;
