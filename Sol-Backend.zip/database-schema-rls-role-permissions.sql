
-- ==============================================================================
-- RLS POLICIES FOR ROLE_PERMISSIONS
-- ==============================================================================
-- Table: public.role_permissions
-- ==============================================================================

-- 1. Enable RLS
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;

-- 2. Define Policies

-- Policy 1: Role permissions are public - everyone can view
CREATE POLICY "Role permissions viewable by everyone" 
ON public.role_permissions 
FOR SELECT 
USING (true);

-- Policy 2: Only super_admin can create role_permissions
CREATE POLICY "Super admin can insert role permissions" 
ON public.role_permissions 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);

-- Policy 3: Only super_admin can update role_permissions
CREATE POLICY "Super admin can update role permissions" 
ON public.role_permissions 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);

-- Policy 4: Only super_admin can delete role_permissions
CREATE POLICY "Super admin can delete role permissions" 
ON public.role_permissions 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);
