
# Design System Components Specification

## 1. Button (`.btn-base`)
The primary interactive element for triggering actions.

**Variants:**
*   **Primary:** `.btn-primary` (Blue). Use for the main action.
*   **Secondary:** `.btn-secondary` (Gray/Border). Use for secondary options.
*   **Ghost:** `.btn-ghost` (Transparent). Use for subtle actions within cards/lists.
*   **Danger:** `.btn-danger` (Red). Use for destructive actions (Delete, Remove).

**Code Example:**
