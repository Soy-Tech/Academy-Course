
-- ==============================================================================
-- NETCOM ACADEMY - SUPABASE DATABASE SCHEMA
-- ==============================================================================
-- This schema sets up the Role-Based Access Control (RBAC) system and User Profiles.
-- It is designed to work with Supabase Auth (auth.users).
--
-- INSTRUCTIONS:
-- 1. Go to your Supabase Dashboard > SQL Editor.
-- 2. Copy and paste the contents of this file.
-- 3. Run the script to create tables, security policies, and seed initial data.
-- ==============================================================================

-- 1. CLEANUP (Optional - Use with caution)
-- DROP TABLE IF EXISTS public.role_permissions CASCADE;
-- DROP TABLE IF EXISTS public.permissions CASCADE;
-- DROP TABLE IF EXISTS public.user_roles CASCADE; -- If using a join table
-- DROP TABLE IF EXISTS public.profiles CASCADE;
-- DROP TABLE IF EXISTS public.roles CASCADE;

-- 2. CREATE TABLES

-- Roles Table
CREATE TABLE IF NOT EXISTS public.roles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Permissions Table
CREATE TABLE IF NOT EXISTS public.permissions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code VARCHAR(100) NOT NULL UNIQUE, -- e.g., 'courses:read', 'users:edit'
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Role Permissions (Many-to-Many)
CREATE TABLE IF NOT EXISTS public.role_permissions (
    role_id UUID REFERENCES public.roles(id) ON DELETE CASCADE,
    permission_id UUID REFERENCES public.permissions(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    PRIMARY KEY (role_id, permission_id)
);

-- Profiles Table (Extends auth.users)
-- Note: 'users' table request is handled here as 'profiles' to avoid conflict with 'auth.users'
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    email VARCHAR(255),
    full_name VARCHAR(100),
    avatar_url TEXT,
    role_id UUID REFERENCES public.roles(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Note: 'refresh_tokens' table is NOT created because Supabase Auth handles 
-- session management and refresh tokens automatically within the 'auth' schema.

-- 3. CREATE INDEXES (Performance)

CREATE INDEX IF NOT EXISTS idx_profiles_email ON public.profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_role_id ON public.profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON public.role_permissions(role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON public.role_permissions(permission_id);

-- 4. ROW LEVEL SECURITY (RLS) POLICIES

-- Enable RLS
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policies for Roles (Readable by everyone, manageable by Admins)
CREATE POLICY "Roles are viewable by everyone" ON public.roles FOR SELECT USING (true);
CREATE POLICY "Roles manageable by super_admin" ON public.roles FOR ALL USING (
  exists (
    select 1 from public.profiles
    where profiles.id = auth.uid()
    and profiles.role_id in (select id from public.roles where name = 'super_admin')
  )
);

-- Policies for Profiles
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- 5. AUTOMATION (Triggers)

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  default_role_id UUID;
BEGIN
  -- Get the 'student' role ID
  SELECT id INTO default_role_id FROM public.roles WHERE name = 'student' LIMIT 1;

  INSERT INTO public.profiles (id, email, full_name, role_id)
  VALUES (
    new.id, 
    new.email, 
    new.raw_user_meta_data->>'full_name',
    default_role_id
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to call the function on auth.users insert
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 6. SEED DATA (Initial Roles & Permissions)

-- Insert Roles
INSERT INTO public.roles (name, description) VALUES
('student', 'Standard user with access to purchased content'),
('instructor', 'Can create and manage own courses'),
('admin', 'Can manage users and content'),
('super_admin', 'Full system access')
ON CONFLICT (name) DO NOTHING;

-- Insert Permissions
INSERT INTO public.permissions (code, description) VALUES
('view:courses', 'Can view available courses'),
('create:course', 'Can create new courses'),
('edit:course', 'Can edit existing courses'),
('delete:course', 'Can delete courses'),
('view:dashboard:student', 'Access to student dashboard'),
('view:dashboard:instructor', 'Access to instructor dashboard'),
('manage:users', 'Can manage system users'),
('manage:roles', 'Can manage roles and permissions'),
('view:admin:panel', 'Access to admin area')
ON CONFLICT (code) DO NOTHING;

-- Map Permissions to Roles (Seed Role_Permissions)
DO $$
DECLARE
  r_student UUID;
  r_instructor UUID;
  r_admin UUID;
  r_super UUID;
  p_view_courses UUID;
  p_create_course UUID;
  p_edit_course UUID;
  p_delete_course UUID;
  p_view_dash_student UUID;
  p_view_dash_instructor UUID;
  p_manage_users UUID;
  p_manage_roles UUID;
  p_view_admin UUID;
BEGIN
  -- Get Role IDs
  SELECT id INTO r_student FROM public.roles WHERE name = 'student';
  SELECT id INTO r_instructor FROM public.roles WHERE name = 'instructor';
  SELECT id INTO r_admin FROM public.roles WHERE name = 'admin';
  SELECT id INTO r_super FROM public.roles WHERE name = 'super_admin';

  -- Get Permission IDs
  SELECT id INTO p_view_courses FROM public.permissions WHERE code = 'view:courses';
  SELECT id INTO p_create_course FROM public.permissions WHERE code = 'create:course';
  SELECT id INTO p_edit_course FROM public.permissions WHERE code = 'edit:course';
  SELECT id INTO p_delete_course FROM public.permissions WHERE code = 'delete:course';
  SELECT id INTO p_view_dash_student FROM public.permissions WHERE code = 'view:dashboard:student';
  SELECT id INTO p_view_dash_instructor FROM public.permissions WHERE code = 'view:dashboard:instructor';
  SELECT id INTO p_manage_users FROM public.permissions WHERE code = 'manage:users';
  SELECT id INTO p_manage_roles FROM public.permissions WHERE code = 'manage:roles';
  SELECT id INTO p_view_admin FROM public.permissions WHERE code = 'view:admin:panel';

  -- Student Permissions
  INSERT INTO public.role_permissions (role_id, permission_id) VALUES
  (r_student, p_view_courses),
  (r_student, p_view_dash_student)
  ON CONFLICT DO NOTHING;

  -- Instructor Permissions
  INSERT INTO public.role_permissions (role_id, permission_id) VALUES
  (r_instructor, p_view_courses),
  (r_instructor, p_create_course),
  (r_instructor, p_edit_course),
  (r_instructor, p_view_dash_instructor)
  ON CONFLICT DO NOTHING;

  -- Admin Permissions
  INSERT INTO public.role_permissions (role_id, permission_id) VALUES
  (r_admin, p_view_courses),
  (r_admin, p_create_course),
  (r_admin, p_edit_course),
  (r_admin, p_delete_course),
  (r_admin, p_view_dash_student),
  (r_admin, p_view_dash_instructor),
  (r_admin, p_manage_users),
  (r_admin, p_view_admin)
  ON CONFLICT DO NOTHING;

  -- Super Admin Permissions (All)
  INSERT INTO public.role_permissions (role_id, permission_id)
  SELECT r_super, id FROM public.permissions
  ON CONFLICT DO NOTHING;
END $$;
