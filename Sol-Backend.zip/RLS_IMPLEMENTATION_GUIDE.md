
# RLS Implementation Guide

This document outlines the step-by-step process for implementing Row Level Security (RLS) and Automated User Triggers in the Supabase database.

## Phase 1: Preparation
Before running the scripts, ensure your Supabase project is initialized and you have access to the **SQL Editor**.

### Restrictions Confirmed
- ✅ No frontend code changes required.
- ✅ No changes to `AuthContext.jsx`.
- ✅ No changes to existing API integrations.
- ✅ All logic is contained within the PostgreSQL database layer.

---

## Phase 2: Execution Order

Execute the SQL scripts in the Supabase SQL Editor in the exact order listed below to ensure dependencies are met.

### Step 1: Base Schema & Trigger
**File:** `database-schema-trigger.sql`
- **Purpose:** Creates the `handle_new_user` function and triggers.
- **Verification:** Check `Database > Triggers` to see `on_auth_user_created`.

### Step 2: Roles RLS
**File:** `database-schema-rls-roles.sql`
- **Purpose:** Secures the `roles` table.
- **Dependencies:** Requires `roles` table (created in base setup).

### Step 3: Permissions RLS
**File:** `database-schema-rls-permissions.sql`
- **Purpose:** Secures the `permissions` table.
- **Dependencies:** Requires `permissions` table.

### Step 4: Profiles (Users) RLS
**File:** `database-schema-rls-users.sql`
- **Purpose:** Secures the `profiles` table and links auth to data.
- **Dependencies:** Requires `profiles` and `roles` tables.

### Step 5: Role-Permissions RLS
**File:** `database-schema-rls-role-permissions.sql`
- **Purpose:** Secures the mapping table.
- **Dependencies:** Requires `role_permissions` table.

### Step 6: Courses RLS
**File:** `database-schema-rls-courses.sql`
- **Purpose:** Creates and secures `courses` table.
- **Action:** Will create table if it doesn't exist.

### Step 7: Enrollments RLS
**File:** `database-schema-rls-enrollments.sql`
- **Purpose:** Creates and secures `enrollments` table.
- **Action:** Will create table if it doesn't exist.

### Step 8: Refresh Tokens RLS
**File:** `database-schema-rls-refresh-tokens.sql`
- **Purpose:** Creates and secures custom token storage.
- **Action:** Will create table if it doesn't exist.

---

## Phase 3: Final Confirmation Checklist (FASE 12)

| Check | Item | Verified |
|-------|------|----------|
| 1 | `profiles` table exists and has RLS enabled | [ ] |
| 2 | `roles` table exists and has RLS enabled | [ ] |
| 3 | `on_auth_user_created` trigger is active | [ ] |
| 4 | Super Admin user exists in database | [ ] |
| 5 | Default 'student' role exists | [ ] |

## Troubleshooting

**Issue: Trigger fails silently**
- **Fix:** Check Supabase Database Logs. Ensure `public.roles` has a row with `name='student'`.

**Issue: Infinite recursion in RLS**
- **Fix:** Ensure policies avoid circular queries (e.g., querying `profiles` inside a `profiles` policy without proper joins). The provided scripts use optimized `EXISTS` clauses to prevent this.

**Issue: Admin cannot see users**
- **Fix:** Verify the admin user has `role_id` pointing to the 'admin' role in `public.roles`.
