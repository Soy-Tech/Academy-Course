
# Netcom Academy Design System

**Version:** 1.0.0  
**Last Updated:** February 6, 2026

## 1. Overview
The Netcom Academy Design System is a comprehensive collection of rules, constraints, and principles implemented in code to ensure a cohesive, accessible, and high-quality user experience across our educational platform. It bridges the gap between design and development by providing a single source of truth.

## 2. Core Foundations

### Color Palette
We use a semantic color system to convey meaning, status, and brand identity.
*   **Primary (Netcom Blue):** `#0052CC` - Used for primary actions, navigation, and key brand elements. Represents trust, professionalism, and depth.
*   **Secondary (Growth Green):** `#10B981` - Used for success states, enrollment confirmations, and growth indicators.
*   **Neutral Scale:** `#111827` to `#FFFFFF` - Provides structure, text hierarchy, and background definition.

### Typography
Two distinct typefaces create a balance between functionality and character.
*   **Primary (UI/Body):** `Inter` - Highly legible sans-serif for interface elements, dense information, and long-form reading.
*   **Secondary (Headings):** `Sora` - Geometric sans-serif with distinct character for headlines and major calls to action.

### Spacing & Grid
*   **Base Unit:** 4px (0.25rem).
*   **Scale:** xs(4px), sm(8px), md(16px), lg(24px), xl(32px), 2xl(48px), 3xl(64px).
*   **Layout:** 12-column grid system with fluid margins and strict container max-widths (1280px standard).

## 3. Brand Identity
**Voice:** Educational, Professional, Encouraging, Trustworthy.  
**Visual Style:** Clean, modern, using generous whitespace and subtle drop shadows to create depth (Elevation) rather than flat design.

## 4. UI Components

### Buttons
*   **Primary:** Solid blue background, white text. Main Call to Action (CTA).
*   **Secondary:** Gray background, dark text. Alternative actions (e.g., "Cancel", "Back").
*   **Ghost:** Transparent background. Contextual actions.
*   **Danger:** Red background. Destructive actions.

### Forms
*   **Inputs:** 44px height minimum for touch targets.
*   **States:** Default, Hover, Focus (Blue Ring), Error (Red Border), Disabled.
*   **Validation:** Inline error messages below inputs.

### Cards
*   White background with `1px` gray border and `shadow-sm`.
*   Hover state lifts the card (`translate-y`) and increases shadow depth.

## 5. Accessibility (WCAG AA)
*   **Contrast:** All text meets 4.5:1 ratio against background.
*   **Focus:** Visible focus indicators for keyboard navigation.
*   **Touch:** Minimum 44x44px target size for interactive elements.
*   **Semantic HTML:** Proper use of heading levels (`h1`-`h6`) and ARIA labels.

## 6. Implementation
Styles are delivered via CSS Custom Properties (Variables) defined in `src/styles/variables.css` and utility classes in `src/styles/design-tokens.css`.

**Usage Example:**
