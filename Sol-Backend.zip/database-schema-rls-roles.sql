
-- ==============================================================================
-- RLS POLICIES FOR ROLES
-- ==============================================================================
-- Table: public.roles
-- ==============================================================================

-- 1. Enable RLS
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

-- 2. Define Policies

-- Policy 1: Roles are public - everyone can view
CREATE POLICY "Roles are viewable by everyone" 
ON public.roles 
FOR SELECT 
USING (true);

-- Policy 2: Only super_admin can create roles
CREATE POLICY "Super admin can insert roles" 
ON public.roles 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles AS r ON profiles.role_id = r.id
    WHERE profiles.id = auth.uid() 
    AND r.name = 'super_admin'
  )
);

-- Policy 3: Only super_admin can update roles
CREATE POLICY "Super admin can update roles" 
ON public.roles 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles AS r ON profiles.role_id = r.id
    WHERE profiles.id = auth.uid() 
    AND r.name = 'super_admin'
  )
);

-- Policy 4: Only super_admin can delete roles
CREATE POLICY "Super admin can delete roles" 
ON public.roles 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles AS r ON profiles.role_id = r.id
    WHERE profiles.id = auth.uid() 
    AND r.name = 'super_admin'
  )
);
