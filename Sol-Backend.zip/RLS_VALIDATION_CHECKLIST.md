
# RLS Validation & Testing Checklist

Use this checklist to validate the security and functionality of the Supabase implementation.

## 1. Pre-Implementation Checklist
- [ ] Database is clean or backed up.
- [ ] 'student', 'admin', 'super_admin' roles exist in `public.roles`.
- [ ] You have access to the Supabase Table Editor to view rows.

## 2. Signup Flow Validation
**Objective:** Verify automatic user creation.
1. Go to Authentication > Users.
2. Invite or create a new user manually (or via signup form).
3. **Expected Result:**
   - User appears in `auth.users`.
   - New row instantly appears in `public.profiles`.
   - `role_id` in `public.profiles` matches the 'student' role UUID.

## 3. RLS Test Cases

Run these SQL queries in the SQL Editor to simulate different user perspectives. Use `set local role authenticated;` and `set request.jwt.claim.sub = 'USER_UUID';` to impersonate users if testing via SQL, or use the App frontend.

| Test Case | Actor | Action | Expected Result |
|-----------|-------|--------|-----------------|
| **TC-01** | Student | `SELECT * FROM profiles WHERE id = 'own_id'` | ✅ Success (1 row) |
| **TC-02** | Student | `SELECT * FROM profiles WHERE id = 'other_id'` | ❌ Empty/Denied |
| **TC-03** | Student | `UPDATE profiles SET role_id = 'admin_id'` | ❌ Denied (Field restriction or RLS) |
| **TC-04** | Admin | `SELECT * FROM profiles` | ✅ Success (All rows) |
| **TC-05** | Admin | `INSERT INTO roles` | ❌ Denied (Only Super Admin) |
| **TC-06** | Super Admin | `DELETE FROM roles` | ✅ Success |
| **TC-07** | Public | `SELECT * FROM roles` | ✅ Success (Publicly readable) |
| **TC-08** | Instructor | `INSERT INTO courses` | ✅ Success |

## 4. SQL Queries for Validation

### Validate Trigger
