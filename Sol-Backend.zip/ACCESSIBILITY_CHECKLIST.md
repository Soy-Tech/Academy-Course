
# Accessibility (a11y) Checklist - WCAG 2.1 AA

## 1. Color & Contrast
- [ ] **Text Contrast:** Normal text (<18pt) must have a contrast ratio of at least **4.5:1** against the background.
- [ ] **Large Text Contrast:** Large text (bold 14pt+ or 18pt+) must have a ratio of **3:1**.
- [ ] **UI Components:** Borders of inputs and buttons must have a **3:1** contrast ratio against the background.
- [ ] **Color Independence:** Color is not used as the *only* visual means of conveying information (e.g., error states should have an icon or text message, not just a red border).

## 2. Focus & Keyboard Navigation
- [ ] **Focus Visible:** All interactive elements (links, buttons, inputs) show a clear focus ring (Standard: `outline: 2px solid var(--color-primary-500)`).
- [ ] **Tab Order:** Navigation order follows the visual logic of the page (Left -> Right, Top -> Bottom).
- [ ] **No Traps:** Keyboard users do not get "stuck" in a component (like a modal or map).
- [ ] **Skip Links:** A "Skip to Main Content" link exists for keyboard users to bypass navigation.

## 3. Forms
- [ ] **Labels:** Every `<input>`, `<select>`, and `<textarea>` has a programmatic label (using `<label for="id">` or `aria-label`).
- [ ] **Error Identification:** Errors are described in text and linked to the field (e.g., `aria-describedby="error-msg-id"`).
- [ ] **Autocomplete:** Input fields have appropriate `autocomplete` attributes (e.g., `email`, `username`).

## 4. Images & Media
- [ ] **Alt Text:** All informative images have `alt` attributes describing the content.
- [ ] **Decorative Images:** Purely decorative images have `alt=""` or `aria-hidden="true"`.
- [ ] **Video:** Videos have captions/subtitles available.

## 5. Structure & Semantics
- [ ] **Headings:** Hierarchy is logical (`h1` -> `h2` -> `h3`) and not skipped. Only one `h1` per page.
- [ ] **Landmarks:** Use of `<nav>`, `<main>`, `<aside>`, `<footer>`, `<header>` regions.
- [ ] **Links:** Link text is descriptive ("Read more about Pricing" vs "Click here").

## 6. Motion
- [ ] **Reduced Motion:** Listen to `prefers-reduced-motion` media query to disable parallax or heavy transitions.
- [ ] **Flashing:** No content flashes more than 3 times per second.

## Testing Tools
1.  **WAVE Evaluation Tool** (Chrome Extension)
2.  **Axe DevTools**
3.  **WebAIM Contrast Checker**
