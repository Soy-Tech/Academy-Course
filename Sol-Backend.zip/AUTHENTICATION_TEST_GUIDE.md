
# Guía de Validación de Autenticación - Netcom Academy

Esta guía documenta el proceso de prueba y validación del sistema de autenticación reparado, incluyendo roles, permisos y redirecciones.

## Credenciales de Prueba (Test Users)

Todos los usuarios de prueba comparten la contraseña: `Test123!@`

| Rol | Email | Dashboard Esperado |
|-----|-------|--------------------|
| **Student** | `student@test.com` | `/student/dashboard` |
| **Instructor** | `instructor@test.com` | `/instructor/dashboard` |
| **Admin** | `admin@test.com` | `/admin/dashboard` |
| **Super Admin** | `superadmin@test.com` | `/admin/super-admin/dashboard` |

## Flujos de Validación

### 1. Validación de Roles y Redirección
- [x] Iniciar sesión como **Student**. Verificar redirección a `/student/dashboard`. Verificar botón "Convertirme en Instructor".
- [x] Iniciar sesión como **Instructor**. Verificar redirección a `/instructor/dashboard`. Verificar ausencia de botón "Convertirme en Instructor".
- [x] Iniciar sesión como **Admin**. Verificar redirección a `/admin/dashboard`. Verificar acceso a gestión de usuarios.
- [x] Iniciar sesión como **Super Admin**. Verificar redirección a `/admin/super-admin/dashboard`. Verificar acceso a consola total.

### 2. Validación de Rutas Protegidas
- [x] Intentar acceder a `/admin/dashboard` como **Student** -> Debe redirigir a `/access-denied`.
- [x] Intentar acceder a `/instructor/dashboard` como **Student** -> Debe redirigir a `/access-denied`.
- [x] Intentar acceder a `/student/dashboard` sin sesión -> Debe redirigir a `/login`.

### 3. Validación de Persistencia
- [x] Recargar página (F5) estando logueado. La sesión debe mantenerse.
- [x] Verificar `localStorage` -> Clave `auth_user` debe existir con datos del usuario.

### 4. Validación de Logout
- [x] Hacer clic en "Cerrar sesión".
- [x] Verificar que `auth_user` se elimina de `localStorage`.
- [x] Verificar redirección a home `/`.

## Troubleshooting

### El usuario no se loguea
- Revisar consola del navegador. Buscar logs con prefijo `[Auth]`.
- Verificar que `src/data/testUsers.js` esté cargado correctamente.

### Redirección incorrecta
- Verificar `LoginPage.jsx` -> switch statement en `handleSubmit`.
- Verificar `App.jsx` -> rutas definidas correctamente.

### Acceso Denegado inesperado
- Verificar los permisos en `src/utils/rolePermissions.js`.
- Asegurarse de que `ProtectedRoute` recibe el prop `allowedRoles` correcto (ej: `allowedRoles={[ROLES.STUDENT]}`).
