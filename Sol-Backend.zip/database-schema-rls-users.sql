
-- ==============================================================================
-- RLS POLICIES FOR USERS (PROFILES)
-- ==============================================================================
-- Enables Row Level Security on the profiles table.
-- Table: public.profiles
-- ==============================================================================

-- 1. Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 2. Define Policies

-- Policy 1: Users can view their own profile
CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

-- Policy 2: Users can update their own profile
CREATE POLICY "Users can update own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = id);

-- Policy 3: Admin can view all users
-- Checks if the requesting user has a role named 'admin' or 'super_admin'
CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name IN ('admin', 'super_admin')
  )
);

-- Policy 4: Super admin can update any user
CREATE POLICY "Super admin can update any profile" 
ON public.profiles 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);

-- Policy 5: Super admin can delete users
CREATE POLICY "Super admin can delete profiles" 
ON public.profiles 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);

-- Policy 6: Trigger can create users for signup
-- Allows INSERTs. In production, 'SECURITY DEFINER' on the trigger function 
-- usually bypasses this, but we enable it explicitly as requested.
CREATE POLICY "Enable insert for registration" 
ON public.profiles 
FOR INSERT 
WITH CHECK (true);
