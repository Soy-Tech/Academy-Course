
# Usuarios de Prueba - Sandbox de Autenticación

Este documento describe las cuentas de usuario de prueba configuradas en el entorno de desarrollo para probar diferentes roles y permisos.

## Tabla de Credenciales

Todas las cuentas utilizan la misma contraseña para facilitar las pruebas.

| Rol | Email | Contraseña | Nivel de Acceso |
|-----|-------|------------|-----------------|
| **Student** | `student@test.com` | `Test123!@` | Acceso básico, comprar cursos, ver progreso. |
| **Instructor** | `instructor@test.com` | `Test123!@` | Crear cursos, ver estudiantes propios. |
| **Admin** | `admin@test.com` | `Test123!@` | Gestión de usuarios, aprobar instructores, reportes básicos. |
| **Super Admin** | `superadmin@test.com` | `Test123!@` | Acceso total, configuración global, gestión de admins. |

## Cómo usar

1.  Navega a la página de inicio de sesión (`/login`).
2.  Verás un panel informativo azul con botones de acceso rápido.
3.  Haz clic en el botón del rol que deseas probar (ej. "Student").
4.  El formulario se llenará automáticamente.
5.  Haz clic en "Iniciar Sesión".

## Identificación de Usuario de Prueba

Cuando inicias sesión con una de estas cuentas, verás un distintivo (badge) especial en la cabecera del sitio:

*   **Badges de Color**: Indican visualmente el rol activo.
    *   🔴 Rojo: Super Admin
    *   🟣 Púrpura: Admin
    *   🔵 Azul: Instructor
    *   🟢 Verde: Estudiante
*   **Texto "TEST USER"**: Aparece junto a tu avatar para recordarte que no estás usando una cuenta real persistente.
*   **Menú de Usuario**: En el menú desplegable, verás la etiqueta "TEST ACCOUNT".

## Rutas Accesibles por Rol

### Student (`student@test.com`)
*   `/dashboard` (Vista de estudiante)
*   `/cursos` (Catálogo público)
*   `/my-courses` (Mis cursos)
*   `/instructor-application` (Puede solicitar ser instructor)
*   **No puede acceder**: `/admin/*`

### Instructor (`instructor@test.com`)
*   `/dashboard` (Vista de instructor)
*   `/instructor/courses` (Gestión de cursos propios)
*   **No puede acceder**: `/admin/*`, `/instructor-application` (ya es instructor)

### Admin (`admin@test.com`)
*   `/admin/dashboard`
*   `/admin/users` (Gestión de usuarios)
*   `/admin/instructor-requests` (Aprobar solicitudes)
*   **Limitado**: No puede crear otros administradores ni ver configuraciones globales.

### Super Admin (`superadmin@test.com`)
*   Todas las rutas anteriores.
*   `/admin/settings`
*   `/admin/admins` (Crear otros administradores)

## Limpiar Datos

Los usuarios de prueba funcionan en memoria para la sesión actual. 
*   Para "reiniciar" el estado de un usuario de prueba, simplemente cierra sesión (`Logout`) e inicia sesión de nuevo.
*   No se guardan cambios persistentes en la base de datos simulada (`mockDb`) para estos usuarios específicos, aunque sus acciones pueden generar logs en `audit_log` (localStorage).

## Notas de Seguridad

⚠️ **ADVERTENCIA**: Estas cuentas son **EXCLUSIVAMENTE PARA DESARROLLO Y PRUEBAS**.
*   Nunca utilices estas credenciales en un entorno de producción.
*   El sistema está diseñado para que estos usuarios solo existan si el archivo `testUsers.js` está presente y cargado.
