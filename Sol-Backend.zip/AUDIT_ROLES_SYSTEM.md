
# AUDITORÍA DEL SISTEMA DE ROLES Y PERMISOS

**Fecha:** 2026-02-04
**Versión del Codebase:** 1.0.0
**Estado:** Análisis Estático sin Cambios

---

## SECCIÓN 1: ROLES ACTUALES

### Definición de Roles
Los roles están definidos explícitamente en el archivo `src/utils/rolePermissions.js`. El sistema utiliza un conjunto finito de roles constantes:

1.  **ADMIN** (`'admin'`): Superusuario con acceso total y bypass de permisos.
2.  **INSTRUCTOR** (`'instructor'`): Usuario con acceso al panel de administración limitado a gestión de contenido.
3.  **STUDENT** (`'student'`): Rol por defecto para consumidores de contenido.

### Almacenamiento y Estado
El sistema maneja los roles en dos capas que pueden generar desincronización:

1.  **AuthContext (`src/contexts/AuthContext.jsx`):**
    *   Almacena el objeto `currentUser` completo.
    *   La propiedad `currentUser.role` define el rol "real" del usuario autenticado.
    *   Persistencia: `localStorage.getItem('mockUser')`.

2.  **RoleContext (`src/contexts/RoleContext.jsx`):**
    *   Gestiona el estado `currentRole` utilizado para la validación de permisos en la UI.
    *   Inicialización: Intenta leer `localStorage.getItem('user_role')` primero. Si no existe, recurre a `currentUser.role`.
    *   **Riesgo Detectado:** El uso de `user_role` separado permite funcionalidades de "Cambiar vista de rol" (útil en desarrollo), pero en producción podría permitir discrepancias entre la identidad del usuario y sus permisos si no se limpia correctamente.

### Rol por Defecto
*   En **SignupPage.jsx**, no se asigna un rol explícitamente en el objeto enviado (se asume backend default).
*   En **AuthContext.jsx**, el mock por defecto (`login()`) asigna `'student'` a menos que se especifique lo contrario.

---

## SECCIÓN 2: CREACIÓN DE INSTRUCTOR POR AUTO-REGISTRO

**Estado Actual: NO IMPLEMENTADO**

*   **SignupPage.jsx:** Utiliza un formulario genérico (Nombre, Email, Password).
*   **Ausencia de UI:** No existe checkbox "¿Quiero ser instructor?" ni formulario de solicitud.
*   **Flujo:** Todo usuario que se registra entra al sistema automáticamente como `STUDENT`.
*   **Conclusión:** Actualmente no es posible que un usuario se convierta en instructor por sus propios medios ni solicite el rol durante el registro.

---

## SECCIÓN 3: CREACIÓN DE INSTRUCTOR POR ADMIN

**Estado Actual: IMPLEMENTADO (Manual)**

*   **Ubicación:** Panel de Administración > Usuarios (`src/pages/AdminUsersPage.jsx`).
*   **Mecanismo:**
    1.  El administrador abre el modal de edición/creación (`UserModal.jsx`).
    2.  El formulario `UserForm.jsx` contiene un `<select name="rol">` con opciones: Estudiante, Instructor, Administrador.
    3.  Al guardar, se actualiza el estado local (mock) o se enviaría la petición al backend.
*   **Limitaciones:**
    *   No hay flujo de invitación por correo.
    *   No hay notificación automática al usuario de que su rol ha cambiado.
    *   El admin puede crear un usuario nuevo directamente con rol Instructor.

---

## SECCIÓN 4: SOPORTE PARA MÚLTIPLES ROLES

**Estado Actual: NO SOPORTADO (Rol Único)**

*   **Estructura de Datos:** Tanto en `AuthContext` como en `mockUsers`, el campo `role` es un **String** (`'student'`), no un Array (`['student', 'instructor']`).
*   **Validación:**
    *   La función `hasPermission` (`src/utils/rolePermissions.js`) evalúa un único rol entrante: `ROLE_PERMISSIONS[role]`.
    *   No existe lógica para combinar permisos de múltiples roles (ej. `role.includes('admin')`).
*   **Prioridad:** Al ser rol único, la prioridad es absoluta. Si eres Instructor, dejas de ser Estudiante (a nivel de etiqueta de rol), aunque los permisos de Instructor suelen ser un superconjunto o incluir acceso de lectura similar.

---

## SECCIÓN 5: IMPACTO EN PERMISOS

### Matriz de Permisos (Instructor vs Otros)
Según `src/utils/rolePermissions.js`:

| Permiso | Student | Instructor | Admin | Observación |
| :--- | :---: | :---: | :---: | :--- |
| **VIEW_ADMIN** | ❌ | ✅ | ✅ | Acceso base al layout `/admin` |
| **MANAGE_USERS** | ❌ | ❌ | ✅ | Solo Admin gestiona usuarios |
| **MANAGE_COURSES** | ❌ | ✅ | ✅ | Crear/Editar cursos |
| **MANAGE_CONTENT** | ❌ | ✅ | ✅ | Módulos y Lecciones |
| **MANAGE_EVENTS** | ❌ | ✅ | ✅ | Webinars |
| **MANAGE_RESOURCES**| ❌ | ✅ | ✅ | Biblioteca global |
| **MANAGE_SETTINGS** | ❌ | ❌ | ✅ | Configuración plataforma |
| **VIEW_COMMUNITY** | ✅ | ✅ | ✅ | Acceso social |

**Permisos Faltantes/Ambiguos para Instructor:**
*   No tiene permiso explícito para **Ver sus propios estudiantes**.
*   `MANAGE_COURSES` es global en la implementación actual (puede editar cursos de otros en el mock).
*   No hay permiso definido para **Analíticas Financieras** (ver sus ventas).

---

## SECCIÓN 6: IMPACTO EN UI/UX

### Header (`Header.jsx`)
*   Muestra enlace **"Admin"** (con icono de escudo) solo si `hasPermission(PERMISSIONS.VIEW_ADMIN)` es true (Instructores y Admins).
*   El resto de la navegación es idéntica.

### Admin Sidebar (`AdminSidebar.jsx`)
*   Filtra ítems del menú según permisos.
*   **Instructor ve:** Dashboard, Cursos, Eventos, Recursos.
*   **Instructor NO ve:** Usuarios, Configuración.

### Dashboard Principal (`DashboardPage.jsx`)
*   Actualmente es genérico para estudiantes.
*   No existe una vista de "Dashboard de Instructor" (con gráficas de ventas o estudiantes activos) fuera del panel `/admin`.

---

## SECCIÓN 7: FLUJO DE TRANSICIÓN (Student → Instructor)

Al cambiar el rol de un usuario de `'student'` a `'instructor'` (vía Admin Panel):

1.  **Acceso:** El usuario gana acceso inmediato a la ruta `/admin`.
2.  **Datos de Estudiante:**
    *   Dado que el sistema no borra datos asociados por ID, el usuario teóricamente mantiene sus inscripciones (`enrollments`).
    *   Sin embargo, la UI no está optimizada para usuarios híbridos. Un instructor podría tener dificultades para encontrar "Mis Cursos (comprados)" si la interfaz prioriza "Mis Cursos (creados)".
3.  **Sesión:** Si el cambio se hace en backend, el usuario probablemente necesite cerrar e iniciar sesión para refrescar el token/contexto en el frontend.

---

## SECCIÓN 8: VALIDACIÓN DE ROL

### Puntos Críticos de Validación

1.  **Rutas Protegidas (`src/components/ProtectedAdminRoute.jsx`):**
    *   Utiliza `useRole()` para obtener `currentRole`.
    *   Verifica `hasPermission(PERMISSIONS.VIEW_ADMIN)`.
    *   Si falla, redirige a `/access-denied`.
    *   **Vulnerabilidad:** Si `currentRole` se manipula en LocalStorage, un usuario podría bypasear esta validación en el frontend (aunque fallaría en llamadas a API real si estuvieran implementadas correctamente con RLS).

2.  **Renderizado Condicional (`hasPermission`):**
    *   Utilizado en `Header`, `AdminSidebar`, etc. para ocultar/mostrar elementos visuales.

3.  **Backend (Ausente/Simulado):**
    *   No hay validación real de servidor en este entorno de prototipo frontend.

---

## SECCIÓN 9: CASOS DE USO ACTUALES

1.  **Estudiante → Instructor:** Posible técnicamente (vía Admin), pero sin flujo de solicitud.
2.  **Admin convierte a Instructor:** Es el único flujo soportado actualmente.
3.  **Instructor + Estudiante:** No soportado como roles simultáneos. Un Instructor actúa como Estudiante implícitamente en áreas públicas, pero su etiqueta de rol es única.
4.  **Degradación (Instructor → Estudiante):** Posible vía Admin Panel. El usuario perdería acceso a `/admin` inmediatamente.

---

## SECCIÓN 10: ESTRUCTURA DE DATOS

### LocalStorage
*   `mockUser`: `{ id, name, email, role: 'string', ... }`
*   `user_role`: `'string'` (Persistencia del contexto de rol).

### Supabase (Esquema Recomendado vs Actual)
*   **Actual (Implícito):** Tabla `users` manejada por Auth, metadatos en JSON.
*   **Tablas Relacionadas:** No existen tablas físicas de `instructors` o `applications` en la data mock.

---

## SECCIÓN 11: RECOMENDACIONES DE ARQUITECTURA

Basado en el análisis, se recomienda la siguiente evolución:

1.  **Modelo de Roles:** Mantener **Rol Único Principal** en la base de datos para simplicidad (`role` column en `profiles`), pero permitir permisos granulares.
    *   *Alternativa:* Usar `claims` en el token JWT de Supabase para mayor seguridad.

2.  **Tabla `profiles`:** Crear tabla pública vinculada a `auth.users` que contenga:
    *   `role` (enum: 'admin', 'instructor', 'student')
    *   `is_verified_instructor` (boolean)

3.  **Seguridad (RLS):**
    *   Los Instructores SOLO deben poder editar filas en la tabla `courses` donde `instructor_id === auth.uid()`.
    *   Actualmente, el frontend permite editar cualquier curso en el mock.

4.  **Flujo de Aprobación:**
    *   Crear tabla `instructor_requests` (user_id, status, bio, portfolio).
    *   Crear UI para que estudiantes soliciten ser instructores.
    *   Crear UI para que Admins aprueben/rechacen solicitudes.

---

## SECCIÓN 12: PLAN DE IMPLEMENTACIÓN

### Fase 1: Endurecimiento de Datos (Backend)
1.  Definir tabla `profiles` en Supabase.
2.  Crear Policies RLS para restringir edición de cursos por `owner_id`.

### Fase 2: Interfaz de Solicitud (Frontend)
1.  Crear página `/become-instructor`.
2.  Formulario que guarde en nueva tabla `instructor_requests`.

### Fase 3: Gestión de Solicitudes (Admin)
1.  Nueva ruta `/admin/requests`.
2.  Lógica para aprobar: Actualizar rol en `profiles` y notificar.

### Fase 4: Refactorización de Contextos
1.  Eliminar la dependencia de `localStorage.getItem('user_role')` para seguridad en producción.
2.  Unificar `AuthContext` y `RoleContext` para que la fuente de la verdad sea siempre el token/perfil de base de datos.
