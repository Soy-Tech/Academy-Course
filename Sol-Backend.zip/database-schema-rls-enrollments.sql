
-- ==============================================================================
-- RLS POLICIES FOR ENROLLMENTS
-- ==============================================================================
-- Table: public.enrollments
-- ==============================================================================

-- 1. Create Table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.enrollments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE, -- Often mapped as student_id
    course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Enable RLS
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;

-- 3. Define Policies

-- Policy 1: Users can view their own enrollments
CREATE POLICY "Users can view own enrollments" 
ON public.enrollments 
FOR SELECT 
USING (user_id = auth.uid());

-- Policy 2: Instructors can view enrollments in their courses
CREATE POLICY "Instructors can view course enrollments" 
ON public.enrollments 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.courses
    WHERE courses.id = enrollments.course_id
    AND courses.instructor_id = auth.uid()
  )
);

-- Policy 3: Users can enroll themselves
CREATE POLICY "Users can enroll themselves" 
ON public.enrollments 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

-- Policy 4: Users can unenroll themselves
CREATE POLICY "Users can unenroll themselves" 
ON public.enrollments 
FOR DELETE 
USING (user_id = auth.uid());
