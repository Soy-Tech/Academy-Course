
-- ==============================================================================
-- RLS POLICIES FOR COURSES
-- ==============================================================================
-- Table: public.courses
-- ==============================================================================

-- 1. Create Table (if it doesn't exist, with necessary columns for RLS)
CREATE TABLE IF NOT EXISTS public.courses (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    instructor_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Enable RLS
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;

-- 3. Define Policies

-- Policy 1: Courses are public - everyone can view
CREATE POLICY "Courses are viewable by everyone" 
ON public.courses 
FOR SELECT 
USING (true);

-- Policy 2: Only instructors/admins/super_admin can create courses
CREATE POLICY "Instructors and admins can create courses" 
ON public.courses 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name IN ('instructor', 'admin', 'super_admin')
  )
);

-- Policy 3: Only course owner (instructor_id) can update their course
-- Note: We also allow admins/super_admins for system management
CREATE POLICY "Owners and admins can update courses" 
ON public.courses 
FOR UPDATE 
USING (
  instructor_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name IN ('admin', 'super_admin')
  )
);

-- Policy 4: Only course owner (instructor_id) can delete their course
CREATE POLICY "Owners and admins can delete courses" 
ON public.courses 
FOR DELETE 
USING (
  instructor_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name IN ('admin', 'super_admin')
  )
);
