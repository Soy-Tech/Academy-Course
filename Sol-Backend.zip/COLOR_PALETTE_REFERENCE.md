
# Color Palette Reference

## Primary Colors (Blue)
*Professionalism, Trust, Technology*

| Variable | Hex | Usage | WCAG (on White) |
| :--- | :--- | :--- | :--- |
| `--color-primary-50` | `#E7F0FF` | Backgrounds, Hovers | Fail (Text) |
| `--color-primary-100` | `#C2DAFF` | Focus Rings | Fail |
| `--color-primary-500` | `#0052CC` | **Main Brand**, Buttons, Links | **Pass (AA)** |
| `--color-primary-600` | `#0047B2` | Button Hover | Pass (AAA) |
| `--color-primary-900` | `#002066` | Dark Mode Backgrounds | Pass (AAA) |

## Secondary Colors (Green)
*Growth, Success, Action*

| Variable | Hex | Usage | WCAG (on White) |
| :--- | :--- | :--- | :--- |
| `--color-secondary-100` | `#D1FAE5` | Success Badge Background | Fail |
| `--color-secondary-500` | `#10B981` | **Main Secondary**, Success Icons | Fail (Text*) |
| `--color-secondary-700` | `#047857` | Success Text | Pass (AA) |
*Note: Green-500 should be used for graphical elements or white text on green background, not green text on white background.*

## Status Colors

| Role | Hex | Variable | Usage |
| :--- | :--- | :--- | :--- |
| **Error** | `#EF4444` | `--color-error` | Validation errors, delete buttons |
| **Warning** | `#F59E0B` | `--color-warning` | Pending states, alerts |
| **Info** | `#3B82F6` | `--color-info` | Tooltips, help text |

## Neutral Scale (Grays)

| Hex | Variable | Usage |
| :--- | :--- | :--- |
| `#FFFFFF` | `--color-neutral-0` | Card Backgrounds, Page Backgrounds |
| `#F9FAFB` | `--color-neutral-50` | Section Backgrounds (Subtle) |
| `#E5E7EB` | `--color-neutral-200` | Borders |
| `#9CA3AF` | `--color-neutral-400` | Placeholders, Disabled Text |
| `#6B7280` | `--color-neutral-500` | Secondary Text (Descriptions) |
| `#111827` | `--color-neutral-900` | Primary Headings, Body Text |
