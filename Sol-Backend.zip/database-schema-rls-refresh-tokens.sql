
-- ==============================================================================
-- RLS POLICIES FOR REFRESH TOKENS
-- ==============================================================================
-- Table: public.refresh_tokens
-- Note: This creates a custom token table as requested.
-- ==============================================================================

-- 1. Create Table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.refresh_tokens (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    token TEXT NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Enable RLS
ALTER TABLE public.refresh_tokens ENABLE ROW LEVEL SECURITY;

-- 3. Define Policies

-- Policy 1: Users can view their own refresh tokens
CREATE POLICY "Users can view own refresh tokens" 
ON public.refresh_tokens 
FOR SELECT 
USING (user_id = auth.uid());

-- Policy 2: Users can create their own refresh tokens
CREATE POLICY "Users can create own refresh tokens" 
ON public.refresh_tokens 
FOR INSERT 
WITH CHECK (user_id = auth.uid());

-- Policy 3: Users can delete their own refresh tokens
CREATE POLICY "Users can delete own refresh tokens" 
ON public.refresh_tokens 
FOR DELETE 
USING (user_id = auth.uid());
