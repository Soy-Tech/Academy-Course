
-- ==============================================================================
-- RLS POLICIES FOR PERMISSIONS
-- ==============================================================================
-- Table: public.permissions
-- ==============================================================================

-- 1. Enable RLS
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;

-- 2. Define Policies

-- Policy 1: Permissions are public - everyone can view
CREATE POLICY "Permissions are viewable by everyone" 
ON public.permissions 
FOR SELECT 
USING (true);

-- Policy 2: Only super_admin can create permissions
CREATE POLICY "Super admin can insert permissions" 
ON public.permissions 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);

-- Policy 3: Only super_admin can update permissions
CREATE POLICY "Super admin can update permissions" 
ON public.permissions 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);

-- Policy 4: Only super_admin can delete permissions
CREATE POLICY "Super admin can delete permissions" 
ON public.permissions 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    JOIN public.roles ON profiles.role_id = roles.id
    WHERE profiles.id = auth.uid() 
    AND roles.name = 'super_admin'
  )
);
