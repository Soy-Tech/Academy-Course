
import { ROLES, ROLE_PERMISSIONS } from '@/config/permissions';

/**
 * DEVELOPMENT ONLY - Test User Configuration
 * This file should NOT be used in production environment.
 */

export const IS_DEV = import.meta.env.DEV;

if (!IS_DEV) {
  console.warn('WARNING: Test configuration loaded in non-development environment!');
}

export const TEST_USERS = [
  {
    id: 'test-super-admin',
    email: 'superadmin@test.com',
    role: ROLES.SUPER_ADMIN,
    name: 'Test Super Admin',
    permissions: ROLE_PERMISSIONS[ROLES.SUPER_ADMIN]
  },
  {
    id: 'test-admin',
    email: 'admin@test.com',
    role: ROLES.ADMIN,
    name: 'Test Admin',
    permissions: ROLE_PERMISSIONS[ROLES.ADMIN]
  },
  {
    id: 'test-instructor',
    email: 'instructor@test.com',
    role: ROLES.INSTRUCTOR,
    name: 'Test Instructor',
    permissions: ROLE_PERMISSIONS[ROLES.INSTRUCTOR]
  },
  {
    id: 'test-student',
    email: 'student@test.com',
    role: ROLES.STUDENT,
    name: 'Test Student',
    permissions: ROLE_PERMISSIONS[ROLES.STUDENT]
  }
];

export const getTestUserByRole = (role) => {
  return TEST_USERS.find(u => u.role === role);
};
