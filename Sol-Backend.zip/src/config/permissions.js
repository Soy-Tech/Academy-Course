
/**
 * Centralized Permission Matrix
 * Defines all roles, permissions, and their relationships.
 * Source of truth for RBAC system.
 */

export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  INSTRUCTOR: 'instructor',
  STUDENT: 'student'
};

export const PERMISSIONS = {
  // Public & Student
  VIEW_PUBLIC_COURSES: 'view_public_courses',
  BUY_COURSES: 'buy_courses',
  VIEW_MY_COURSES: 'view_my_courses',
  VIEW_PROGRESS: 'view_progress',
  VIEW_HISTORY: 'view_history',
  DOWNLOAD_CERTIFICATES: 'download_certificates',
  APPLY_INSTRUCTOR: 'apply_instructor',

  // Instructor
  CREATE_COURSE: 'create_course',
  EDIT_OWN_COURSES: 'edit_own_courses',
  DELETE_OWN_COURSES: 'delete_own_courses',
  VIEW_STUDENTS: 'view_students',
  VIEW_STUDENT_PROGRESS: 'view_student_progress',

  // Admin Core
  VIEW_ADMIN_DASHBOARD: 'view_admin_dashboard',
  VIEW_REPORTS: 'view_reports',
  
  // Admin Management Groups (Mapped for Sidebar)
  MANAGE_USERS: 'manage_users', // Maps to viewing/editing users
  MANAGE_COURSES: 'manage_courses', // Maps to editing other courses
  MANAGE_EVENTS: 'manage_events',
  MANAGE_RESOURCES: 'manage_resources',
  MANAGE_SETTINGS: 'manage_settings',

  // Granular Admin Permissions
  VIEW_ALL_USERS: 'view_all_users',
  CREATE_STUDENTS: 'create_students',
  CREATE_INSTRUCTORS: 'create_instructors',
  EDIT_USERS: 'edit_users',
  DELETE_USERS: 'delete_users',
  APPROVE_INSTRUCTORS: 'approve_instructors',
  REJECT_INSTRUCTORS: 'reject_instructors',
  EDIT_OTHER_COURSES: 'edit_other_courses',
  DELETE_OTHER_COURSES: 'delete_other_courses',

  // Super Admin
  CREATE_ADMINS: 'create_admins',
  EDIT_ADMINS: 'edit_admins',
  DELETE_ADMINS: 'delete_admins',
  GLOBAL_SETTINGS: 'global_settings',
  ADVANCED_REPORTS: 'advanced_reports',
  FULL_ACCESS: 'full_access',
  MANAGE_ROLES: 'manage_roles'
};

export const ROLE_PERMISSIONS = {
  [ROLES.STUDENT]: [
    PERMISSIONS.VIEW_PUBLIC_COURSES,
    PERMISSIONS.BUY_COURSES,
    PERMISSIONS.VIEW_MY_COURSES,
    PERMISSIONS.VIEW_PROGRESS,
    PERMISSIONS.VIEW_HISTORY,
    PERMISSIONS.DOWNLOAD_CERTIFICATES,
    PERMISSIONS.APPLY_INSTRUCTOR
  ],
  [ROLES.INSTRUCTOR]: [
    PERMISSIONS.VIEW_PUBLIC_COURSES,
    PERMISSIONS.BUY_COURSES,
    PERMISSIONS.VIEW_MY_COURSES,
    PERMISSIONS.VIEW_PROGRESS,
    PERMISSIONS.VIEW_HISTORY,
    PERMISSIONS.DOWNLOAD_CERTIFICATES,
    PERMISSIONS.CREATE_COURSE,
    PERMISSIONS.EDIT_OWN_COURSES,
    PERMISSIONS.DELETE_OWN_COURSES,
    PERMISSIONS.VIEW_STUDENTS,
    PERMISSIONS.VIEW_STUDENT_PROGRESS
  ],
  [ROLES.ADMIN]: [
    // Base
    PERMISSIONS.VIEW_PUBLIC_COURSES,
    PERMISSIONS.BUY_COURSES,
    PERMISSIONS.VIEW_MY_COURSES,
    PERMISSIONS.VIEW_PROGRESS,
    PERMISSIONS.VIEW_HISTORY,
    PERMISSIONS.DOWNLOAD_CERTIFICATES,
    
    // Dashboard Access
    PERMISSIONS.VIEW_ADMIN_DASHBOARD,
    PERMISSIONS.VIEW_REPORTS,

    // Management Groups (For Sidebar)
    PERMISSIONS.MANAGE_USERS,
    PERMISSIONS.MANAGE_COURSES,
    PERMISSIONS.MANAGE_EVENTS,
    PERMISSIONS.MANAGE_RESOURCES,
    PERMISSIONS.MANAGE_SETTINGS,

    // Granular
    PERMISSIONS.VIEW_ALL_USERS,
    PERMISSIONS.CREATE_STUDENTS,
    PERMISSIONS.CREATE_INSTRUCTORS,
    PERMISSIONS.EDIT_USERS,
    PERMISSIONS.DELETE_USERS,
    PERMISSIONS.APPROVE_INSTRUCTORS,
    PERMISSIONS.REJECT_INSTRUCTORS,
    PERMISSIONS.EDIT_OTHER_COURSES,
    PERMISSIONS.DELETE_OTHER_COURSES
  ],
  [ROLES.SUPER_ADMIN]: [
    ...Object.values(PERMISSIONS)
  ]
};

/**
 * Checks if a role has a specific permission
 * @param {string} role - The user's role
 * @param {string} permission - The permission to check
 * @returns {boolean}
 */
export const hasPermission = (role, permission) => {
  if (!role) return false;
  if (role === ROLES.SUPER_ADMIN) return true;
  
  const permissions = ROLE_PERMISSIONS[role];
  return permissions ? permissions.includes(permission) : false;
};

/**
 * Checks if a role can access a specific route
 * @param {string} role - The user's role
 * @param {string} routePath - The path being accessed
 * @returns {boolean}
 */
export const canAccessRoute = (role, routePath) => {
  if (!role) return false;
  if (role === ROLES.SUPER_ADMIN) return true;
  if (role === ROLES.ADMIN) return true; // Admins generally access all dashboard routes

  if (routePath.startsWith('/admin')) {
    return hasPermission(role, PERMISSIONS.VIEW_ADMIN_DASHBOARD);
  }
  
  if (routePath.startsWith('/instructor')) {
    return role === ROLES.INSTRUCTOR || role === ROLES.ADMIN;
  }

  // Public routes are accessible by default or handled by auth guard
  return true;
};
