
import React, { createContext, useContext, useState, useEffect } from 'react';
import { ROLES, ROLE_PERMISSIONS, hasPermission as checkPermission } from '@/config/permissions';
import { mockSettings } from '@/data/mockSettings';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { logRoleSync, logValidation } from '@/utils/roleLogger';
import { validateRoleIntegrity, getStoredRole } from '@/utils/roleValidation';
import { useTestUser } from '@/hooks/useTestUser';

const RoleContext = createContext();

export const RoleProvider = ({ children }) => {
  const { currentUser, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const { isDev, testMode, testRole } = useTestUser();
  
  // Internal State
  const [currentRole, setCurrentRole] = useState(ROLES.STUDENT);
  const [permissions, setPermissions] = useState(ROLE_PERMISSIONS[ROLES.STUDENT]);
  const [platformSettings, setPlatformSettings] = useState(mockSettings);

  // Synchronization Effect: Auth -> RoleContext
  useEffect(() => {
    // 1. Determine Target Role
    let targetRole = ROLES.STUDENT; // Default fallback

    if (isAuthenticated && currentUser?.role) {
      targetRole = currentUser.role;
    }

    // 2. Dev Mode Override
    if (isDev && testMode && testRole) {
      logRoleSync('Applying Test Role Override', { testRole });
      targetRole = testRole;
    }

    // 3. Sync State if Changed
    if (targetRole !== currentRole) {
      logRoleSync('Updating Context Role', { from: currentRole, to: targetRole });
      
      // Perform integrity check before applying
      const storedRoleData = getStoredRole();
      const integrity = validateRoleIntegrity(targetRole, null, storedRoleData);
      
      if (!integrity.valid && integrity.action === 'UPDATE_STORAGE') {
         logValidation('Role storage mismatch detected during sync, will be auto-corrected by AuthContext', integrity);
      }

      setCurrentRole(targetRole);
      setPermissions(ROLE_PERMISSIONS[targetRole] || []);
    }
  }, [currentUser, isAuthenticated, testMode, testRole, isDev, currentRole]);

  // Load Settings
  useEffect(() => {
    const savedSettings = localStorage.getItem('platform_settings');
    if (savedSettings) {
      try {
        setPlatformSettings(JSON.parse(savedSettings));
      } catch (e) {
        console.error('Error parsing settings', e);
      }
    }
  }, []);

  // Helper Methods
  const hasPermission = (permission) => {
    return checkPermission(currentRole, permission);
  };

  const canAccess = (route) => {
    // Basic route check based on role
    // NOTE: This is for UI hiding only. Real protection is in RoleGuard/ProtectedRoute
    if (currentRole === ROLES.SUPER_ADMIN) return true;
    if (currentRole === ROLES.ADMIN) return true;

    if (route.startsWith('/admin')) {
      return hasPermission('view_admin_dashboard');
    }
    
    return true;
  };

  const updateSettings = (newSettings) => {
    const updated = { ...platformSettings, ...newSettings };
    setPlatformSettings(updated);
    localStorage.setItem('platform_settings', JSON.stringify(updated));
    toast({
      title: "Configuración actualizada",
      description: "Los cambios han sido guardados correctamente."
    });
  };

  const value = {
    currentRole,
    currentUser,
    permissions,
    platformSettings,
    // Note: setRole is removed to enforce Source of Truth logic
    hasPermission,
    canAccess,
    updateSettings
  };

  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>;
};

export const useRole = () => {
  const context = useContext(RoleContext);
  if (context === undefined) {
    throw new Error('useRole must be used within a RoleProvider');
  }
  return context;
};
