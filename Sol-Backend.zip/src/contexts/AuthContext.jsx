
import React, { createContext, useState, useEffect, useContext } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { ROLES } from '@/config/permissions';

export const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);

  // Helper to load detailed user profile with role and permissions
  const fetchUserProfile = async (userId) => {
    try {
      // Join profiles -> roles -> role_permissions -> permissions
      const { data: profile, error } = await supabase
        .from('profiles')
        .select(`
          *,
          roles (
            name,
            role_permissions (
              permissions (
                code
              )
            )
          )
        `)
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user profile:', error);
        return null;
      }

      // Extract permissions into a clean array
      const permissions = profile.roles?.role_permissions?.map(rp => rp.permissions?.code).filter(Boolean) || [];
      const roleName = profile.roles?.name || ROLES.STUDENT; // Default to student if no role assigned

      return {
        ...profile,
        name: profile.full_name || profile.email,
        role: roleName,
        permissions: permissions,
      };
    } catch (err) {
      console.error('Unexpected error fetching profile:', err);
      return null;
    }
  };

  useEffect(() => {
    // 1. Check active session on mount
    const initializeAuth = async () => {
      setLoading(true);
      if (!supabase) {
        console.warn('Supabase client not initialized');
        setLoading(false);
        return;
      }

      const { data: { session: currentSession } } = await supabase.auth.getSession();
      setSession(currentSession);

      if (currentSession?.user) {
        const user = await fetchUserProfile(currentSession.user.id);
        setCurrentUser(user ? { ...user, id: currentSession.user.id, email: currentSession.user.email } : null);
      } else {
        setCurrentUser(null);
      }
      setLoading(false);
    };

    initializeAuth();

    // 2. Listen for auth changes (LOGIN, SIGNUP, LOGOUT)
    if (supabase) {
      const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
        setSession(newSession);
        
        if (newSession?.user) {
          // Only refetch if we don't have the user or it's a different user
          if (!currentUser || currentUser.id !== newSession.user.id) {
            setLoading(true);
            const user = await fetchUserProfile(newSession.user.id);
            setCurrentUser(user ? { ...user, id: newSession.user.id, email: newSession.user.email } : null);
            setLoading(false);
          }
        } else {
          setCurrentUser(null);
          setLoading(false);
        }
      });

      return () => {
        subscription.unsubscribe();
      };
    } else {
      setLoading(false);
    }
  }, []); // Run once on mount

  // Auth Actions
  const login = async (email, password) => {
    if (!supabase) throw new Error('Auth service unavailable');
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
    return data;
  };

  const signup = async (userData) => {
    if (!supabase) throw new Error('Auth service unavailable');

    // Sign up with Supabase Auth
    // The database trigger 'handle_new_user' will automatically create the profile record
    const { data, error } = await supabase.auth.signUp({
      email: userData.email,
      password: userData.password,
      options: {
        data: {
          full_name: userData.name, // This meta_data is used by the trigger
        },
      },
    });

    if (error) throw error;
    return data;
  };

  const logout = async () => {
    if (!supabase) return;
    const { error } = await supabase.auth.signOut();
    if (error) console.error('Error signing out:', error);
    setCurrentUser(null);
    setSession(null);
  };

  const hasPermission = (permission) => {
    if (!currentUser) return false;
    if (currentUser.role === ROLES.SUPER_ADMIN) return true;
    return currentUser.permissions && currentUser.permissions.includes(permission);
  };

  const hasRole = (role) => {
    if (!currentUser) return false;
    return currentUser.role === role;
  };

  const refreshUser = async () => {
    if (currentUser?.id) {
      const updatedUser = await fetchUserProfile(currentUser.id);
      if (updatedUser) {
        setCurrentUser(prev => ({ ...prev, ...updatedUser }));
      }
    }
  };

  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      isAuthenticated: !!currentUser,
      isLoading: loading,
      isSupabaseConfigured: !!supabase,
      isAdmin: currentUser?.role === ROLES.ADMIN || currentUser?.role === ROLES.SUPER_ADMIN,
      isPreviewMode: false,
      login, 
      signup, 
      logout, 
      hasPermission,
      hasRole,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
