
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
// Use the new service
import { 
  submitApplication, 
  getApplicationByUserId, 
  getAllApplications,
  updateApplicationStatus
} from '@/services/instructorApplicationService';
import { 
  sendConfirmationEmail, 
  sendAdminNotificationEmail,
  sendApprovalEmail, 
  sendRejectionEmail 
} from '@/services/emailService';

// Legacy DB imports for compatibility
import { 
  submitInstructorRequest as legacySubmit, 
  getInstructorRequests as legacyGet, 
  approveInstructorRequest as legacyApprove, 
  rejectInstructorRequest as legacyReject,
  createInstructorRequestsTable
} from '@/lib/instructorRequestsDb';

const InstructorRequestContext = createContext(null);

export const useInstructorRequest = () => {
  const context = useContext(InstructorRequestContext);
  if (!context) {
    throw new Error('useInstructorRequest must be used within an InstructorRequestProvider');
  }
  return context;
};

export const InstructorRequestProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const [requests, setRequests] = useState([]);
  const [currentApplication, setCurrentApplication] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    // Initialize legacy DB just in case
    createInstructorRequestsTable();
  }, []);

  // Fetch current user's application on mount/change
  useEffect(() => {
    if (currentUser) {
      fetchUserApplication(currentUser.id);
    }
  }, [currentUser]);

  const fetchUserApplication = async (userId) => {
    try {
      const app = await getApplicationByUserId(userId);
      setCurrentApplication(app);
    } catch (err) {
      console.error("Error fetching application:", err);
    }
  };

  // Modern method
  const submitInstructorApplication = async (formData) => {
    setLoading(true);
    setError(null);
    try {
      const newApp = await submitApplication(formData);
      setCurrentApplication(newApp);
      
      // Emails
      await sendConfirmationEmail(formData.personalData.email, formData.personalData.fullName, newApp.id);
      await sendAdminNotificationEmail('admin@netcom.com', { 
        fullName: formData.personalData.fullName, 
        email: formData.personalData.email,
        specialty: formData.experience.specialty
      });

      toast({
        title: "Solicitud enviada con éxito",
        description: "Revisa tu correo para más detalles.",
        className: "bg-green-600 text-white border-none"
      });
      return newApp;
    } catch (err) {
      setError(err.message);
      toast({
        title: "Error al enviar",
        description: err.message || "Hubo un problema procesando tu solicitud.",
        variant: "destructive"
      });
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Admin methods
  const fetchAllApplications = async () => {
    setLoading(true);
    try {
      const apps = await getAllApplications();
      setRequests(apps);
      return apps;
    } catch (err) {
      console.error(err);
      toast({ variant: "destructive", title: "Error", description: "No se pudieron cargar las solicitudes" });
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (appId, status, notes) => {
    setLoading(true);
    try {
      const updatedApp = await updateApplicationStatus(appId, status, notes);
      
      // Send email based on status
      const userEmail = updatedApp.personalData.email;
      const userName = updatedApp.personalData.fullName;
      
      if (status === 'approved') {
        await sendApprovalEmail(userEmail, userName);
      } else if (status === 'rejected') {
        await sendRejectionEmail(userEmail, userName, notes);
      }

      // Update local state
      setRequests(prev => prev.map(r => r.id === appId ? updatedApp : r));
      return updatedApp;
    } catch (err) {
      console.error(err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Legacy support wrappers
  const submitRequest = async (data) => {
    // Map legacy simple data to new structure if needed, or just use legacy DB
    return legacySubmit(data);
  };

  const fetchRequests = async (filters) => {
    // Merge new system apps with legacy ones for admin view
    const legacy = await legacyGet(filters);
    const modern = await getAllApplications();
    // Normalize modern to legacy shape for table display if needed, or just setRequests with both
    // For now, let's prioritize modern
    setRequests(modern); 
  };
  
  const approveRequest = async (id, adminId, email, name) => updateStatus(id, 'approved', 'Approved by admin');
  const rejectRequest = async (id, adminId, reason, email, name) => updateStatus(id, 'rejected', reason);

  return (
    <InstructorRequestContext.Provider value={{
      requests,
      currentApplication,
      loading,
      error,
      submitInstructorApplication,
      fetchAllApplications,
      updateStatus,
      // Legacy compatibility
      submitRequest,
      fetchRequests,
      approveRequest,
      rejectRequest
    }}>
      {children}
    </InstructorRequestContext.Provider>
  );
};
