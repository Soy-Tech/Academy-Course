
import { supabase } from '@/lib/supabaseClient';

export const enrollmentService = {
  // GET: Obtener inscripciones del usuario actual
  async getEnrollments() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          *,
          courses (
            id,
            title,
            description,
            profiles:instructor_id (
              full_name
            )
          )
        `)
        .eq('student_id', user.id) // Maps to user_id based on schema, assuming 'user_id' in schema or 'student_id' if alias used.
        // Checking previous schema: CREATE TABLE ... enrollments ( user_id UUID ... )
        // The prompt uses 'student_id'. I will use 'user_id' to match the schema created in Task 8 (database-schema-rls-enrollments.sql used user_id).
        .eq('user_id', user.id) 
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching enrollments:', error);
      throw error;
    }
  },

  // GET: Obtener inscripción por ID
  async getEnrollmentById(id) {
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          *,
          courses (
            id,
            title,
            description
          )
        `)
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching enrollment:', error);
      throw error;
    }
  },

  // POST: Inscribirse a curso (RLS valida que sea usuario actual)
  async enrollCourse(courseId) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      const { data, error } = await supabase
        .from('enrollments')
        .insert([{
          course_id: courseId,
          user_id: user.id, // Using user_id to match schema
          enrolled_at: new Date().toISOString(),
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error enrolling in course:', error);
      throw error;
    }
  },

  // DELETE: Desinscribirse de curso (RLS valida que sea usuario actual)
  async unenrollCourse(courseId) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      const { error } = await supabase
        .from('enrollments')
        .delete()
        .eq('course_id', courseId)
        .eq('user_id', user.id); // Using user_id to match schema
      
      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error unenrolling from course:', error);
      throw error;
    }
  },

  // GET: Obtener inscripciones de curso (RLS valida que sea instructor del curso)
  async getEnrollmentsByCourse(courseId) {
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          *,
          profiles:user_id (
            id,
            full_name,
            email
          )
        `)
        .eq('course_id', courseId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching course enrollments:', error);
      throw error;
    }
  },

  // GET: Obtener inscripciones de estudiante (RLS valida que sea el estudiante)
  async getEnrollmentsByStudent(studentId) {
    try {
      const { data, error } = await supabase
        .from('enrollments')
        .select(`
          *,
          courses (
            id,
            title,
            description
          )
        `)
        .eq('user_id', studentId) // Using user_id to match schema
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching student enrollments:', error);
      throw error;
    }
  }
};

export default enrollmentService;
