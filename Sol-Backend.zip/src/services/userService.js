
import { supabase } from '@/lib/supabaseClient';

export const getUserById = async (id) => {
  const { data, error } = await supabase
    .from('profiles')
    .select(`
      *,
      roles (
        id,
        name,
        description
      )
    `)
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
};

export const updateUser = async (id, updates) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const listUsers = async () => {
  const { data, error } = await supabase
    .from('profiles')
    .select(`
      *,
      roles (
        name
      )
    `)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const changeUserRole = async (userId, roleId) => {
  const { data, error } = await supabase
    .from('profiles')
    .update({ role_id: roleId })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getUserPermissions = async (userId) => {
  // Fetch user -> role -> role_permissions -> permissions
  const { data, error } = await supabase
    .from('profiles')
    .select(`
      roles (
        role_permissions (
          permissions (
            code
          )
        )
      )
    `)
    .eq('id', userId)
    .single();

  if (error) throw error;

  // Flatten the structure to return an array of permission codes
  const permissions = data.roles?.role_permissions?.map(rp => rp.permissions.code) || [];
  return permissions;
};
