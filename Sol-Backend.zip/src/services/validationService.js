
export const validateEmail = (email) => {
  const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  if (!email) return { isValid: false, message: 'El correo electrónico es obligatorio.' };
  if (!re.test(email)) return { isValid: false, message: 'Formato de correo electrónico inválido.' };
  return { isValid: true };
};

export const validatePhone = (phone) => {
  const re = /^\+?[\d\s-]{8,}$/;
  if (!phone) return { isValid: false, message: 'El teléfono es obligatorio.' };
  if (!re.test(phone)) return { isValid: false, message: 'Formato de teléfono inválido (mínimo 8 dígitos).' };
  return { isValid: true };
};

export const validateURL = (url) => {
  if (!url) return { isValid: true }; // Optional field usually
  try {
    new URL(url);
    return { isValid: true };
  } catch (_) {
    return { isValid: false, message: 'URL inválida. Asegúrate de incluir http:// o https://' };
  }
};

export const validateFileSize = (file, maxSizeMB) => {
  if (!file) return { isValid: true };
  const sizeInMB = file.size / (1024 * 1024);
  if (sizeInMB > maxSizeMB) {
    return { isValid: false, message: `El archivo excede el tamaño máximo de ${maxSizeMB}MB.` };
  }
  return { isValid: true };
};

export const validateFileType = (file, allowedTypes) => {
  if (!file) return { isValid: true };
  if (!allowedTypes.includes(file.type)) {
    return { isValid: false, message: `Tipo de archivo no permitido. Tipos permitidos: ${allowedTypes.join(', ')}` };
  }
  return { isValid: true };
};

export const validateMinLength = (text, min) => {
  if (!text || text.length < min) {
    return { isValid: false, message: `Debe tener al menos ${min} caracteres.` };
  }
  return { isValid: true };
};

export const validateMaxLength = (text, max) => {
  if (text && text.length > max) {
    return { isValid: false, message: `No puede exceder los ${max} caracteres.` };
  }
  return { isValid: true };
};

export const validateYearsOfExperience = (years) => {
  if (years === undefined || years === null || years === '') return { isValid: false, message: 'Este campo es obligatorio.' };
  const num = parseInt(years, 10);
  if (isNaN(num) || num < 2) {
    return { isValid: false, message: 'Se requieren al menos 2 años de experiencia.' };
  }
  return { isValid: true };
};

export const validateCheckboxes = (checkedItems, requiredKeys) => {
  // checkedItems is an object like { key1: true, key2: false }
  // requiredKeys is an array of keys that MUST be true
  const missing = requiredKeys.filter(key => !checkedItems[key]);
  if (missing.length > 0) {
    return { isValid: false, message: 'Debes aceptar todas las condiciones obligatorias.' };
  }
  return { isValid: true };
};
