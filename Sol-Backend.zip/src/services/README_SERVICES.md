
# Servicios Frontend: Courses y Enrollments

## Descripción General

Servicios frontend que confían exclusivamente en RLS (Row Level Security) de Supabase para autorización.

## Principio Fundamental

**NO hay validación de autorización en frontend.**
**RLS en BD valida autorización en cada query.**

Si usuario intenta operación no permitida:
1. Frontend envía query a BD
2. RLS en BD rechaza con error 403 (o filtra filas silenciosamente en SELECT)
3. Frontend captura error y lo muestra al usuario

## Servicios Disponibles

### courseService.js

Métodos:
- `getCourses()` - Obtener todos los cursos (público)
- `getCourseById(id)` - Obtener curso por ID (público)
- `createCourse(courseData)` - Crear curso (RLS valida instructor)
- `updateCourse(id, courseData)` - Actualizar curso (RLS valida propietario)
- `deleteCourse(id)` - Eliminar curso (RLS valida propietario)
- `getCoursesByInstructor(instructorId)` - Obtener cursos de instructor (público)

Ejemplo de uso:
