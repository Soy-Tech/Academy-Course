
import { supabase } from '@/lib/supabaseClient';

export const listRoles = async () => {
  const { data, error } = await supabase
    .from('roles')
    .select('*')
    .order('name');

  if (error) throw error;
  return data;
};

export const getRoleById = async (id) => {
  const { data, error } = await supabase
    .from('roles')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
};

export const getRolePermissions = async (roleId) => {
  const { data, error } = await supabase
    .from('role_permissions')
    .select(`
      permissions (
        id,
        code,
        description
      )
    `)
    .eq('role_id', roleId);

  if (error) throw error;
  return data.map(item => item.permissions);
};

export const createRole = async (name, description, permissionIds = []) => {
  // 1. Create Role
  const { data: role, error: roleError } = await supabase
    .from('roles')
    .insert({ name, description })
    .select()
    .single();

  if (roleError) throw roleError;

  // 2. Assign Permissions if any
  if (permissionIds.length > 0) {
    const rolePermissions = permissionIds.map(permId => ({
      role_id: role.id,
      permission_id: permId
    }));

    const { error: permError } = await supabase
      .from('role_permissions')
      .insert(rolePermissions);

    if (permError) throw permError;
  }

  return role;
};

export const updateRole = async (id, name, description, permissionIds) => {
  // 1. Update Role Details
  const { data: role, error: roleError } = await supabase
    .from('roles')
    .update({ name, description })
    .eq('id', id)
    .select()
    .single();

  if (roleError) throw roleError;

  // 2. Update Permissions (if provided)
  if (permissionIds) {
    // Delete existing
    const { error: deleteError } = await supabase
      .from('role_permissions')
      .delete()
      .eq('role_id', id);

    if (deleteError) throw deleteError;

    // Insert new
    if (permissionIds.length > 0) {
      const newPermissions = permissionIds.map(permId => ({
        role_id: id,
        permission_id: permId
      }));

      const { error: insertError } = await supabase
        .from('role_permissions')
        .insert(newPermissions);

      if (insertError) throw insertError;
    }
  }

  return role;
};

export const deleteRole = async (id) => {
  const { error } = await supabase
    .from('roles')
    .delete()
    .eq('id', id);

  if (error) throw error;
  return true;
};
