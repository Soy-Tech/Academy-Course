
import { supabase } from '@/lib/supabaseClient';

export const courseService = {
  // GET: Obtener todos los cursos (público)
  async getCourses() {
    try {
      const { data, error } = await supabase
        .from('courses')
        .select('*, users:instructor_id(first_name, last_name, email)') // Changed 'users' to specific join if strictly needed, but typically mapped via FK. Assuming 'users' is the relation name or using FK column.
        // Note: In Supabase/PostgREST, if the FK is instructor_id -> profiles.id, the relation is usually named 'profiles'.
        // However, sticking to the requested structure or standard convention. 
        // If the prompt assumes 'users' view or table mapping, I will follow the prompt's implied structure or standard profiles.
        // Given previous context used 'profiles' table for users, but prompt code used 'users', I will align with 'profiles' which maps to public.users requirement but aliased/joined correctly.
        // Wait, the prompt specifically requested: .select('*, users(first_name, last_name, email)')
        // I will use 'profiles' as the actual table name based on previous tasks, but if the prompt assumes a 'users' view/table, I should probably stick to 'profiles' as that's what we built.
        // Actually, looking at the provided prompt code: .select('*, users(first_name, last_name, email)')
        // I will use 'profiles' since that is the table we created in previous steps.
        .select(`
          *,
          profiles:instructor_id (
            first_name: full_name, 
            email
          )
        `)
        // NOTE: The prompt code used 'users'. I am adapting to 'profiles' based on the schema we actually built (public.profiles).
        // If I must strictly follow the prompt code, I would, but it would fail against the schema I just built.
        // I will use 'profiles' to ensure it actually works with the schema from Task 1.
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching courses:', error);
      throw error;
    }
  },

  // GET: Obtener curso por ID (público)
  async getCourseById(id) {
    try {
      const { data, error } = await supabase
        .from('courses')
        .select(`
          *,
          profiles:instructor_id (
            first_name: full_name,
            email
          )
        `)
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching course:', error);
      throw error;
    }
  },

  // POST: Crear curso (RLS valida que sea instructor)
  async createCourse(courseData) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('User not authenticated');
      
      const { data, error } = await supabase
        .from('courses')
        .insert([{
          title: courseData.title,
          description: courseData.description,
          instructor_id: user.id,
          category: courseData.category || null,
          level: courseData.level || 'beginner',
          price: courseData.price || 0,
          image_url: courseData.image_url || null,
          is_published: courseData.is_published || false,
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error creating course:', error);
      throw error;
    }
  },

  // PUT: Actualizar curso (RLS valida que sea propietario)
  async updateCourse(id, courseData) {
    try {
      const { data, error } = await supabase
        .from('courses')
        .update(courseData)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating course:', error);
      throw error;
    }
  },

  // DELETE: Eliminar curso (RLS valida que sea propietario)
  async deleteCourse(id) {
    try {
      const { error } = await supabase
        .from('courses')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error deleting course:', error);
      throw error;
    }
  },

  // GET: Obtener cursos de instructor (público)
  async getCoursesByInstructor(instructorId) {
    try {
      const { data, error } = await supabase
        .from('courses')
        .select('*')
        .eq('instructor_id', instructorId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching instructor courses:', error);
      throw error;
    }
  }
};

export default courseService;
