
export const videosData = [
  {
    id: 'v1',
    courseId: 'full-stack-2025',
    title: 'Introducción al Full Stack',
    description: 'Conceptos básicos y configuración del entorno de desarrollo.',
    duration: 15,
    videoUrl: 'https://example.com/video1.mp4',
    order: 1,
    isActive: true,
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
    uploadedDate: '2025-10-01T10:00:00Z'
  },
  {
    id: 'v2',
    courseId: 'full-stack-2025',
    title: 'Configurando React con Vite',
    description: 'Aprende a iniciar un proyecto React moderno con Vite.',
    duration: 25,
    videoUrl: 'https://example.com/video2.mp4',
    order: 2,
    isActive: true,
    thumbnail: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400&h=225&fit=crop',
    uploadedDate: '2025-10-02T11:00:00Z'
  },
  {
    id: 'v3',
    courseId: 'full-stack-2025',
    title: 'Componentes y Props',
    description: 'Entendiendo la arquitectura de componentes en React.',
    duration: 30,
    videoUrl: 'https://example.com/video3.mp4',
    order: 3,
    isActive: true,
    thumbnail: 'https://images.unsplash.com/photo-1555099962-4199c345e5dd?w=400&h=225&fit=crop',
    uploadedDate: '2025-10-03T09:00:00Z'
  },
  {
    id: 'v4',
    courseId: 'backend-node',
    title: 'Introducción a Node.js',
    description: '¿Qué es Node.js y por qué usarlo en el backend?',
    duration: 20,
    videoUrl: 'https://example.com/video4.mp4',
    order: 1,
    isActive: true,
    thumbnail: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=225&fit=crop',
    uploadedDate: '2025-10-05T14:00:00Z'
  },
  {
    id: 'v5',
    courseId: 'backend-node',
    title: 'Express Framework',
    description: 'Creando tu primer servidor HTTP con Express.',
    duration: 45,
    videoUrl: 'https://example.com/video5.mp4',
    order: 2,
    isActive: false,
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=225&fit=crop',
    uploadedDate: '2025-10-06T15:00:00Z'
  }
];
