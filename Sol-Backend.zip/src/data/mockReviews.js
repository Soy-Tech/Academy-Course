
export const mockReviews = [
  {
    id: 1,
    userId: 101,
    userName: 'Alice Johnson',
    userAvatar: 'A',
    rating: 5,
    comment: 'This course was absolutely amazing! The instructor explains complex concepts very clearly.',
    date: '2 days ago',
    helpfulCount: 12,
    courseId: '1'
  },
  {
    id: 2,
    userId: 102,
    userName: 'Bob Smith',
    userAvatar: 'B',
    rating: 4,
    comment: 'Great content, but I wish there were more practical exercises in the later modules.',
    date: '1 week ago',
    helpfulCount: 5,
    instructorReply: 'Thanks for the feedback Bob! We are adding 3 new projects next month.',
    courseId: '1'
  },
  {
    id: 3,
    userId: 103,
    userName: 'Charlie Brown',
    userAvatar: 'C',
    rating: 5,
    comment: 'Best investment for my career. I landed a job right after finishing this bootcamp.',
    date: '3 weeks ago',
    helpfulCount: 24,
    courseId: '2'
  },
  {
    id: 4,
    userId: 104,
    userName: 'Diana Prince',
    userAvatar: 'D',
    rating: 3,
    comment: 'Good introduction, but a bit too fast-paced for absolute beginners.',
    date: '1 month ago',
    helpfulCount: 2,
    courseId: '2'
  },
  {
    id: 5,
    userId: 105,
    userName: 'Evan Wright',
    userAvatar: 'E',
    rating: 5,
    comment: 'Sarah is a fantastic teacher. Her examples are real-world relevant.',
    date: '2 months ago',
    helpfulCount: 8,
    courseId: '1'
  }
];
