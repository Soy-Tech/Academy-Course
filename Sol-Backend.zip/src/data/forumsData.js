
export const mockForumUsers = [
  { id: 'u1', name: 'Sofia García', avatar: 'SG', role: 'instructor', joinDate: '2023-01-15', reputation: 1250 },
  { id: 'u2', name: 'Carlos Rodriguez', avatar: 'CR', role: 'admin', joinDate: '2023-02-01', reputation: 3000 },
  { id: 'u3', name: 'Ana Martínez', avatar: 'AM', role: 'student', joinDate: '2023-03-10', reputation: 450 },
  { id: 'u4', name: 'David Lopez', avatar: 'DL', role: 'student', joinDate: '2023-04-05', reputation: 120 },
  { id: 'u5', name: 'Elena Torres', avatar: 'ET', role: 'student', joinDate: '2023-05-20', reputation: 85 },
  { id: 'u6', name: 'Miguel Angel', avatar: 'MA', role: 'student', joinDate: '2023-06-12', reputation: 340 },
  { id: 'u7', name: 'Laura Sanchez', avatar: 'LS', role: 'student', joinDate: '2023-07-01', reputation: 15 },
  { id: 'u8', name: 'Pablo Ruiz', avatar: 'PR', role: 'instructor', joinDate: '2023-02-20', reputation: 980 }
];

export const mockForumCategories = [
  { id: 'cat-react', name: 'React', description: 'Todo sobre React, Hooks y Componentes', color: 'bg-blue-100 text-blue-700', icon: '⚛️' },
  { id: 'cat-js', name: 'JavaScript', description: 'Dudas de ES6+, asincronía y lógica', color: 'bg-yellow-100 text-yellow-700', icon: '📜' },
  { id: 'cat-general', name: 'General', description: 'Discusiones generales sobre tecnología', color: 'bg-gray-100 text-gray-700', icon: '💬' },
  { id: 'cat-help', name: 'Ayuda', description: 'Soporte técnico de la plataforma', color: 'bg-green-100 text-green-700', icon: '🆘' },
  { id: 'cat-announcements', name: 'Anuncios', description: 'Noticias y actualizaciones oficiales', color: 'bg-red-100 text-red-700', icon: '📢' }
];

export const mockForumTopics = [
  {
    id: 't1',
    title: '¿Cómo manejar el estado global sin Redux?',
    content: 'Hola a todos, estoy empezando con React y veo que Redux es muy complejo. ¿Qué alternativas recomiendan para proyectos medianos? He escuchado sobre Context API y Zustand.',
    authorId: 'u3',
    categoryId: 'cat-react',
    createdAt: '2023-10-15T10:30:00Z',
    updatedAt: '2023-10-15T14:20:00Z',
    views: 125,
    isPinned: false,
    isSolved: true,
    tags: ['react', 'state-management', 'context']
  },
  {
    id: 't2',
    title: 'Bienvenidos al nuevo foro de Netcom Academy',
    content: 'Nos complace anunciar el lanzamiento de nuestro nuevo foro. Aquí podrán compartir conocimientos, resolver dudas y conectar con otros estudiantes.',
    authorId: 'u2',
    categoryId: 'cat-announcements',
    createdAt: '2023-09-01T08:00:00Z',
    updatedAt: '2023-09-01T08:00:00Z',
    views: 540,
    isPinned: true,
    isSolved: false,
    tags: ['oficial', 'bienvenida']
  },
  {
    id: 't3',
    title: 'Problema con useEffect y dependencias infinitas',
    content: 'Tengo un useEffect que hace una llamada a la API, pero entra en un bucle infinito. ¿Alguien me puede explicar cómo configurar correctamente el array de dependencias?',
    authorId: 'u4',
    categoryId: 'cat-react',
    createdAt: '2023-10-18T16:45:00Z',
    updatedAt: '2023-10-19T09:15:00Z',
    views: 89,
    isPinned: false,
    isSolved: false,
    tags: ['react', 'hooks', 'useEffect', 'bug']
  },
  {
    id: 't4',
    title: 'Duda sobre Promesas y Async/Await',
    content: 'No entiendo bien la diferencia entre usar .then() y async/await. ¿Cuál es mejor práctica hoy en día?',
    authorId: 'u5',
    categoryId: 'cat-js',
    createdAt: '2023-10-20T11:20:00Z',
    updatedAt: '2023-10-20T13:40:00Z',
    views: 210,
    isPinned: false,
    isSolved: true,
    tags: ['javascript', 'asincronia', 'es6']
  },
  {
    id: 't5',
    title: 'No puedo acceder al curso de Node.js',
    content: 'Acabo de comprar el curso pero me sigue apareciendo bloqueado. Ya cerré sesión y volví a entrar.',
    authorId: 'u6',
    categoryId: 'cat-help',
    createdAt: '2023-10-22T09:00:00Z',
    updatedAt: '2023-10-22T09:30:00Z',
    views: 45,
    isPinned: false,
    isSolved: true,
    tags: ['soporte', 'acceso', 'pagos']
  }
];

export const mockForumReplies = [
  {
    id: 'r1',
    topicId: 't1',
    authorId: 'u1',
    content: 'Para proyectos medianos, Context API es suficiente. Si necesitas algo más potente pero simple, Zustand es una excelente opción. Redux Toolkit también simplifica mucho las cosas hoy en día.',
    createdAt: '2023-10-15T11:00:00Z',
    updatedAt: '2023-10-15T11:00:00Z',
    likes: 15,
    isAccepted: true
  },
  {
    id: 'r2',
    topicId: 't1',
    authorId: 'u4',
    content: 'Yo uso Recoil y me va muy bien, se siente muy "React".',
    createdAt: '2023-10-15T12:30:00Z',
    updatedAt: '2023-10-15T12:30:00Z',
    likes: 3,
    isAccepted: false
  },
  {
    id: 'r3',
    topicId: 't3',
    authorId: 'u8',
    content: 'Probablemente estás actualizando un estado dentro del useEffect que a su vez está en las dependencias. Verifica que no estés incluyendo funciones que se recrean en cada render sin usar useCallback.',
    createdAt: '2023-10-18T17:30:00Z',
    updatedAt: '2023-10-18T17:30:00Z',
    likes: 8,
    isAccepted: false
  },
  {
    id: 'r4',
    topicId: 't4',
    authorId: 'u2',
    content: 'Async/Await es azúcar sintáctico sobre las Promesas. Hace el código más legible, pareciendo síncrono. Es la práctica recomendada actualmente, aunque .then() sigue siendo útil en ciertos casos.',
    createdAt: '2023-10-20T12:15:00Z',
    updatedAt: '2023-10-20T12:15:00Z',
    likes: 22,
    isAccepted: true
  },
  {
    id: 'r5',
    topicId: 't5',
    authorId: 'u2',
    content: 'Hola Miguel, hemos verificado tu cuenta y ya deberías tener acceso. Por favor intenta nuevamente.',
    createdAt: '2023-10-22T09:30:00Z',
    updatedAt: '2023-10-22T09:30:00Z',
    likes: 1,
    isAccepted: true
  }
];
