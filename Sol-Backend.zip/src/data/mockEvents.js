
export const mockEvents = [
  {
    id: 1,
    title: 'Workshop: Introducción a React 19',
    description: 'Aprende las nuevas características de React 19, incluyendo el compilador automático y las mejoras en Server Components. Este taller práctico te guiará paso a paso.',
    date: '2026-02-15T18:00:00',
    location: 'Online (Zoom)',
    speaker: 'María García',
    max_attendees: 50,
    current_attendees: 42,
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    title: 'Webinar: Tendencias en IA para 2026',
    description: 'Descubre las últimas tendencias en inteligencia artificial generativa y cómo impactarán en el desarrollo de software este año.',
    date: '2026-02-20T19:00:00',
    location: 'Online (Youtube Live)',
    speaker: 'Dr. Carlos Martínez',
    max_attendees: 200,
    current_attendees: 156,
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 3,
    title: 'Hackathon: Soluciones Verdes',
    description: 'Participa en nuestro hackathon anual enfocado en crear soluciones tecnológicas para la sostenibilidad y el cambio climático.',
    date: '2026-03-10T09:00:00',
    location: 'Madrid, Espacio Tech',
    speaker: 'Equipo Netcom',
    max_attendees: 100,
    current_attendees: 85,
    image: 'https://images.unsplash.com/photo-1504384308090-c54be3855485?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 4,
    title: 'Masterclass: Ciberseguridad Ofensiva',
    description: 'Técnicas avanzadas de pentesting y cómo proteger tus aplicaciones web de las vulnerabilidades más comunes del OWASP Top 10.',
    date: '2026-03-05T17:00:00',
    location: 'Online',
    speaker: 'Roberto Hacker',
    max_attendees: 40,
    current_attendees: 10,
    image: 'https://images.unsplash.com/photo-1563206767-5b1d972f9fb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  }
];
