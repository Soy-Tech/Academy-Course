
export const mockResources = [
  {
    id: 1,
    title: 'Guía Completa de React Hooks',
    description: 'Un manual detallado con ejemplos de uso para todos los hooks oficiales de React 18+.',
    category: 'Frontend',
    file_type: 'PDF',
    downloads: 1240,
    url: '#',
    created_at: '2025-11-01'
  },
  {
    id: 2,
    title: 'Cheat Sheet de Comandos Git',
    description: 'Referencia rápida para los comandos más utilizados en el control de versiones con Git.',
    category: 'General',
    file_type: 'Imagen',
    downloads: 3500,
    url: '#',
    created_at: '2025-10-20'
  },
  {
    id: 3,
    title: 'Arquitecturas de Microservicios',
    description: 'Whitepaper sobre patrones de diseño para sistemas distribuidos escalables.',
    category: 'Backend',
    file_type: 'PDF',
    downloads: 890,
    url: '#',
    created_at: '2025-12-05'
  },
  {
    id: 4,
    title: 'Introducción a Machine Learning con Python',
    description: 'Notebook de Jupyter con ejercicios básicos de scikit-learn y pandas.',
    category: 'Data',
    file_type: 'ZIP',
    downloads: 2100,
    url: '#',
    created_at: '2026-01-10'
  },
  {
    id: 5,
    title: 'Seguridad en AWS S3',
    description: 'Lista de verificación para asegurar tus buckets de S3 y prevenir fugas de datos.',
    category: 'Cloud',
    file_type: 'PDF',
    downloads: 670,
    url: '#',
    created_at: '2026-01-15'
  }
];
