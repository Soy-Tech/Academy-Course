
export const coursesData = [
  {
    id: 'full-stack-2025',
    title: 'Full Stack Moderno 2025',
    shortDescription: 'Domina React, Node.js y MongoDB.',
    fullDescription: 'Este curso intensivo te guiará a través del ecosistema Full Stack moderno.',
    category: 'Programación',
    level: 'Intermedio',
    instructor: 'Carlos Hernández',
    price: '299€',
    rating: 4.9,
    reviews: 136,
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee',
    featured: true,
    modules: 12,
    duration: '120h'
  },
  {
    id: 'react-pro',
    title: 'React Pro+ Hooks y Next.js',
    shortDescription: 'Patrones avanzados y SSR.',
    fullDescription: 'Eleva tus habilidades de React al siguiente nivel.',
    category: 'Programación',
    level: 'Avanzado',
    instructor: 'Elena Rodríguez',
    price: '249€',
    rating: 4.8,
    reviews: 237,
    image: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159',
    featured: true,
    modules: 10,
    duration: '80h'
  },
  {
    id: 'typescript-total',
    title: 'TypeScript Total',
    shortDescription: 'Tipado estático robusto.',
    fullDescription: 'TypeScript se ha convertido en el estándar de la industria.',
    category: 'Programación',
    level: 'Intermedio',
    instructor: 'Carlos Hernández',
    price: '199€',
    rating: 4.7,
    reviews: 178,
    image: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea',
    featured: false,
    modules: 8,
    duration: '60h'
  },
  {
    id: 'backend-node',
    title: 'Backend Node y Express',
    shortDescription: 'APIs REST escalables.',
    fullDescription: 'Conviértete en un especialista en Backend.',
    category: 'Programación',
    level: 'Avanzado',
    instructor: 'David Kim',
    price: '279€',
    rating: 4.8,
    reviews: 312,
    image: 'https://images.unsplash.com/photo-1627398242454-45a1465c2479',
    featured: false,
    modules: 15,
    duration: '90h'
  },
  {
    id: 'python-automation',
    title: 'Automatización con Python',
    shortDescription: 'Scripts y APIs rápidas.',
    fullDescription: 'Python es el lenguaje líder para automatización.',
    category: 'Programación',
    level: 'Intermedio',
    instructor: 'Roberto Sanchez',
    price: '229€',
    rating: 4.7,
    reviews: 255,
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5',
    featured: true,
    modules: 9,
    duration: '70h'
  },
  {
    id: 'ia-aplicada',
    title: 'Fundamentos de IA Aplicada',
    shortDescription: 'Intro práctica a IA.',
    fullDescription: 'Entra en el mundo de la IA sin necesidad de un doctorado.',
    category: 'IA y Datos',
    level: 'Principiante',
    instructor: 'Sofia Martinez',
    price: '249€',
    rating: 4.8,
    reviews: 95,
    image: 'https://images.unsplash.com/photo-1555255707-c07966088b7b',
    featured: true,
    modules: 8,
    duration: '80h'
  },
  {
    id: 'power-bi',
    title: 'Power BI Profesional',
    shortDescription: 'BI y Dashboards.',
    fullDescription: 'Domina la herramienta líder en Business Intelligence.',
    category: 'Productividad',
    level: 'Intermedio',
    instructor: 'Ana Productivity',
    price: '199€',
    rating: 4.9,
    reviews: 120,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
    featured: true,
    modules: 7,
    duration: '60h'
  },
  {
    id: 'ciber-basic',
    title: 'Introducción a Ciberseguridad',
    shortDescription: 'Protege redes y sistemas.',
    fullDescription: 'Aprende los fundamentos para proteger sistemas informáticos.',
    category: 'Ciberseguridad',
    level: 'Principiante',
    instructor: 'Marco Security',
    price: '189€',
    rating: 4.6,
    reviews: 88,
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b',
    featured: false,
    modules: 6,
    duration: '40h'
  }
];

export const categories = [
  {
    id: 'programacion',
    name: 'Programación',
    icon: 'Code'
  },
  {
    id: 'ia-datos',
    name: 'IA y Datos',
    icon: 'Brain'
  },
  {
    id: 'ciberseguridad',
    name: 'Ciberseguridad',
    icon: 'Shield'
  },
  {
    id: 'productividad',
    name: 'Productividad',
    icon: 'Zap'
  }
];
