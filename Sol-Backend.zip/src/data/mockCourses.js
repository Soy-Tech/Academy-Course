
// Comprehensive mock data for 30+ courses ensuring data consistency
const baseCourses = [
  {
    id: '1',
    title: 'Desarrollo Web Full Stack con React y Node.js',
    description: 'Aprende a construir aplicaciones web modernas desde cero usando el stack MERN.',
    shortDescription: 'Domina el stack MERN y conviértete en desarrollador Full Stack.',
    instructor: 'Sarah Instructor',
    image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee',
    category: 'Programación',
    level: 'Intermedio',
    duration: '42h',
    price: 99.99,
    rating: 4.8,
    reviews: 1240,
    studentCount: 5400,
    modules: [
       { id: 'm1', title: 'Fundamentos de React', lessons: 12 },
       { id: 'm2', title: 'Backend con Node.js', lessons: 15 }
    ]
  },
  {
    id: '2',
    title: 'Introducción a Python para Data Science',
    description: 'Domina los fundamentos de Python, Pandas y NumPy para el análisis de datos.',
    shortDescription: 'Inicia tu carrera en Ciencia de Datos con Python.',
    instructor: 'Jane Smith',
    image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935',
    category: 'Data Science',
    level: 'Principiante',
    duration: '28h',
    price: 79.99,
    rating: 4.9,
    reviews: 890,
    studentCount: 3200,
    modules: []
  },
  {
    id: '3',
    title: 'Master en Ciberseguridad: Hacking Ético',
    description: 'Aprende a proteger sistemas, redes y aplicaciones web de ataques cibernéticos.',
    shortDescription: 'Conviértete en un experto en seguridad informática.',
    instructor: 'David Miller',
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b',
    category: 'Ciberseguridad',
    level: 'Avanzado',
    duration: '55h',
    price: 129.99,
    rating: 4.7,
    reviews: 560,
    studentCount: 1800,
    modules: []
  },
  {
    id: '4',
    title: 'Diseño UX/UI: De la Idea al Prototipo',
    description: 'Domina Figma y los principios de diseño centrado en el usuario.',
    shortDescription: 'Crea interfaces digitales impactantes y funcionales.',
    instructor: 'Jessica Brown',
    image: 'https://images.unsplash.com/photo-1586717791821-3f44a5638d48',
    category: 'Diseño',
    level: 'Principiante',
    duration: '35h',
    price: 69.99,
    rating: 4.8,
    reviews: 420,
    studentCount: 2100,
    modules: []
  },
  {
    id: '5',
    title: 'DevOps: Docker, Kubernetes y Jenkins',
    description: 'Automatiza el despliegue de aplicaciones y gestiona infraestructuras escalables.',
    shortDescription: 'Implementa pipelines de CI/CD como un profesional.',
    instructor: 'David Miller',
    image: 'https://images.unsplash.com/photo-1667372393119-c85c02088947',
    category: 'DevOps',
    level: 'Avanzado',
    duration: '48h',
    price: 119.99,
    rating: 4.6,
    reviews: 310,
    studentCount: 1200,
    modules: []
  }
];

// Generate 25 more courses programmatically to reach 30+
const generateAdditionalCourses = () => {
  const categories = ['Programación', 'Negocios', 'Marketing', 'Data Science', 'Diseño', 'Idiomas'];
  const levels = ['Principiante', 'Intermedio', 'Avanzado'];
  const instructors = ['Sarah Instructor', 'Jane Smith', 'David Miller', 'Jessica Brown', 'Robert Code'];
  const images = [
    'https://images.unsplash.com/photo-1517694712202-14dd9538aa97',
    'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
    'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
    'https://images.unsplash.com/photo-1579389083078-4e7018379f7e',
    'https://images.unsplash.com/photo-1542744173-8e7e53415bb0'
  ];

  const generated = [];
  for (let i = 6; i <= 35; i++) {
    const cat = categories[Math.floor(Math.random() * categories.length)];
    const lvl = levels[Math.floor(Math.random() * levels.length)];
    const img = images[Math.floor(Math.random() * images.length)];
    
    generated.push({
      id: i.toString(),
      title: `Curso Completo de ${cat} ${lvl} - Edición ${2025}`,
      description: `Una guía exhaustiva para dominar ${cat} desde cero hasta un nivel profesional. Incluye proyectos prácticos.`,
      shortDescription: `Aprende ${cat} con este curso práctico de nivel ${lvl}.`,
      instructor: instructors[Math.floor(Math.random() * instructors.length)],
      image: img,
      category: cat,
      level: lvl,
      duration: `${Math.floor(Math.random() * 40) + 10}h`,
      price: parseFloat((Math.random() * 100 + 20).toFixed(2)),
      rating: parseFloat((Math.random() * 2 + 3).toFixed(1)), // 3.0 to 5.0
      reviews: Math.floor(Math.random() * 500),
      studentCount: Math.floor(Math.random() * 5000),
      modules: []
    });
  }
  return generated;
};

export const coursesData = [...baseCourses, ...generateAdditionalCourses()];
