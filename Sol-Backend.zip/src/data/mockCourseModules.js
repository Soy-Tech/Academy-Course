
// Dynamic generator for course modules
export const generateModulesForCourse = (courseId) => {
  const moduleThemes = [
    "Fundamentos y Conceptos Básicos",
    "Herramientas y Configuración",
    "Arquitectura y Estructura",
    "Técnicas Avanzadas",
    "Proyecto Final y Despliegue"
  ];

  return moduleThemes.map((theme, index) => {
    const moduleNum = index + 1;
    // Ensure consistent IDs based on courseId
    const moduleId = `${courseId}-m${moduleNum}`;

    return {
      id: moduleId,
      courseId: courseId,
      title: `Módulo ${moduleNum}: ${theme}`,
      resources: {
        videos: [
          {
            id: `${moduleId}-v1`,
            title: `Introducción al Módulo ${moduleNum}`,
            videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-library/sample/BigBuckBunny.mp4",
            duration: 600
          },
          {
            id: `${moduleId}-v2`,
            title: `Conceptos Clave de ${theme.split(' ')[0]}`,
            videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-library/sample/ElephantsDream.mp4",
            duration: 900
          },
           {
            id: `${moduleId}-v3`,
            title: `Deep Dive: ${theme.split(' ')[0]} en Práctica`,
            videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-library/sample/ForBiggerBlazes.mp4",
            duration: 1200
          }
        ],
        pdfs: [
          {
            id: `${moduleId}-p1`,
            title: `Guía de ${theme}.pdf`,
            url: "/docs/guide.pdf"
          },
          {
            id: `${moduleId}-p2`,
            title: `Cheatsheet Módulo ${moduleNum}.pdf`,
            url: "/docs/cheatsheet.pdf"
          }
        ],
        docs: [
          {
            id: `${moduleId}-d1`,
            title: "Documentación Oficial Relacionada",
            url: "https://example.com/docs"
          }
        ],
        files: [
          {
            id: `${moduleId}-f1`,
            title: `recursos_m${moduleNum}.zip`,
            url: "/downloads/resources.zip"
          }
        ],
        activities: [
          {
            id: `${moduleId}-a1`,
            title: `Ejercicio Práctico: ${theme}`,
            instructions: `Realiza los ejercicios prácticos relacionados con ${theme}. Implementa los conceptos vistos en los videos anteriores y compara tu solución con la guía PDF.`
          }
        ]
      }
    };
  });
};

// Deprecated static array - kept for potential backward compat if absolute necessity, 
// but applications should use generateModulesForCourse
export const mockCourseModules = []; 

// Helper for finding resources across modules
export const getResourceById = (courseId, resourceId) => {
  // Generate modules specifically for the requested course
  const modules = generateModulesForCourse(courseId);
  
  for (const module of modules) {
    const allResources = [
      ...(module.resources.videos || []).map(r => ({ ...r, type: 'video', moduleId: module.id })),
      ...(module.resources.pdfs || []).map(r => ({ ...r, type: 'pdf', moduleId: module.id })),
      ...(module.resources.docs || []).map(r => ({ ...r, type: 'doc', moduleId: module.id })),
      ...(module.resources.files || []).map(r => ({ ...r, type: 'file', moduleId: module.id })),
      ...(module.resources.activities || []).map(r => ({ ...r, type: 'activity', moduleId: module.id }))
    ];
    
    const resource = allResources.find(r => r.id === resourceId);
    if (resource) return resource;
  }
  return null;
};
