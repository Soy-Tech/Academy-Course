
export const mockTestimonials = [
  {
    id: 1,
    name: 'Elena Rodríguez',
    role: 'Frontend Developer',
    company: 'Mercado Libre',
    comment: 'Gracias al curso de React Pro, pude refactorizar la arquitectura frontend de mi empresa. Los conceptos de hooks avanzados y patrones de diseño fueron clave para mi ascenso.',
    rating: 5,
    course: 'React Pro+ Hooks y Next.js',
    image: 'https://ui-avatars.com/api/?name=Elena+Rodriguez&background=0B3D91&color=fff',
    date: '2025-11-15'
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Data Scientist',
    company: 'Spotify',
    comment: 'La ruta de Data Science es increíblemente completa. Pasé de usar Excel a construir modelos predictivos con Python en semanas. Los proyectos prácticos son lo mejor.',
    rating: 5,
    course: 'Data Science con Python',
    image: 'https://ui-avatars.com/api/?name=Michael+Chen&background=CFAE70&color=fff',
    date: '2025-10-22'
  },
  {
    id: 3,
    name: 'Sarah Johnson',
    role: 'Product Manager',
    company: 'Google',
    comment: 'Necesitaba entender mejor la tecnología para comunicarme con mi equipo de ingeniería. El curso de Fundamentos de Programación fue perfecto: claro, directo y muy útil.',
    rating: 4,
    course: 'Fundamentos de Programación',
    image: 'https://ui-avatars.com/api/?name=Sarah+Johnson&background=10B981&color=fff',
    date: '2025-12-05'
  },
  {
    id: 4,
    name: 'David Kim',
    role: 'Backend Engineer',
    company: 'Amazon',
    comment: 'El contenido sobre Microservicios y Node.js está muy actualizado. Aprecio mucho que incluyan temas de seguridad y escalabilidad que rara vez se ven en otros cursos.',
    rating: 5,
    course: 'Arquitectura Backend Escalable',
    image: 'https://ui-avatars.com/api/?name=David+Kim&background=EF4444&color=fff',
    date: '2025-09-18'
  },
  {
    id: 5,
    name: 'Laura Martínez',
    role: 'UX/UI Designer',
    company: 'Globant',
    comment: 'Como diseñadora, aprender a maquetar mis propios diseños con Tailwind CSS me dio una ventaja competitiva enorme. Ahora puedo entregar prototipos funcionales.',
    rating: 5,
    course: 'CSS Moderno & Tailwind',
    image: 'https://ui-avatars.com/api/?name=Laura+Martinez&background=8B5CF6&color=fff',
    date: '2026-01-10'
  },
  {
    id: 6,
    name: 'James Wilson',
    role: 'DevOps Engineer',
    company: 'Netflix',
    comment: 'La guía de Docker y Kubernetes es oro puro. Simplificó conceptos que me habían costado meses entender por mi cuenta. Excelente pedagogía.',
    rating: 5,
    course: 'DevOps & Cloud Computing',
    image: 'https://ui-avatars.com/api/?name=James+Wilson&background=F59E0B&color=fff',
    date: '2025-11-30'
  },
  {
    id: 7,
    name: 'Ana Silva',
    role: 'Full Stack Developer',
    company: 'Freelance',
    comment: 'Empecé desde cero y hoy tengo mi propia cartera de clientes internacionales. Netcom Academy me dio no solo código, sino la confianza para lanzarme como freelancer.',
    rating: 5,
    course: 'Carrera Full Stack',
    image: 'https://ui-avatars.com/api/?name=Ana+Silva&background=EC4899&color=fff',
    date: '2025-12-20'
  },
  {
    id: 8,
    name: 'Robert Taylor',
    role: 'Security Analyst',
    company: 'Accenture',
    comment: 'El enfoque práctico del curso de Ethical Hacking es lo que necesitaba. Laboratorios reales, escenarios controlados y herramientas actuales. Muy recomendado.',
    rating: 4,
    course: 'Ciberseguridad Ofensiva',
    image: 'https://ui-avatars.com/api/?name=Robert+Taylor&background=6366F1&color=fff',
    date: '2025-10-05'
  },
  {
    id: 9,
    name: 'Emily Davis',
    role: 'Digital Marketer',
    company: 'HubSpot',
    comment: 'Entender SQL me permitió dejar de depender del equipo de datos para mis reportes. Ahora puedo hacer mis propias consultas y tomar decisiones más rápidas.',
    rating: 5,
    course: 'SQL para Analistas',
    image: 'https://ui-avatars.com/api/?name=Emily+Davis&background=14B8A6&color=fff',
    date: '2026-01-15'
  },
  {
    id: 10,
    name: 'Carlos Méndez',
    role: 'Mobile Developer',
    company: 'Rappi',
    comment: 'La transición de web a móvil con React Native fue muy suave gracias a este curso. En dos meses ya tenía mi primera app publicada en las tiendas.',
    rating: 5,
    course: 'React Native Masterclass',
    image: 'https://ui-avatars.com/api/?name=Carlos+Mendez&background=3B82F6&color=fff',
    date: '2025-11-01'
  }
];
