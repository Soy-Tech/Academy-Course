
export const mockInstructorApplications = [
  {
    id: 'app_001',
    userId: 'u1',
    status: 'approved',
    submittedAt: '2023-10-15T10:30:00Z',
    personalData: {
      fullName: 'Instructor Demo',
      email: 'instructor@example.com',
      phone: '+1234567890',
      country: 'Mexico',
      bio: 'Experto en desarrollo web con 10 años de experiencia.',
    },
    experience: {
      years: 10,
      specialty: 'Web Development',
      company: 'Tech Solutions',
      position: 'Senior Dev',
      description: 'Liderando equipos de frontend.',
    },
    courseProposal: {
      topic: 'React Avanzado',
      description: 'Curso completo de React.',
      level: 'Advanced',
      targetAudience: 'Developers',
    },
    commitment: {
      weeklyAvailability: '10-20 hours',
      motivation: 'Me encanta enseñar.',
    }
  }
];
