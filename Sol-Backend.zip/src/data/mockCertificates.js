
export const mockCertificates = [
  {
    id: 'cert-001',
    courseId: '2',
    courseName: 'Introducción a Python para Data Science',
    dateObtained: '2023-10-15',
    certificateUrl: '#',
    grade: 98
  },
  {
    id: 'cert-002',
    courseId: '6',
    courseName: 'Marketing Digital 360',
    dateObtained: '2023-08-22',
    certificateUrl: '#',
    grade: 92
  }
];
