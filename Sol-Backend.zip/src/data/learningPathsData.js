
export const learningPathsData = [
  {
    id: 'javascript-mastery',
    title: 'Maestría en JavaScript Moderno',
    shortDescription: 'Domina el lenguaje de la web desde fundamentos hasta conceptos avanzados.',
    description: 'Conviértete en un experto en JavaScript, el lenguaje de programación más popular del mundo. Esta ruta te llevará desde los conceptos básicos de variables y funciones hasta temas avanzados como programación asíncrona, prototipos, y patrones de diseño modernos. Ideal para quienes buscan una base sólida antes de saltar a frameworks.',
    image: 'https://images.unsplash.com/photo-1624388611710-bdf95023d1c2',
    level: 'Intermedio',
    duration: '4 Meses',
    totalHours: 180,
    courses: ['typescript-total', 'backend-node', 'react-pro'],
    learningOutcomes: [
      'Comprender a profundidad el Event Loop y Asincronía',
      'Dominar ES6+ y las últimas características del lenguaje',
      'Patrones de diseño y arquitectura de código limpio',
      'Testing unitario y de integración en JavaScript'
    ],
    targetAudience: [
      'Desarrolladores Frontend Junior',
      'Estudiantes de informática',
      'Programadores de otros lenguajes'
    ],
    whyLearn: [
      { title: 'Alta Demanda', description: 'JS es esencial para el 98% de los sitios web.' },
      { title: 'Versatilidad', description: 'Usa JS en Frontend, Backend, Móvil y Desktop.' },
      { title: 'Ecosistema', description: 'Acceso a npm, el repositorio de paquetes más grande.' }
    ],
    instructor: 'Carlos Hernández'
  },
  {
    id: 'react-specialist',
    title: 'Especialista en React y Ecosistema',
    shortDescription: 'Crea aplicaciones web modernas, rápidas y escalables con React.',
    description: 'Esta ruta está diseñada para transformar desarrolladores JavaScript en especialistas de React. Aprenderás no solo la librería base, sino todo el ecosistema moderno incluyendo Redux, React Query, Testing Library y Next.js. Al finalizar, podrás arquitectar y construir aplicaciones complejas de nivel empresarial.',
    image: 'https://images.unsplash.com/photo-1695480497603-381a2bee1c05',
    level: 'Avanzado',
    duration: '5 Meses',
    totalHours: 220,
    courses: ['full-stack-2025', 'react-pro', 'testing-moderno'],
    learningOutcomes: [
      'Arquitectura de componentes escalables',
      'Gestión de estado global eficiente',
      'Server Side Rendering y Static Generation',
      'Optimización de rendimiento y Core Web Vitals'
    ],
    targetAudience: [
      'Desarrolladores Web',
      'Frontend Engineers',
      'Freelancers'
    ],
    whyLearn: [
      { title: 'Líder de Mercado', description: 'React es la librería UI más usada mundialmente.' },
      { title: 'Salarios Altos', description: 'Los especialistas en React son muy valorados.' },
      { title: 'Comunidad', description: 'Soporte masivo y recursos infinitos.' }
    ],
    instructor: 'Elena Rodríguez'
  },
  {
    id: 'full-stack-pro',
    title: 'Full Stack Developer Pro',
    shortDescription: 'Domina tanto Frontend como Backend para construir productos completos.',
    description: 'La ruta definitiva para convertirte en un desarrollador Full Stack completo. Aprenderás a conectar interfaces de usuario reactivas con backends robustos y bases de datos escalables. Desde el diseño de la API hasta el despliegue en la nube, cubrirás todo el ciclo de vida del desarrollo de software moderno.',
    image: 'https://images.unsplash.com/photo-1695548303345-b5db7453593c',
    level: 'Avanzado',
    duration: '6 Meses',
    totalHours: 300,
    courses: ['full-stack-2025', 'backend-node', 'microservicios', 'ciberseguridad-101'],
    learningOutcomes: [
      'Desarrollo End-to-End de aplicaciones web',
      'Diseño y gestión de bases de datos SQL y NoSQL',
      'Seguridad web y autenticación robusta',
      'Despliegue CI/CD y gestión de infraestructura básica'
    ],
    targetAudience: [
      'Desarrolladores ambiciosos',
      'Emprendedores técnicos',
      'Ingenieros de software'
    ],
    whyLearn: [
      { title: 'Autonomía', description: 'Crea productos completos por ti mismo.' },
      { title: 'Visión Global', description: 'Entiende cómo funcionan todas las piezas juntas.' },
      { title: 'Oportunidades', description: 'Accede a roles de liderazgo técnico y arquitectura.' }
    ],
    instructor: 'David Kim'
  },
  {
    id: 'python-data-science',
    title: 'Ciencia de Datos con Python',
    shortDescription: 'Analiza datos, crea visualizaciones y modelos de ML con Python.',
    description: 'Entra en el mundo de los datos con Python. Esta ruta te enseña a manipular grandes conjuntos de datos, crear visualizaciones impactantes y construir modelos predictivos de Machine Learning. Es el camino perfecto para analistas que quieren potenciar sus habilidades o desarrolladores que buscan entrar en IA.',
    image: 'https://images.unsplash.com/photo-1591206246016-b4355bcd5f93',
    level: 'Intermedio',
    duration: '4 Meses',
    totalHours: 160,
    courses: ['python-automation', 'ia-aplicada', 'analisis-datos', 'machine-learning'],
    learningOutcomes: [
      'Análisis exploratorio de datos (EDA)',
      'Visualización de datos avanzada',
      'Modelado estadístico y predictivo',
      'Automatización de pipelines de datos'
    ],
    targetAudience: [
      'Analistas de Negocio',
      'Matemáticos y Estadísticos',
      'Desarrolladores Python'
    ],
    whyLearn: [
      { title: 'Futuro', description: 'Los datos son el nuevo petróleo de la economía digital.' },
      { title: 'Impacto', description: 'Toma decisiones basadas en evidencia real.' },
      { title: 'Innovación', description: 'Lidera proyectos de IA y transformación digital.' }
    ],
    instructor: 'Sofia Martinez'
  }
];
