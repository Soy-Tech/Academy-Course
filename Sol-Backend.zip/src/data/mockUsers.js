
export const mockUsers = [
  {
    id: 1,
    name: 'Admin User',
    email: 'admin@netcom.academy',
    role: 'admin',
    status: 'active',
    joinDate: '2023-01-15',
    avatar: 'A'
  },
  {
    id: 2,
    name: 'Sarah Instructor',
    email: 'sarah@netcom.academy',
    role: 'instructor',
    status: 'active',
    joinDate: '2023-02-10',
    avatar: 'S'
  },
  {
    id: 3,
    name: 'Mike Student',
    email: 'mike@student.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-03-05',
    avatar: 'M'
  },
  {
    id: 4,
    name: 'John Doe',
    email: 'john.doe@example.com',
    role: 'student',
    status: 'inactive',
    joinDate: '2023-03-12',
    avatar: 'J'
  },
  {
    id: 5,
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    role: 'instructor',
    status: 'active',
    joinDate: '2023-01-20',
    avatar: 'J'
  },
  {
    id: 6,
    name: 'Robert Johnson',
    email: 'robert.j@example.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-04-01',
    avatar: 'R'
  },
  {
    id: 7,
    name: 'Emily Davis',
    email: 'emily.d@example.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-04-15',
    avatar: 'E'
  },
  {
    id: 8,
    name: 'Michael Wilson',
    email: 'michael.w@example.com',
    role: 'student',
    status: 'inactive',
    joinDate: '2023-05-02',
    avatar: 'M'
  },
  {
    id: 9,
    name: 'Jessica Brown',
    email: 'jessica.b@example.com',
    role: 'instructor',
    status: 'active',
    joinDate: '2023-02-28',
    avatar: 'J'
  },
  {
    id: 10,
    name: 'David Miller',
    email: 'david.m@example.com',
    role: 'admin',
    status: 'active',
    joinDate: '2023-01-10',
    avatar: 'D'
  },
  {
    id: 11,
    name: 'Richard Taylor',
    email: 'richard.t@example.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-06-10',
    avatar: 'R'
  },
  {
    id: 12,
    name: 'Joseph Anderson',
    email: 'joseph.a@example.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-06-12',
    avatar: 'J'
  },
  {
    id: 13,
    name: 'Thomas Thomas',
    email: 'thomas.t@example.com',
    role: 'student',
    status: 'inactive',
    joinDate: '2023-06-15',
    avatar: 'T'
  },
  {
    id: 14,
    name: 'Charles Jackson',
    email: 'charles.j@example.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-06-20',
    avatar: 'C'
  },
  {
    id: 15,
    name: 'Christopher White',
    email: 'christopher.w@example.com',
    role: 'student',
    status: 'active',
    joinDate: '2023-06-25',
    avatar: 'C'
  }
];
