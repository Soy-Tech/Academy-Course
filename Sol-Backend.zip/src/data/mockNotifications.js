
export const mockNotifications = [
  {
    id: 1,
    type: 'course',
    title: 'New Module Released',
    description: 'Advanced React Patterns module is now available in "Full Stack Development".',
    icon: 'BookOpen',
    date: '2 hours ago',
    isRead: false,
    isArchived: false
  },
  {
    id: 2,
    type: 'achievement',
    title: 'Certificate Earned',
    description: 'Congratulations! You have completed "Introduction to Python".',
    icon: 'Award',
    date: '1 day ago',
    isRead: false,
    isArchived: false
  },
  {
    id: 3,
    type: 'message',
    title: 'New Reply',
    description: 'Sarah Instructor replied to your question in the Q&A forum.',
    icon: 'MessageSquare',
    date: '2 days ago',
    isRead: true,
    isArchived: false
  },
  {
    id: 4,
    type: 'event',
    title: 'Live Webinar Reminder',
    description: 'The "Future of AI" webinar starts in 30 minutes.',
    icon: 'Calendar',
    date: '3 days ago',
    isRead: true,
    isArchived: true
  }
];
