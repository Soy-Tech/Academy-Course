
import { ROLE_PERMISSIONS } from '@/utils/rolePermissions';

// Re-exporting for consistency with the requested file structure
export { ROLE_PERMISSIONS };
