
import { ROLES, ROLE_PERMISSIONS } from '@/utils/rolePermissions';

export const testUsers = [
  {
    id: 'test-student-001',
    email: 'student@test.com',
    password: 'Test123!@',
    name: 'Test Student',
    role: ROLES.STUDENT,
    userType: 'public',
    status: 'active',
    profileImage: null,
    bio: 'I am a test student account for development purposes.',
    permissions: ROLE_PERMISSIONS[ROLES.STUDENT],
    isEmailVerified: true,
    createdAt: new Date('2024-01-01').toISOString(),
    isTestUser: true,
    avatar: 'TS'
  },
  {
    id: 'test-instructor-001',
    email: 'instructor@test.com',
    password: 'Test123!@',
    name: 'Test Instructor',
    role: ROLES.INSTRUCTOR,
    userType: 'invited',
    status: 'active',
    profileImage: null,
    bio: 'I am a test instructor account with course creation capabilities.',
    permissions: ROLE_PERMISSIONS[ROLES.INSTRUCTOR],
    isEmailVerified: true,
    createdAt: new Date('2024-01-01').toISOString(),
    isTestUser: true,
    avatar: 'TI'
  },
  {
    id: 'test-admin-001',
    email: 'admin@test.com',
    password: 'Test123!@',
    name: 'Test Admin',
    role: ROLES.ADMIN,
    userType: 'internal',
    status: 'active',
    profileImage: null,
    bio: 'I am a test admin account for managing users and content.',
    permissions: ROLE_PERMISSIONS[ROLES.ADMIN],
    isEmailVerified: true,
    createdAt: new Date('2024-01-01').toISOString(),
    isTestUser: true,
    avatar: 'TA'
  },
  {
    id: 'test-superadmin-001',
    email: 'superadmin@test.com',
    password: 'Test123!@',
    name: 'Test Super Admin',
    role: ROLES.SUPER_ADMIN, // Changed from ROLES.STUDENT to ROLES.SUPER_ADMIN
    userType: 'internal',
    status: 'active',
    profileImage: null,
    bio: 'I am a test super admin with full system access.',
    permissions: ROLE_PERMISSIONS[ROLES.SUPER_ADMIN],
    isEmailVerified: true,
    createdAt: new Date('2024-01-01').toISOString(),
    isTestUser: true,
    avatar: 'SA'
  }
];
