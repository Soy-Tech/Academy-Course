
import { Code, Database, Shield, Palette, Briefcase, TrendingUp, Smartphone, Globe, Cpu, Layers } from 'lucide-react';

export const mockCategories = [
  {
    id: 'programming',
    name: 'Programming',
    icon: Code,
    description: 'Learn to code with Python, Java, JavaScript, and more.',
    color: 'bg-blue-100 text-blue-600'
  },
  {
    id: 'datascience',
    name: 'Data Science',
    icon: Database,
    description: 'Master data analysis, machine learning, and AI.',
    color: 'bg-purple-100 text-purple-600'
  },
  {
    id: 'security',
    name: 'Cybersecurity',
    icon: Shield,
    description: 'Protect systems and networks from digital attacks.',
    color: 'bg-red-100 text-red-600'
  },
  {
    id: 'design',
    name: 'Design',
    icon: Palette,
    description: 'UI/UX design, graphic design, and 3D modeling.',
    color: 'bg-pink-100 text-pink-600'
  },
  {
    id: 'business',
    name: 'Business',
    icon: Briefcase,
    description: 'Leadership, management, and entrepreneurship skills.',
    color: 'bg-amber-100 text-amber-600'
  },
  {
    id: 'marketing',
    name: 'Marketing',
    icon: TrendingUp,
    description: 'Digital marketing, SEO, and social media strategies.',
    color: 'bg-green-100 text-green-600'
  },
  {
    id: 'mobile',
    name: 'Mobile Dev',
    icon: Smartphone,
    description: 'Build apps for iOS and Android.',
    color: 'bg-indigo-100 text-indigo-600'
  },
  {
    id: 'web',
    name: 'Web Dev',
    icon: Globe,
    description: 'Frontend and Backend web development technologies.',
    color: 'bg-cyan-100 text-cyan-600'
  },
  {
    id: 'ai',
    name: 'Artificial Intelligence',
    icon: Cpu,
    description: 'Deep learning, neural networks, and robotics.',
    color: 'bg-teal-100 text-teal-600'
  },
  {
    id: 'devops',
    name: 'DevOps',
    icon: Layers,
    description: 'Cloud computing, CI/CD, and infrastructure automation.',
    color: 'bg-orange-100 text-orange-600'
  }
];
