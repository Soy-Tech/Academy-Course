
export const mockFAQs = [
  {
    id: 1,
    category: 'Cursos',
    question: '¿Los cursos tienen certificado?',
    answer: 'Sí, al completar cualquier curso o ruta de aprendizaje recibirás un certificado digital verificado que puedes añadir a tu LinkedIn.'
  },
  {
    id: 2,
    category: 'Cursos',
    question: '¿Tengo acceso de por vida al contenido?',
    answer: 'Sí, una vez compras un curso, tienes acceso ilimitado de por vida, incluyendo futuras actualizaciones del contenido.'
  },
  {
    id: 3,
    category: 'Pagos',
    question: '¿Qué métodos de pago aceptan?',
    answer: 'Aceptamos tarjetas de crédito/débito (Visa, Mastercard, Amex), PayPal y en algunos países transferencia bancaria local.'
  },
  {
    id: 4,
    category: 'Soporte',
    question: '¿Cómo puedo contactar con el instructor?',
    answer: 'Cada curso tiene una sección de preguntas y respuestas donde puedes interactuar directamente con el instructor y otros estudiantes.'
  },
  {
    id: 5,
    category: 'General',
    question: '¿Puedo pedir un reembolso?',
    answer: 'Ofrecemos una garantía de devolución de 30 días. Si el curso no cumple tus expectativas, te devolvemos el dinero sin preguntas.'
  }
];
