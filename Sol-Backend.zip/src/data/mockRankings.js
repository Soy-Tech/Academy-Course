
export const mockRankings = [
  {
    id: 1,
    points: 1250,
    contributions_count: 45,
    users: {
      name: 'Sofía Rodríguez',
      specialty: 'Full Stack Developer',
      profile_photo_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      achievements: ['Top Contributor', 'Bug Hunter', 'Mentor']
    }
  },
  {
    id: 2,
    points: 980,
    contributions_count: 32,
    users: {
      name: 'Miguel Ángel Torres',
      specialty: 'DevOps Engineer',
      profile_photo_url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      achievements: ['Fast Learner']
    }
  },
  {
    id: 3,
    points: 850,
    contributions_count: 28,
    users: {
      name: 'Elena Pastor',
      specialty: 'UX Designer',
      profile_photo_url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      achievements: ['Design Guru']
    }
  },
  {
    id: 4,
    points: 720,
    contributions_count: 20,
    users: {
      name: 'Lucas Mendez',
      specialty: 'Python Developer',
      profile_photo_url: null,
      achievements: []
    }
  },
  {
    id: 5,
    points: 690,
    contributions_count: 15,
    users: {
      name: 'Carmen Vega',
      specialty: 'Data Analyst',
      profile_photo_url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      achievements: ['Data Whiz']
    }
  }
];
