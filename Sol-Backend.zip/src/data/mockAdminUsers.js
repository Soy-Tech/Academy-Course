
export const mockAdminUsers = [
  {
    id: 1,
    nombre: 'Admin User',
    email: 'admin@example.com',
    rol: 'admin',
    estado: 'active',
    fechaRegistro: '2023-01-15',
    cursosAsignados: []
  },
  {
    id: 2,
    nombre: 'Carlos Hernández',
    email: 'carlos.hernandez@netcom.com',
    rol: 'instructor',
    estado: 'active',
    fechaRegistro: '2023-02-20',
    cursosAsignados: ['Full Stack Moderno 2025']
  },
  {
    id: 3,
    nombre: 'María Gómez',
    email: 'maria.gomez@gmail.com',
    rol: 'student',
    estado: 'active',
    fechaRegistro: '2023-03-10',
    cursosAsignados: ['Full Stack Moderno 2025', 'UX/UI Design Masterclass']
  },
  {
    id: 4,
    nombre: 'Juan Pérez',
    email: 'juan.perez@outlook.com',
    rol: 'student',
    estado: 'inactive',
    fechaRegistro: '2023-04-05',
    cursosAsignados: []
  },
  {
    id: 5,
    nombre: 'Elena Rodríguez',
    email: 'elena.rodriguez@netcom.com',
    rol: 'instructor',
    estado: 'active',
    fechaRegistro: '2023-02-25',
    cursosAsignados: ['React Pro+ Hooks y Next.js']
  },
  {
    id: 6,
    nombre: 'Laura Martínez',
    email: 'laura.martinez@netcom.com',
    rol: 'instructor',
    estado: 'active',
    fechaRegistro: '2023-05-15',
    cursosAsignados: ['UX/UI Design Masterclass']
  },
  {
    id: 7,
    nombre: 'David Kim',
    email: 'david.kim@netcom.com',
    rol: 'instructor',
    estado: 'inactive',
    fechaRegistro: '2023-06-01',
    cursosAsignados: ['Arquitectura de Microservicios']
  },
  {
    id: 8,
    nombre: 'Ana López',
    email: 'ana.lopez@yahoo.com',
    rol: 'student',
    estado: 'active',
    fechaRegistro: '2023-07-20',
    cursosAsignados: ['React Pro+ Hooks y Next.js']
  },
  {
    id: 9,
    nombre: 'Roberto Sanchez',
    email: 'roberto.s@gmail.com',
    rol: 'student',
    estado: 'active',
    fechaRegistro: '2023-08-15',
    cursosAsignados: ['Introducción a Python']
  },
  {
    id: 10,
    nombre: 'Lucia Fernandez',
    email: 'lucia.fer@outlook.com',
    rol: 'student',
    estado: 'inactive',
    fechaRegistro: '2023-09-01',
    cursosAsignados: []
  }
];
