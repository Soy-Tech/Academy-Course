
export const mockForumCategories = [
  {
    id: 'general',
    title: 'Discusión General',
    description: 'Charlas sobre tecnología, carrera y noticias del sector.',
    topicCount: 156,
    latestActivity: 'Hace 2 horas'
  },
  {
    id: 'development',
    title: 'Desarrollo Web & Mobile',
    description: 'Frontend, Backend, React, Node.js y más.',
    topicCount: 342,
    latestActivity: 'Hace 5 minutos'
  },
  {
    id: 'data-science',
    title: 'Data Science & IA',
    description: 'Python, Machine Learning, SQL y Big Data.',
    topicCount: 215,
    latestActivity: 'Hace 1 hora'
  },
  {
    id: 'cybersecurity',
    title: 'Ciberseguridad',
    description: 'Ethical Hacking, redes y seguridad defensiva.',
    topicCount: 98,
    latestActivity: 'Hace 1 día'
  }
];

export const mockForumTopics = [
  {
    id: 't1',
    categoryId: 'development',
    title: '¿Mejor forma de manejar estado en React 2025?',
    author: 'JuanDev',
    date: '2025-01-28',
    views: 1240,
    content: 'Hola a todos, estoy empezando un proyecto grande y dudo entre Redux Toolkit, Zustand o simplemente Context API. ¿Qué recomiendan para escalar?',
    replies: [
      { id: 'r1', author: 'AnaCode', date: '2025-01-28', content: 'Zustand es muy ligero y fácil de usar. Lo recomiendo para la mayoría de casos.' },
      { id: 'r2', author: 'PedroJS', date: '2025-01-29', content: 'Si el equipo es grande, Redux Toolkit sigue siendo el estándar por su estructura.' }
    ]
  },
  {
    id: 't2',
    categoryId: 'general',
    title: 'Consejos para primera entrevista técnica',
    author: 'NewbieTech',
    date: '2025-01-30',
    views: 560,
    content: 'Tengo mi primera entrevista para Junior Dev la próxima semana. ¿Algún consejo sobre qué repasar?',
    replies: [
      { id: 'r3', author: 'SeniorDev', date: '2025-01-30', content: 'Repasa fundamentos de JS, estructuras de datos y ten listos proyectos para mostrar.' }
    ]
  },
  {
    id: 't3',
    categoryId: 'data-science',
    title: 'Pandas vs Polars para datasets grandes',
    author: 'DataWiz',
    date: '2025-01-25',
    views: 890,
    content: 'He escuchado que Polars es mucho más rápido. ¿Vale la pena migrar mis scripts de Pandas?',
    replies: []
  }
];
