
export const mockInstructors = [
  {
    id: 1,
    name: 'Sarah Instructor',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
    bio: 'Senior Software Engineer with 10+ years of experience in Full Stack Development. Passionate about teaching modern web technologies.',
    fullBio: 'I started my journey as a self-taught developer and have since worked with top tech companies in Silicon Valley. My expertise lies in React, Node.js, and Cloud Architecture. I believe in learning by doing, which is why all my courses are project-based. When I am not coding, I enjoy hiking and photography.',
    specialty: 'Web Development',
    rating: 4.8,
    studentCount: 15420,
    courseIds: ['1', '6'],
    socialLinks: {
      linkedin: '#',
      twitter: '#',
      github: '#'
    },
    experience: [
      'Senior Engineer at TechCorp (2018-Present)',
      'Frontend Lead at WebSolutions (2015-2018)',
      'Freelance Developer (2012-2015)'
    ],
    certifications: [
      'AWS Certified Solutions Architect',
      'Google Cloud Professional Developer'
    ]
  },
  {
    id: 2,
    name: 'Jane Smith',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80',
    bio: 'Data Scientist and AI enthusiast. Helping students master Python and Machine Learning.',
    specialty: 'Data Science',
    rating: 4.9,
    studentCount: 8900,
    courseIds: ['2', '9', '10'],
    socialLinks: {
      linkedin: '#',
      github: '#'
    },
    experience: [
      'Lead Data Scientist at DataFlow',
      'Research Assistant at MIT'
    ],
    certifications: [
      'TensorFlow Developer Certificate',
      'IBM Data Science Professional'
    ]
  },
  {
    id: 3,
    name: 'Jessica Brown',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2',
    bio: 'UX/UI Designer with a passion for creating beautiful and functional interfaces.',
    specialty: 'Design',
    rating: 4.7,
    studentCount: 5600,
    courseIds: ['3', '7'],
    socialLinks: {
      twitter: '#',
      dribbble: '#'
    },
    experience: [
      'Product Designer at CreativeAgency',
      'UI Designer at AppStudio'
    ],
    certifications: [
      'Google UX Design Professional Certificate'
    ]
  },
  {
    id: 4,
    name: 'David Miller',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e',
    bio: 'Cloud Architect and DevOps Engineer. Specialist in AWS, Docker, and Kubernetes.',
    specialty: 'DevOps & Cloud',
    rating: 4.6,
    studentCount: 12000,
    courseIds: ['4', '5', '8'],
    socialLinks: {
      linkedin: '#',
      github: '#'
    },
    experience: [
      'Principal Cloud Architect at CloudSystems',
      'DevOps Engineer at InfraTech'
    ],
    certifications: [
      'AWS Certified DevOps Engineer',
      'CKA: Certified Kubernetes Administrator'
    ]
  }
];
