
# Backend Integration Guide

## Overview
This frontend is built with React 18, utilizing functional components, hooks, and Context API. It currently relies on mock data located in `src/data/`. To integrate a real backend (e.g., Supabase, Node.js/Express, Django), follow this guide.

## Authentication
**Current State**: `src/contexts/AuthContext.jsx` uses `localStorage` to simulate session persistence.
**Integration**:
1. Replace `login`, `register`, `logout` functions in `AuthContext` to call your API.
2. Store the returned JWT/Session Token in `localStorage` or `HttpOnly` cookies.
3. Add the token to the `Authorization` header in all protected API requests.

