
import React from 'react';
import { Check, X, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const InstructorFormField = ({
  label,
  value,
  onChange,
  error,
  isValid,
  type = 'text',
  placeholder,
  required,
  maxLength,
  minLength,
  helperText,
  name,
  rows = 4
}) => {
  const showValidation = value && value.length > 0;
  
  return (
    <div className="w-full">
      <div className="flex justify-between mb-1.5">
        <label className="block text-sm font-semibold text-gray-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
        {maxLength && (
          <span className={cn("text-xs", 
            value?.length > maxLength ? "text-red-500 font-bold" : "text-gray-400"
          )}>
            {value?.length || 0} / {maxLength}
          </span>
        )}
      </div>
      
      <div className="relative">
        {type === 'textarea' ? (
          <textarea
            name={name}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            rows={rows}
            maxLength={maxLength}
            className={cn(
              "w-full px-4 py-3 rounded-lg border bg-gray-50/50 focus:bg-white transition-all outline-none focus:ring-2",
              error 
                ? "border-red-300 focus:border-red-500 focus:ring-red-100" 
                : (isValid && showValidation)
                  ? "border-green-300 focus:border-green-500 focus:ring-green-100"
                  : "border-gray-200 focus:border-[#0B3D91] focus:ring-[#0B3D91]/10"
            )}
          />
        ) : (
          <input
            type={type}
            name={name}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            maxLength={maxLength}
            className={cn(
              "w-full px-4 py-3 rounded-lg border bg-gray-50/50 focus:bg-white transition-all outline-none focus:ring-2",
              error 
                ? "border-red-300 focus:border-red-500 focus:ring-red-100" 
                : (isValid && showValidation)
                  ? "border-green-300 focus:border-green-500 focus:ring-green-100"
                  : "border-gray-200 focus:border-[#0B3D91] focus:ring-[#0B3D91]/10"
            )}
          />
        )}

        {/* Icons */}
        <div className="absolute right-3 top-3.5 pointer-events-none">
          {error ? (
            <X className="text-red-500" size={18} />
          ) : (isValid && showValidation) ? (
            <Check className="text-green-500" size={18} />
          ) : null}
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-1 mt-1.5 text-xs text-red-600 font-medium animate-in slide-in-from-top-1">
          <AlertCircle size={12} />
          <span>{error}</span>
        </div>
      )}
      
      {!error && helperText && (
        <p className="mt-1.5 text-xs text-gray-500">{helperText}</p>
      )}
    </div>
  );
};

export default InstructorFormField;
