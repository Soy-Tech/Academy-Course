
import React from 'react';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const FormButton = ({
  children,
  loading = false,
  variant = 'primary',
  className,
  disabled,
  ...props
}) => {
  const variants = {
    primary: "bg-[#0B3D91] hover:bg-[#082d6b] text-white shadow-lg shadow-[#0B3D91]/20",
    secondary: "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50",
    outline: "bg-transparent border-2 border-[#0B3D91] text-[#0B3D91] hover:bg-[#0B3D91]/5",
    ghost: "bg-transparent hover:bg-gray-100 text-gray-600"
  };

  return (
    <Button
      className={cn(
        "relative w-full py-6 font-semibold transition-all duration-200",
        variants[variant],
        loading && "cursor-wait opacity-90",
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="flex items-center justify-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Procesando...</span>
        </span>
      ) : (
        children
      )}
    </Button>
  );
};

export default FormButton;
