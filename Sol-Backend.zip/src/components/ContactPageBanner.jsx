
import React from 'react';
import PageBanner from '@/components/PageBanner';

const ContactPageBanner = () => {
  const scrollToForm = () => {
    const form = document.getElementById('contact-form');
    if(form) form.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <PageBanner 
      title="¿Necesitas ayuda?"
      subtitle="Estamos aquí para responder tus preguntas y ayudarte a elegir el mejor camino para tu aprendizaje."
      badges={['Soporte 24/7', 'Asesoría Académica', 'Ventas Corporativas']}
      cta={{ 
        label: "Enviar mensaje", 
        onClick: scrollToForm 
      }}
      backgroundImage="https://images.unsplash.com/photo-1596524430615-b46475ddff6e"
    />
  );
};

export default ContactPageBanner;
