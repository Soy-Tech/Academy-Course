
import React, { useState, useEffect } from 'react';
import { Save, X, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const EventForm = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    nombre: '',
    descripcion: '',
    fecha: '',
    hora: '',
    ubicacion: '',
    instructor: '',
    estado: 'scheduled'
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
         nombre: '',
         descripcion: '',
         fecha: '',
         hora: '',
         ubicacion: '',
         instructor: '',
         estado: 'scheduled'
      });
    }
    setErrors({});
  }, [initialData]);

  const validate = () => {
    const newErrors = {};
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (!formData.nombre.trim()) newErrors.nombre = 'El nombre del evento es obligatorio.';
    if (!formData.fecha) {
      newErrors.fecha = 'La fecha es obligatoria.';
    } else {
      const eventDate = new Date(formData.fecha);
      if (eventDate < today && !initialData) { // Only check future dates for new events
        newErrors.fecha = 'La fecha no puede ser en el pasado.';
      }
    }
    if (!formData.hora) newErrors.hora = 'La hora es obligatoria.';
    if (!formData.ubicacion.trim()) newErrors.ubicacion = 'La ubicación es obligatoria.';
    if (!formData.instructor.trim()) newErrors.instructor = 'El instructor es obligatorio.';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSave(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Nombre del Evento *</label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.nombre ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.nombre && <p className="mt-1 text-xs text-red-500">{errors.nombre}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Fecha *</label>
          <input
            type="date"
            name="fecha"
            value={formData.fecha}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.fecha ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.fecha && <p className="mt-1 text-xs text-red-500">{errors.fecha}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Hora *</label>
          <input
            type="time"
            name="hora"
            value={formData.hora}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.hora ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.hora && <p className="mt-1 text-xs text-red-500">{errors.hora}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Ubicación / Link *</label>
          <input
            type="text"
            name="ubicacion"
            value={formData.ubicacion}
            onChange={handleChange}
            placeholder="Ej: Online (Zoom)"
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.ubicacion ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.ubicacion && <p className="mt-1 text-xs text-red-500">{errors.ubicacion}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Instructor *</label>
          <input
            type="text"
            name="instructor"
            value={formData.instructor}
            onChange={handleChange}
            className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 text-sm ${errors.instructor ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-500'}`}
          />
          {errors.instructor && <p className="mt-1 text-xs text-red-500">{errors.instructor}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Estado</label>
          <select
            name="estado"
            value={formData.estado}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm bg-white"
          >
            <option value="scheduled">Programado</option>
            <option value="ongoing">En curso</option>
            <option value="completed">Completado</option>
            <option value="cancelled">Cancelado</option>
          </select>
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
          <textarea
            name="descripcion"
            value={formData.descripcion}
            onChange={handleChange}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-gray-100 mt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex items-center gap-2">
          <X size={16} /> Cancelar
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2">
          <Save size={16} /> Guardar Evento
        </Button>
      </div>
    </form>
  );
};

export default EventForm;
