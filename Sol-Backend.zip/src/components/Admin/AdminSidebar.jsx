
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, Users, Calendar, FileText, Settings, LogOut, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useRole } from '@/contexts/RoleContext';
import { PERMISSIONS } from '@/config/permissions';

const AdminSidebar = ({ isOpen, setIsOpen }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { logout, hasPermission, currentRole } = useRole();

  const handleLogout = () => {
    logout();
    toast({
      title: "Sesión cerrada",
      description: "Has salido del panel de administración."
    });
    navigate('/');
  };

  const navItems = [
    { 
      icon: LayoutDashboard, 
      label: 'Dashboard', 
      path: '/admin/dashboard', 
      exact: true,
      permission: PERMISSIONS.VIEW_ADMIN_DASHBOARD 
    },
    { 
      icon: Users, 
      label: 'Usuarios', 
      path: '/admin/users', 
      exact: false,
      permission: PERMISSIONS.MANAGE_USERS 
    },
    { 
      icon: BookOpen, 
      label: 'Cursos', 
      path: '/admin/courses', 
      exact: false,
      permission: PERMISSIONS.MANAGE_COURSES 
    },
    { 
      icon: Calendar, 
      label: 'Eventos', 
      path: '/admin/events', 
      exact: false,
      permission: PERMISSIONS.MANAGE_EVENTS 
    },
    { 
      icon: FileText, 
      label: 'Recursos', 
      path: '/admin/resources', 
      exact: false,
      permission: PERMISSIONS.MANAGE_RESOURCES 
    },
    { 
      icon: Settings, 
      label: 'Configuración', 
      path: '/admin/settings', 
      exact: false,
      permission: PERMISSIONS.MANAGE_SETTINGS 
    },
  ];

  // Filter items based on permissions
  const visibleItems = navItems.filter(item => hasPermission(item.permission));

  return (
    <aside 
      className={`fixed inset-y-0 left-0 z-50 w-64 bg-[#1E293B] text-white transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0 lg:static lg:inset-auto flex flex-col`}
    >
      {/* Logo Area */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-700 bg-[#0F172A]">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg">
            <span className="font-bold text-white text-lg">N</span>
          </div>
          <span className="text-xl font-bold tracking-tight">AdminPanel</span>
        </div>
        <button onClick={() => setIsOpen(false)} className="lg:hidden text-gray-400 hover:text-white">
          <X size={20} />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-6 px-3 space-y-1">
        {visibleItems.map((item) => (
          <NavLink
            key={item.label}
            to={item.path}
            end={item.exact}
            onClick={() => window.innerWidth < 1024 && setIsOpen(false)}
            className={({ isActive }) =>
              `flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 group ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20'
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`
            }
          >
            <item.icon className={`w-5 h-5 mr-3 transition-transform duration-200 ${
              window.location.pathname === item.path ? 'scale-100' : 'group-hover:scale-110'
            }`} />
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* User Info & Logout */}
      <div className="p-4 border-t border-gray-700 bg-[#1E293B]">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-xs font-bold ring-2 ring-gray-700">
            {currentRole?.charAt(0).toUpperCase()}
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-medium text-white truncate capitalize">{currentRole}</p>
            <p className="text-xs text-gray-500">Sesión activa</p>
          </div>
        </div>
        
        <button 
          onClick={handleLogout}
          className="flex items-center justify-center w-full px-4 py-2 text-sm font-medium text-red-400 bg-red-400/10 rounded-lg hover:bg-red-500 hover:text-white transition-all duration-200"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Salir
        </button>
      </div>
    </aside>
  );
};

export default AdminSidebar;
