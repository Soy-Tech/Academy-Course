
import React from 'react';
import { Edit, Trash2, FileText, Video, File, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ResourcesList = ({ resources, onEdit, onDelete, onToggleStatus }) => {
  const getIcon = (type) => {
    switch (type) {
      case 'video': return <Video className="text-blue-500" size={20} />;
      case 'pdf': return <FileText className="text-red-500" size={20} />;
      default: return <File className="text-gray-500" size={20} />;
    }
  };

  if (!resources || resources.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-12 text-center border border-gray-100">
        <File className="mx-auto h-12 w-12 text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-1">No hay recursos disponibles</h3>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-200">
              <th className="px-6 py-4 font-semibold text-gray-700">Recurso</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Tipo</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Tamaño</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Instructor</th>
              <th className="px-6 py-4 font-semibold text-gray-700">Estado</th>
              <th className="px-6 py-4 font-semibold text-gray-700 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {resources.map((resource) => (
              <tr key={resource.id} className="hover:bg-gray-50/80 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-gray-100 rounded-lg">
                      {getIcon(resource.tipo)}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{resource.nombre}</p>
                      <p className="text-xs text-gray-500">{resource.fechaSubida}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 capitalize">{resource.tipo}</td>
                <td className="px-6 py-4 text-gray-600">{resource.tamaño}</td>
                <td className="px-6 py-4 text-gray-600">{resource.instructor}</td>
                <td className="px-6 py-4">
                  <button
                    onClick={() => onToggleStatus(resource.id)}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border transition-all
                      ${resource.estado === 'published'
                        ? 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100'
                        : 'bg-yellow-50 text-yellow-700 border-yellow-200 hover:bg-yellow-100'}`}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${resource.estado === 'published' ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
                    {resource.estado === 'published' ? 'Publicado' : 'Borrador'}
                  </button>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="ghost" size="icon" onClick={() => onEdit(resource)} className="h-8 w-8 text-blue-600 hover:bg-blue-50">
                      <Edit size={16} />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(resource.id)} className="h-8 w-8 text-red-500 hover:bg-red-50">
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ResourcesList;
