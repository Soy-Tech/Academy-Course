
import React from 'react';
import { Shield, BookOpen, User, Info } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';

const AdminToggle = () => {
  const { currentUser, switchRole } = useAuth();

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
            <Info size={16} className="text-blue-500" />
            Modo Demo: Selector de Roles
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            Cambia tu rol actual para probar diferentes permisos y vistas.
            <br />
            Rol actual: <span className="font-bold capitalize text-blue-600">{currentUser?.rol}</span>
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button 
            size="sm" 
            variant={currentUser?.rol === 'admin' ? 'default' : 'outline'}
            onClick={() => switchRole('admin')}
            className={currentUser?.rol === 'admin' ? 'bg-purple-600 hover:bg-purple-700' : ''}
          >
            <Shield size={14} className="mr-2" />
            Admin
          </Button>
          
          <Button 
            size="sm" 
            variant={currentUser?.rol === 'instructor' ? 'default' : 'outline'}
            onClick={() => switchRole('instructor')}
            className={currentUser?.rol === 'instructor' ? 'bg-blue-600 hover:bg-blue-700' : ''}
          >
            <BookOpen size={14} className="mr-2" />
            Instructor
          </Button>
          
          <Button 
            size="sm" 
            variant={currentUser?.rol === 'student' ? 'default' : 'outline'}
            onClick={() => switchRole('student')}
            className={currentUser?.rol === 'student' ? 'bg-green-600 hover:bg-green-700' : ''}
          >
            <User size={14} className="mr-2" />
            Student
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AdminToggle;
