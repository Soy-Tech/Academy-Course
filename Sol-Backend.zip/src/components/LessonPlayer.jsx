
import React from 'react';
import VideoPlayer from '@/components/VideoPlayer';
import ResourcesList from '@/components/ResourcesList';
import { CheckCircle, Circle } from 'lucide-react';
import { Button } from '@/components/ui/button';

const LessonPlayer = ({ lesson, onMarkComplete, isCompleted }) => {
  if (!lesson) return null;

  return (
    <div className="flex flex-col gap-6 animate-in fade-in duration-500">
      {/* Video Section */}
      <div className="w-full">
        {lesson.type === 'video' ? (
          <VideoPlayer 
            videoUrl={lesson.videoUrl} 
            title={lesson.title}
            onEnded={() => !isCompleted && onMarkComplete(true)} 
          />
        ) : (
          <div className="aspect-video bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300">
            <div className="text-center p-6">
              <h3 className="text-xl font-semibold text-gray-700 mb-2">Lección de Lectura</h3>
              <p className="text-gray-500">Esta lección no contiene video. Lee el contenido abajo.</p>
            </div>
          </div>
        )}
      </div>

      {/* Info Section */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-6 border-b border-gray-100">
        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-gray-900">{lesson.title}</h1>
          <p className="text-gray-600 max-w-3xl leading-relaxed">{lesson.description}</p>
        </div>

        <Button
          onClick={() => onMarkComplete(!isCompleted)}
          variant={isCompleted ? "outline" : "default"}
          className={`shrink-0 transition-all gap-2 ${
            isCompleted 
              ? "bg-green-50 text-green-700 border-green-200 hover:bg-green-100 hover:text-green-800" 
              : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          {isCompleted ? <CheckCircle size={18} /> : <Circle size={18} />}
          {isCompleted ? "Completada" : "Marcar como vista"}
        </Button>
      </div>

      {/* Resources Section */}
      <ResourcesList resources={lesson.resources} />
    </div>
  );
};

export default LessonPlayer;
