
import React, { useRef, useState } from 'react';
import { UploadCloud, File, X, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const InstructorFileUpload = ({ 
  label, 
  onFileSelect, 
  error, 
  isValid, 
  acceptedTypes, 
  maxSizeMB, 
  required,
  currentFile 
}) => {
  const inputRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      onFileSelect(e.target.files[0]);
    }
  };

  return (
    <div className="w-full">
      <label className="block text-sm font-semibold text-gray-700 mb-2">
        {label} {required && <span className="text-red-500">*</span>}
      </label>

      {!currentFile ? (
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={cn(
            "border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all duration-200 group",
            isDragging 
              ? "border-[#0B3D91] bg-blue-50" 
              : error 
                ? "border-red-300 bg-red-50/50 hover:bg-red-50" 
                : "border-gray-200 hover:border-[#0B3D91] hover:bg-gray-50"
          )}
        >
          <input
            ref={inputRef}
            type="file"
            className="hidden"
            accept={acceptedTypes.join(',')}
            onChange={handleChange}
          />
          <div className="w-12 h-12 bg-blue-100 text-[#0B3D91] rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
            <UploadCloud size={24} />
          </div>
          <p className="text-sm font-medium text-gray-900">
            Haz clic para subir o arrastra aquí
          </p>
          <p className="text-xs text-gray-500 mt-1">
            Máximo {maxSizeMB}MB. Formatos: {acceptedTypes.map(t => t.split('/')[1].toUpperCase()).join(', ')}
          </p>
        </div>
      ) : (
        <div className={cn(
          "flex items-center justify-between p-4 rounded-xl border transition-all",
          isValid ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"
        )}>
          <div className="flex items-center gap-3 overflow-hidden">
            <div className={cn("p-2 rounded-lg", isValid ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700")}>
              <File size={20} />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate max-w-[200px]">{currentFile.name}</p>
              <p className="text-xs text-gray-500">{(currentFile.size / (1024 * 1024)).toFixed(2)} MB</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={(e) => { e.stopPropagation(); onFileSelect(null); }}
            className="text-gray-500 hover:text-red-600 hover:bg-red-100/50 h-8 w-8 p-0 rounded-full"
          >
            <X size={16} />
          </Button>
        </div>
      )}

      {error && (
        <p className="mt-1.5 text-xs text-red-600 font-medium flex items-center gap-1">
          <X size={12} /> {error}
        </p>
      )}
      {isValid && currentFile && (
        <p className="mt-1.5 text-xs text-green-600 font-medium flex items-center gap-1">
          <CheckCircle2 size={12} /> Archivo válido
        </p>
      )}
    </div>
  );
};

export default InstructorFileUpload;
