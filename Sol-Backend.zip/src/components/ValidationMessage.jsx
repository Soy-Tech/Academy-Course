
import React from 'react';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const ValidationMessage = ({ isValid, message, className }) => {
  if (isValid === undefined) return null; // Not validated yet
  
  return (
    <div className={cn("flex items-center gap-1.5 text-xs mt-1.5 animate-in slide-in-from-top-1", 
      isValid ? "text-green-600" : "text-red-500",
      className
    )}>
      {isValid ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />}
      <span>{message || (isValid ? "Válido" : "Error")}</span>
    </div>
  );
};

export default ValidationMessage;
