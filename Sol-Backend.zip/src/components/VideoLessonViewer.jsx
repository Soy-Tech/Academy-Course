
import React from 'react';
import VideoPlayer from './VideoPlayer';
import { Button } from '@/components/ui/button';
import { CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import { cn } from '@/lib/utils';

const VideoLessonViewer = ({ 
  lesson, 
  moduleTitle, 
  isCompleted, 
  onLessonComplete, 
  onNavigate,
  nextLessonId,
  prevLessonId 
}) => {
  if (!lesson) return null;

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto w-full">
      <div className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-200">
        <VideoPlayer 
          video={lesson} 
          onNext={() => nextLessonId && onNavigate(nextLessonId)}
          onPrev={() => prevLessonId && onNavigate(prevLessonId)}
          onEnded={() => !isCompleted && onLessonComplete(true)}
        />
      </div>

      <div className="bg-white p-6 md:p-8 rounded-xl border border-gray-200 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
           <div>
              <p className="text-sm text-[#0B3D91] font-bold mb-1 uppercase tracking-wide">{moduleTitle}</p>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900">{lesson.title}</h1>
           </div>
           
           <Button
              onClick={() => onLessonComplete(!isCompleted)}
              variant={isCompleted ? "outline" : "default"}
              className={cn(
                "transition-all min-w-[200px] h-12 text-base",
                isCompleted 
                  ? "border-green-600 text-green-700 bg-green-50 hover:bg-green-100 hover:text-green-800" 
                  : "bg-[#0B3D91] text-white hover:bg-[#082d6b]"
              )}
           >
              {isCompleted ? (
                 <>
                   <CheckCircle size={20} className="mr-2" /> Completada
                 </>
              ) : "Marcar como completada"}
           </Button>
        </div>

        <div className="border-t border-gray-100 pt-6">
          <h3 className="font-bold text-gray-900 mb-2">Descripción</h3>
          <p className="text-gray-600 leading-relaxed">
            {lesson.description || "No hay descripción disponible para esta lección."}
          </p>
        </div>

        {/* Navigation Footer */}
        <div className="flex items-center justify-between pt-6 border-t border-gray-100">
           <Button 
             variant="ghost" 
             onClick={() => onNavigate(prevLessonId)} 
             disabled={!prevLessonId}
             className="text-gray-500 hover:text-[#0B3D91]"
           >
             <ArrowLeft size={18} className="mr-2" /> Anterior
           </Button>

           <Button 
             variant="ghost" 
             onClick={() => onNavigate(nextLessonId)} 
             disabled={!nextLessonId}
             className="text-gray-500 hover:text-[#0B3D91]"
           >
             Siguiente <ArrowRight size={18} className="ml-2" />
           </Button>
        </div>
      </div>
    </div>
  );
};

export default VideoLessonViewer;
