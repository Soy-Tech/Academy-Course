
import React from 'react';
import { FileText, Link as LinkIcon, Download, File, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ResourcesList = ({ resources = [] }) => {
  if (!resources || resources.length === 0) return null;

  const getIcon = (type) => {
    switch (type.toLowerCase()) {
      case 'pdf': return <FileText className="text-red-500" />;
      case 'link': return <LinkIcon className="text-blue-500" />;
      case 'code': return <Code className="text-emerald-500" />;
      default: return <File className="text-gray-500" />;
    }
  };

  return (
    <div className="mt-8 border-t border-gray-100 pt-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
        <FileText size={20} className="text-gray-400" />
        Recursos de la lección
      </h3>
      <div className="grid gap-3 sm:grid-cols-2">
        {resources.map((resource, index) => (
          <div 
            key={index} 
            className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg hover:border-blue-300 hover:shadow-sm transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gray-50 rounded-lg group-hover:bg-blue-50 transition-colors">
                {getIcon(resource.type)}
              </div>
              <div>
                <p className="font-medium text-gray-900 text-sm">{resource.title}</p>
                {resource.size && (
                  <p className="text-xs text-gray-500">{resource.size} • {resource.type.toUpperCase()}</p>
                )}
                {!resource.size && (
                  <p className="text-xs text-gray-500">{resource.type.toUpperCase()}</p>
                )}
              </div>
            </div>
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
              onClick={() => window.open(resource.url, '_blank')}
            >
              <Download size={18} />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ResourcesList;
