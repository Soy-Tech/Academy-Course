
import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { logGuardCheck, logValidation } from '@/utils/roleLogger';
import { validateRoleIntegrity } from '@/utils/roleValidation';
import { Loader2 } from 'lucide-react';

/**
 * Advanced Permission-Based Route Guard
 * Validates Authentication -> Role Coherence -> Permissions
 */
const RoleGuard = ({ children, requiredPermissions = [] }) => {
  const { currentUser, isAuthenticated, isLoading } = useAuth();
  const { currentRole, hasPermission } = useRole();
  const location = useLocation();
  const [isValidated, setIsValidated] = useState(false);
  const [accessDenied, setAccessDenied] = useState(false);

  useEffect(() => {
    if (isLoading) return;

    // 1. Auth Check handled by parent ProtectedRoute typically, but double check
    if (!isAuthenticated) {
      logGuardCheck('Not authenticated', { path: location.pathname });
      return;
    }

    // 2. Coherence Check
    const integrity = validateRoleIntegrity(currentUser.role, currentRole, null);
    if (!integrity.valid) {
      logValidation('Guard blocked: Role mismatch', integrity);
      // Allow one render cycle for RoleContext to sync if mismatch is purely timing
      // If persistent, access denied
      return; 
    }

    // 3. Permission Check
    // Convert single permission string to array
    const permissionsToCheck = Array.isArray(requiredPermissions) 
      ? requiredPermissions 
      : [requiredPermissions];

    if (permissionsToCheck.length === 0) {
      setIsValidated(true);
      return;
    }

    const hasAll = permissionsToCheck.every(p => hasPermission(p));
    
    logGuardCheck('Permission Check', { 
      role: currentRole, 
      required: permissionsToCheck, 
      granted: hasAll 
    });

    if (hasAll) {
      setIsValidated(true);
      setAccessDenied(false);
    } else {
      setIsValidated(true);
      setAccessDenied(true);
    }

  }, [isLoading, isAuthenticated, currentUser, currentRole, requiredPermissions, location, hasPermission]);

  if (isLoading || !isValidated) {
     // Don't block if no permissions required and authenticated
     if (!isLoading && isAuthenticated && requiredPermissions.length === 0) {
        return children;
     }

     return (
       <div className="flex justify-center items-center p-12">
         <Loader2 className="h-6 w-6 animate-spin text-gray-400" />
       </div>
     );
  }

  if (accessDenied) {
    return <Navigate to="/access-denied" replace state={{ from: location }} />;
  }

  return children;
};

export default RoleGuard;
