
import React from 'react';
import { motion } from 'framer-motion';
import { SearchX, Inbox, BellOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

const EmptyState = ({ 
  type = 'default', 
  title = 'No se encontraron resultados', 
  description = 'Intenta ajustar tus filtros o búsqueda.', 
  action 
}) => {
  const icons = {
    search: SearchX,
    inbox: Inbox,
    notifications: BellOff,
    default: SearchX
  };

  const Icon = icons[type] || icons.default;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center text-center p-12 bg-gray-50/50 rounded-2xl border border-dashed border-gray-200"
    >
      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
        <Icon className="w-8 h-8 text-gray-400" />
      </div>
      <h3 className="text-lg font-bold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-500 max-w-sm mb-6">{description}</p>
      {action && (
        <Button onClick={action.onClick} variant="outline">
          {action.label}
        </Button>
      )}
    </motion.div>
  );
};

export default EmptyState;
