
import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ErrorState = ({ 
  title = 'Algo salió mal', 
  message = 'No pudimos cargar la información. Por favor intenta de nuevo.', 
  onRetry 
}) => {
  return (
    <div className="flex flex-col items-center justify-center text-center p-12 bg-red-50 rounded-2xl border border-red-100">
      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
        <AlertCircle className="w-8 h-8 text-red-500" />
      </div>
      <h3 className="text-lg font-bold text-red-900 mb-2">{title}</h3>
      <p className="text-red-600 max-w-sm mb-6">{message}</p>
      {onRetry && (
        <Button onClick={onRetry} variant="outline" className="border-red-200 text-red-700 hover:bg-red-100">
          <RefreshCw className="w-4 h-4 mr-2" />
          Reintentar
        </Button>
      )}
    </div>
  );
};

export default ErrorState;
