
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

const SuccessState = ({ title = '¡Éxito!', message = 'La operación se completó correctamente.' }) => {
  return (
    <motion.div 
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="flex flex-col items-center justify-center text-center p-8 bg-green-50 rounded-xl border border-green-100"
    >
      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
        <CheckCircle className="w-10 h-10 text-green-500" />
      </div>
      <h3 className="text-xl font-bold text-green-900 mb-2">{title}</h3>
      <p className="text-green-700">{message}</p>
    </motion.div>
  );
};

export default SuccessState;
