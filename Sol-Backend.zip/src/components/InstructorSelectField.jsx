
import React from 'react';
import { Check, AlertCircle, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

const InstructorSelectField = ({
  label,
  value,
  onChange,
  options,
  error,
  isValid,
  required,
  placeholder = "Selecciona una opción",
  name
}) => {
  return (
    <div className="w-full">
      <label className="block text-sm font-semibold text-gray-700 mb-1.5">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      
      <div className="relative">
        <select
          name={name}
          value={value}
          onChange={onChange}
          className={cn(
            "w-full px-4 py-3 pr-10 rounded-lg border appearance-none bg-gray-50/50 focus:bg-white transition-all outline-none focus:ring-2 cursor-pointer",
            error 
              ? "border-red-300 focus:border-red-500 focus:ring-red-100" 
              : (isValid && value)
                ? "border-green-300 focus:border-green-500 focus:ring-green-100"
                : "border-gray-200 focus:border-[#0B3D91] focus:ring-[#0B3D91]/10",
            !value && "text-gray-400"
          )}
        >
          <option value="" disabled>{placeholder}</option>
          {options.map((opt) => (
            <option key={opt.value} value={opt.value} className="text-gray-900">
              {opt.label}
            </option>
          ))}
        </select>
        
        <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 flex items-center gap-2">
           {/* If valid show check, else show chevron */}
           {(isValid && value && !error) && <Check className="text-green-500" size={16} />}
           <ChevronDown size={16} />
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-1 mt-1.5 text-xs text-red-600 font-medium animate-in slide-in-from-top-1">
          <AlertCircle size={12} />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

export default InstructorSelectField;
