
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useInstructorRequest } from '@/contexts/InstructorRequestContext';
import { Button } from '@/components/ui/button';
import { Loader2, ChevronRight, ChevronLeft, Upload, Save, CheckSquare } from 'lucide-react';
import FormSection from '@/components/FormSection';
import FormInput from '@/components/FormInput';
import ProgressBar from '@/components/ProgressBar';
import ValidationMessage from '@/components/ValidationMessage';
import * as Validators from '@/services/validationService';
import { useToast } from '@/components/ui/use-toast';

const SECTIONS = [
  'Datos Personales',
  'Experiencia Profesional',
  'Propuesta de Curso',
  'Compromiso',
  'Términos y Condiciones'
];

const InstructorApplicationForm = () => {
  const { currentUser } = useAuth();
  const { submitInstructorApplication, loading: apiLoading, currentApplication } = useInstructorRequest();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState({
    personalData: {
      fullName: currentUser?.name || '',
      email: currentUser?.email || '',
      phone: '',
      country: '',
      bio: '',
      photo: null // File object
    },
    experience: {
      years: '',
      specialty: '',
      company: '',
      position: '',
      certifications: null, // File
      description: '',
      portfolioUrl: ''
    },
    courseProposal: {
      topic: '',
      description: '',
      level: 'beginner',
      targetAudience: '',
      hasResources: false
    },
    commitment: {
      weeklyAvailability: '',
      responseTime: '24h',
      motivation: '',
      agreeTerms: false,
      agreeQuality: false,
      agreeDeadlines: false
    },
    policies: {
      originalContent: false,
      noSpam: false,
      respectCopyright: false,
      professionalConduct: false,
      dataPrivacy: false
    }
  });

  const [errors, setErrors] = useState({});

  useEffect(() => {
    // If already has application, redirect
    if (currentApplication && currentApplication.status !== 'rejected') {
      navigate('/instructor-application-status');
    }
  }, [currentApplication, navigate]);

  const validateStep = (step) => {
    const newErrors = {};
    let isValid = true;

    if (step === 0) {
      const { fullName, email, phone, bio } = formData.personalData;
      if (!Validators.validateMinLength(fullName, 3).isValid) newErrors.fullName = 'Nombre muy corto';
      if (!Validators.validateEmail(email).isValid) newErrors.email = 'Email inválido';
      if (!Validators.validatePhone(phone).isValid) newErrors.phone = 'Teléfono inválido';
      if (!Validators.validateMinLength(bio, 20).isValid) newErrors.bio = 'La biografía debe tener al menos 20 caracteres';
    }

    if (step === 1) {
      const { years, specialty, description, portfolioUrl } = formData.experience;
      if (!Validators.validateYearsOfExperience(years).isValid) newErrors.years = 'Mínimo 2 años requeridos';
      if (!Validators.validateMinLength(specialty, 3).isValid) newErrors.specialty = 'Requerido';
      if (!Validators.validateMinLength(description, 50).isValid) newErrors.expDescription = 'Detalla más tu experiencia (min 50 caracteres)';
      if (portfolioUrl && !Validators.validateURL(portfolioUrl).isValid) newErrors.portfolioUrl = 'URL inválida';
    }

    if (step === 2) {
      const { topic, description, targetAudience } = formData.courseProposal;
      if (!Validators.validateMinLength(topic, 5).isValid) newErrors.topic = 'Tema muy corto';
      if (!Validators.validateMinLength(description, 50).isValid) newErrors.courseDescription = 'Descripción muy corta';
      if (!Validators.validateMinLength(targetAudience, 10).isValid) newErrors.targetAudience = 'Define mejor tu audiencia';
    }

    if (step === 3) {
      const { weeklyAvailability, motivation, agreeTerms, agreeQuality, agreeDeadlines } = formData.commitment;
      if (!weeklyAvailability) newErrors.weeklyAvailability = 'Requerido';
      if (!Validators.validateMinLength(motivation, 30).isValid) newErrors.motivation = 'Explica tu motivación (min 30 caracteres)';
      if (!agreeTerms || !agreeQuality || !agreeDeadlines) newErrors.commitmentChecks = 'Debes aceptar todos los compromisos';
    }

    if (step === 4) {
      const { originalContent, noSpam, respectCopyright, professionalConduct, dataPrivacy } = formData.policies;
      if (!originalContent || !noSpam || !respectCopyright || !professionalConduct || !dataPrivacy) {
        newErrors.policies = 'Debes aceptar todas las políticas';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(activeStep)) {
      setActiveStep(prev => Math.min(prev + 1, SECTIONS.length - 1));
      window.scrollTo(0, 0);
    } else {
      toast({ title: "Corrige los errores", variant: "destructive" });
    }
  };

  const handlePrev = () => {
    setActiveStep(prev => Math.max(prev - 1, 0));
    window.scrollTo(0, 0);
  };

  const handleSubmit = async () => {
    if (!validateStep(activeStep)) return;

    try {
      const submissionData = {
        userId: currentUser.id,
        ...formData
      };
      await submitInstructorApplication(submissionData);
      navigate('/instructor-application-status');
    } catch (error) {
      console.error(error);
    }
  };

  const updateField = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
    // Clear error for this field
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  return (
    <div className="max-w-3xl mx-auto pb-20">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#0B3D91] mb-2">Solicitud de Instructor</h1>
        <p className="text-gray-600 mb-6">Completa los 5 pasos para unirte a nuestro equipo docente.</p>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold text-gray-500">Paso {activeStep + 1} de {SECTIONS.length}: {SECTIONS[activeStep]}</span>
          <span className="text-sm font-bold text-[#0B3D91]">{Math.round(((activeStep + 1) / SECTIONS.length) * 100)}%</span>
        </div>
        <ProgressBar currentStep={activeStep + 1} totalSteps={SECTIONS.length} />
      </div>

      <AnimatePresence mode="wait">
        
        {/* SECTION 1: PERSONAL DATA */}
        {activeStep === 0 && (
          <FormSection key="step1" title="Datos Personales" description="Cuéntanos quién eres. Esta información será usada para tu perfil público.">
            <div className="grid md:grid-cols-2 gap-6">
              <FormInput 
                label="Nombre Completo" 
                value={formData.personalData.fullName}
                onChange={(e) => updateField('personalData', 'fullName', e.target.value)}
                error={errors.fullName}
                placeholder="Juan Pérez"
              />
              <FormInput 
                label="Email" 
                type="email"
                value={formData.personalData.email}
                onChange={(e) => updateField('personalData', 'email', e.target.value)}
                error={errors.email}
                placeholder="juan@ejemplo.com"
                disabled // Email usually locked to account
              />
              <FormInput 
                label="Teléfono" 
                value={formData.personalData.phone}
                onChange={(e) => updateField('personalData', 'phone', e.target.value)}
                error={errors.phone}
                placeholder="+52 55 1234 5678"
              />
              <FormInput 
                label="País de Residencia" 
                value={formData.personalData.country}
                onChange={(e) => updateField('personalData', 'country', e.target.value)}
                placeholder="México"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Biografía Profesional</label>
              <textarea 
                className="w-full border border-gray-200 rounded-lg p-3 min-h-[100px] focus:ring-2 focus:ring-[#0B3D91]/20 focus:border-[#0B3D91] outline-none"
                value={formData.personalData.bio}
                onChange={(e) => updateField('personalData', 'bio', e.target.value)}
                placeholder="Resumen breve de tu carrera..."
              />
              {errors.bio && <ValidationMessage isValid={false} message={errors.bio} />}
            </div>
          </FormSection>
        )}

        {/* SECTION 2: EXPERIENCE */}
        {activeStep === 1 && (
          <FormSection key="step2" title="Experiencia Profesional" description="Demuestra tu expertise en el área.">
            <div className="grid md:grid-cols-2 gap-6">
               <FormInput 
                label="Años de Experiencia" 
                type="number"
                value={formData.experience.years}
                onChange={(e) => updateField('experience', 'years', e.target.value)}
                error={errors.years}
                placeholder="Ej. 5"
              />
              <FormInput 
                label="Especialidad Principal" 
                value={formData.experience.specialty}
                onChange={(e) => updateField('experience', 'specialty', e.target.value)}
                error={errors.specialty}
                placeholder="Ej. Desarrollo Web, Marketing Digital"
              />
              <FormInput 
                label="Empresa Actual (Opcional)" 
                value={formData.experience.company}
                onChange={(e) => updateField('experience', 'company', e.target.value)}
                placeholder="Tech Corp"
              />
              <FormInput 
                label="Cargo Actual (Opcional)" 
                value={formData.experience.position}
                onChange={(e) => updateField('experience', 'position', e.target.value)}
                placeholder="Senior Developer"
              />
            </div>
            <FormInput 
              label="Portfolio / LinkedIn / GitHub URL" 
              value={formData.experience.portfolioUrl}
              onChange={(e) => updateField('experience', 'portfolioUrl', e.target.value)}
              error={errors.portfolioUrl}
              placeholder="https://linkedin.com/in/..."
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Descripción Detallada de Experiencia</label>
              <textarea 
                className="w-full border border-gray-200 rounded-lg p-3 min-h-[120px] focus:ring-2 focus:ring-[#0B3D91]/20 outline-none"
                value={formData.experience.description}
                onChange={(e) => updateField('experience', 'description', e.target.value)}
                placeholder="Describe tus logros más relevantes, tecnologías que dominas, proyectos importantes..."
              />
              {errors.expDescription && <ValidationMessage isValid={false} message={errors.expDescription} />}
            </div>
          </FormSection>
        )}

        {/* SECTION 3: COURSE PROPOSAL */}
        {activeStep === 2 && (
          <FormSection key="step3" title="Propuesta de Curso" description="¿Qué te gustaría enseñar primero?">
            <FormInput 
              label="Título Tentativo del Curso" 
              value={formData.courseProposal.topic}
              onChange={(e) => updateField('courseProposal', 'topic', e.target.value)}
              error={errors.topic}
              placeholder="Ej. Master en React Avanzado"
            />
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Nivel del Curso</label>
              <select 
                className="w-full border border-gray-200 rounded-lg p-2.5 bg-white outline-none"
                value={formData.courseProposal.level}
                onChange={(e) => updateField('courseProposal', 'level', e.target.value)}
              >
                <option value="beginner">Principiante</option>
                <option value="intermediate">Intermedio</option>
                <option value="advanced">Avanzado</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Descripción del Curso</label>
              <textarea 
                className="w-full border border-gray-200 rounded-lg p-3 min-h-[100px] outline-none"
                value={formData.courseProposal.description}
                onChange={(e) => updateField('courseProposal', 'description', e.target.value)}
                placeholder="¿Qué aprenderán los estudiantes?"
              />
              {errors.courseDescription && <ValidationMessage isValid={false} message={errors.courseDescription} />}
            </div>
            <FormInput 
              label="Público Objetivo" 
              value={formData.courseProposal.targetAudience}
              onChange={(e) => updateField('courseProposal', 'targetAudience', e.target.value)}
              error={errors.targetAudience}
              placeholder="Ej. Desarrolladores con conocimientos básicos de JS"
            />
            <div className="flex items-center gap-2 mt-4">
              <input 
                type="checkbox" 
                id="hasResources"
                checked={formData.courseProposal.hasResources}
                onChange={(e) => updateField('courseProposal', 'hasResources', e.target.checked)}
                className="w-4 h-4 text-[#0B3D91]"
              />
              <label htmlFor="hasResources" className="text-sm text-gray-700">Tengo material/recursos ya preparados</label>
            </div>
          </FormSection>
        )}

        {/* SECTION 4: COMMITMENT */}
        {activeStep === 3 && (
          <FormSection key="step4" title="Compromiso" description="Tu dedicación es clave para el éxito de los estudiantes.">
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">Disponibilidad Semanal para Crear/Actualizar Contenido</label>
              <select 
                className="w-full border border-gray-200 rounded-lg p-2.5 bg-white outline-none"
                value={formData.commitment.weeklyAvailability}
                onChange={(e) => updateField('commitment', 'weeklyAvailability', e.target.value)}
              >
                <option value="">Selecciona...</option>
                <option value="1-5">1-5 horas</option>
                <option value="5-10">5-10 horas</option>
                <option value="10+">10+ horas</option>
              </select>
              {errors.weeklyAvailability && <ValidationMessage isValid={false} message={errors.weeklyAvailability} />}
            </div>

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-1.5">¿Por qué quieres ser instructor?</label>
              <textarea 
                className="w-full border border-gray-200 rounded-lg p-3 min-h-[100px] outline-none"
                value={formData.commitment.motivation}
                onChange={(e) => updateField('commitment', 'motivation', e.target.value)}
                placeholder="Comparte tu motivación..."
              />
              {errors.motivation && <ValidationMessage isValid={false} message={errors.motivation} />}
            </div>

            <div className="bg-blue-50 p-4 rounded-lg space-y-3">
              <h4 className="font-semibold text-[#0B3D91]">Compromisos Requeridos</h4>
              {[
                { key: 'agreeTerms', text: 'Acepto los términos y condiciones de la plataforma.' },
                { key: 'agreeQuality', text: 'Me comprometo a entregar contenido de alta calidad (Audio/Video HD).' },
                { key: 'agreeDeadlines', text: 'Me comprometo a responder dudas de alumnos en menos de 48h.' },
              ].map(item => (
                <div key={item.key} className="flex items-start gap-2">
                  <input 
                    type="checkbox" 
                    id={item.key}
                    checked={formData.commitment[item.key]}
                    onChange={(e) => updateField('commitment', item.key, e.target.checked)}
                    className="mt-1 w-4 h-4 text-[#0B3D91]"
                  />
                  <label htmlFor={item.key} className="text-sm text-gray-700 cursor-pointer">{item.text}</label>
                </div>
              ))}
              {errors.commitmentChecks && <ValidationMessage isValid={false} message={errors.commitmentChecks} />}
            </div>
          </FormSection>
        )}

        {/* SECTION 5: POLICIES */}
        {activeStep === 4 && (
          <FormSection key="step5" title="Políticas y Normas" description="Último paso. Confirma que entiendes nuestras reglas.">
            <div className="space-y-4">
              {[
                { key: 'originalContent', text: 'Todo el material que subiré es de mi autoría o tengo derechos explícitos.' },
                { key: 'noSpam', text: 'No usaré la plataforma para enviar spam ni promocionar servicios externos sin permiso.' },
                { key: 'respectCopyright', text: 'Entiendo que el plagio resultará en la baja inmediata.' },
                { key: 'professionalConduct', text: 'Mantendré una conducta profesional y respetuosa con los alumnos.' },
                { key: 'dataPrivacy', text: 'Respetaré la privacidad de los datos de los estudiantes según el GDPR.' },
              ].map(item => (
                <div key={item.key} className="flex items-start gap-3 p-3 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors">
                  <input 
                    type="checkbox" 
                    id={item.key}
                    checked={formData.policies[item.key]}
                    onChange={(e) => updateField('policies', item.key, e.target.checked)}
                    className="mt-1 w-5 h-5 text-[#0B3D91]"
                  />
                  <label htmlFor={item.key} className="text-sm text-gray-800 cursor-pointer font-medium">{item.text}</label>
                </div>
              ))}
              {errors.policies && <ValidationMessage isValid={false} message={errors.policies} />}
            </div>

            <div className="mt-8 bg-yellow-50 p-4 rounded-lg border border-yellow-100 flex gap-3">
              <CheckSquare className="text-yellow-600 shrink-0" />
              <p className="text-sm text-yellow-800">
                Al enviar esta solicitud, confirmas que toda la información proporcionada es verídica. 
                Nuestro equipo revisará tu perfil manualmente.
              </p>
            </div>
          </FormSection>
        )}

      </AnimatePresence>

      {/* NAVIGATION BUTTONS */}
      <div className="flex justify-between mt-8 pt-6 border-t border-gray-100">
        <Button 
          variant="outline" 
          onClick={handlePrev}
          disabled={activeStep === 0 || apiLoading}
          className="w-32"
        >
          <ChevronLeft size={16} className="mr-2" /> Anterior
        </Button>

        {activeStep < SECTIONS.length - 1 ? (
          <Button 
            onClick={handleNext}
            className="w-32 bg-[#0B3D91] hover:bg-[#092c69]"
          >
             Siguiente <ChevronRight size={16} className="ml-2" />
          </Button>
        ) : (
          <Button 
            onClick={handleSubmit}
            disabled={apiLoading}
            className="w-48 bg-green-600 hover:bg-green-700 text-white shadow-md"
          >
            {apiLoading ? <Loader2 className="animate-spin mr-2" /> : <Save className="mr-2" size={18} />}
            Enviar Solicitud
          </Button>
        )}
      </div>
    </div>
  );
};

export default InstructorApplicationForm;
