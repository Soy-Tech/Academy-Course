
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ImageOff } from 'lucide-react';
import useLazyImage from '@/hooks/useLazyImage';
import { cn } from '@/lib/utils';

const LazyImage = ({ 
  src, 
  alt, 
  className, 
  placeholderSrc,
  fallbackSrc = "https://via.placeholder.com/400x300?text=Image+Not+Found",
  containerClassName
}) => {
  const { imgRef, imageSrc, isLoaded, error, handleLoad, handleError } = useLazyImage(src);

  return (
    <div className={cn("relative overflow-hidden bg-gray-100", containerClassName, className)}>
      {/* Placeholder / Skeleton */}
      <AnimatePresence>
        {!isLoaded && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-10 bg-gray-200 animate-pulse flex items-center justify-center"
          >
            {placeholderSrc && (
               <img src={placeholderSrc} alt="" className="w-full h-full object-cover blur-sm opacity-50" />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Actual Image */}
      <img
        ref={imgRef}
        src={error ? fallbackSrc : (imageSrc || placeholderSrc)}
        alt={alt}
        onLoad={handleLoad}
        onError={handleError}
        className={cn(
          "w-full h-full object-cover transition-opacity duration-500",
          isLoaded ? "opacity-100" : "opacity-0"
        )}
      />

      {/* Error State */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-100 text-gray-400">
          <ImageOff size={24} />
        </div>
      )}
    </div>
  );
};

export default LazyImage;
