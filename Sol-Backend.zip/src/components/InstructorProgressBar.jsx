
import React from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const InstructorProgressBar = ({ currentSection, totalSections, percentage }) => {
  return (
    <div className="w-full">
      <div className="flex justify-between items-end mb-2">
        <span className="text-xs font-bold text-[#0B3D91] uppercase tracking-wide">
          Progreso de Solicitud
        </span>
        <span className="text-xs font-medium text-gray-500">
          {Math.round(percentage)}% completado
        </span>
      </div>
      <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className={cn(
            "h-full bg-gradient-to-r from-[#0B3D91] to-blue-500 rounded-full shadow-sm",
            percentage === 100 && "bg-green-500"
          )}
        />
      </div>
      <div className="mt-2 flex justify-between text-xs text-gray-400">
         <span>Inicio</span>
         <span>Finalizar</span>
      </div>
    </div>
  );
};

export default InstructorProgressBar;
