
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { courseService } from '@/services/courseService';
import { enrollmentService } from '@/services/enrollmentService';
import { useAuth } from '@/hooks/useAuth';
import EnrollButton from './EnrollButton';
import UnenrollButton from './UnenrollButton';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/UI/Card'; // Corrected import
import { Button } from '@/components/ui/button';
import { Loader2, ArrowLeft, User, BarChart, DollarSign, Clock } from 'lucide-react';

const CourseDetail = () => {
  const { id } = useParams();
  const { currentUser } = useAuth();
  const [course, setCourse] = useState(null);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        // Fetch course details
        const courseData = await courseService.getCourseById(id);
        setCourse(courseData);

        // Check enrollment status if user is logged in
        if (currentUser) {
          const enrollments = await enrollmentService.getEnrollments();
          const enrolled = enrollments.some(e => e.course_id === id);
          setIsEnrolled(enrolled);
        }
      } catch (err) {
        console.error('Error loading course details:', err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchData();
    }
  }, [id, currentUser]);

  const handleEnrollmentChange = async () => {
    // Refresh enrollment status
    if (currentUser) {
      const enrollments = await enrollmentService.getEnrollments();
      const enrolled = enrollments.some(e => e.course_id === id);
      setIsEnrolled(enrolled);
    }
  };

  if (loading) return <div className="flex justify-center p-12"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  if (error || !course) return <div className="text-center p-12 text-red-500">Error al cargar el curso.</div>;

  return (
    <div className="container mx-auto py-8 px-4">
      <Link to="/cursos" className="inline-flex items-center text-sm text-gray-500 hover:text-gray-900 mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Volver a Cursos
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-lg p-6 shadow-sm border">
            <h1 className="text-3xl font-bold mb-4">{course.title}</h1>
            <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-6">
              <div className="flex items-center">
                <User className="h-4 w-4 mr-2" />
                {course.profiles?.first_name || 'Instructor'}
              </div>
              <div className="flex items-center">
                <BarChart className="h-4 w-4 mr-2" />
                {course.level}
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                Última actualización: {new Date(course.updated_at).toLocaleDateString()}
              </div>
            </div>
            
            <div className="prose max-w-none">
              <h3 className="text-xl font-semibold mb-2">Descripción del Curso</h3>
              <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                {course.description}
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Precio</span>
                <span className="text-2xl font-bold text-green-600">
                  {course.price > 0 ? `$${course.price}` : 'Gratis'}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {currentUser ? (
                <div className="space-y-4">
                  {isEnrolled ? (
                    <>
                      <div className="p-3 bg-green-50 text-green-700 rounded-md text-sm text-center font-medium">
                        ¡Ya estás inscrito!
                      </div>
                      <Button asChild className="w-full">
                        <Link to={`/learning/${course.id}`}>Ir al Aula Virtual</Link>
                      </Button>
                      <UnenrollButton 
                        courseId={course.id} 
                        onSuccess={handleEnrollmentChange} 
                      />
                    </>
                  ) : (
                    <EnrollButton 
                      courseId={course.id} 
                      onSuccess={handleEnrollmentChange} 
                    />
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm text-gray-500 text-center">
                    Inicia sesión para inscribirte en este curso.
                  </p>
                  <Button asChild className="w-full">
                    <Link to="/login" state={{ from: `/cursos/${id}` }}>
                      Iniciar Sesión
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
