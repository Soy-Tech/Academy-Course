
import React, { useState } from 'react';
import { enrollmentService } from '@/services/enrollmentService';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const EnrollButton = ({ courseId, onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleEnroll = async () => {
    setLoading(true);
    try {
      await enrollmentService.enrollCourse(courseId);
      toast({
        title: "¡Inscripción exitosa!",
        description: "Te has inscrito correctamente en el curso.",
      });
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Enrollment failed:', error);
      toast({
        variant: "destructive",
        title: "Error de inscripción",
        description: "No se pudo completar la inscripción. Inténtalo de nuevo.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button onClick={handleEnroll} disabled={loading} className="w-full">
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Inscribiendo...
        </>
      ) : (
        "Inscribirse al Curso"
      )}
    </Button>
  );
};

export default EnrollButton;
