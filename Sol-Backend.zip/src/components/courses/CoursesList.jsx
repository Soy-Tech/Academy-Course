
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { courseService } from '@/services/courseService';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/UI/Card'; // Corrected import
import { Button } from '@/components/ui/button';
import { Loader2, BookOpen, User, DollarSign } from 'lucide-react';

const CoursesList = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        setLoading(true);
        const data = await courseService.getCourses();
        setCourses(data);
      } catch (err) {
        console.error('Error fetching courses:', err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchCourses();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-10 text-red-500">
        <p>Error al cargar los cursos. Por favor, intenta de nuevo más tarde.</p>
      </div>
    );
  }

  if (courses.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500">
        <BookOpen className="mx-auto h-12 w-12 mb-4 opacity-50" />
        <p className="text-xl font-medium">No hay cursos disponibles</p>
        <p>Vuelve pronto para ver nuevo contenido.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Nuestros Cursos</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <Card key={course.id} className="flex flex-col h-full hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex justify-between items-start">
                <CardTitle className="line-clamp-2 text-xl">{course.title}</CardTitle>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                  {course.level}
                </span>
              </div>
              <CardDescription className="flex items-center mt-2">
                <User className="h-4 w-4 mr-1" />
                {course.profiles?.first_name 
                  ? `${course.profiles.first_name} ${course.profiles.last_name || ''}`
                  : 'Instructor'}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <p className="text-sm text-gray-600 line-clamp-3 mb-4">
                {course.description}
              </p>
              <div className="flex items-center font-semibold text-green-600">
                <DollarSign className="h-4 w-4" />
                {course.price > 0 ? `$${course.price}` : 'Gratis'}
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link to={`/cursos/${course.id}`}>Ver Detalles</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CoursesList;
