
import React, { useState } from 'react';
import { enrollmentService } from '@/services/enrollmentService';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const UnenrollButton = ({ courseId, onSuccess }) => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleUnenroll = async () => {
    if (!window.confirm("¿Estás seguro de que deseas abandonar este curso?")) {
      return;
    }

    setLoading(true);
    try {
      await enrollmentService.unenrollCourse(courseId);
      toast({
        title: "Baja confirmada",
        description: "Te has dado de baja del curso correctamente.",
      });
      if (onSuccess) onSuccess();
    } catch (error) {
      console.error('Unenrollment failed:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo procesar la baja. Inténtalo de nuevo.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={handleUnenroll} 
      disabled={loading} 
      variant="destructive" 
      className="w-full"
    >
      {loading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Procesando...
        </>
      ) : (
        "Darse de Baja"
      )}
    </Button>
  );
};

export default UnenrollButton;
