
import React, { useState } from 'react';
import { X, Tag, MessageSquare, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import FormInput from '@/components/FormInput';
import { useForums } from '@/hooks/useForums';

const ForumTopicForm = ({ isOpen, onClose, onSubmit }) => {
  const { getCategories } = useForums();
  const categories = getCategories();
  
  const [formData, setFormData] = useState({
    title: '',
    categoryId: '',
    content: '',
    tags: ''
  });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};
    if (formData.title.length < 10) newErrors.title = 'El título debe tener al menos 10 caracteres';
    if (!formData.categoryId) newErrors.categoryId = 'Debes seleccionar una categoría';
    if (formData.content.length < 20) newErrors.content = 'El contenido debe ser más detallado (mínimo 20 caracteres)';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    const tagsArray = formData.tags
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    onSubmit({
      ...formData,
      tags: tagsArray
    });
    
    // Reset form
    setFormData({ title: '', categoryId: '', content: '', tags: '' });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-all">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="flex justify-between items-center p-6 border-b border-gray-100 bg-gray-50/50">
            <div>
               <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                 <MessageSquare className="text-[#0B3D91]" size={24} />
                 Crear Nuevo Tema
               </h2>
               <p className="text-sm text-gray-500 mt-1">Comparte tus dudas o conocimientos con la comunidad</p>
            </div>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors p-2 hover:bg-gray-100 rounded-full">
              <X size={24} />
            </button>
          </div>

          {/* Form */}
          <div className="overflow-y-auto p-6">
            <form id="topicForm" onSubmit={handleSubmit} className="space-y-5">
              <FormInput
                label="Título del tema"
                placeholder="Ej: Problema con useEffect en React 18 al hacer fetch..."
                value={formData.title}
                onChange={(e) => {
                    setFormData({ ...formData, title: e.target.value });
                    if(errors.title) setErrors({...errors, title: null});
                }}
                error={errors.title}
                required
                className="text-lg"
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                       Categoría <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={formData.categoryId}
                      onChange={(e) => {
                          setFormData({ ...formData, categoryId: e.target.value });
                          if(errors.categoryId) setErrors({...errors, categoryId: null});
                      }}
                      className={`w-full bg-white border rounded-lg py-2.5 px-4 focus:ring-2 focus:ring-[#0B3D91]/20 focus:border-[#0B3D91] outline-none transition-colors ${errors.categoryId ? 'border-red-500' : 'border-gray-200'}`}
                    >
                      <option value="">Selecciona una categoría...</option>
                      {categories.map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.icon} {cat.name}</option>
                      ))}
                    </select>
                    {errors.categoryId && (
                       <p className="mt-1.5 flex items-center gap-1 text-sm text-red-500">
                          <AlertCircle size={14} /> {errors.categoryId}
                       </p>
                    )}
                 </div>

                 <FormInput
                    label="Etiquetas (opcional)"
                    placeholder="react, hooks, api..."
                    value={formData.tags}
                    onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                    icon={Tag}
                 />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                   Contenido <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                   <textarea
                     rows="8"
                     placeholder="Describe tu duda o aporte con el mayor detalle posible para que otros puedan ayudarte mejor..."
                     value={formData.content}
                     onChange={(e) => {
                        setFormData({ ...formData, content: e.target.value });
                        if(errors.content) setErrors({...errors, content: null});
                     }}
                     className={`w-full bg-white border rounded-lg py-3 px-4 focus:ring-2 focus:ring-[#0B3D91]/20 focus:border-[#0B3D91] outline-none resize-none transition-colors ${errors.content ? 'border-red-500' : 'border-gray-200'}`}
                   />
                </div>
                {errors.content && (
                   <p className="mt-1.5 flex items-center gap-1 text-sm text-red-500">
                      <AlertCircle size={14} /> {errors.content}
                   </p>
                )}
                <p className="text-xs text-gray-400 mt-2 text-right">
                   {formData.content.length} caracteres (mínimo 20)
                </p>
              </div>
            </form>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-gray-100 bg-gray-50 flex gap-3 justify-end">
             <Button type="button" variant="outline" onClick={onClose} className="border-gray-300 text-gray-700 hover:bg-white w-full sm:w-auto">
               Cancelar
             </Button>
             <Button type="submit" form="topicForm" className="bg-[#0B3D91] hover:bg-[#082d6b] text-white w-full sm:w-auto shadow-md">
               Publicar Tema
             </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ForumTopicForm;
