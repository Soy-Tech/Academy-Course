
import React from 'react';
import CourseCard from './CourseCard';

// Since the requirement is to use the exact same clean design as CourseCard
// without overlays or popovers for the preview, we can simply reuse the component.
// This maintains dry code and visual consistency.
const CourseCardPreview = ({ course }) => {
  return <CourseCard course={course} />;
};

export default CourseCardPreview;
