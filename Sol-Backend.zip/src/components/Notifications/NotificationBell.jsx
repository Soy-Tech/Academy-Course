
import React, { useState, useRef, useEffect } from 'react';
import { Bell, X, Check, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

const mockNotifications = [
  { id: 1, title: 'Nuevo curso disponible', description: 'Se ha publicado "React Avanzado".', time: '2 horas', read: false, type: 'course' },
  { id: 2, title: 'Tarea calificada', description: 'Tu tarea del Módulo 3 ha sido calificada.', time: '5 horas', read: false, type: 'achievement' },
  { id: 3, title: 'Respuesta del instructor', description: 'Sarah ha respondido a tu pregunta.', time: '1 día', read: true, type: 'message' },
  { id: 4, title: 'Recordatorio de evento', description: 'El webinar comienza en 30 minutos.', time: '1 día', read: true, type: 'event' },
  { id: 5, title: 'Bienvenido', description: 'Gracias por unirte a Netcom Academy.', time: '3 días', read: true, type: 'system' }
];

const NotificationBell = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);
  const dropdownRef = useRef(null);

  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const markAsRead = (id, e) => {
    e.stopPropagation();
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)} 
        className="relative p-2 text-gray-600 hover:text-blue-600 transition-colors rounded-full hover:bg-gray-100"
      >
        <Bell size={22} />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
            {unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute right-0 mt-2 w-80 md:w-96 bg-white rounded-xl shadow-xl border border-gray-200 z-50 overflow-hidden"
          >
            <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
              <h3 className="font-bold text-gray-900">Notificaciones</h3>
              {unreadCount > 0 && (
                <button onClick={markAllRead} className="text-xs text-blue-600 hover:text-blue-800 font-medium">
                  Marcar todo como leído
                </button>
              )}
            </div>

            <div className="max-h-[400px] overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-gray-500 text-sm">
                  No tienes notificaciones.
                </div>
              ) : (
                <div className="divide-y divide-gray-100">
                  {notifications.map((notification) => (
                    <div 
                      key={notification.id} 
                      className={`p-4 hover:bg-gray-50 transition-colors relative group ${!notification.read ? 'bg-blue-50/50' : ''}`}
                    >
                      <div className="flex justify-between items-start gap-3">
                        <div className="flex-1">
                          <p className={`text-sm ${!notification.read ? 'font-bold text-gray-900' : 'font-medium text-gray-700'}`}>
                            {notification.title}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">{notification.description}</p>
                          <div className="flex items-center gap-1 mt-2 text-[10px] text-gray-400">
                            <Clock size={10} />
                            <span>Hace {notification.time}</span>
                          </div>
                        </div>
                        {!notification.read && (
                          <button 
                            onClick={(e) => markAsRead(notification.id, e)}
                            className="text-blue-600 hover:text-blue-800 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                            title="Marcar como leído"
                          >
                            <Check size={14} />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-3 border-t border-gray-100 bg-gray-50 text-center">
              <Link 
                to="/notifications" 
                onClick={() => setIsOpen(false)}
                className="text-sm font-semibold text-blue-600 hover:text-blue-800 block w-full py-1"
              >
                Ver todas las notificaciones
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NotificationBell;
