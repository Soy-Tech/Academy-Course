
import React from 'react';
import { cn } from '@/lib/utils';
// Re-exporting shadcn/ui Card components for consistent import path
import {
  Card as ShadcnCard,
  CardHeader as ShadcnCardHeader,
  CardTitle as ShadcnCardTitle,
  CardDescription as ShadcnCardDescription,
  CardContent as ShadcnCardContent,
  CardFooter as ShadcnCardFooter,
} from '@/components/ui/card';

// Custom Card wrapper that applies hover effect by default
const Card = ({ className, children, hoverEffect = true, ...props }) => {
  return (
    <ShadcnCard
      className={cn(
        "rounded-xl border border-gray-200 shadow-sm overflow-hidden",
        hoverEffect && "hover:shadow-lg hover:-translate-y-1 transition-all duration-300",
        className
      )}
      {...props}
    >
      {children}
    </ShadcnCard>
  );
};

export {
  Card,
  ShadcnCardHeader as CardHeader,
  ShadcnCardTitle as CardTitle,
  ShadcnCardDescription as CardDescription,
  ShadcnCardContent as CardContent,
  ShadcnCardFooter as CardFooter,
};
