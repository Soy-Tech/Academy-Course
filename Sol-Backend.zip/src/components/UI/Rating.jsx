
import React from 'react';
import { Star, StarHalf } from 'lucide-react';

const Rating = ({ rating = 0, count, showCount = true, size = 'sm' }) => {
  const starSize = size === 'lg' ? 20 : size === 'md' ? 16 : 14;
  
  return (
    <div className="flex items-center gap-1">
      <div className="flex text-yellow-400">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star 
            key={star} 
            size={starSize} 
            className={`${star <= Math.round(rating) ? 'fill-current' : 'text-gray-300'}`} 
          />
        ))}
      </div>
      {showCount && count !== undefined && (
        <span className={`text-gray-500 ${size === 'lg' ? 'text-base' : 'text-xs'} ml-1`}>
          ({count})
        </span>
      )}
    </div>
  );
};

export default Rating;
