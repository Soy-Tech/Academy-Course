
import React, { useState } from 'react';
import { Filter, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';

const FilterSection = ({ title, options, selected, onChange }) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="border-b border-gray-100 py-4 last:border-0">
      <button 
        className="flex items-center justify-between w-full mb-2"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-semibold text-gray-900 text-sm">{title}</span>
        {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </button>
      
      {isOpen && (
        <div className="space-y-2 mt-2">
          {options.map((option) => (
            <div key={option.value} className="flex items-center space-x-2">
              <Checkbox 
                id={`${title}-${option.value}`} 
                checked={selected.includes(option.value)}
                onCheckedChange={() => onChange(option.value)}
              />
              <label 
                htmlFor={`${title}-${option.value}`}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 text-gray-600 cursor-pointer select-none"
              >
                {option.label}
              </label>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const FilterSidebar = ({ filters, onFilterChange, onClear }) => {
  const categories = [
    { label: 'Programación', value: 'Programación' },
    { label: 'IA y Datos', value: 'IA y Datos' },
    { label: 'Ciberseguridad', value: 'Ciberseguridad' },
    { label: 'Diseño', value: 'Diseño' },
    { label: 'Marketing', value: 'Marketing' }
  ];

  const levels = [
    { label: 'Principiante', value: 'Principiante' },
    { label: 'Intermedio', value: 'Intermedio' },
    { label: 'Avanzado', value: 'Avanzado' }
  ];

  const prices = [
    { label: 'Gratis', value: 'free' },
    { label: 'De pago', value: 'paid' }
  ];

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-100">
        <h3 className="font-bold text-gray-900 flex items-center gap-2">
          <Filter size={18} /> Filtros
        </h3>
        <button 
          onClick={onClear}
          className="text-xs text-blue-600 hover:text-blue-800 font-medium hover:underline"
        >
          Limpiar todo
        </button>
      </div>

      <div className="space-y-1">
        <FilterSection 
          title="Categoría" 
          options={categories} 
          selected={filters.categories || []}
          onChange={(val) => onFilterChange('categories', val)}
        />
        <FilterSection 
          title="Nivel" 
          options={levels} 
          selected={filters.levels || []}
          onChange={(val) => onFilterChange('levels', val)}
        />
        <FilterSection 
          title="Precio" 
          options={prices} 
          selected={filters.prices || []}
          onChange={(val) => onFilterChange('prices', val)}
        />
      </div>
    </div>
  );
};

export default FilterSidebar;
