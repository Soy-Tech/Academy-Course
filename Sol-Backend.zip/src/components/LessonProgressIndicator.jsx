
import React from 'react';
import { CheckCircle2, PlayCircle, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';

const LessonProgressIndicator = ({ isCompleted, type, className }) => {
  const TypeIcon = type === 'video' ? PlayCircle : FileText;

  return (
    <div className={cn("relative flex items-center justify-center w-8 h-8", className)}>
      {isCompleted ? (
        <div className="absolute inset-0 flex items-center justify-center animate-in zoom-in duration-200 text-green-600">
          <CheckCircle2 className="w-5 h-5 fill-white" />
        </div>
      ) : (
        <div className="absolute inset-0 flex items-center justify-center text-gray-400">
           <TypeIcon className="w-5 h-5" />
        </div>
      )}
    </div>
  );
};

export default LessonProgressIndicator;
