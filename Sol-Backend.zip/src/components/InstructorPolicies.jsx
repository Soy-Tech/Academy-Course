
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Copyright, Video, FileText, CheckCircle, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';

const PolicyItem = ({ icon: Icon, title, description }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border border-gray-200 rounded-lg mb-3 overflow-hidden bg-white">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-full text-[#0B3D91]">
            <Icon size={20} />
          </div>
          <span className="font-semibold text-gray-800">{title}</span>
        </div>
        {isOpen ? <ChevronUp size={18} className="text-gray-500" /> : <ChevronDown size={18} className="text-gray-500" />}
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-4 text-gray-600 text-sm leading-relaxed border-t border-gray-100">
              {description}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const InstructorPolicies = () => {
  const policies = [
    {
      icon: Copyright,
      title: "Derechos de Autor y Originalidad",
      description: "Todo el contenido subido debe ser 100% original creado por ti. No se permite el uso de material protegido por derechos de autor de terceros sin licencia explícita. Netcom se toma muy en serio la propiedad intelectual."
    },
    {
      icon: Video,
      title: "Calidad de Audio y Video",
      description: "Los cursos deben cumplir con estándares mínimos de calidad: Video HD (720p mínimo, 1080p recomendado), audio claro sin ruido de fondo, y buena iluminación. Contenidos de baja calidad técnica serán rechazados."
    },
    {
      icon: Shield,
      title: "Cumplimiento de la Plataforma",
      description: "Debes adherirte a nuestros términos de servicio. No se permite redirigir a los estudiantes a plataformas externas de pago, ni recopilar datos personales sin consentimiento explícito."
    },
    {
      icon: FileText,
      title: "Responsabilidad del Contenido",
      description: "Como instructor, eres responsable de la exactitud y actualización de tu material. Debes estar dispuesto a responder preguntas de los estudiantes en los foros del curso."
    },
    {
      icon: AlertTriangle,
      title: "Contenido Prohibido",
      description: "Está estrictamente prohibido el contenido ofensivo, discriminatorio, sexualmente explícito, político extremista o que promueva actividades ilegales. Tolerancia cero."
    }
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <h3 className="text-xl font-bold text-[#0B3D91] mb-2 flex items-center gap-2">
        <Shield className="text-[#CFAE70]" /> Políticas de Instructor
      </h3>
      <p className="text-gray-500 text-sm mb-6">Por favor revisa cuidadosamente nuestras normas antes de aplicar.</p>
      
      <div className="space-y-1">
        {policies.map((policy, index) => (
          <PolicyItem key={index} {...policy} />
        ))}
      </div>
    </div>
  );
};

export default InstructorPolicies;
