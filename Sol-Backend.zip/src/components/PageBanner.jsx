
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const PageBanner = ({ 
  title, 
  subtitle, 
  badges = [], 
  cta = null, 
  backgroundImage, 
  height = "h-[350px] md:h-[450px]" 
}) => {
  return (
    <section className={`relative w-full ${height} flex items-center justify-center overflow-hidden`}>
      {/* Background Image */}
      {backgroundImage && (
        <div className="absolute inset-0 z-0">
          <img 
            src={backgroundImage} 
            alt={title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0B3D91]/95 to-[#082d6b]/80 mix-blend-multiply" />
          <div className="absolute inset-0 bg-black/20" />
        </div>
      )}

      {!backgroundImage && (
         <div className="absolute inset-0 z-0 bg-gradient-to-br from-[#0B3D91] to-[#0F172A]" />
      )}

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="max-w-4xl mx-auto"
        >
          {badges.length > 0 && (
            <div className="flex flex-wrap justify-center gap-2 mb-6">
              {badges.map((badge, index) => (
                <span 
                  key={index} 
                  className="bg-[#CFAE70]/20 text-[#CFAE70] border border-[#CFAE70]/40 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-sm"
                >
                  {badge}
                </span>
              ))}
            </div>
          )}

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight tracking-tight drop-shadow-lg">
            {title}
          </h1>

          {subtitle && (
            <p className="text-lg md:text-xl text-gray-100 mb-8 max-w-2xl mx-auto font-medium leading-relaxed drop-shadow-md opacity-95">
              {subtitle}
            </p>
          )}

          {cta && (
            <div className="flex justify-center">
               <Button 
                 onClick={cta.onClick}
                 className="bg-[#CFAE70] hover:bg-[#b89a5f] text-white font-bold py-6 px-8 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 text-base group"
               >
                 {cta.label}
                 <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
               </Button>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
};

export default PageBanner;
