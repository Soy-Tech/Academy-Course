
import React from 'react';
import { ThumbsUp, Shield, Check, Award } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useForums } from '@/hooks/useForums';

const ForumReplyCard = ({ reply, isTopicAuthor, isAccepted }) => {
  const { getUsers } = useForums();
  const author = getUsers().find(u => u.id === reply.authorId);
  const isInstructor = author?.role === 'instructor' || author?.role === 'admin';

  return (
    <div className={cn(
      "p-6 rounded-xl border transition-all relative",
      isAccepted ? "bg-green-50 border-green-200" : "bg-white border-gray-100"
    )}>
      {isAccepted && (
        <div className="absolute -top-3 right-6 bg-green-600 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 shadow-sm">
          <Check size={12} strokeWidth={3} />
          SOLUCIÓN ACEPTADA
        </div>
      )}

      <div className="flex gap-4">
        <div className="flex flex-col items-center gap-2">
          <div className={cn(
            "w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm",
            isInstructor ? "bg-purple-600" : "bg-gray-400"
          )}>
            {author?.avatar || 'U'}
          </div>
          {isInstructor && (
            <span className="text-[10px] bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded font-bold border border-purple-200">
              STAFF
            </span>
          )}
        </div>

        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="font-bold text-gray-900 mr-2">{author?.name}</span>
              <span className="text-xs text-gray-400">
                {new Date(reply.createdAt).toLocaleDateString()}
              </span>
            </div>
            {isTopicAuthor && (
              <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-bold border border-blue-100">
                AUTOR
              </span>
            )}
          </div>

          <div className="prose prose-sm max-w-none text-gray-700 mb-4">
            <p>{reply.content}</p>
          </div>

          <div className="flex items-center gap-4 border-t border-gray-100/50 pt-3">
            <button className="flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-[#0B3D91] transition-colors">
              <ThumbsUp size={14} />
              {reply.likes} Útil
            </button>
            <button className="flex items-center gap-1.5 text-xs font-medium text-gray-400 hover:text-red-500 transition-colors ml-auto">
              <Shield size={14} />
              Reportar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForumReplyCard;
