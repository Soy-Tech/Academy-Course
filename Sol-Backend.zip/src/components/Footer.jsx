import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
  ];

  return (
    <footer className="bg-[#0B1120] text-gray-300 font-sans border-t border-gray-800">
      <div className="container mx-auto px-6 py-12">
        {/* Main Footer Content - 4 Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          
          {/* Column 1: Brand & Desc */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#0B3D91] rounded-[4px] flex items-center justify-center">
                <span className="text-white font-bold text-lg">N</span>
              </div>
              <span className="text-xl font-bold text-white tracking-tight">Netcom</span>
            </Link>
            <p className="text-sm leading-relaxed text-gray-400 max-w-xs">
              Transformando el futuro a través de la educación tecnológica de calidad. Únete a nuestra comunidad de expertos y aprendices.
            </p>
            <div className="flex gap-3 pt-2">
              {socialLinks.map((social) => (
                <a 
                  key={social.label}
                  href={social.href}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-800 text-gray-400 hover:bg-white hover:text-[#0B1120] transition-all duration-300"
                  aria-label={social.label}
                >
                  <social.icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Column 2: Academia */}
          <div>
            <h3 className="text-white font-bold text-base mb-4">Academia</h3>
            <ul className="space-y-2.5">
              <li><Link to="/cursos" className="text-sm text-gray-400 hover:text-white transition-colors">Todos los Cursos</Link></li>
              <li><Link to="/learning-paths" className="text-sm text-gray-400 hover:text-white transition-colors">Rutas de Aprendizaje</Link></li>
              <li><Link to="/store" className="text-sm text-gray-400 hover:text-white transition-colors">Tienda Oficial</Link></li>
              <li><Link to="/recursos-gratuitos" className="text-sm text-gray-400 hover:text-white transition-colors">Recursos Gratuitos</Link></li>
            </ul>
          </div>

          {/* Column 3: Comunidad */}
          <div>
            <h3 className="text-white font-bold text-base mb-4">Comunidad</h3>
            <ul className="space-y-2.5">
              <li><Link to="/forums" className="text-sm text-gray-400 hover:text-white transition-colors">Foros de Discusión</Link></li>
              <li><Link to="/blog" className="text-sm text-gray-400 hover:text-white transition-colors">Blog Tech</Link></li>
              <li><Link to="/eventos-webinars" className="text-sm text-gray-400 hover:text-white transition-colors">Eventos y Webinars</Link></li>
              <li><Link to="/about" className="text-sm text-gray-400 hover:text-white transition-colors">Sobre Nosotros</Link></li>
              <li><Link to="/contact" className="text-sm text-gray-400 hover:text-white transition-colors">Contacto</Link></li>
            </ul>
          </div>

          {/* Column 4: Soporte */}
          <div>
            <h3 className="text-white font-bold text-base mb-4">Soporte</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm text-gray-400">
                <Mail size={16} className="text-[#3b82f6] mt-0.5" />
                <span>soporte@netcom.academy</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-gray-400">
                <Phone size={16} className="text-[#3b82f6] mt-0.5" />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-gray-400">
                <MapPin size={16} className="text-[#3b82f6] mt-0.5" />
                <span>Ciudad Tecnológica, Edificio Innovation, Piso 4</span>
              </li>
              <li className="pt-2">
                <Link to="/help" className="text-sm font-medium text-white bg-gray-800 hover:bg-[#0B3D91] px-3 py-1.5 rounded-[4px] transition-all duration-300 inline-flex items-center gap-2">
                   Centro de Ayuda
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="border-t border-gray-800 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-500">
          <p>© {currentYear} Netcom Academy. Todos los derechos reservados.</p>
          <div className="flex gap-6">
            <Link to="/privacy" className="hover:text-white transition-colors">Política de Privacidad</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Términos de Servicio</Link>
            <Link to="/legal" className="hover:text-white transition-colors">Legal</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;