
import React from 'react';
import CourseCard from './CourseCard';
import { CardSkeleton } from '@/components/States/LoadingState';
import EmptyState from '@/components/States/EmptyState';
import ErrorState from '@/components/States/ErrorState';

const CourseGrid = ({ courses, loading, error, emptyTitle, emptyMsg }) => {
  if (loading) {
    return <CardSkeleton count={6} />;
  }

  if (error) {
    return <ErrorState />;
  }

  if (!courses || courses.length === 0) {
    return <EmptyState type="search" title={emptyTitle} description={emptyMsg} />;
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {courses.map((course) => (
        <CourseCard key={course.id} course={course} />
      ))}
    </div>
  );
};

export default CourseGrid;
