
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, Users, BookOpen, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Badge from '@/components/UI/Badge';
import Rating from '@/components/UI/Rating';
import { useCart } from '@/hooks/useCart';

const CourseCard = ({ course }) => {
  const { addToCart } = useCart();
  
  // Handle case where course data might be missing structure
  if (!course) return null;
  
  const {
    id,
    title,
    instructor = 'Instructor Netcom',
    price,
    image,
    rating = 0,
    reviews = 0,
    duration = '0h',
    level = 'Principiante',
    category
  } = course;

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    // Use addToCart from hook
    addToCart({ 
      id, 
      title, 
      price: typeof price === 'string' ? parseFloat(price.replace(/[^0-9.]/g, '')) : price,
      image,
      quantity: 1
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.2 }}
      className="group bg-white rounded-xl overflow-hidden border border-gray-200 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full"
    >
      <Link to={`/cursos/${id}`} className="relative block aspect-video overflow-hidden">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
           {category && <Badge variant="primary" size="sm">{category}</Badge>}
        </div>
      </Link>

      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <Badge variant={level === 'Avanzado' ? 'advanced' : level === 'Intermedio' ? 'intermediate' : 'beginner'} size="sm">
            {level}
          </Badge>
          <div className="flex items-center text-gray-500 text-xs">
            <Clock size={12} className="mr-1" />
            {duration}
          </div>
        </div>

        <Link to={`/cursos/${id}`} className="block mb-2 flex-grow">
          <h3 className="font-bold text-gray-900 leading-tight group-hover:text-blue-600 transition-colors line-clamp-2">
            {title}
          </h3>
        </Link>

        <p className="text-xs text-gray-500 mb-3 line-clamp-1">Por {instructor}</p>

        <div className="flex items-center mb-4">
          <span className="font-bold text-yellow-500 text-sm mr-1">{rating}</span>
          <Rating rating={rating} count={reviews} showCount={true} />
        </div>

        <div className="border-t border-gray-100 pt-3 mt-auto flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-lg font-bold text-gray-900">
               {typeof price === 'number' ? `$${price}` : price}
            </span>
          </div>
          <Button 
            size="sm" 
            className="rounded-full w-10 h-10 p-0 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-colors"
            onClick={handleAddToCart}
          >
            <ShoppingCart size={18} />
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default CourseCard;
