
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Clock, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const EventCard = ({ event, delay }) => {
  const eventDate = new Date(event.date);
  const now = new Date();
  
  // Determine event status
  let status = 'upcoming';
  if (eventDate < now) {
    status = 'past';
  } else if (eventDate.toDateString() === now.toDateString()) {
    status = 'live';
  }

  const statusConfig = {
    upcoming: { label: 'Próximo', className: 'bg-blue-100 text-blue-700 border-blue-200' },
    live: { label: 'En Vivo', className: 'bg-red-100 text-red-700 border-red-200 animate-pulse' },
    past: { label: 'Pasado', className: 'bg-gray-100 text-gray-500 border-gray-200' }
  };

  const currentStatus = statusConfig[status];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className="bg-white rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.06)] hover:shadow-[0_12px_24px_rgba(0,0,0,0.12)] transition-all duration-300 overflow-hidden border border-gray-100 flex flex-col h-full group"
    >
      <div className="p-6 md:p-8 flex flex-col h-full">
        <div className="flex justify-between items-start mb-6">
          <div className="flex flex-col items-center bg-gray-50 rounded-lg p-3 border border-gray-100 min-w-[70px]">
            <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">
              {eventDate.toLocaleDateString('es-ES', { month: 'short' }).replace('.', '')}
            </span>
            <span className="text-2xl font-bold text-[#0B3D91] leading-none mt-1">
              {eventDate.getDate()}
            </span>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-bold border ${currentStatus.className}`}>
            {currentStatus.label}
          </span>
        </div>

        <h3 className="text-xl font-bold text-[#1a1a1a] mb-3 group-hover:text-[#0B3D91] transition-colors line-clamp-2">
          {event.title}
        </h3>

        <p className="text-[#666] text-[15px] mb-6 line-clamp-2 flex-grow">
          {event.description}
        </p>

        <div className="space-y-3 mb-6 border-t border-gray-50 pt-4">
          <div className="flex items-center gap-2.5 text-sm text-gray-500">
            <Clock size={16} className="text-[#CFAE70]" />
            <span>{eventDate.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })} hrs</span>
          </div>
          <div className="flex items-center gap-2.5 text-sm text-gray-500">
            <MapPin size={16} className="text-[#CFAE70]" />
            <span className="truncate">{event.location}</span>
          </div>
        </div>

        <div className="mt-auto">
          <Link to={`/events/${event.id}`} className="block">
            <Button className="w-full bg-[#0B3D91] hover:bg-[#082d6b] text-white font-semibold h-11 transition-all shadow-sm hover:shadow-md">
              {status === 'past' ? 'Ver grabación' : 'Registrarse ahora'}
              <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default EventCard;
