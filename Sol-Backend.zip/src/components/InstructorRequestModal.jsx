
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle, XCircle, User, Mail, Briefcase, FileText, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const InstructorRequestModal = ({ request, isOpen, onClose, onApprove, onReject }) => {
  const [rejectMode, setRejectMode] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [processing, setProcessing] = useState(false);

  if (!request) return null;

  const handleApprove = async () => {
    setProcessing(true);
    try {
      await onApprove(request.id, request.email, request.fullName);
      onClose();
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!rejectionReason.trim()) return;
    setProcessing(true);
    try {
      await onReject(request.id, rejectionReason, request.email, request.fullName);
      onClose();
    } finally {
      setProcessing(false);
    }
  };

  const StatusBadge = ({ status }) => {
    const styles = {
      pending: "bg-yellow-100 text-yellow-800",
      approved: "bg-green-100 text-green-800",
      rejected: "bg-red-100 text-red-800"
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${styles[status]}`}>
        {status === 'pending' ? 'Pendiente' : status === 'approved' ? 'Aprobado' : 'Rechazado'}
      </span>
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          />
          
          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white rounded-xl shadow-xl flex flex-col"
          >
            <div className="p-6">
              {/* Header */}
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-[#0B3D91] flex items-center gap-3">
                    Solicitud de Instructor
                    <StatusBadge status={request.status} />
                  </h2>
                  <p className="text-sm text-gray-500 mt-1">
                    Enviado el {new Date(request.createdAt).toLocaleDateString()} a las {new Date(request.createdAt).toLocaleTimeString()}
                  </p>
                </div>
                <button 
                  onClick={onClose}
                  className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-full hover:bg-gray-100"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                {/* Personal Info */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-500 mb-1">
                      <User size={16} /> <span className="text-xs font-bold uppercase">Nombre</span>
                    </div>
                    <p className="font-semibold text-gray-900">{request.fullName}</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-gray-500 mb-1">
                      <Mail size={16} /> <span className="text-xs font-bold uppercase">Email</span>
                    </div>
                    <p className="font-semibold text-gray-900">{request.email}</p>
                  </div>
                </div>

                {/* Long Text Fields */}
                <div>
                  <div className="flex items-center gap-2 text-[#0B3D91] mb-2 font-semibold">
                    <Briefcase size={18} /> Experiencia Profesional
                  </div>
                  <div className="bg-white border border-gray-200 p-4 rounded-lg text-gray-700 whitespace-pre-wrap text-sm">
                    {request.experience}
                  </div>
                </div>

                <div>
                  <div className="flex items-center gap-2 text-[#0B3D91] mb-2 font-semibold">
                    <FileText size={18} /> Motivación
                  </div>
                  <div className="bg-white border border-gray-200 p-4 rounded-lg text-gray-700 whitespace-pre-wrap text-sm">
                    {request.motivation}
                  </div>
                </div>

                {/* Rejection Details if rejected */}
                {request.status === 'rejected' && request.rejectionReason && (
                  <div className="bg-red-50 border border-red-100 p-4 rounded-lg">
                     <h4 className="text-red-800 font-bold text-sm mb-1">Motivo del rechazo:</h4>
                     <p className="text-red-600 text-sm">{request.rejectionReason}</p>
                  </div>
                )}

                {/* Actions - Only for Pending */}
                {request.status === 'pending' && (
                  <div className="border-t border-gray-100 pt-6 mt-2">
                    {!rejectMode ? (
                      <div className="flex justify-end gap-3">
                        <Button variant="outline" onClick={() => setRejectMode(true)} className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700">
                          <XCircle className="mr-2 h-4 w-4" /> Rechazar
                        </Button>
                        <Button onClick={handleApprove} disabled={processing} className="bg-green-600 hover:bg-green-700 text-white">
                          {processing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
                          Aprobar Solicitud
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4 bg-red-50 p-4 rounded-lg border border-red-100">
                        <h4 className="font-bold text-red-800 text-sm">Rechazar Solicitud</h4>
                        <div className="space-y-2">
                          <label htmlFor="reason" className="text-sm font-medium text-red-700">Motivo del rechazo (se enviará por correo)</label>
                          <textarea 
                            id="reason"
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                            className="w-full p-2 border border-red-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-500/20"
                            rows={3}
                            placeholder="Indica por qué se rechaza la solicitud..."
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" onClick={() => setRejectMode(false)} size="sm">Cancelar</Button>
                          <Button 
                            variant="destructive" 
                            size="sm" 
                            onClick={handleReject}
                            disabled={!rejectionReason.trim() || processing}
                          >
                            {processing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Confirmar Rechazo"}
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default InstructorRequestModal;
