
import React from 'react';
import { motion } from 'framer-motion';
import useIntersectionObserver from '@/hooks/useIntersectionObserver';

const ScrollFadeIn = ({ 
  children, 
  delay = 0, 
  duration = 0.6, 
  className = "", 
  direction = 'up', // 'up', 'down', 'left', 'right'
  distance = 20
}) => {
  const { elementRef, isVisible } = useIntersectionObserver();

  const getInitial = () => {
    switch (direction) {
      case 'down': return { opacity: 0, y: -distance };
      case 'left': return { opacity: 0, x: distance };
      case 'right': return { opacity: 0, x: -distance };
      case 'up':
      default: return { opacity: 0, y: distance };
    }
  };

  const getAnimate = () => {
    switch (direction) {
      case 'down': case 'up': return { opacity: 1, y: 0 };
      case 'left': case 'right': return { opacity: 1, x: 0 };
      default: return { opacity: 1, y: 0 };
    }
  };

  return (
    <div ref={elementRef} className={className}>
      <motion.div
        initial={getInitial()}
        animate={isVisible ? getAnimate() : getInitial()}
        transition={{ 
          duration, 
          delay, 
          ease: "easeOut" 
        }}
      >
        {children}
      </motion.div>
    </div>
  );
};

export default ScrollFadeIn;
