
import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ReviewForm = ({ onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (rating === 0) {
      toast({ title: "Error", description: "Por favor selecciona una calificación.", variant: "destructive" });
      return;
    }
    if (comment.length < 10) {
      toast({ title: "Error", description: "El comentario debe tener al menos 10 caracteres.", variant: "destructive" });
      return;
    }

    if (onSubmit) {
      onSubmit({ rating, comment, date: new Date().toISOString() });
    }
    
    toast({ title: "Reseña enviada", description: "¡Gracias por tu opinión!" });
    setRating(0);
    setComment('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 p-6 rounded-xl border border-gray-200">
      <h3 className="font-bold text-lg mb-4 text-gray-900">Escribe una reseña</h3>
      
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">Calificación</label>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              className="focus:outline-none transition-transform hover:scale-110"
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(star)}
            >
              <Star 
                size={24} 
                className={`${
                  star <= (hoverRating || rating) 
                    ? 'fill-yellow-400 text-yellow-400' 
                    : 'text-gray-300'
                } transition-colors`} 
              />
            </button>
          ))}
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">Tu comentario</label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          maxLength={500}
          rows={4}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
          placeholder="¿Qué te pareció este curso?"
        />
        <div className="flex justify-end mt-1">
          <span className="text-xs text-gray-500">{comment.length}/500</span>
        </div>
      </div>

      <Button 
        type="submit" 
        className="w-full bg-blue-600 hover:bg-blue-700"
        disabled={rating === 0 || comment.length < 10}
      >
        Enviar Reseña
      </Button>
    </form>
  );
};

export default ReviewForm;
