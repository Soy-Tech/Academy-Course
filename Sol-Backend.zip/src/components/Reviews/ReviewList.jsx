
import React, { useState, useMemo, memo } from 'react';
import { Star, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import LazyImage from '@/components/LazyImage';
import ScrollFadeIn from '@/components/ScrollFadeIn';

const ReviewItem = memo(({ review }) => (
  <ScrollFadeIn>
    <article className="border-b border-gray-100 pb-6 last:border-0 last:pb-0">
      <div className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-full bg-blue-100 overflow-hidden flex-shrink-0">
          {review.user?.avatar ? (
             <LazyImage src={review.user.avatar} alt={review.user.name} />
          ) : (
             <div className="w-full h-full flex items-center justify-center text-blue-600 font-bold">
               {review.user?.name?.charAt(0) || 'U'}
             </div>
          )}
        </div>
        <div className="flex-1">
          <header className="flex justify-between items-start mb-1">
            <div>
              <h4 className="font-bold text-gray-900 text-sm">{review.user?.name || 'Usuario'}</h4>
              <div className="flex items-center gap-2 text-xs text-gray-500" aria-label={`Calificado con ${review.rating} de 5 estrellas`}>
                <div className="flex text-yellow-400" aria-hidden="true">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={12} className={i < review.rating ? "fill-current" : "text-gray-300"} />
                  ))}
                </div>
                <span aria-hidden="true">•</span>
                <time dateTime={review.date}>{review.date}</time>
              </div>
            </div>
          </header>
          
          <p className="text-gray-600 text-sm mt-2 leading-relaxed">{review.comment}</p>
          
          <div className="flex items-center gap-4 mt-3">
            <button className="flex items-center gap-1 text-xs text-gray-500 hover:text-blue-600 transition-colors" aria-label={`Marcar como útil (${review.helpful || 0})`}>
              <ThumbsUp size={14} aria-hidden="true" /> Útil ({review.helpful || 0})
            </button>
            <button className="flex items-center gap-1 text-xs text-gray-500 hover:text-red-600 transition-colors" aria-label="Marcar como no útil">
              <ThumbsDown size={14} aria-hidden="true" /> No útil
            </button>
          </div>

          {review.reply && (
            <div className="mt-4 bg-gray-50 p-4 rounded-lg border-l-4 border-blue-500">
              <div className="flex items-center gap-2 mb-2">
                <span className="font-bold text-xs text-blue-700">Respuesta del Instructor</span>
                <span className="text-xs text-gray-400" aria-hidden="true">•</span>
                <time className="text-xs text-gray-400">{review.replyDate}</time>
              </div>
              <p className="text-sm text-gray-600">{review.reply}</p>
            </div>
          )}
        </div>
      </div>
    </article>
  </ScrollFadeIn>
));

ReviewItem.displayName = 'ReviewItem';

const ReviewList = ({ reviews = [] }) => {
  const [page, setPage] = useState(1);
  const reviewsPerPage = 5;
  
  const sortedReviews = useMemo(() => {
    return [...reviews].sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [reviews]);

  const totalPages = Math.ceil(sortedReviews.length / reviewsPerPage);
  
  const currentReviews = useMemo(() => {
    return sortedReviews.slice((page - 1) * reviewsPerPage, page * reviewsPerPage);
  }, [sortedReviews, page]);

  if (!reviews || reviews.length === 0) {
    return (
      <div className="text-center py-10 text-gray-500 bg-gray-50 rounded-xl" role="status">
        No hay reseñas todavía. ¡Sé el primero en opinar!
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {currentReviews.map((review) => (
        <ReviewItem key={review.id} review={review} />
      ))}

      {totalPages > 1 && (
        <nav className="flex justify-center gap-2 mt-6" aria-label="Navegación de reseñas">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            aria-label="Página anterior"
          >
            Anterior
          </Button>
          <span className="text-sm flex items-center px-2 text-gray-500" aria-current="page">
            Página {page} de {totalPages}
          </span>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            aria-label="Página siguiente"
          >
            Siguiente
          </Button>
        </nav>
      )}
    </div>
  );
};

export default ReviewList;
