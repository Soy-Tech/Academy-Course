
import React from 'react';
import { PlayCircle, CheckCircle, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

const VideoList = ({ videos, currentVideoId, onVideoSelect }) => {
  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm h-full flex flex-col">
      <div className="p-4 border-b border-gray-100 bg-gray-50">
        <h3 className="font-bold text-gray-900">Contenido del Curso</h3>
        <p className="text-xs text-gray-500 mt-1">{videos.length} videos • {videos.reduce((acc, v) => acc + v.duration, 0)} mins total</p>
      </div>
      
      <div className="overflow-y-auto flex-1 p-2 space-y-2 max-h-[500px] lg:max-h-none">
        {videos.map((video, index) => {
          const isActive = currentVideoId === video.id;
          const isLocked = !video.isActive; // Assuming inactive means locked for demo logic
          
          return (
            <button
              key={video.id}
              onClick={() => !isLocked && onVideoSelect(video)}
              disabled={isLocked}
              className={cn(
                "w-full flex items-start gap-3 p-3 rounded-lg text-left transition-all duration-200 group relative",
                isActive ? "bg-[#0B3D91]/5 border border-[#0B3D91]/20" : "hover:bg-gray-50 border border-transparent",
                isLocked && "opacity-60 cursor-not-allowed grayscale"
              )}
            >
              <div className="relative flex-shrink-0 w-24 h-16 bg-gray-200 rounded overflow-hidden">
                <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                {isLocked && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                        <Lock size={16} className="text-white" />
                    </div>
                )}
                {!isLocked && isActive && (
                    <div className="absolute inset-0 flex items-center justify-center bg-[#0B3D91]/40">
                         <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-[#0B3D91] rounded-full animate-pulse" />
                         </div>
                    </div>
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className={cn(
                    "text-sm font-medium line-clamp-2 mb-1 group-hover:text-[#0B3D91] transition-colors",
                    isActive ? "text-[#0B3D91]" : "text-gray-900"
                )}>
                    {index + 1}. {video.title}
                </h4>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                        <PlayCircle size={12} /> {video.duration} min
                    </span>
                    {video.completed && <CheckCircle size={12} className="text-green-500" />}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default VideoList;
