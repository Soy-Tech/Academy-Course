
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useEnrollment } from '@/hooks/useEnrollment';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Loader2, PlayCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const EnrollButton = ({ courseId, courseName, onEnrollSuccess, className }) => {
  const { currentUser } = useAuth();
  const { isEnrolled, enrollCourse } = useEnrollment();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const enrolled = isEnrolled(courseId);

  const handleEnroll = async () => {
    if (!currentUser) {
      // Redirect to login with return url
      navigate(`/login?redirect=/cursos/${courseId}`);
      return;
    }

    if (enrolled) {
      // Already enrolled logic (optional: navigate to content)
      return;
    }

    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      enrollCourse(courseId);
      setIsLoading(false);
      if (onEnrollSuccess) onEnrollSuccess();
    }, 1500);
  };

  return (
    <div className={className}>
      <AnimatePresence mode="wait">
        {enrolled ? (
          <motion.div
            key="enrolled"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
             <Button 
                variant="outline" 
                className="w-full bg-green-50 text-green-700 border-green-200 hover:bg-green-100 hover:text-green-800 font-semibold h-12 text-base"
                disabled
              >
                <CheckCircle2 className="mr-2 h-5 w-5" />
                Inscrito
              </Button>
          </motion.div>
        ) : (
          <motion.div
            key="enroll"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            <Button
              onClick={handleEnroll}
              disabled={isLoading}
              className="w-full bg-[#CFAE70] hover:bg-[#b89a5f] text-white font-bold shadow-lg hover:shadow-xl transition-all duration-300 h-12 text-lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Procesando...
                </>
              ) : (
                <>
                  {!currentUser ? 'Inicia sesión para inscribirte' : 'Inscribirme ahora'}
                </>
              )}
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default EnrollButton;
