
import React from 'react';
import { usePreviewAuth } from '@/contexts/PreviewAuthContext';
import { ROLES } from '@/utils/rolePermissions';
import { Eye, ChevronDown, User, Shield, Briefcase, GraduationCap } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';

const PreviewRoleSelector = () => {
  const { currentRole, switchRole } = usePreviewAuth();

  const roleConfig = {
    [ROLES.STUDENT]: { label: 'Student', icon: GraduationCap, color: 'text-blue-600', bg: 'bg-blue-100' },
    [ROLES.INSTRUCTOR]: { label: 'Instructor', icon: Briefcase, color: 'text-green-600', bg: 'bg-green-100' },
    [ROLES.ADMIN]: { label: 'Admin', icon: Shield, color: 'text-purple-600', bg: 'bg-purple-100' },
    [ROLES.SUPER_ADMIN]: { label: 'Super Admin', icon: Shield, color: 'text-red-600', bg: 'bg-red-100' },
  };

  const currentConfig = roleConfig[currentRole] || roleConfig[ROLES.STUDENT];
  const Icon = currentConfig.icon;

  return (
    <div className="flex items-center gap-2 mr-2">
      <div className="hidden md:flex items-center gap-1.5 px-2 py-1 bg-yellow-100 text-yellow-800 text-[10px] font-bold uppercase tracking-wider rounded border border-yellow-200">
        <Eye size={12} />
        Preview Mode
      </div>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            size="sm" 
            className="h-9 gap-2 border-dashed border-gray-300 hover:border-blue-400 bg-gray-50/50"
          >
            <div className={`w-5 h-5 rounded-full flex items-center justify-center ${currentConfig.bg}`}>
               <Icon size={12} className={currentConfig.color} />
            </div>
            <span className="text-xs font-semibold text-gray-700 hidden sm:inline-block">
              View as: {currentConfig.label}
            </span>
            <ChevronDown size={14} className="text-gray-400" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuLabel className="text-xs text-gray-500 font-normal">Switch Role</DropdownMenuLabel>
          <DropdownMenuSeparator />
          
          {Object.entries(roleConfig).map(([role, config]) => {
            const RoleIcon = config.icon;
            const isSelected = currentRole === role;
            
            return (
              <DropdownMenuItem 
                key={role}
                onClick={() => switchRole(role)}
                className={`cursor-pointer gap-2 ${isSelected ? 'bg-blue-50 text-blue-700' : ''}`}
              >
                <RoleIcon size={14} className={config.color} />
                <span className="text-sm font-medium">{config.label}</span>
                {isSelected && <span className="ml-auto text-blue-600 text-[10px]">●</span>}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default PreviewRoleSelector;
