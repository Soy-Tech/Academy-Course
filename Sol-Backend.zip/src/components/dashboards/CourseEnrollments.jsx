
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { enrollmentService } from '@/services/enrollmentService';
import { courseService } from '@/services/courseService';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowLeft } from 'lucide-react';
import { Card } from '@/components/UI/Card'; // Import Card, as it was missing from the original component

const CourseEnrollments = () => {
  const { courseId } = useParams();
  const [students, setStudents] = useState([]);
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const [enrollmentData, courseData] = await Promise.all([
          enrollmentService.getEnrollmentsByCourse(courseId),
          courseService.getCourseById(courseId)
        ]);
        setStudents(enrollmentData);
        setCourse(courseData);
      } catch (error) {
        console.error('Error loading enrollment data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (courseId) {
      loadData();
    }
  }, [courseId]);

  if (loading) return <div className="flex justify-center p-12"><Loader2 className="animate-spin" /></div>;

  return (
    <div className="container mx-auto py-8 px-4">
      <Link to="/instructor/dashboard" className="inline-flex items-center text-sm text-gray-500 hover:text-gray-900 mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" /> Volver al Dashboard
      </Link>
      
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Estudiantes Inscritos</h1>
        <p className="text-gray-600">Curso: <span className="font-semibold">{course?.title}</span></p>
      </div>

      {/* Wrapping the table in a Card for consistent styling */}
      <Card hoverEffect={false} className="rounded-lg shadow overflow-hidden">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 text-gray-700 uppercase">
            <tr>
              <th className="px-6 py-3">Nombre</th>
              <th className="px-6 py-3">Email</th>
              <th className="px-6 py-3">Fecha de Inscripción</th>
            </tr>
          </thead>
          <tbody>
            {students.map((enrollment) => (
              <tr key={enrollment.id} className="border-b hover:bg-gray-50">
                <td className="px-6 py-4 font-medium">
                  {enrollment.profiles?.full_name || 'Usuario'}
                </td>
                <td className="px-6 py-4">{enrollment.profiles?.email || 'N/A'}</td>
                <td className="px-6 py-4">
                  {new Date(enrollment.created_at).toLocaleDateString()}
                </td>
              </tr>
            ))}
            {students.length === 0 && (
              <tr>
                <td colSpan="3" className="px-6 py-8 text-center text-gray-500">
                  No hay estudiantes inscritos en este curso.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
};

export default CourseEnrollments;
