
import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Eye, Pin, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useForums } from '@/hooks/useForums';

const ForumTopicCard = ({ topic }) => {
  const { getUserById, getCategories, getReplies } = useForums();
  
  // Fetch associated data
  const author = getUserById(topic.authorId);
  const categories = getCategories();
  const category = categories.find(c => c.id === topic.categoryId);
  const replies = getReplies(topic.id);
  const replyCount = replies.length;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4, boxShadow: "0 4px 16px rgba(0,0,0,0.15)" }}
      transition={{ duration: 0.2 }}
      className={cn(
        "bg-white rounded-xl p-5 mb-4 transition-all duration-200 border relative",
        topic.isPinned ? "border-[#CFAE70]/50 bg-[#CFAE70]/5" : "border-gray-100 shadow-sm"
      )}
      style={{ boxShadow: topic.isPinned ? 'none' : '0 2px 8px rgba(0,0,0,0.05)' }}
    >
      <div className="flex items-start gap-4">
        {/* Author Avatar */}
        <div className="flex-shrink-0">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#082d6b] flex items-center justify-center text-white font-bold text-sm shadow-md ring-2 ring-white">
            {author?.avatar || 'U'}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center flex-wrap gap-2 mb-1.5">
            {topic.isPinned && (
              <span className="bg-[#CFAE70] text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                <Pin size={10} fill="currentColor" /> FIJADO
              </span>
            )}
            <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide border", category?.color || 'bg-gray-100 text-gray-600 border-gray-200')}>
              {category?.name || 'General'}
            </span>
            <span className="text-xs text-gray-400 font-medium">
              {new Date(topic.createdAt).toLocaleDateString()}
            </span>
          </div>

          <Link to={`/forums/${topic.id}`} className="block group">
            <h3 className="text-lg font-bold text-gray-900 group-hover:text-[#0B3D91] transition-colors mb-1.5 leading-tight">
              {topic.title}
            </h3>
          </Link>

          <p className="text-sm text-gray-600 line-clamp-2 mb-3.5 leading-relaxed">
            {topic.content}
          </p>

          <div className="flex items-center justify-between mt-auto pt-2 border-t border-gray-50">
            <div className="flex flex-wrap gap-2">
              {topic.tags && topic.tags.map(tag => (
                <span key={tag} className="text-[11px] font-medium text-gray-500 bg-gray-50 px-2 py-1 rounded border border-gray-100 hover:bg-gray-100 transition-colors">
                  #{tag}
                </span>
              ))}
            </div>

            <div className="flex items-center gap-4 text-xs font-medium text-gray-400 flex-shrink-0 ml-2">
              <div className="flex items-center gap-1.5" title="Vistas">
                <Eye size={14} />
                {topic.views}
              </div>
              <div className={cn("flex items-center gap-1.5", replyCount > 0 ? "text-[#0B3D91]" : "")} title="Respuestas">
                <MessageCircle size={14} />
                {replyCount}
              </div>
              {topic.isSolved && (
                <div className="flex items-center gap-1 text-green-600 bg-green-50 px-2 py-0.5 rounded-full border border-green-100">
                  <CheckCircle size={12} />
                  <span className="text-[10px] font-bold">RESUELTO</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ForumTopicCard;
