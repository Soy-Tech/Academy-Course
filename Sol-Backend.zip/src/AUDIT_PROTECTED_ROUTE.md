
# AUDITORÍA TÉCNICA: ProtectedRoute y Estrategia de Seguridad Frontend

## 1. Contexto del Proyecto
El proyecto actual opera bajo una arquitectura **Frontend-Only** con las siguientes características:
- Framework: React + Vite
- Backend: Simulado (Mock Data / LocalStorage)
- Autenticación: Gestión de estado en cliente (Context + LocalStorage)
- Validación de Roles: Exclusivamente en lado cliente

## 2. Análisis de ProtectedRoute
El componente `ProtectedRoute.jsx` actual funciona interceptando la navegación basada en el estado del `AuthContext`.

### Mecanismo Actual
1. **Verificación de Sesión**: Comprueba si existe un objeto `user` en el contexto.
2. **Validación de Roles**: Si la ruta requiere roles específicos, verifica `user.role`.
3. **Redirección**: Si falla alguna validación, redirige a `/login` o `/access-denied`.

### Limitaciones de Seguridad
Dado que no existe un backend real para validar tokens o sesiones:
- **Seguridad Real**: Nula. Un usuario avanzado puede modificar `localStorage` para simular una sesión.
- **Propósito Real**: UX (Experiencia de Usuario). Previene que usuarios normales accedan a vistas rotas o sin datos.

## 3. Auditoría de Rutas Protegidas

Se ha evaluado la necesidad de protección para cada ruta basada en tres criterios:
1. **Datos Sensibles**: ¿La vista muestra PII (Información Personal Identificable)?
2. **Acción de Escritura**: ¿La vista modifica el estado de la aplicación?
3. **Restricción de Negocio**: ¿Es contenido exclusivo para usuarios registrados?

| Ruta | Estado Anterior | Análisis de Riesgo/Necesidad | Recomendación |
|------|-----------------|------------------------------|---------------|
| `/student/dashboard` | Protegida | **Alto**. Muestra progreso y datos del estudiante. | ✅ Mantener Protegida |
| `/instructor/dashboard` | Protegida | **Alto**. Datos de cursos e ingresos. | ✅ Mantener Protegida |
| `/admin/*` | Protegida | **Alto**. Gestión de usuarios y configuración. | ✅ Mantener Protegida |
| `/profile` | Protegida | **Alto**. Edición de datos personales. | ✅ Mantener Protegida |
| `/notifications` | Protegida | **Medio**. Historial personal de alertas. | ✅ Mantener Protegida |
| `/cart` | Protegida | **Bajo**. El carrito puede ser anónimo. Bloquearlo daña la conversión. | 🔓 **Hacer PÚBLICA** |
| `/checkout` | Protegida | **Bajo**. La compra estándar permite "Guest Checkout". | 🔓 **Hacer PÚBLICA** |
| `/order-confirmation` | Protegida | **Bajo**. Confirmación de transacción. | 🔓 **Hacer PÚBLICA** |
| `/recursos-gratuitos`* | Protegida | **Nulo**. Contenido Lead Magnet. Debe ser accesible. | 🔓 **Hacer PÚBLICA** |
| `/blog-tech`* | Protegida | **Nulo**. Contenido SEO. Debe ser público. | 🔓 **Hacer PÚBLICA** |

*\*Nota: Rutas marcadas con asterisco se identificaron como candidatos a ser públicos si se implementan en el futuro.*

## 4. Estrategia Implementada (Opción C - Híbrida)

Se ha seleccionado la estrategia híbrida que balancea la UX con la conversión:

1. **Rutas de Usuario (Dashboard, Perfil)**: Mantienen `ProtectedRoute` para asegurar que el usuario tenga el contexto necesario cargado.
2. **Rutas de E-commerce (Cart, Checkout)**: Se liberan de `ProtectedRoute` y se mueven al `MainLayout` público. Esto reduce la fricción de compra y permite flujo de usuarios anónimos.
3. **Integración con Layout**: Al mover las rutas de e-commerce a `MainLayout`, ganan automáticamente Header y Footer consistentes, mejorando la coherencia visual.

## 5. Conclusión y Próximos Pasos
La protección actual es suficiente para el prototipo y MVP frontend. Cuando se integre un backend real (Supabase/Firebase):
1. `ProtectedRoute` deberá validar el token de sesión contra el servidor (o verificar su vigencia).
2. Las rutas públicas seguirán siendo públicas.
3. La seguridad real se delegará a las Reglas de Seguridad de la Base de Datos (RLS) y validación de API.
