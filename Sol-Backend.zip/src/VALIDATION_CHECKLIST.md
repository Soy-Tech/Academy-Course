
# Frontend Validation Checklist

## NAVIGATION
- [x] **Home Route**: `/` loads correctly.
- [x] **Courses List**: `/cursos` displays grid and filters.
- [x] **Course Detail**: `/cursos/:id` shows correct data.
- [x] **Lesson View**: `/course/:id/lesson/:id` loads sidebar and player.
- [x] **User Profile**: `/profile` tabs work (Courses, Certs, Settings).
- [x] **Instructor Profile**: `/instructor/:id` shows bio and courses.
- [x] **Cart Flow**: Add to cart -> Cart Page -> Checkout -> Success.
- [x] **Dashboards**: Student, Instructor, and Admin dashboards load.
- [x] **Onboarding**: 4-step flow completes successfully.
- [x] **Error Pages**: 404 and 500 pages accessible and functional.
- [x] **Mobile Menu**: Opens/closes correctly on small screens.
- [x] **Links**: All internal links (Footer/Header) are functional.

## VISUAL STATES
- [x] **Loading**: Skeleton loaders appear during data fetch.
- [x] **Empty**: "No results" states visible for search/cart/notifications.
- [x] **Error**: Form validation errors appear red and distinct.
- [x] **Success**: Green toast/banners appear on successful actions.

## RESPONSIVE DESIGN
- [x] **Mobile (375px)**: No horizontal scroll, readable text.
- [x] **Mobile (414px)**: Layout elements stack correctly.
- [x] **Tablet (768px)**: Grid switches to 2 columns, sidebar appears.
- [x] **Desktop (1024px)**: Full layout, 3-4 column grids.
- [x] **Large (1280px+)**: Content centered with max-width.
- [x] **Touch Targets**: Buttons/links are at least 48px height on mobile.

## ANIMATIONS
- [x] **Page Transitions**: Smooth fade/slide between pages.
- [x] **Hover Effects**: Buttons and cards react to mouseover.
- [x] **Modals**: Smooth entrance and exit animations.
- [x] **Toasts**: Slide in from edge, dismiss smoothly.
- [x] **Performance**: No visible lag or jank during scrolling.

## CONSISTENCY
- [x] **Colors**: All use CSS variables (`--color-primary`, etc.).
- [x] **Spacing**: Consistent margins/padding using Tailwind tokens.
- [x] **Typography**: Hierarchy is maintained (H1 > H2 > H3).
- [x] **Radius**: Consistent rounded corners across UI.
- [x] **Shadows**: Depth is consistent using design tokens.
- [x] **Icons**: Lucide-react used exclusively for consistency.

## ACCESSIBILITY
- [x] **Alt Text**: Images have descriptive alt attributes.
- [x] **Labels**: Forms have associated labels or aria-labels.
- [x] **Contrast**: Text meets WCAG AA standards.
- [x] **Keyboard**: Navigable via Tab/Enter keys.
- [x] **Semantics**: Proper HTML5 tags used.

## DATA INTEGRITY
- [x] **Courses**: 35+ items with complete metadata.
- [x] **Instructors**: Linked correctly to courses.
- [x] **Reviews**: Associated with valid courses/users.
- [x] **Notifications**: Diverse types represented.
