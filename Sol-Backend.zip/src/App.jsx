import React, { Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import ScrollToTop from '@/components/ScrollToTop';
import { CartProvider } from '@/hooks/useCart';
import { ROLES } from '@/config/permissions';
import { LoadingSpinner } from '@/components/States/LoadingState';

// Global Context Providers
import { EnrollmentProvider } from '@/contexts/EnrollmentContext';
import { RoleProvider } from '@/contexts/RoleContext';
import { InstructorRequestProvider } from '@/contexts/InstructorRequestContext';
import { AuthProvider } from '@/contexts/AuthContext';
import PreviewAuthProvider from '@/contexts/PreviewAuthContext';
import PREVIEW_ENABLED from '@/config/previewMode';

// Layout Components
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProtectedRoute from '@/components/ProtectedRoute';
import MainLayout from '@/components/MainLayout';

// New Course Components
import CoursesList from '@/components/courses/CoursesList';
import CourseDetail from '@/components/courses/CourseDetail';
import InstructorDashboard from '@/components/dashboards/InstructorDashboard';
import CourseEnrollments from '@/components/dashboards/CourseEnrollments';
import AdminDashboard from '@/components/dashboards/AdminDashboard';
import UserManagement from '@/components/dashboards/UserManagement';

// Lazy Loaded Pages
const HomePage = React.lazy(() => import('@/pages/HomePage'));
const StudentDashboard = React.lazy(() => import('@/pages/StudentDashboard'));
const UserProfilePage = React.lazy(() => import('@/pages/UserProfilePage'));
const NotificationsPage = React.lazy(() => import('@/pages/NotificationsPage'));
const CartPage = React.lazy(() => import('@/pages/CartPage'));
const CheckoutPage = React.lazy(() => import('@/pages/CheckoutPage'));
const OrderConfirmationPage = React.lazy(() => import('@/pages/OrderConfirmationPage'));
const OnboardingPage = React.lazy(() => import('@/pages/OnboardingPage'));
const NotFoundPage = React.lazy(() => import('@/pages/NotFoundPage'));
const ServerErrorPage = React.lazy(() => import('@/pages/ServerErrorPage'));
const LoginPage = React.lazy(() => import('@/pages/LoginPage'));
const SignupPage = React.lazy(() => import('@/pages/SignupPage'));
const InstructorProfilePage = React.lazy(() => import('@/pages/InstructorProfilePage'));
const StorePage = React.lazy(() => import('@/pages/StorePage'));
const ProductDetailPage = React.lazy(() => import('@/pages/ProductDetailPage'));
const SuccessPage = React.lazy(() => import('@/pages/SuccessPage'));
const AboutPage = React.lazy(() => import('@/pages/AboutPage'));
const ContactPage = React.lazy(() => import('@/pages/ContactPage'));
const ResourcesPage = React.lazy(() => import('@/pages/ResourcesPage'));
const BlogPage = React.lazy(() => import('@/pages/BlogPage'));
const EventsPage = React.lazy(() => import('@/pages/EventsPage'));
const ForumsPage = React.lazy(() => import('@/pages/ForumsPage'));
const ForumTopicDetailPage = React.lazy(() => import('@/pages/ForumTopicDetailPage'));
const CommunityPage = React.lazy(() => import('@/pages/CommunityPage'));
const LearningPathsPage = React.lazy(() => import('@/pages/LearningPathsPage'));
const AcademiaPage = React.lazy(() => import('@/pages/AcademiaPage'));
const AdminSettingsPage = React.lazy(() => import('@/pages/AdminSettingsPage'));

function App() {
  const AuthProviderComponent = PREVIEW_ENABLED ? PreviewAuthProvider : AuthProvider;

  return (
    <AuthProviderComponent>
      <RoleProvider>
        <EnrollmentProvider>
          <InstructorRequestProvider>
            <CartProvider>
              <div className="min-h-screen flex flex-col bg-white">
                <ScrollToTop />
                <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><LoadingSpinner size="lg" text="Cargando Netcom Academy..." /></div>}>
                  <Routes>
                    {/* Public Routes with MainLayout */}
                    <Route element={<MainLayout />}>
                      <Route path="/" element={<HomePage />} />
                      
                      {/* FASE 1: Course Routes */}
                      <Route path="/cursos" element={<CoursesList />} />
                      <Route path="/cursos/:id" element={<CourseDetail />} />

                      {/* E-commerce & Standard */}
                      <Route path="/cart" element={<CartPage />} />
                      <Route path="/checkout" element={<CheckoutPage />} />
                      <Route path="/order-confirmation" element={<OrderConfirmationPage />} />
                      <Route path="/store" element={<StorePage />} />
                      <Route path="/product/:id" element={<ProductDetailPage />} />
                      <Route path="/success" element={<SuccessPage />} />
                      
                      <Route path="/about" element={<AboutPage />} />
                      <Route path="/contact" element={<ContactPage />} />
                      <Route path="/login" element={<LoginPage />} />
                      <Route path="/signup" element={<SignupPage />} />

                      {/* Other Public Content */}
                      <Route path="/recursos-gratuitos" element={<ResourcesPage />} />
                      <Route path="/blog-tech" element={<BlogPage />} />
                      <Route path="/eventos-y-webinar" element={<EventsPage />} />
                      <Route path="/foros" element={<ForumsPage />} />
                      <Route path="/forums" element={<ForumsPage />} />
                      <Route path="/forums/:id" element={<ForumTopicDetailPage />} />
                      <Route path="/comunidad" element={<CommunityPage />} />
                      <Route path="/learning-paths" element={<LearningPathsPage />} />
                      <Route path="/academia" element={<AcademiaPage />} />
                      <Route path="/instructor/:id" element={<InstructorProfilePage />} />
                      <Route path="/onboarding" element={<OnboardingPage />} />
                      <Route path="/500" element={<ServerErrorPage />} />
                      <Route path="*" element={<NotFoundPage />} />
                    </Route>

                    {/* FASE 2: Protected Routes */}
                    
                    {/* Instructor Dashboard */}
                    <Route 
                      path="/instructor/dashboard" 
                      element={
                        <ProtectedRoute allowedRoles={[ROLES.INSTRUCTOR, ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                          <Header />
                          <InstructorDashboard />
                          <Footer />
                        </ProtectedRoute>
                      } 
                    />
                    <Route 
                      path="/instructor/estudiantes/:courseId" 
                      element={
                        <ProtectedRoute allowedRoles={[ROLES.INSTRUCTOR, ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                          <Header />
                          <CourseEnrollments />
                          <Footer />
                        </ProtectedRoute>
                      } 
                    />

                    {/* Admin Dashboard */}
                    <Route path="/admin">
                      <Route index element={<Navigate to="dashboard" replace />} />
                      <Route path="dashboard" element={
                        <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                          <Header />
                          <AdminDashboard />
                          <Footer />
                        </ProtectedRoute>
                      } />
                      <Route path="usuarios" element={
                        <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                          <Header />
                          <UserManagement />
                          <Footer />
                        </ProtectedRoute>
                      } />
                      {/* Legacy/Other Admin Routes */}
                      <Route path="settings" element={
                        <ProtectedRoute allowedRoles={[ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                          <Header />
                          <AdminSettingsPage />
                          <Footer />
                        </ProtectedRoute>
                      } />
                    </Route>

                    {/* Student Dashboard */}
                    <Route 
                      path="/student/dashboard" 
                      element={
                        <ProtectedRoute allowedRoles={[ROLES.STUDENT, ROLES.INSTRUCTOR, ROLES.ADMIN, ROLES.SUPER_ADMIN]}>
                          <Header />
                          <StudentDashboard />
                          <Footer />
                        </ProtectedRoute>
                      } 
                    />

                    {/* User Personal Routes */}
                    <Route path="/profile" element={<ProtectedRoute><Header /><UserProfilePage /><Footer /></ProtectedRoute>} />
                    <Route path="/notifications" element={<ProtectedRoute><Header /><NotificationsPage /><Footer /></ProtectedRoute>} />

                  </Routes>
                </Suspense>
                <Toaster />
              </div>
            </CartProvider>
          </InstructorRequestProvider>
        </EnrollmentProvider>
      </RoleProvider>
    </AuthProviderComponent>
  );
}

export default App;