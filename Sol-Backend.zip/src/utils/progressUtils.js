
export const STORAGE_KEY_PREFIX = 'netcom_course_progress_';

export const saveLessonProgress = (courseId, lessonId, isCompleted) => {
  try {
    const key = `${STORAGE_KEY_PREFIX}${courseId}`;
    const stored = localStorage.getItem(key);
    const progress = stored ? JSON.parse(stored) : { completedLessons: [] };
    
    let completedLessons = new Set(progress.completedLessons);
    
    if (isCompleted) {
      completedLessons.add(lessonId);
    } else {
      completedLessons.delete(lessonId);
    }
    
    const newProgress = {
      ...progress,
      lastAccessed: new Date().toISOString(),
      lastLessonId: lessonId,
      completedLessons: Array.from(completedLessons)
    };
    
    localStorage.setItem(key, JSON.stringify(newProgress));
    
    // Dispatch custom event for real-time updates
    window.dispatchEvent(new CustomEvent('lessonProgressUpdated', {
      detail: { courseId, lessonId, isCompleted }
    }));
    
    return true;
  } catch (error) {
    console.error('Error saving progress:', error);
    return false;
  }
};

export const getLessonProgress = (courseId, lessonId) => {
  try {
    const key = `${STORAGE_KEY_PREFIX}${courseId}`;
    const stored = localStorage.getItem(key);
    if (!stored) return false;
    
    const progress = JSON.parse(stored);
    return progress.completedLessons.includes(lessonId);
  } catch (error) {
    return false;
  }
};

export const getCourseProgress = (courseId, totalLessons = 0) => {
  try {
    const key = `${STORAGE_KEY_PREFIX}${courseId}`;
    const stored = localStorage.getItem(key);
    
    if (!stored) return { completedCount: 0, percentage: 0, lastLessonId: null };
    
    const progress = JSON.parse(stored);
    const completedCount = progress.completedLessons.length;
    const percentage = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;
    
    return {
      completedCount,
      percentage,
      lastLessonId: progress.lastLessonId,
      completedLessons: progress.completedLessons
    };
  } catch (error) {
    return { completedCount: 0, percentage: 0, lastLessonId: null };
  }
};

export const getLastAccessedLesson = (courseId) => {
  try {
    const key = `${STORAGE_KEY_PREFIX}${courseId}`;
    const stored = localStorage.getItem(key);
    if (!stored) return null;
    return JSON.parse(stored).lastLessonId;
  } catch (error) {
    return null;
  }
};
