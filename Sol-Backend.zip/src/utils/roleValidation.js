
import { ROLES, ROLE_PERMISSIONS } from '@/config/permissions';
import { logValidation, logStorageUpdate } from '@/utils/roleLogger';

const STORAGE_KEY = 'role_integrity_v1';
const CURRENT_VERSION = '1.0';
const VALIDITY_DURATION = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Validates if a role string is a valid defined role
 */
export const isValidRole = (role) => {
  return Object.values(ROLES).includes(role);
};

/**
 * Validates the integrity of the role state across different sources
 * @param {string} authRole - Role from AuthContext (Source of Truth)
 * @param {string} contextRole - Role from RoleContext
 * @param {object|null} storedData - Data from localStorage
 */
export const validateRoleIntegrity = (authRole, contextRole, storedData) => {
  logValidation('Checking role integrity...', { authRole, contextRole, storedData });

  // 1. Critical: Auth Role must exist if user is authenticated
  if (!authRole) {
    return { valid: false, reason: 'NO_AUTH_ROLE', action: 'LOGOUT' };
  }

  // 2. Validate against defined roles
  if (!isValidRole(authRole)) {
    return { valid: false, reason: 'INVALID_AUTH_ROLE', action: 'RESET' };
  }

  // 3. Check consistency with Context (if provided)
  if (contextRole && authRole !== contextRole) {
    return { 
      valid: false, 
      reason: 'CONTEXT_MISMATCH', 
      action: 'SYNC_FROM_AUTH',
      detail: `Auth says ${authRole}, Context says ${contextRole}` 
    };
  }

  // 4. Check consistency with Storage (if provided)
  if (storedData) {
    if (storedData.role !== authRole) {
      return {
        valid: false,
        reason: 'STORAGE_MISMATCH',
        action: 'UPDATE_STORAGE'
      };
    }
    
    // Check version/expiration
    const now = Date.now();
    if (storedData.version !== CURRENT_VERSION) {
      return { valid: false, reason: 'STORAGE_VERSION_OLD', action: 'UPDATE_STORAGE' };
    }
    
    if (now - storedData.timestamp > VALIDITY_DURATION) {
      return { valid: false, reason: 'STORAGE_EXPIRED', action: 'UPDATE_STORAGE' };
    }
  }

  return { valid: true };
};

/**
 * Validates stored role data structure and content
 */
export const validateStoredRole = (userId, storedData) => {
  if (!storedData) return false;
  
  try {
    const { role, userId: storedId, timestamp, version } = storedData;

    if (!role || !isValidRole(role)) {
      logValidation('Invalid stored role format');
      return false;
    }

    if (userId && storedId !== userId) {
      logValidation('Stored role belongs to different user', { expected: userId, found: storedId });
      return false;
    }

    if (version !== CURRENT_VERSION) {
      logValidation('Stored role version mismatch');
      return false;
    }

    return true;
  } catch (e) {
    logValidation('Error parsing stored role data', e);
    return false;
  }
};

/**
 * Syncs the role state based on the valid Auth Role
 */
export const syncRoleState = (authRole, userId) => {
  if (!isValidRole(authRole)) {
    console.error('Cannot sync invalid role:', authRole);
    return;
  }

  const data = {
    role: authRole,
    userId: userId || 'guest',
    timestamp: Date.now(),
    version: CURRENT_VERSION
  };

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    logStorageUpdate('Role synced to localStorage', data);
  } catch (e) {
    console.error('Failed to sync role to storage', e);
  }
};

export const clearStoredRole = () => {
  localStorage.removeItem(STORAGE_KEY);
  logStorageUpdate('Role data cleared from localStorage');
};

export const getStoredRole = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
};
