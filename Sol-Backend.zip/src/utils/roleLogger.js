
/**
 * Centralized logging utility for Role-Based Access Control (RBAC)
 * Provides standardized logging formats and environment awareness.
 */

const IS_DEV = import.meta.env.DEV;

// Standardized prefixes for different operation types
const PREFIXES = {
  SYNC: '[ROLE_SYNC]',
  GUARD: '[GUARD_CHECK]',
  STORAGE: '[STORAGE_UPDATE]',
  VALIDATION: '[ROLE_VALIDATION]',
  TEST: '[TEST_USER]',
  AUTH: '[AUTH_SYNC]'
};

const formatMessage = (prefix, message, data = null) => {
  const timestamp = new Date().toISOString().split('T')[1].slice(0, 8); // HH:MM:SS
  return {
    label: `${prefix} ${timestamp} | ${message}`,
    data
  };
};

export const logRoleSync = (message, data) => {
  if (!IS_DEV) return;
  const { label, data: logData } = formatMessage(PREFIXES.SYNC, message, data);
  console.log(`%c${label}`, 'color: #3b82f6; font-weight: bold;', logData || '');
};

export const logGuardCheck = (message, data) => {
  if (!IS_DEV) return;
  const { label, data: logData } = formatMessage(PREFIXES.GUARD, message, data);
  // Guard checks can be noisy, maybe use debug or lighter color
  console.groupCollapsed(`%c${label}`, 'color: #8b5cf6; font-weight: bold;');
  console.log('Details:', logData);
  console.groupEnd();
};

export const logStorageUpdate = (message, data) => {
  if (!IS_DEV) return;
  const { label, data: logData } = formatMessage(PREFIXES.STORAGE, message, data);
  console.log(`%c${label}`, 'color: #10b981; font-weight: bold;', logData || '');
};

export const logValidation = (message, data) => {
  if (!IS_DEV) return;
  const { label, data: logData } = formatMessage(PREFIXES.VALIDATION, message, data);
  if (data?.valid === false) {
    console.warn(label, logData);
  } else {
    console.log(`%c${label}`, 'color: #f59e0b; font-weight: bold;', logData || '');
  }
};

export const logTestUser = (message, data) => {
  if (!IS_DEV) return;
  const { label, data: logData } = formatMessage(PREFIXES.TEST, message, data);
  console.log(`%c${label}`, 'color: #ef4444; font-weight: bold;', logData || '');
};

export const logAuthSync = (message, data) => {
  if (!IS_DEV) return;
  const { label, data: logData } = formatMessage(PREFIXES.AUTH, message, data);
  console.log(`%c${label}`, 'color: #ec4899; font-weight: bold;', logData || '');
};

export default {
  logRoleSync,
  logGuardCheck,
  logStorageUpdate,
  logValidation,
  logTestUser,
  logAuthSync
};
