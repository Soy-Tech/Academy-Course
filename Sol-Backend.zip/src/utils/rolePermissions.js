

import { ROLES, PERMISSIONS, ROLE_PERMISSIONS, hasPermission, canAccessRoute } from '@/config/permissions';

/**
 * Get human-readable label for a role
 */
const getRoleLabel = (role) => {
  const labels = {
    'admin': 'Administrador',
    'instructor': 'Instructor',
    'student': 'Estudiante',
    'super_admin': 'Super Administrador'
  };
  return labels[role] || role;
};

/**
 * Adapter re-exporting from new centralized config
 * Maintains backward compatibility for existing files
 */

export { 
  ROLES, 
  PERMISSIONS, 
  ROLE_PERMISSIONS, 
  hasPermission,
  canAccessRoute as canAccess,
  getRoleLabel
};

// Also export the default object for compatibility if some files import default
export default {
  ROLES,
  PERMISSIONS,
  ROLE_PERMISSIONS,
  hasPermission,
  canAccess: canAccessRoute,
  getRoleLabel
};
