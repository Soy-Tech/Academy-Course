
export const validateFullName = (name) => {
  if (!name) return { isValid: false, errors: ['El nombre es obligatorio'] };
  if (name.length < 3) return { isValid: false, errors: ['Mínimo 3 caracteres'] };
  if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(name)) return { isValid: false, errors: ['Solo letras y espacios'] };
  return { isValid: true, errors: [] };
};

export const validateEmail = (email) => {
  if (!email) return { isValid: false, errors: ['El email es obligatorio'] };
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) return { isValid: false, errors: ['Formato inválido'] };
  
  // Simulate check in localStorage
  try {
    const existingApps = JSON.parse(localStorage.getItem('instructorApplications') || '[]');
    const exists = existingApps.some(app => app.personal.email === email);
    if (exists) return { isValid: false, errors: ['Ya existe una solicitud con este email'] };
  } catch (e) {
    console.error(e);
  }
  
  return { isValid: true, errors: [] };
};

export const validatePhone = (phone) => {
  if (!phone) return { isValid: false, errors: ['El teléfono es obligatorio'] };
  // Basic international format check (allows +, spaces, dashes, digits)
  if (!/^\+?[\d\s-]{8,20}$/.test(phone)) return { isValid: false, errors: ['Formato internacional inválido (mín. 8 dígitos)'] };
  return { isValid: true, errors: [] };
};

export const validateBio = (bio) => {
  return validateCharacterRange(bio, 100, 500);
};

export const validateYearsExperience = (years) => {
  if (!years) return { isValid: false, errors: ['Campo obligatorio'] };
  const num = parseInt(years, 10);
  if (isNaN(num) || num < 2) return { isValid: false, errors: ['Mínimo 2 años de experiencia requeridos'] };
  return { isValid: true, errors: [] };
};

export const validateURL = (url) => {
  if (!url) return { isValid: true, errors: [] }; // Optional usually, but if provided must be valid
  try {
    new URL(url);
    return { isValid: true, errors: [] };
  } catch (e) {
    return { isValid: false, errors: ['URL inválida (incluye http:// o https://)'] };
  }
};

export const validateFileSize = (file, maxMB) => {
  if (!file) return { isValid: true, errors: [] };
  const sizeMB = file.size / (1024 * 1024);
  if (sizeMB > maxMB) return { isValid: false, errors: [`El archivo excede ${maxMB}MB`] };
  return { isValid: true, errors: [] };
};

export const validateFileType = (file, allowedTypes) => {
  if (!file) return { isValid: true, errors: [] };
  if (!allowedTypes.includes(file.type)) return { isValid: false, errors: ['Tipo de archivo no permitido'] };
  return { isValid: true, errors: [] };
};

export const validateCharacterRange = (text, min, max) => {
  if (!text) return { isValid: false, errors: ['Campo obligatorio'] };
  if (text.length < min) return { isValid: false, errors: [`Mínimo ${min} caracteres`] };
  if (text.length > max) return { isValid: false, errors: [`Máximo ${max} caracteres`] };
  return { isValid: true, errors: [] };
};

export const validateCheckboxes = (checkedItems, requiredKeys) => {
  // checkedItems is object { key: boolean }
  const missing = requiredKeys.filter(key => !checkedItems[key]);
  if (missing.length > 0) return { isValid: false, errors: ['Debes aceptar todos los campos requeridos'] };
  return { isValid: true, errors: [] };
};

export const validateTeachingExperience = (hasTaught, fields) => {
  if (hasTaught === 'yes') {
    if (!fields.whereWhen || fields.whereWhen.length < 5) return { isValid: false, errors: ['Detalla dónde y cuándo'] };
    if (!fields.methodology || fields.methodology.length < 100) return { isValid: false, errors: ['Metodología muy breve (mín. 100 caracteres)'] };
  }
  return { isValid: true, errors: [] };
};

export const validateCourseDescription = (description) => {
  return validateCharacterRange(description, 200, 2000);
};

export const validateDifferentiator = (text) => {
  return validateCharacterRange(text, 100, 1000);
};
