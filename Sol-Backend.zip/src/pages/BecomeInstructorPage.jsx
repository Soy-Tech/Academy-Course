
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useInstructorRequest } from '@/contexts/InstructorRequestContext';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Briefcase, ChevronRight } from 'lucide-react';
import InstructorPolicies from '@/components/InstructorPolicies';
import InstructorBenefits from '@/components/InstructorBenefits';
import ApplicationStatusBadge from '@/components/ApplicationStatusBadge';

const BecomeInstructorPage = () => {
  const { currentUser, isAuthenticated } = useAuth();
  const { currentApplication } = useInstructorRequest();
  const navigate = useNavigate();

  useEffect(() => {
    // If user is already an instructor, redirect to dashboard or show specific message
    if (currentUser?.role === 'instructor') {
      navigate('/dashboard'); 
    }
  }, [currentUser, navigate]);

  const handleStartApplication = () => {
    if (!isAuthenticated) {
      navigate('/login?redirect=/become-instructor');
      return;
    }
    navigate('/instructor-application');
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 pt-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" onClick={() => navigate(-1)} className="mb-4 text-gray-500 hover:text-[#0B3D91] pl-0">
            <ArrowLeft size={18} className="mr-2" /> Volver
          </Button>
          
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
             <div>
                <h1 className="text-4xl font-bold text-[#0B3D91] mb-2">Conviértete en Instructor</h1>
                <p className="text-lg text-gray-600">Comparte tu conocimiento y transforma vidas con Netcom Academy.</p>
             </div>
             {currentApplication && (
               <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-xs text-gray-500 font-semibold uppercase">Estado de tu solicitud</p>
                    <p className="text-sm text-gray-900">{new Date(currentApplication.submittedAt).toLocaleDateString()}</p>
                  </div>
                  <ApplicationStatusBadge status={currentApplication.status} className="px-4 py-2 text-sm" />
                  <Button variant="outline" size="sm" onClick={() => navigate('/instructor-application-status')}>
                    Ver Detalles
                  </Button>
               </div>
             )}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* CTA Card */}
            <div className="bg-white p-8 rounded-xl shadow-lg border-l-4 border-[#0B3D91] relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-10">
                 <Briefcase size={120} />
               </div>
               
               <h2 className="text-2xl font-bold text-gray-900 mb-4 relative z-10">¿Listo para empezar?</h2>
               <p className="text-gray-600 mb-6 max-w-lg relative z-10">
                 Únete a más de 50 instructores que ya están generando ingresos pasivos y construyendo su marca personal.
               </p>

               {currentApplication ? (
                 <Button disabled className="bg-gray-200 text-gray-500 cursor-not-allowed">
                   Ya tienes una solicitud en proceso
                 </Button>
               ) : (
                 <Button 
                  onClick={handleStartApplication}
                  className="bg-[#0B3D91] hover:bg-[#092c69] text-white px-8 py-6 text-lg font-bold shadow-md relative z-10"
                >
                  Iniciar Solicitud <ChevronRight className="ml-2" />
                </Button>
               )}
            </div>
            
            <InstructorPolicies />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
             <InstructorBenefits />
             
             <div className="bg-gradient-to-br from-[#0B3D91] to-blue-900 p-6 rounded-xl text-white shadow-lg">
                <h3 className="font-bold text-lg mb-2">¿Necesitas ayuda?</h3>
                <p className="text-blue-100 text-sm mb-4">Si tienes dudas sobre el proceso de aplicación, contacta a nuestro equipo de soporte.</p>
                <Button variant="secondary" className="w-full text-[#0B3D91]" onClick={() => navigate('/contact')}>
                  Contactar Soporte
                </Button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BecomeInstructorPage;
