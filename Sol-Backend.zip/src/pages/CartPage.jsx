
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, ArrowRight, ShieldCheck, ShoppingBag, Tag, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/useCart';
import EmptyState from '@/components/States/EmptyState';
import { motion, AnimatePresence } from 'framer-motion';
import { formatCurrency } from '@/api/EcommerceApi';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const CartPage = () => {
  const { cartItems, removeFromCart, getCartTotal } = useCart();
  const navigate = useNavigate();
  const [discountCode, setDiscountCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  
  const subtotal = getCartTotal();
  const tax = subtotal * 0.16; // 16% tax mock
  const discountAmount = discountApplied ? subtotal * 0.1 : 0; // 10% discount
  const total = subtotal + tax - discountAmount;

  const handleApplyDiscount = () => {
    if (discountCode.toLowerCase() === 'netcom10') {
      setDiscountApplied(true);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <EmptyState 
            type="search" 
            title="Tu carrito está vacío" 
            description="Parece que aún no has añadido ningún curso."
            action={{ label: "Explorar Cursos", onClick: () => navigate('/cursos') }}
          />
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans flex flex-col">
      <Helmet>
        <title>Carrito de Compras | Netcom Academy</title>
      </Helmet>
      <Header />

      <main className="flex-1 container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-3">
          <ShoppingBag className="text-[#0B3D91]" /> Tu Carrito ({cartItems.length})
        </h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Cart Items List */}
          <div className="lg:w-2/3 space-y-4">
            <AnimatePresence>
              {cartItems.map((item) => (
                <motion.div 
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                  className="bg-white p-4 sm:p-6 rounded-xl shadow-sm border border-gray-200 flex flex-col sm:flex-row gap-6 group"
                >
                  <Link to={`/cursos/${item.id}`} className="sm:w-32 aspect-video bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                    <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </Link>
                  
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start mb-1">
                         <Link to={`/cursos/${item.id}`}>
                           <h3 className="font-bold text-gray-900 hover:text-blue-600 transition-colors line-clamp-1">{item.title}</h3>
                         </Link>
                         <span className="font-bold text-lg text-[#0B3D91]">
                            {typeof item.price === 'number' ? formatCurrency(item.price * 100, {currency: 'USD'}) : item.price}
                         </span>
                      </div>
                      <p className="text-sm text-gray-500 mb-2">Por Netcom Instructor</p>
                    </div>
                    
                    <div className="flex items-center gap-4 mt-2">
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="text-sm text-red-500 hover:text-red-700 flex items-center gap-1 hover:bg-red-50 px-2 py-1 rounded transition-colors"
                      >
                        <Trash2 size={16} /> Eliminar
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Checkout Summary */}
          <div className="lg:w-1/3">
             <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-6 sticky top-24">
                <h2 className="text-lg font-bold text-gray-900 mb-6 pb-2 border-b border-gray-100">Resumen del Pedido</h2>
                
                <div className="space-y-4 mb-6">
                   <div className="flex justify-between text-gray-600">
                      <span>Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                   </div>
                   <div className="flex justify-between text-gray-600">
                      <span>Impuestos (Estimados)</span>
                      <span>${tax.toFixed(2)}</span>
                   </div>
                   {discountApplied && (
                     <div className="flex justify-between text-green-600 font-medium">
                        <span>Descuento (10%)</span>
                        <span>-${discountAmount.toFixed(2)}</span>
                     </div>
                   )}
                   
                   <div className="pt-2">
                     <label className="text-xs font-semibold text-gray-500 mb-1 block">Código de Descuento</label>
                     <div className="flex gap-2">
                       <input 
                         type="text" 
                         value={discountCode}
                         onChange={(e) => setDiscountCode(e.target.value)}
                         placeholder="NETCOM10"
                         className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                         disabled={discountApplied}
                       />
                       <Button variant="outline" size="sm" onClick={handleApplyDiscount} disabled={!discountCode || discountApplied}>
                         {discountApplied ? 'Aplicado' : 'Aplicar'}
                       </Button>
                     </div>
                   </div>

                   <div className="border-t border-gray-100 pt-4 flex justify-between font-bold text-xl text-gray-900">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                   </div>
                </div>

                <Link to="/checkout">
                  <Button className="w-full h-12 text-lg font-bold bg-[#0B3D91] hover:bg-[#092c69] mb-4 shadow-lg shadow-blue-900/20">
                     Proceder al Pago <ArrowRight size={20} className="ml-2" />
                  </Button>
                </Link>

                <div className="text-xs text-center text-gray-500 flex flex-col gap-2 items-center bg-gray-50 p-3 rounded-lg">
                   <div className="flex items-center gap-2 font-medium">
                      <ShieldCheck size={16} className="text-green-600" /> Pago 100% Seguro
                   </div>
                   <div className="flex gap-2 opacity-60">
                     <CreditCard size={20} />
                     <div className="w-8 h-5 bg-gray-300 rounded"></div>
                     <div className="w-8 h-5 bg-gray-300 rounded"></div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CartPage;
