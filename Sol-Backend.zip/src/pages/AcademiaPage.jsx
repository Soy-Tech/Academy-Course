
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { BookOpen, Map, GraduationCap, ArrowRight } from 'lucide-react';
import PageBanner from '@/components/PageBanner';
import { Button } from '@/components/ui/button';

const AcademiaPage = () => {
  return (
    <>
      <Helmet>
        <title>Academia - Netcom Academy</title>
        <meta name="description" content="Descubre nuestra oferta académica completa: cursos, rutas de aprendizaje y certificaciones." />
      </Helmet>
      
      <PageBanner 
        title="Academia Netcom" 
        subtitle="Tu centro de formación profesional en tecnología. Elige cómo quieres aprender hoy."
        backgroundImage="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
      />

      <div className="container mx-auto px-4 py-16">
         <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Card 1: Cursos */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
               <div className="w-14 h-14 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mb-6">
                  <BookOpen size={28} />
               </div>
               <h3 className="text-2xl font-bold text-gray-900 mb-3">Catálogo de Cursos</h3>
               <p className="text-gray-600 mb-6">Explora nuestra biblioteca de cursos individuales sobre desarrollo, diseño, data y más.</p>
               <Link to="/cursos">
                  <Button variant="outline" className="w-full justify-between group">
                     Ver Cursos <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </Button>
               </Link>
            </div>

            {/* Card 2: Rutas */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
               <div className="w-14 h-14 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mb-6">
                  <Map size={28} />
               </div>
               <h3 className="text-2xl font-bold text-gray-900 mb-3">Rutas de Aprendizaje</h3>
               <p className="text-gray-600 mb-6">Sigue caminos estructurados desde cero hasta experto en carreras específicas.</p>
               <Link to="/learning-paths">
                  <Button variant="outline" className="w-full justify-between group">
                     Ver Rutas <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </Button>
               </Link>
            </div>

            {/* Card 3: Certificaciones */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
               <div className="w-14 h-14 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mb-6">
                  <GraduationCap size={28} />
               </div>
               <h3 className="text-2xl font-bold text-gray-900 mb-3">Certificaciones</h3>
               <p className="text-gray-600 mb-6">Valida tus conocimientos con nuestros exámenes y obtén certificados reconocidos.</p>
               <Link to="/contact">
                   <Button variant="outline" className="w-full justify-between group">
                     Más Información <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                   </Button>
               </Link>
            </div>
         </div>
      </div>
    </>
  );
};

export default AcademiaPage;
