
import React, { useState } from 'react';
import AdminLayout from '@/components/Admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { mockDb } from '@/data/mockDatabase';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { ROLES } from '@/utils/rolePermissions';

const AdminCreateInstructorPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    specialty: '',
    bio: '',
    portfolio: ''
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    if(mockDb.users.getByEmail(formData.email)) {
      toast({ title: 'Error', description: 'El email ya existe.', variant: 'destructive' });
      setLoading(false);
      return;
    }

    try {
      const newUser = mockDb.users.create({
        ...formData,
        password: 'instructor123',
        role: ROLES.INSTRUCTOR,
        userType: 'invited',
        status: 'active',
        avatar: formData.name.charAt(0).toUpperCase()
      });

      console.log(`[EMAIL SERVICE] Invitation sent to ${newUser.email}`);

      toast({
        title: "Instructor invitado",
        description: "Se ha enviado la invitación por correo.",
      });
      navigate('/admin/users');
    } catch (error) {
      toast({ title: 'Error', description: 'Falló la creación', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/admin/users')}>
            <ArrowLeft size={16} />
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Invitar Nuevo Instructor</h1>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
          <div className="grid grid-cols-1 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Nombre Completo</label>
              <input required className="w-full px-3 py-2 border rounded-lg outline-none"
                value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Email</label>
              <input required type="email" className="w-full px-3 py-2 border rounded-lg outline-none"
                value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Especialidad Principal</label>
              <select className="w-full px-3 py-2 border rounded-lg outline-none"
                value={formData.specialty} onChange={(e) => setFormData({...formData, specialty: e.target.value})}>
                <option value="">Seleccionar...</option>
                <option value="web">Desarrollo Web</option>
                <option value="data">Data Science</option>
                <option value="design">Diseño</option>
                <option value="business">Negocios</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Biografía / Perfil</label>
              <textarea required className="w-full px-3 py-2 border rounded-lg outline-none h-32"
                value={formData.bio} onChange={(e) => setFormData({...formData, bio: e.target.value})} />
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => navigate('/admin/users')}>Cancelar</Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700" disabled={loading}>
              {loading ? 'Procesando...' : 'Enviar Invitación'}
            </Button>
          </div>
        </form>
      </div>
    </AdminLayout>
  );
};

export default AdminCreateInstructorPage;
