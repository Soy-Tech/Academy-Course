
import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Users, GraduationCap, TrendingUp, MoreVertical, Calendar, ArrowRight, Activity, DollarSign, FileText, UserPlus } from 'lucide-react';
import AdminLayout from '@/components/Admin/AdminLayout';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { mockDb } from '@/data/mockDatabase';
import { ROLES } from '@/utils/rolePermissions';

const AdminDashboard = () => {
  const users = mockDb.users.getAll();
  const applications = mockDb.applications.getAll();
  
  // Real-time stats from mockDb
  const totalUsers = users.length;
  const totalStudents = users.filter(u => u.role === ROLES.STUDENT).length;
  const totalInstructors = users.filter(u => u.role === ROLES.INSTRUCTOR).length;
  const pendingApplications = applications.filter(a => a.status === 'pending').length;
  
  // Placeholder revenue data
  const totalRevenue = 15420;

  const stats = [
    { 
      label: 'Usuarios Totales', 
      value: totalUsers, 
      icon: Users, 
      color: 'text-blue-600', 
      bg: 'bg-blue-100',
      trend: '+12% vs mes anterior',
      trendUp: true
    },
    { 
      label: 'Solicitudes Pendientes', 
      value: pendingApplications, 
      icon: FileText, 
      color: 'text-orange-600', 
      bg: 'bg-orange-100',
      trend: 'Requiere atención',
      trendUp: false
    },
    { 
      label: 'Instructores', 
      value: totalInstructors, 
      icon: GraduationCap, 
      color: 'text-green-600', 
      bg: 'bg-green-100',
      trend: 'Crecimiento estable',
      trendUp: true
    },
    { 
      label: 'Ingresos Totales', 
      value: `$${totalRevenue.toLocaleString()}`, 
      icon: DollarSign, 
      color: 'text-emerald-600', 
      bg: 'bg-emerald-100',
      trend: '+8.2% este mes',
      trendUp: true
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-[#0B3D91] to-[#1E40AF] rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <div className="relative z-10">
            <h2 className="text-3xl font-bold mb-2">Panel de Control</h2>
            <p className="text-blue-100 max-w-xl text-lg font-light">
              Vista general del rendimiento de Netcom Academy.
            </p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
            >
              <div className="flex justify-between items-start mb-4">
                <div className={`p-3 rounded-xl ${stat.bg}`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
                {stat.trendUp !== undefined && (
                   stat.trendUp ? <TrendingUp size={18} className="text-green-500" /> : <TrendingUp size={18} className="text-orange-500" />
                )}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
              <p className="text-sm font-medium text-gray-500 mb-3">{stat.label}</p>
              <div className="inline-flex items-center px-2 py-1 rounded-full bg-gray-50 text-xs font-medium text-gray-600">
                {stat.trend}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="font-bold text-lg text-gray-900 mb-6 flex items-center gap-2">
              <MoreVertical size={20} className="text-gray-400" />
              Acciones Rápidas
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <Link to="/admin/users/create-student">
                  <Button variant="outline" className="w-full h-auto py-6 flex flex-col gap-2 hover:bg-blue-50 border-dashed border-2">
                    <UserPlus size={24} className="text-blue-600" />
                    <span className="font-semibold text-gray-700">Crear Estudiante Corp.</span>
                  </Button>
               </Link>
               
               <Link to="/admin/users/create-instructor">
                  <Button variant="outline" className="w-full h-auto py-6 flex flex-col gap-2 hover:bg-green-50 border-dashed border-2">
                    <GraduationCap size={24} className="text-green-600" />
                    <span className="font-semibold text-gray-700">Invitar Instructor</span>
                  </Button>
               </Link>

               <Link to="/admin/instructor-requests">
                  <Button variant="outline" className="w-full h-auto py-6 flex flex-col gap-2 hover:bg-orange-50 border-dashed border-2">
                    <FileText size={24} className="text-orange-600" />
                    <span className="font-semibold text-gray-700">Revisar Solicitudes ({pendingApplications})</span>
                  </Button>
               </Link>
            </div>
          </div>

          {/* Recent Users List */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-100 bg-gray-50/50">
              <h3 className="font-bold text-lg text-gray-900">Usuarios Recientes</h3>
            </div>
            <div className="divide-y divide-gray-100">
              {users.slice(-5).reverse().map((user) => (
                <div key={user.id} className="p-4 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs font-bold text-gray-600">
                    {user.avatar}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-gray-900 truncate">{user.name}</p>
                    <p className="text-xs text-gray-500 truncate">{user.email}</p>
                  </div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 bg-gray-100 px-2 py-0.5 rounded">
                    {user.role}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;
