
import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, Download, ArrowRight, Calendar, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const OrderConfirmationPage = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const orderDate = new Date().toLocaleDateString('es-ES', { 
    year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  return (
    <div className="min-h-screen bg-gray-50 font-sans flex flex-col">
      <Helmet>
        <title>Pedido Confirmado | Netcom Academy</title>
      </Helmet>
      <Header />

      <main className="flex-1 container mx-auto px-4 py-12 flex items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="bg-white max-w-2xl w-full rounded-2xl shadow-xl border border-gray-100 overflow-hidden"
        >
          {/* Success Header */}
          <div className="bg-[#0B3D91] p-8 text-center text-white relative overflow-hidden">
             <div className="absolute inset-0 bg-white/5 pattern-grid opacity-20"></div>
             <motion.div 
               initial={{ scale: 0 }} 
               animate={{ scale: 1 }} 
               transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
               className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg relative z-10"
             >
                <Check size={40} strokeWidth={4} />
             </motion.div>
             <h1 className="text-3xl font-bold mb-2 relative z-10">¡Gracias por tu pedido!</h1>
             <p className="text-blue-100 relative z-10">Hemos enviado un recibo a tu correo electrónico.</p>
          </div>

          <div className="p-8">
             <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-100 pb-6 mb-6 gap-4">
                <div>
                   <p className="text-xs text-gray-500 uppercase tracking-wider font-bold">Número de Orden</p>
                   <p className="text-lg font-mono font-bold text-gray-900">#NET-883492</p>
                </div>
                <div className="text-left md:text-right">
                   <p className="text-xs text-gray-500 uppercase tracking-wider font-bold flex items-center gap-1 md:justify-end">
                      <Calendar size={12} /> Fecha
                   </p>
                   <p className="text-sm font-medium text-gray-900">{orderDate}</p>
                </div>
             </div>

             <div className="space-y-6 mb-8">
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                   <Package size={20} className="text-blue-600" /> Resumen de Compra
                </h3>
                
                {/* Mock Item */}
                <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                   <div className="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                      <img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085" alt="Course" className="w-full h-full object-cover" />
                   </div>
                   <div className="flex-1">
                      <h4 className="font-bold text-gray-900 text-sm">Desarrollo Web Full Stack</h4>
                      <p className="text-xs text-gray-500">Curso Online</p>
                   </div>
                   <span className="font-bold text-gray-900">$99.99</span>
                </div>

                <div className="flex justify-between items-center pt-4 border-t border-gray-100">
                   <span className="font-bold text-lg text-gray-900">Total Pagado</span>
                   <span className="font-bold text-2xl text-[#0B3D91]">$115.99</span>
                </div>
             </div>

             <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Link to="/student/courses" className="w-full">
                   <Button className="w-full h-12 font-bold bg-[#0B3D91] hover:bg-[#092c69]">
                      Ir a Mis Cursos <ArrowRight size={18} className="ml-2" />
                   </Button>
                </Link>
                <Button variant="outline" className="w-full h-12 font-bold border-gray-300">
                   <Download size={18} className="mr-2" /> Descargar Recibo
                </Button>
             </div>
          </div>
        </motion.div>
      </main>
      <Footer />
    </div>
  );
};

export default OrderConfirmationPage;
