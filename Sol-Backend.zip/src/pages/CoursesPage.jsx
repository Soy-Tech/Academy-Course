
import React, { useState, useEffect, useMemo, useCallback, Suspense } from 'react';
import { Helmet } from 'react-helmet';
import { SlidersHorizontal } from 'lucide-react';
import { coursesData } from '@/data/coursesData';
import { Button } from '@/components/ui/button';
import { LoadingSpinner } from '@/components/States/LoadingState';

// Lazy load heavy components
const SearchBar = React.lazy(() => import('@/components/Search/SearchBar'));
const FilterSidebar = React.lazy(() => import('@/components/Search/FilterSidebar'));
const CourseGrid = React.lazy(() => import('@/components/Courses/CourseGrid'));

const CoursesPage = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    categories: [],
    levels: [],
    prices: []
  });
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const filteredCourses = useMemo(() => {
    let result = coursesData;

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(c => 
        c.title.toLowerCase().includes(q) || 
        c.shortDescription.toLowerCase().includes(q)
      );
    }

    if (filters.categories.length > 0) {
      result = result.filter(c => filters.categories.includes(c.category));
    }

    if (filters.levels.length > 0) {
      result = result.filter(c => filters.levels.includes(c.level));
    }

    return result;
  }, [searchQuery, filters]);

  const handleFilterChange = useCallback((type, value) => {
    setFilters(prev => {
      const current = prev[type];
      const updated = current.includes(value)
        ? current.filter(item => item !== value)
        : [...current, value];
      return { ...prev, [type]: updated };
    });
  }, []);

  const clearFilters = useCallback(() => {
    setFilters({ categories: [], levels: [], prices: [] });
    setSearchQuery('');
  }, []);

  const handleSearch = useCallback((query) => {
    setSearchQuery(query);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      <Helmet>
        <title>Explorar Cursos | Netcom Academy</title>
        <meta name="description" content="Encuentra el curso perfecto para impulsar tu carrera tecnológica." />
      </Helmet>

      <header className="bg-[#0B3D91] text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Explora nuestros cursos</h1>
          <p className="text-blue-100 max-w-2xl mx-auto text-lg">
            Descubre conocimientos prácticos impartidos por expertos de la industria.
          </p>
        </div>
      </header>

      <div className="container mx-auto px-4 -mt-8">
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <Suspense fallback={<div className="h-10 bg-gray-100 w-full rounded animate-pulse"></div>}>
              <SearchBar onSearch={handleSearch} />
            </Suspense>
            <div className="flex items-center gap-2 w-full md:w-auto">
               <Button 
                  variant="outline" 
                  className="md:hidden w-full"
                  onClick={() => setShowMobileFilters(!showMobileFilters)}
                  aria-expanded={showMobileFilters}
                  aria-controls="filter-sidebar"
               >
                 <SlidersHorizontal className="mr-2 h-4 w-4" aria-hidden="true" /> Filtros
               </Button>
               <select 
                  className="bg-gray-50 border border-gray-200 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
                  aria-label="Ordenar cursos"
               >
                  <option>Más relevantes</option>
                  <option>Más recientes</option>
                  <option>Mejor valorados</option>
                  <option>Precio: Menor a Mayor</option>
               </select>
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          <aside 
            id="filter-sidebar"
            className={`md:w-64 flex-shrink-0 ${showMobileFilters ? 'block' : 'hidden md:block'}`}
            aria-label="Filtros de búsqueda"
          >
            <Suspense fallback={<div className="h-96 bg-gray-100 rounded animate-pulse"></div>}>
              <FilterSidebar 
                filters={filters} 
                onFilterChange={handleFilterChange} 
                onClear={clearFilters}
              />
            </Suspense>
          </aside>

          <main className="flex-1">
            <div className="mb-4 text-sm text-gray-500" aria-live="polite">
               Mostrando <strong>{filteredCourses.length}</strong> cursos
            </div>
            <Suspense fallback={<LoadingSpinner size="lg" text="Cargando cursos..." />}>
              <CourseGrid 
                courses={filteredCourses} 
                loading={isLoading}
                emptyTitle="No encontramos cursos"
                emptyMsg="Intenta cambiar los términos de búsqueda o limpiar los filtros."
              />
            </Suspense>
          </main>
        </div>
      </div>
    </div>
  );
};

export default CoursesPage;
