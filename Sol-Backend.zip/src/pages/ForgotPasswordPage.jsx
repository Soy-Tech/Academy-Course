
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const { resetPassword } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const { error } = await resetPassword(email);

    if (error) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
      setIsLoading(false);
    } else {
      setEmailSent(true);
      toast({
        title: 'Correo enviado',
        description: 'Revisa tu bandeja de entrada para restablecer tu contraseña.'
      });
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Recuperar Contraseña - Netcom Academy</title>
        <meta name="description" content="Recupera tu contraseña de Netcom Academy." />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-[#0B3D91] to-[#082d6b] flex items-center justify-center px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-[#0B3D91] rounded-xl flex items-center justify-center mx-auto mb-4">
              <span className="text-white font-bold text-3xl">N</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {emailSent ? '¡Correo enviado!' : '¿Olvidaste tu contraseña?'}
            </h1>
            <p className="text-gray-600">
              {emailSent
                ? 'Hemos enviado instrucciones a tu correo electrónico'
                : 'Te enviaremos instrucciones para restablecer tu contraseña'}
            </p>
          </div>

          {!emailSent ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Correo electrónico
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#CFAE70] focus:border-transparent outline-none transition-all text-gray-900 bg-white"
                    placeholder="tu@email.com"
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full btn-primary py-3 text-base"
              >
                {isLoading ? 'Enviando...' : 'Enviar instrucciones'}
              </Button>
            </form>
          ) : (
            <div className="space-y-6">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                <p className="text-green-800">
                  Revisa tu bandeja de entrada y sigue las instrucciones para restablecer tu contraseña.
                </p>
              </div>
              <Button
                onClick={() => setEmailSent(false)}
                variant="outline"
                className="w-full py-3"
              >
                Enviar de nuevo
              </Button>
            </div>
          )}

          <Link
            to="/login"
            className="mt-6 flex items-center justify-center text-sm text-[#0B3D91] hover:text-[#CFAE70] transition-colors"
          >
            <ArrowLeft size={16} className="mr-2" />
            Volver al inicio de sesión
          </Link>
        </motion.div>
      </div>
    </>
  );
};

export default ForgotPasswordPage;
