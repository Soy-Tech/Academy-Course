
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Plus, Edit, Trash2, Eye, GripVertical } from 'lucide-react';
import AdminLayout from '@/components/Admin/AdminLayout';
import AdminVideoForm from '@/components/Admin/AdminVideoForm';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useVideos } from '@/hooks/useVideos';
import { coursesData } from '@/data/coursesData';

const AdminVideoPanel = () => {
  const { courseId } = useParams();
  const { getVideosByCourse, addVideo, updateVideo, deleteVideo } = useVideos();
  const { toast } = useToast();
  
  const [videos, setVideos] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const course = coursesData.find(c => c.id === courseId);

  useEffect(() => {
    setVideos(getVideosByCourse(courseId));
  }, [courseId, getVideosByCourse, isModalOpen]); // Reload when modal closes/changes

  const handleSave = (videoData) => {
    if (currentVideo) {
      updateVideo(currentVideo.id, videoData);
      toast({ title: "Video actualizado" });
    } else {
      addVideo({ ...videoData, courseId });
      toast({ title: "Video creado exitosamente" });
    }
    setIsModalOpen(false);
    setVideos(getVideosByCourse(courseId)); // Refresh list
  };

  const handleDelete = (id) => {
    if (confirm("¿Estás seguro de eliminar este video?")) {
      deleteVideo(id);
      setVideos(getVideosByCourse(courseId));
      toast({ title: "Video eliminado", variant: "destructive" });
    }
  };

  const handleEdit = (video) => {
    setCurrentVideo(video);
    setIsModalOpen(true);
  };

  const handleCreate = () => {
    setCurrentVideo(null);
    setIsModalOpen(true);
  };

  const handleToggleStatus = (video) => {
      updateVideo(video.id, { isActive: !video.isActive });
      setVideos(getVideosByCourse(courseId));
      toast({ title: `Video ${!video.isActive ? 'activado' : 'desactivado'}` });
  };

  const filteredVideos = videos.filter(v => 
    v.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!course) return <AdminLayout><div>Curso no encontrado</div></AdminLayout>;

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
             <Link to="/admin/courses" className="text-gray-500 hover:text-gray-900 flex items-center gap-2 mb-2 text-sm">
                <ArrowLeft size={16} /> Volver a cursos
             </Link>
             <h1 className="text-2xl font-bold text-gray-900">Videos: {course.title}</h1>
             <p className="text-gray-500">{videos.length} videos en total</p>
          </div>
          <Button onClick={handleCreate} className="bg-[#0B3D91] hover:bg-[#082d6b] text-white">
            <Plus size={18} className="mr-2" /> Añadir Video
          </Button>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-100 flex gap-4">
                <input 
                    type="text" 
                    placeholder="Buscar videos..." 
                    className="flex-1 px-4 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#0B3D91]"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 text-gray-500 uppercase font-medium">
                        <tr>
                            <th className="px-6 py-4 w-12">#</th>
                            <th className="px-6 py-4">Título</th>
                            <th className="px-6 py-4">Duración</th>
                            <th className="px-6 py-4">Estado</th>
                            <th className="px-6 py-4 text-right">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                        {filteredVideos.length > 0 ? (
                            filteredVideos.map((video) => (
                                <tr key={video.id} className="hover:bg-gray-50 group">
                                    <td className="px-6 py-4 text-gray-500">
                                        <div className="flex items-center gap-2">
                                            <GripVertical size={14} className="text-gray-300 cursor-move" />
                                            {video.order}
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 font-medium text-gray-900">
                                        {video.title}
                                    </td>
                                    <td className="px-6 py-4 text-gray-500">
                                        {video.duration} min
                                    </td>
                                    <td className="px-6 py-4">
                                        <button 
                                            onClick={() => handleToggleStatus(video)}
                                            className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider ${
                                                video.isActive 
                                                ? 'bg-green-100 text-green-700' 
                                                : 'bg-gray-100 text-gray-500'
                                            }`}
                                        >
                                            {video.isActive ? 'Activo' : 'Inactivo'}
                                        </button>
                                    </td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => window.open(video.videoUrl, '_blank')} className="text-gray-400 hover:text-gray-600" title="Ver demo">
                                            <Eye size={18} />
                                        </button>
                                        <button onClick={() => handleEdit(video)} className="text-blue-600 hover:text-blue-800" title="Editar">
                                            <Edit size={18} />
                                        </button>
                                        <button onClick={() => handleDelete(video.id)} className="text-red-500 hover:text-red-700" title="Eliminar">
                                            <Trash2 size={18} />
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                                    No hay videos disponibles. ¡Añade el primero!
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
      </div>

      <AdminVideoForm 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialData={currentVideo}
        onSave={handleSave}
      />
    </AdminLayout>
  );
};

export default AdminVideoPanel;
