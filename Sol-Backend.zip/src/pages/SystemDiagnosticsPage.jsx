
import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2, CheckCircle, XCircle, AlertTriangle, Shield, Database, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const SystemDiagnosticsPage = () => {
  const { currentUser, isAuthenticated } = useAuth();
  const [results, setResults] = useState({});
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState([]);

  const addLog = (message, type = 'info') => {
    setLogs(prev => [...prev, { message, type, timestamp: new Date().toLocaleTimeString() }]);
  };

  const runDiagnostics = async () => {
    setLoading(true);
    setResults({});
    setLogs([]);
    addLog('Starting system diagnostics...', 'info');

    const newResults = {
      auth: { status: 'pending', details: '' },
      profile: { status: 'pending', details: '' },
      rlsUsers: { status: 'pending', details: '' },
      rlsRoles: { status: 'pending', details: '' },
      rlsPermissions: { status: 'pending', details: '' },
    };

    try {
      // 1. Auth Check
      addLog('Checking authentication status...', 'info');
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        newResults.auth = { status: 'pass', details: `Authenticated as ${session.user.email}` };
        addLog('Authentication valid.', 'success');

        // 2. Profile/Trigger Check
        addLog('Verifying public profile existence (Trigger Check)...', 'info');
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*, roles(name)')
          .eq('id', session.user.id)
          .single();

        if (profileError) {
          newResults.profile = { status: 'fail', details: `Profile missing. Trigger failed? Error: ${profileError.message}` };
          addLog('Profile check failed.', 'error');
        } else {
          newResults.profile = { 
            status: 'pass', 
            details: `Profile found. Role: ${profile.roles?.name || 'No Role Linked'}. Name: ${profile.full_name}` 
          };
          addLog('Profile exists and is linked.', 'success');
        }

        // 3. RLS Users Check
        addLog('Testing RLS policies for Users table...', 'info');
        const { count: userCount, error: countError } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true });

        if (countError) {
             newResults.rlsUsers = { status: 'fail', details: `Error querying profiles: ${countError.message}` };
        } else {
             const role = profile?.roles?.name;
             if (role === 'student' && userCount === 1) {
                 newResults.rlsUsers = { status: 'pass', details: 'Student sees only 1 profile (Self). RLS working.' };
             } else if (['admin', 'super_admin'].includes(role) && userCount > 1) {
                 newResults.rlsUsers = { status: 'pass', details: `Admin sees ${userCount} profiles. RLS working.` };
             } else if (role === 'student' && userCount > 1) {
                 newResults.rlsUsers = { status: 'fail', details: `SECURITY RISK: Student sees ${userCount} profiles.` };
             } else {
                 newResults.rlsUsers = { status: 'warning', details: `User count: ${userCount}. Verify if this matches expected behavior for role ${role}.` };
             }
        }

        // 4. RLS Roles Check (Read)
        addLog('Testing RLS policies for Roles table...', 'info');
        const { data: roles, error: rolesError } = await supabase.from('roles').select('id');
        if (rolesError) {
             newResults.rlsRoles = { status: 'fail', details: `Cannot read roles. Error: ${rolesError.message}` };
        } else if (roles.length > 0) {
             // Try Write (Should fail for student)
             if (profile?.roles?.name === 'student') {
                 const { error: writeError } = await supabase.from('roles').insert({ name: 'test_hack', description: 'hack' });
                 if (writeError) {
                     newResults.rlsRoles = { status: 'pass', details: 'Roles readable. Write blocked correctly.' };
                 } else {
                     newResults.rlsRoles = { status: 'fail', details: 'SECURITY RISK: Student was able to insert a role!' };
                 }
             } else {
                 newResults.rlsRoles = { status: 'pass', details: `Roles readable. Count: ${roles.length}` };
             }
        } else {
            newResults.rlsRoles = { status: 'warning', details: 'No roles found. Seed data missing?' };
        }

      } else {
        newResults.auth = { status: 'fail', details: 'No active session. Please log in.' };
        addLog('No active session found.', 'error');
      }

    } catch (e) {
      addLog(`Unexpected error: ${e.message}`, 'error');
    }

    setResults(newResults);
    setLoading(false);
  };

  const StatusBadge = ({ status }) => {
    if (status === 'pass') return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800"><CheckCircle size={14} className="mr-1"/> PASS</span>;
    if (status === 'fail') return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800"><XCircle size={14} className="mr-1"/> FAIL</span>;
    if (status === 'warning') return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800"><AlertTriangle size={14} className="mr-1"/> WARN</span>;
    return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">PENDING</span>;
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="flex items-center justify-between mb-8">
        <div>
           <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
             <Shield className="text-[#0B3D91]" /> System Diagnostics
           </h1>
           <p className="text-gray-500 mt-1">Pre-implementation Verification Suite (RLS & Triggers)</p>
        </div>
        <Button onClick={runDiagnostics} disabled={loading} className="bg-[#0B3D91]">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Run Verification Suite'}
        </Button>
      </div>

      <div className="grid gap-6">
        {/* Auth Context State */}
        <Card>
           <CardHeader>
             <CardTitle className="text-lg flex items-center gap-2"><User size={20}/> Current Context State</CardTitle>
           </CardHeader>
           <CardContent>
              <div className="bg-slate-50 p-4 rounded-md font-mono text-xs overflow-auto">
                 {isAuthenticated ? (
                    <pre>{JSON.stringify({ 
                        user_id: currentUser?.id, 
                        email: currentUser?.email, 
                        role: currentUser?.role,
                        permissions_count: currentUser?.permissions?.length
                    }, null, 2)}</pre>
                 ) : (
                    <p className="text-red-500">Not Authenticated. Log in to run RLS tests.</p>
                 )}
              </div>
           </CardContent>
        </Card>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
                <CardHeader className="pb-2">
                    <CardTitle className="text-base">Authentication & Trigger</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between items-start border-b pb-2">
                        <span className="text-sm font-medium">Session Check</span>
                        <div className="text-right">
                           <StatusBadge status={results.auth?.status} />
                           {results.auth?.details && <p className="text-xs text-gray-500 mt-1 max-w-[200px]">{results.auth.details}</p>}
                        </div>
                    </div>
                    <div className="flex justify-between items-start border-b pb-2">
                        <span className="text-sm font-medium">Profile (Trigger)</span>
                        <div className="text-right">
                           <StatusBadge status={results.profile?.status} />
                           {results.profile?.details && <p className="text-xs text-gray-500 mt-1 max-w-[200px]">{results.profile.details}</p>}
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2"><Database size={16}/> RLS Policies</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between items-start border-b pb-2">
                        <span className="text-sm font-medium">Users Table</span>
                        <div className="text-right">
                           <StatusBadge status={results.rlsUsers?.status} />
                           {results.rlsUsers?.details && <p className="text-xs text-gray-500 mt-1 max-w-[200px]">{results.rlsUsers.details}</p>}
                        </div>
                    </div>
                    <div className="flex justify-between items-start border-b pb-2">
                        <span className="text-sm font-medium">Roles Table</span>
                        <div className="text-right">
                           <StatusBadge status={results.rlsRoles?.status} />
                           {results.rlsRoles?.details && <p className="text-xs text-gray-500 mt-1 max-w-[200px]">{results.rlsRoles.details}</p>}
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>

        {/* Logs */}
        <Card>
            <CardHeader>
                <CardTitle className="text-sm text-gray-500 uppercase tracking-wider">Execution Logs</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="h-48 overflow-y-auto bg-gray-900 rounded-md p-4 text-xs font-mono space-y-1">
                    {logs.length === 0 && <span className="text-gray-500">Ready to start...</span>}
                    {logs.map((log, i) => (
                        <div key={i} className={`${
                            log.type === 'error' ? 'text-red-400' : 
                            log.type === 'success' ? 'text-green-400' : 'text-blue-300'
                        }`}>
                            <span className="opacity-50">[{log.timestamp}]</span> {log.message}
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SystemDiagnosticsPage;
