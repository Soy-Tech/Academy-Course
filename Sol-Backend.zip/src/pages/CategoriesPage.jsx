
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Code, Brain, Shield, Zap } from 'lucide-react';
import { coursesData } from '@/data/coursesData';
import CourseCardPreview from '@/components/CourseCardPreview';
import PageBanner from '@/components/PageBanner';

const CategoriesPage = () => {
  const [searchParams] = useSearchParams();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const navigate = useNavigate();

  useEffect(() => {
    const cat = searchParams.get('cat');
    if (cat) {
      const categoryMap = {
        'programacion': 'Programación',
        'ia-datos': 'IA y Datos',
        'ciberseguridad': 'Ciberseguridad',
        'productividad': 'Productividad'
      };
      setSelectedCategory(categoryMap[cat] || 'all');
    }
  }, [searchParams]);

  const categories = [
    {
      id: 'all',
      name: 'Todas',
      icon: null,
      description: 'Ver todos los cursos'
    },
    {
      id: 'Programación',
      name: 'Programación',
      icon: Code,
      description: 'Desarrollo web y software'
    },
    {
      id: 'IA y Datos',
      name: 'IA y Datos',
      icon: Brain,
      description: 'Machine Learning y Datos'
    },
    {
      id: 'Ciberseguridad',
      name: 'Ciberseguridad',
      icon: Shield,
      description: 'Seguridad y Redes'
    },
    {
      id: 'Productividad',
      name: 'Productividad',
      icon: Zap,
      description: 'Herramientas Digitales'
    }
  ];

  const filteredCourses = selectedCategory === 'all' 
    ? coursesData 
    : coursesData.filter(course => course.category === selectedCategory);

  const scrollToGrid = () => {
    document.getElementById('categories-grid').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Categorías - Netcom Academy</title>
        <meta name="description" content="Explora nuestras categorías de cursos." />
      </Helmet>

      <PageBanner 
        title="Categorías"
        subtitle="Explora nuestra amplia variedad de cursos organizados por áreas de conocimiento."
        cta={{ label: "Ver todas las categorías", onClick: scrollToGrid }}
        backgroundImage="https://images.unsplash.com/photo-1695548303345-b5db7453593c"
      />

      <section id="categories-grid" className="bg-white py-12 border-b border-gray-100">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-10"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-3 text-[#0B3D91]">
              Explora por área
            </h2>
            <p className="text-gray-600 max-w-xl mx-auto">
              Selecciona un área para comenzar tu ruta de especialización
            </p>
          </motion.div>

          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => {
              const Icon = category.icon;
              const isSelected = selectedCategory === category.id;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-5 py-2.5 rounded-full font-medium transition-all duration-300 flex items-center gap-2 text-sm border ${
                    isSelected
                      ? 'bg-[#0B3D91] text-white border-[#0B3D91] shadow-md'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-[#0B3D91] hover:text-[#0B3D91]'
                  }`}
                >
                  {Icon && <Icon size={16} />}
                  <span>{category.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-12 bg-gray-50 min-h-[500px]">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
            className="mb-6 flex justify-between items-center"
          >
            <h2 className="text-xl font-bold text-[#1C1C1C]">
              {selectedCategory === 'all' ? 'Todos los cursos' : `Cursos de ${selectedCategory}`}
            </h2>
            <span className="text-sm text-gray-500 bg-white px-3 py-1 rounded border border-gray-200">
              {filteredCourses.length} resultados
            </span>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredCourses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.5) }}
              >
                <CourseCardPreview course={course} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default CategoriesPage;
