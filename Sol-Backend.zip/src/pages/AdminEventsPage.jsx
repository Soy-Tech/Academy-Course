
import React, { useState } from 'react';
import { Plus, Search, Filter } from 'lucide-react';
import AdminLayout from '@/components/Admin/AdminLayout';
import EventsList from '@/components/Admin/EventsList';
import EventModal from '@/components/Admin/EventModal';
import { Button } from '@/components/ui/button';
import { useAdminEvents } from '@/hooks/useAdminEvents';

const AdminEventsPage = () => {
  const { events, addEvent, updateEvent, deleteEvent } = useAdminEvents();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentEvent, setCurrentEvent] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredEvents = events.filter(evt => {
    const matchesStatus = filterStatus === 'all' || evt.estado === filterStatus;
    const matchesSearch = evt.nombre.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleCreateNew = () => {
    setCurrentEvent(null);
    setIsModalOpen(true);
  };

  const handleEdit = (event) => {
    setCurrentEvent(event);
    setIsModalOpen(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('¿Estás seguro de cancelar este evento?')) {
      deleteEvent(id);
    }
  };

  const handleStatusChange = (id, newStatus) => {
      // In a real app this would likely be a dropdown in the list or a modal action
      // For simplicity here, we assume editing via modal handles status changes
  };

  const handleSaveEvent = (eventData) => {
    if (currentEvent) {
      updateEvent(currentEvent.id, eventData);
    } else {
      addEvent(eventData);
    }
    setIsModalOpen(false);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestión de Eventos</h1>
            <p className="text-gray-500 mt-1">Organiza talleres, webinars y conferencias.</p>
          </div>
          <Button onClick={handleCreateNew} className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2">
            <Plus size={18} /> Nuevo Evento
          </Button>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col sm:flex-row gap-4 justify-between items-center">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Buscar evento..."
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <Filter size={18} className="text-gray-400" />
            <select
              className="bg-gray-50 border border-gray-200 rounded-lg text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer flex-1"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <option value="all">Todos los estados</option>
              <option value="scheduled">Programado</option>
              <option value="ongoing">En curso</option>
              <option value="completed">Completado</option>
              <option value="cancelled">Cancelado</option>
            </select>
          </div>
        </div>

        <EventsList 
          events={filteredEvents} 
          onEdit={handleEdit} 
          onDelete={handleDelete}
        />

        <EventModal 
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          initialData={currentEvent}
          onSave={handleSaveEvent}
          title={currentEvent ? 'Editar Evento' : 'Nuevo Evento'}
        />
      </div>
    </AdminLayout>
  );
};

export default AdminEventsPage;
