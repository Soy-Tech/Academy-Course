
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, CheckCircle, Lock, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/useCart';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const CheckoutPage = () => {
  const navigate = useNavigate();
  const { cartItems, getCartTotal, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '', email: '', address: '', city: '', postal: '', country: '', cardName: '', cardNumber: '', expiry: '', cvc: ''
  });

  const total = getCartTotal() * 1.16; // Including tax

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      clearCart();
      navigate('/order-confirmation');
    }, 2000);
  };

  const isFormValid = Object.values(formData).every(val => val.length > 0);

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Helmet><title>Checkout | Netcom Academy</title></Helmet>
      
      {/* Simplified Header for Checkout */}
      <div className="bg-white border-b border-gray-200 py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
           <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#0B3D91] rounded-lg flex items-center justify-center text-white font-bold">N</div>
              <span className="font-bold text-xl text-[#0B3D91]">Checkout</span>
           </div>
           <div className="flex items-center gap-2 text-sm text-green-600">
              <Lock size={16} /> Conexión Segura
           </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <button onClick={() => navigate('/store/cart')} className="flex items-center text-gray-500 hover:text-gray-900 mb-6 transition-colors">
           <ArrowLeft size={18} className="mr-2" /> Volver al Carrito
        </button>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Form Section */}
          <div className="lg:w-2/3">
             <form onSubmit={handleSubmit} className="space-y-6">
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                   <h3 className="font-bold text-lg mb-4 text-gray-900">Información de Facturación</h3>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1">
                         <label className="text-sm font-medium text-gray-700">Nombre Completo</label>
                         <input required name="name" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div className="space-y-1">
                         <label className="text-sm font-medium text-gray-700">Email</label>
                         <input required type="email" name="email" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div className="space-y-1 md:col-span-2">
                         <label className="text-sm font-medium text-gray-700">Dirección</label>
                         <input required name="address" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div className="space-y-1">
                         <label className="text-sm font-medium text-gray-700">Ciudad</label>
                         <input required name="city" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div className="space-y-1">
                         <label className="text-sm font-medium text-gray-700">Código Postal</label>
                         <input required name="postal" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" />
                      </div>
                      <div className="space-y-1 md:col-span-2">
                         <label className="text-sm font-medium text-gray-700">País</label>
                         <select required name="country" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg bg-white">
                           <option value="">Selecciona un país</option>
                           <option value="ES">España</option>
                           <option value="MX">México</option>
                           <option value="CO">Colombia</option>
                           <option value="AR">Argentina</option>
                         </select>
                      </div>
                   </div>
                </motion.div>

                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                   <h3 className="font-bold text-lg mb-4 text-gray-900">Método de Pago</h3>
                   
                   <div className="flex gap-4 mb-6">
                      <div className="flex-1 p-4 border-2 border-blue-600 bg-blue-50 rounded-lg cursor-pointer flex flex-col items-center justify-center text-blue-700">
                         <CreditCard size={24} className="mb-2" />
                         <span className="text-sm font-bold">Tarjeta</span>
                      </div>
                      <div className="flex-1 p-4 border border-gray-200 rounded-lg cursor-pointer flex flex-col items-center justify-center text-gray-500 hover:border-blue-300 hover:bg-gray-50">
                         <span className="font-bold text-lg mb-1 italic">PayPal</span>
                         <span className="text-sm">Wallet</span>
                      </div>
                   </div>

                   <div className="space-y-4">
                      <div className="space-y-1">
                         <label className="text-sm font-medium text-gray-700">Nombre en la tarjeta</label>
                         <input required name="cardName" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg" />
                      </div>
                      <div className="space-y-1">
                         <label className="text-sm font-medium text-gray-700">Número de tarjeta</label>
                         <div className="relative">
                           <CreditCard className="absolute left-3 top-3 text-gray-400" size={18} />
                           <input required name="cardNumber" placeholder="0000 0000 0000 0000" onChange={handleInputChange} className="w-full p-2.5 pl-10 border border-gray-300 rounded-lg" />
                         </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-1">
                            <label className="text-sm font-medium text-gray-700">Expiración</label>
                            <input required name="expiry" placeholder="MM/YY" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg" />
                         </div>
                         <div className="space-y-1">
                            <label className="text-sm font-medium text-gray-700">CVC</label>
                            <input required name="cvc" type="password" placeholder="123" onChange={handleInputChange} className="w-full p-2.5 border border-gray-300 rounded-lg" />
                         </div>
                      </div>
                   </div>
                </motion.div>

                <Button 
                  type="submit" 
                  disabled={!isFormValid || loading}
                  className="w-full h-14 text-lg font-bold bg-[#0B3D91] hover:bg-[#092c69] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  {loading ? 'Procesando...' : `Pagar $${total.toFixed(2)}`}
                </Button>
                
                <p className="text-center text-xs text-gray-500 mt-4">
                   Al completar la compra aceptas nuestros <a href="#" className="underline">Términos y Condiciones</a>.
                </p>
             </form>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:w-1/3">
             <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 sticky top-8">
                <h3 className="font-bold text-gray-900 mb-4">Resumen del Pedido</h3>
                <div className="space-y-3 mb-4 max-h-60 overflow-y-auto pr-2">
                   {cartItems.map(item => (
                      <div key={item.id} className="flex gap-3 text-sm">
                         <img src={item.image} alt="" className="w-12 h-12 rounded object-cover bg-gray-200" />
                         <div className="flex-1">
                            <p className="font-medium text-gray-900 line-clamp-1">{item.title}</p>
                            <p className="text-gray-500">${item.price}</p>
                         </div>
                      </div>
                   ))}
                </div>
                <div className="border-t border-gray-200 pt-4 space-y-2 text-sm">
                   <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="font-medium">${getCartTotal().toFixed(2)}</span>
                   </div>
                   <div className="flex justify-between">
                      <span className="text-gray-600">Impuestos</span>
                      <span className="font-medium">${(getCartTotal() * 0.16).toFixed(2)}</span>
                   </div>
                   <div className="flex justify-between pt-2 border-t border-gray-200 text-base font-bold text-gray-900">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default CheckoutPage;
