
import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Quote, Filter, Users, Award, TrendingUp } from 'lucide-react';
import { mockTestimonials } from '@/data/mockTestimonials';
import { Button } from '@/components/ui/button';

const TestimonialsPage = () => {
  const [selectedCourse, setSelectedCourse] = useState('Todos');

  // Extract unique courses for filter
  const courses = ['Todos', ...new Set(mockTestimonials.map(t => t.course))];

  // Filter logic
  const filteredTestimonials = useMemo(() => {
    return selectedCourse === 'Todos'
      ? mockTestimonials
      : mockTestimonials.filter(t => t.course === selectedCourse);
  }, [selectedCourse]);

  // Statistics logic
  const stats = useMemo(() => {
    const total = mockTestimonials.length;
    const avgRating = (mockTestimonials.reduce((acc, curr) => acc + curr.rating, 0) / total).toFixed(1);
    const satisfiedStudents = "500+"; // Mock static data for visual impact
    return { total, avgRating, satisfiedStudents };
  }, []);

  return (
    <>
      <Helmet>
        <title>Testimonios - Netcom Academy</title>
        <meta name="description" content="Descubre lo que dicen nuestros estudiantes sobre su experiencia de aprendizaje." />
      </Helmet>

      <div className="bg-gray-50 min-h-screen">
        {/* Hero & Stats Section */}
        <section className="bg-[#0B3D91] text-white pt-20 pb-24 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10">
            <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-white blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full bg-[#CFAE70] blur-3xl"></div>
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center max-w-3xl mx-auto mb-12"
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Historias que inspiran
              </h1>
              <p className="text-xl text-blue-100 leading-relaxed">
                Descubre cómo Netcom Academy ha impulsado las carreras de profesionales en las empresas más importantes del mundo.
              </p>
            </motion.div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 text-center hover:bg-white/20 transition-all"
              >
                <div className="w-12 h-12 bg-[#CFAE70] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="text-white fill-current" size={24} />
                </div>
                <h3 className="text-3xl font-bold mb-1">{stats.avgRating}/5</h3>
                <p className="text-blue-200 text-sm">Calificación Promedio</p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 text-center hover:bg-white/20 transition-all"
              >
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="text-white" size={24} />
                </div>
                <h3 className="text-3xl font-bold mb-1">{stats.satisfiedStudents}</h3>
                <p className="text-blue-200 text-sm">Estudiantes Satisfechos</p>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 text-center hover:bg-white/20 transition-all"
              >
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="text-white" size={24} />
                </div>
                <h3 className="text-3xl font-bold mb-1">94%</h3>
                <p className="text-blue-200 text-sm">Tasa de Finalización</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Filters & Grid Section */}
        <section className="py-16 container mx-auto px-4 max-w-7xl -mt-12 relative z-20">
          <div className="bg-white rounded-2xl shadow-xl p-6 mb-12 border border-gray-100">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <h2 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
                <Filter size={20} className="text-[#0B3D91]" />
                Filtrar por curso:
              </h2>
              <div className="flex overflow-x-auto pb-2 md:pb-0 gap-2 w-full md:w-auto no-scrollbar">
                {courses.map((course) => (
                  <button
                    key={course}
                    onClick={() => setSelectedCourse(course)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                      selectedCourse === course
                        ? 'bg-[#0B3D91] text-white shadow-md transform scale-105'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {course}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            <AnimatePresence>
              {filteredTestimonials.map((testimonial) => (
                <motion.div
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  key={testimonial.id}
                  className="bg-white rounded-xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 flex flex-col h-full"
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className="relative">
                      <img 
                        src={testimonial.image} 
                        alt={testimonial.name} 
                        className="w-16 h-16 rounded-full object-cover border-2 border-gray-100 shadow-sm"
                      />
                      <div className="absolute -bottom-1 -right-1 bg-[#CFAE70] rounded-full p-1 border-2 border-white">
                         <Quote size={12} className="text-white fill-current" />
                      </div>
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg leading-tight">{testimonial.name}</h3>
                      <p className="text-sm text-gray-500 font-medium">{testimonial.role}</p>
                      <p className="text-xs text-[#0B3D91] font-semibold">{testimonial.company}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <span className="inline-block px-3 py-1 bg-blue-50 text-[#0B3D91] text-xs font-semibold rounded-full">
                      {testimonial.course}
                    </span>
                  </div>

                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        size={16} 
                        className={`${i < testimonial.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                      />
                    ))}
                  </div>

                  <p className="text-gray-600 italic leading-relaxed mb-6 flex-grow relative z-10">
                    "{testimonial.comment}"
                  </p>

                  <div className="mt-auto pt-4 border-t border-gray-50 flex justify-between items-center text-xs text-gray-400">
                    <span>Verificado</span>
                    <span>{new Date(testimonial.date).toLocaleDateString()}</span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredTestimonials.length === 0 && (
            <div className="text-center py-20">
              <p className="text-gray-500 text-lg">No se encontraron testimonios para este filtro.</p>
              <Button 
                variant="link" 
                onClick={() => setSelectedCourse('Todos')}
                className="text-[#0B3D91] mt-2"
              >
                Ver todos los testimonios
              </Button>
            </div>
          )}
        </section>

        {/* CTA Section */}
        <section className="bg-gray-900 text-white py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">¿Listo para escribir tu propia historia?</h2>
            <p className="text-gray-400 max-w-2xl mx-auto mb-8">
              Únete a miles de estudiantes que ya están transformando su futuro con Netcom Academy.
            </p>
            <Button className="btn-primary text-lg px-8 py-6 h-auto">
              Explorar Cursos
            </Button>
          </div>
        </section>
      </div>
    </>
  );
};

export default TestimonialsPage;
