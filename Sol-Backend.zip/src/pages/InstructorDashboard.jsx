
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, DollarSign, BookOpen, TrendingUp, Plus, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const InstructorDashboard = () => {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const stats = [
    { label: 'Estudiantes Totales', value: 128, icon: Users, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Ingresos (Mes)', value: '$1,240', icon: DollarSign, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Cursos Activos', value: 4, icon: BookOpen, color: 'text-orange-600', bg: 'bg-orange-100' },
    { label: 'Valoración Media', value: '4.8', icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-100' },
  ];

  const handleStartCreation = () => {
    setIsCreateModalOpen(false);
    toast({
      title: "Funcionalidad en desarrollo",
      description: "El creador de cursos estará disponible próximamente.",
      variant: "default"
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-12 font-sans">
      <div className="bg-white border-b border-gray-200 pt-8 pb-8 px-6">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Panel de Instructor</h1>
            <p className="text-gray-500">Bienvenido de nuevo, {currentUser?.name}.</p>
          </div>
          <Button 
            onClick={() => setIsCreateModalOpen(true)}
            className="bg-[#0B3D91] hover:bg-[#092c69] flex items-center gap-2"
          >
            <Plus size={18} /> Crear Nuevo Curso
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 transition-all hover:shadow-md">
               <div className="flex justify-between items-start mb-4">
                  <div className={`p-3 rounded-xl ${stat.bg}`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
               </div>
               <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
               <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden min-h-[400px]">
            <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                <h3 className="font-bold text-gray-900">Mis Cursos</h3>
                <Button variant="ghost" size="sm" className="text-sm text-blue-600">Ver Todos</Button>
            </div>
            <div className="p-12 text-center flex flex-col items-center justify-center h-full">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <BookOpen className="text-gray-400" size={32} />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Gestiona tu contenido</h4>
                <p className="text-gray-500 max-w-md mx-auto mb-6">Aquí aparecerá la lista de tus cursos creados. Comienza a compartir tu conocimiento hoy mismo.</p>
                <Button variant="outline" onClick={() => setIsCreateModalOpen(true)}>
                  Crear mi primer curso
                </Button>
            </div>
        </div>
      </div>

      {/* Simple Creation Modal */}
      <AnimatePresence>
        {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden"
            >
              <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center">
                <h3 className="font-bold text-lg text-gray-900">Crear Nuevo Curso</h3>
                <button onClick={() => setIsCreateModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <X size={20} />
                </button>
              </div>
              
              <div className="p-6">
                <p className="text-gray-600 mb-6">
                  Estás a punto de crear un nuevo curso. ¿Qué tipo de contenido deseas crear?
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                   <button className="p-4 border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left group">
                      <div className="mb-2 w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <BookOpen size={20} />
                      </div>
                      <span className="font-semibold text-gray-900 block">Curso Estándar</span>
                      <span className="text-xs text-gray-500">Módulos, lecciones y quizzes</span>
                   </button>
                   
                   <button className="p-4 border border-gray-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all text-left group">
                      <div className="mb-2 w-10 h-10 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center group-hover:bg-purple-600 group-hover:text-white transition-colors">
                        <TrendingUp size={20} />
                      </div>
                      <span className="font-semibold text-gray-900 block">Workshop</span>
                      <span className="text-xs text-gray-500">Sesión en vivo intensiva</span>
                   </button>
                </div>

                <div className="flex justify-end gap-3">
                  <Button variant="ghost" onClick={() => setIsCreateModalOpen(false)}>Cancelar</Button>
                  <Button onClick={handleStartCreation} className="bg-[#0B3D91]">Continuar</Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default InstructorDashboard;
