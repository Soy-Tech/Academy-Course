
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Check, Trash2, Archive, MessageSquare, Award, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

// Mock Notifications Data
const mockNotifications = Array.from({ length: 25 }, (_, i) => ({
  id: i + 1,
  title: [
    'Nuevo módulo disponible en "React Avanzado"',
    '¡Felicidades! Has completado el curso',
    'Juan comentó en tu proyecto',
    'Recordatorio: Webinar de UX mañana'
  ][i % 4],
  description: 'Haz clic para ver los detalles y continuar con tu aprendizaje.',
  type: ['course', 'achievement', 'message', 'event'][i % 4],
  read: i > 5,
  archived: i > 20,
  date: `${Math.floor(i / 2) + 1}h ago`
}));

const NotificationsPage = () => {
  const [filter, setFilter] = useState('all'); // all, unread, archived
  const [notifications, setNotifications] = useState(mockNotifications);

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'unread') return !n.read && !n.archived;
    if (filter === 'archived') return n.archived;
    return !n.archived;
  });

  const getIcon = (type) => {
    switch(type) {
      case 'achievement': return <Award className="text-yellow-500" />;
      case 'message': return <MessageSquare className="text-blue-500" />;
      case 'course': return <BookOpen className="text-green-500" />;
      default: return <Bell className="text-gray-500" />;
    }
  };

  const markAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const archiveNotification = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, archived: true } : n));
  };

  const deleteNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans flex flex-col">
      <Header />
      <div className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
               <Bell size={20} />
            </div>
            Notificaciones
          </h1>
          <Button variant="ghost" onClick={() => setNotifications(prev => prev.map(n => ({ ...n, read: true })))}>
             Marcar todo como leído
          </Button>
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6 border-b border-gray-200 pb-1">
          {['all', 'unread', 'archived'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 text-sm font-medium rounded-t-lg transition-colors capitalize ${
                filter === f 
                  ? 'bg-white border-x border-t border-gray-200 text-blue-600 border-b-white -mb-[1px] relative z-10' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              {f === 'all' ? 'Todas' : f === 'unread' ? 'No leídas' : 'Archivadas'}
            </button>
          ))}
        </div>

        {/* List */}
        <div className="space-y-3">
          <AnimatePresence>
            {filteredNotifications.length === 0 ? (
               <div className="text-center py-12 text-gray-500 bg-white rounded-xl border border-dashed border-gray-200">
                  <Bell size={32} className="mx-auto mb-2 opacity-20" />
                  <p>No tienes notificaciones en esta sección.</p>
               </div>
            ) : (
              filteredNotifications.map((notification) => (
                <motion.div
                  key={notification.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className={`bg-white p-4 rounded-xl border transition-all flex gap-4 ${
                    !notification.read ? 'border-blue-200 shadow-sm bg-blue-50/10' : 'border-gray-200'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-gray-50 border border-gray-100`}>
                    {getIcon(notification.type)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <h4 className={`text-sm ${!notification.read ? 'font-bold text-gray-900' : 'font-medium text-gray-700'}`}>
                        {notification.title}
                      </h4>
                      <span className="text-xs text-gray-400 whitespace-nowrap ml-2">{notification.date}</span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">{notification.description}</p>
                  </div>

                  <div className="flex items-center gap-1 self-center pl-4 border-l border-gray-100 ml-2">
                     {!notification.read && (
                       <button onClick={() => markAsRead(notification.id)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full" title="Marcar como leído">
                          <Check size={16} />
                       </button>
                     )}
                     <button onClick={() => archiveNotification(notification.id)} className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-full" title="Archivar">
                        <Archive size={16} />
                     </button>
                     <button onClick={() => deleteNotification(notification.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full" title="Eliminar">
                        <Trash2 size={16} />
                     </button>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default NotificationsPage;
