
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { BookOpen, GraduationCap, Check, ArrowRight, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { mockCategories } from '@/data/mockCategories';
import { coursesData } from '@/data/coursesData';
import CourseCard from '@/components/CourseCard';

const OnboardingPage = () => {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState(null);
  const [selectedInterests, setSelectedInterests] = useState([]);
  const navigate = useNavigate();

  const totalSteps = 4;
  const progress = (step / totalSteps) * 100;

  const nextStep = () => setStep(prev => Math.min(prev + 1, totalSteps));
  const prevStep = () => setStep(prev => Math.max(prev - 1, 1));
  const skip = () => nextStep();

  const toggleInterest = (id) => {
    setSelectedInterests(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const recommendedCourses = coursesData.slice(0, 4); // Mock recommendation logic

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Progress Bar */}
      <div className="h-1.5 w-full bg-gray-100">
        <motion.div 
          className="h-full bg-blue-600" 
          initial={{ width: 0 }} 
          animate={{ width: `${progress}%` }} 
          transition={{ duration: 0.5 }}
        />
      </div>

      <div className="flex-1 container mx-auto px-4 py-8 flex flex-col items-center justify-center max-w-5xl">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div 
              key="step1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="text-center max-w-lg"
            >
              <div className="w-20 h-20 bg-blue-600 rounded-2xl mx-auto mb-6 flex items-center justify-center shadow-xl rotate-3">
                <span className="text-white text-4xl font-bold">N</span>
              </div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Welcome to Netcom Academy</h1>
              <p className="text-lg text-gray-600 mb-8">
                Your journey to mastering technology starts here. Let's personalize your experience to help you reach your goals faster.
              </p>
              <Button onClick={nextStep} className="w-full md:w-auto h-12 px-8 text-lg bg-blue-600 hover:bg-blue-700">
                Get Started <ArrowRight className="ml-2" />
              </Button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div 
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full max-w-2xl"
            >
              <h2 className="text-3xl font-bold text-center mb-2">What's your primary goal?</h2>
              <p className="text-center text-gray-500 mb-8">We'll adapt the interface to your needs.</p>
              
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div 
                  onClick={() => setRole('student')}
                  className={`cursor-pointer p-8 rounded-2xl border-2 transition-all duration-200 hover:shadow-lg ${
                    role === 'student' ? 'border-blue-600 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
                    role === 'student' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}>
                    <BookOpen size={24} />
                  </div>
                  <h3 className="text-xl font-bold mb-2">I want to learn</h3>
                  <p className="text-gray-500 text-sm">Access thousands of courses, track your progress, and earn certificates.</p>
                  {role === 'student' && <div className="mt-4 flex justify-end"><Check className="text-blue-600" /></div>}
                </div>

                <div 
                  onClick={() => setRole('instructor')}
                  className={`cursor-pointer p-8 rounded-2xl border-2 transition-all duration-200 hover:shadow-lg ${
                    role === 'instructor' ? 'border-purple-600 bg-purple-50' : 'border-gray-200 hover:border-purple-300'
                  }`}
                >
                   <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-4 ${
                    role === 'instructor' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}>
                    <GraduationCap size={24} />
                  </div>
                  <h3 className="text-xl font-bold mb-2">I want to teach</h3>
                  <p className="text-gray-500 text-sm">Create courses, mentor students, and earn money sharing your knowledge.</p>
                   {role === 'instructor' && <div className="mt-4 flex justify-end"><Check className="text-purple-600" /></div>}
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="ghost" onClick={prevStep}>Back</Button>
                <Button onClick={nextStep} disabled={!role} className="bg-blue-600 hover:bg-blue-700">Next Step</Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div 
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full max-w-3xl"
            >
              <h2 className="text-3xl font-bold text-center mb-2">What are you interested in?</h2>
              <p className="text-center text-gray-500 mb-8">Select at least one topic to get personalized recommendations.</p>
              
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
                {mockCategories.map(cat => (
                  <div
                    key={cat.id}
                    onClick={() => toggleInterest(cat.id)}
                    className={`cursor-pointer p-4 rounded-xl border transition-all duration-200 text-center flex flex-col items-center gap-3 ${
                      selectedInterests.includes(cat.id) 
                        ? 'border-blue-600 bg-blue-50 shadow-md ring-1 ring-blue-600' 
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <cat.icon size={24} className={selectedInterests.includes(cat.id) ? 'text-blue-600' : 'text-gray-500'} />
                    <span className={`text-sm font-medium ${selectedInterests.includes(cat.id) ? 'text-blue-900' : 'text-gray-700'}`}>
                      {cat.name}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center">
                <Button variant="ghost" onClick={prevStep}>Back</Button>
                <div className="flex gap-4">
                  <Button variant="ghost" onClick={skip} className="text-gray-500">Skip</Button>
                  <Button onClick={nextStep} disabled={selectedInterests.length === 0} className="bg-blue-600 hover:bg-blue-700">
                    Next Step ({selectedInterests.length})
                  </Button>
                </div>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div 
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="w-full"
            >
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold mb-2">We found some courses for you!</h2>
                <p className="text-gray-500">Based on your interests in {role === 'student' ? 'learning' : 'teaching'} technology.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                {recommendedCourses.map((course, idx) => (
                   <motion.div 
                    key={course.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                   >
                     <CourseCard course={course} />
                   </motion.div>
                ))}
              </div>

              <div className="flex justify-center gap-4">
                 <Button onClick={() => navigate('/dashboard')} className="h-12 px-8 text-lg bg-blue-600 hover:bg-blue-700">
                    Go to Dashboard
                 </Button>
                 <Button onClick={() => navigate('/cursos')} variant="outline" className="h-12 px-8 text-lg">
                    Explore All Courses
                 </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default OnboardingPage;
