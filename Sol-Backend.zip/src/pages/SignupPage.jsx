
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, User, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import FormInput from '@/components/FormInput';
import FormButton from '@/components/FormButton';

const SignupPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: 'Error de validación',
        description: 'Las contraseñas no coinciden.',
        variant: 'destructive'
      });
      return;
    }

    setIsLoading(true);

    try {
      // Call Supabase SignUp via AuthContext
      await signup({
          email: formData.email,
          password: formData.password,
          name: formData.name
      });

      toast({
          title: '¡Cuenta creada!',
          description: 'Por favor verifica tu correo electrónico para confirmar tu cuenta.',
      });

      // Redirect to login
      navigate('/login');

    } catch (error) {
      console.error(error);
      toast({
        title: 'Error al registrarse',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Crear Cuenta - Netcom Academy</title>
      </Helmet>

      <div className="min-h-screen flex bg-gray-50">
        {/* Left Side - Hero/Image */}
        <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gray-900">
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-900 to-[#0B3D91] opacity-90 z-10"></div>
          <div className="absolute inset-0 z-0">
             <img 
               src="https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=2670&auto=format&fit=crop" 
               className="w-full h-full object-cover" 
               alt="Coding"
             />
          </div>
          <div className="relative z-20 flex flex-col justify-between p-12 text-white h-full">
            <div className="text-sm font-bold tracking-widest uppercase opacity-70">Netcom Academy</div>
            <div>
              <h1 className="text-4xl font-bold mb-4">Aprende sin límites.</h1>
              <p className="text-lg text-gray-300 max-w-md">
                Desarrolla las habilidades que necesitas para el trabajo que deseas. Cursos prácticos, mentoría y comunidad.
              </p>
            </div>
            <div className="flex gap-2">
               <div className="h-1 w-8 bg-[#CFAE70] rounded-full"></div>
               <div className="h-1 w-2 bg-gray-600 rounded-full"></div>
               <div className="h-1 w-2 bg-gray-600 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="w-full lg:w-1/2 flex items-center justify-center p-6 lg:p-12 overflow-y-auto">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full max-w-md"
          >
            <div className="mb-6">
              <Link to="/" className="inline-flex items-center text-sm font-medium text-gray-500 hover:text-[#0B3D91] mb-6">
                 <ArrowRight className="rotate-180 mr-2" size={16} /> Volver al inicio
              </Link>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Crea tu cuenta gratis</h2>
              <p className="text-gray-500">No se requiere tarjeta de crédito.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <FormInput
                label="Nombre completo"
                placeholder="Juan Pérez"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                icon={User}
                required
              />

              <FormInput
                label="Correo electrónico"
                type="email"
                placeholder="tu@email.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                icon={Mail}
                required
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormInput
                  label="Contraseña"
                  type="password"
                  placeholder="Min. 8 chars"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  icon={Lock}
                  required
                />
                
                <FormInput
                  label="Confirmar"
                  type="password"
                  placeholder="Repetir"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  icon={Lock}
                  required
                />
              </div>

              <div className="flex items-start gap-3 mt-2">
                <input 
                  type="checkbox" 
                  id="terms" 
                  required
                  className="mt-1 rounded border-gray-300 text-[#0B3D91] focus:ring-[#0B3D91]" 
                />
                <label htmlFor="terms" className="text-xs text-gray-600">
                  Acepto los <Link to="/terms" className="text-[#0B3D91] underline">Términos</Link> y la <Link to="/privacy" className="text-[#0B3D91] underline">Política de Privacidad</Link>.
                </label>
              </div>

              <FormButton type="submit" loading={isLoading} className="mt-2">
                Crear Cuenta
              </FormButton>
            </form>

            <p className="mt-8 text-center text-gray-600">
              ¿Ya tienes una cuenta?{' '}
              <Link to="/login" className="text-[#0B3D91] font-bold hover:underline">
                Inicia sesión aquí
              </Link>
            </p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default SignupPage;
