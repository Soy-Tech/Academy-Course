
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, Settings, User, Camera, Lock, Bell, Moon, Download, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CourseCard from '@/components/Courses/CourseCard';
import ProgressBar from '@/components/UI/ProgressBar';
import { useAuth } from '@/contexts/AuthContext';

// Mock Data
const enrolledCourses = [
  { id: 1, title: 'Desarrollo Web Full Stack', progress: 45, image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085', instructor: 'Sarah Instructor' },
  { id: 2, title: 'Introducción a Python', progress: 12, image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5', instructor: 'Jane Smith' }
];

const completedCourses = [
  { id: 3, title: 'Fundamentos de Marketing', grade: 95, date: '15 Oct 2023', image: 'https://images.unsplash.com/photo-1533750516457-a7f992034fec' }
];

const UserProfilePage = () => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('courses');

  const tabs = [
    { id: 'courses', label: 'Mis Cursos', icon: BookOpen },
    { id: 'certificates', label: 'Certificados', icon: Award },
    { id: 'settings', label: 'Configuración', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      <Header />
      
      {/* Profile Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="container mx-auto px-6 py-8">
           <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="relative group cursor-pointer">
                 <div className="w-24 h-24 rounded-full bg-blue-600 flex items-center justify-center text-3xl font-bold text-white ring-4 ring-blue-50 overflow-hidden">
                    {currentUser?.avatar || currentUser?.name?.charAt(0) || 'U'}
                 </div>
                 <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Camera className="text-white" size={24} />
                 </div>
              </div>
              <div className="text-center md:text-left">
                 <h1 className="text-2xl font-bold text-gray-900">{currentUser?.name || 'Usuario'}</h1>
                 <p className="text-gray-500">{currentUser?.email || 'usuario@ejemplo.com'}</p>
                 <p className="text-sm text-gray-400 mt-1 max-w-md">Apasionado por el aprendizaje continuo y la tecnología.</p>
              </div>
           </div>
           
           {/* Tab Nav */}
           <div className="flex gap-6 mt-8 overflow-x-auto pb-2 md:pb-0">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 pb-3 px-1 border-b-2 transition-all whitespace-nowrap ${
                    activeTab === tab.id 
                      ? 'border-blue-600 text-blue-600 font-bold' 
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <tab.icon size={18} />
                  {tab.label}
                </button>
              ))}
           </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 container mx-auto px-6 py-8">
         <motion.div
           key={activeTab}
           initial={{ opacity: 0, y: 10 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.3 }}
         >
           {activeTab === 'courses' && (
             <div className="space-y-12">
                <section>
                   <h2 className="text-xl font-bold text-gray-900 mb-6">Cursos en Progreso</h2>
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {enrolledCourses.map((course) => (
                         <div key={course.id} className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                            <div className="h-40 bg-gray-200 overflow-hidden">
                               <img src={course.image} alt={course.title} className="w-full h-full object-cover" />
                            </div>
                            <div className="p-5">
                               <h3 className="font-bold text-gray-900 mb-2 truncate">{course.title}</h3>
                               <p className="text-xs text-gray-500 mb-4">Inst: {course.instructor}</p>
                               <div className="mb-4">
                                  <div className="flex justify-between text-xs mb-1">
                                     <span className="font-semibold text-blue-600">{course.progress}%</span>
                                     <span className="text-gray-400">Completado</span>
                                  </div>
                                  <ProgressBar value={course.progress} className="h-1.5" />
                               </div>
                               <Button className="w-full bg-[#0B3D91]">Continuar</Button>
                            </div>
                         </div>
                      ))}
                   </div>
                </section>
                
                <section>
                   <h2 className="text-xl font-bold text-gray-900 mb-6">Completados</h2>
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {completedCourses.map((course) => (
                         <div key={course.id} className="bg-white rounded-xl border border-gray-200 p-5 flex items-center gap-4 shadow-sm opacity-75 hover:opacity-100 transition-opacity">
                            <div className="w-16 h-16 rounded-lg bg-green-100 flex items-center justify-center text-green-600 flex-shrink-0">
                               <Award size={32} />
                            </div>
                            <div>
                               <h3 className="font-bold text-gray-900 text-sm">{course.title}</h3>
                               <p className="text-xs text-gray-500">Finalizado: {course.date}</p>
                               <p className="text-xs font-bold text-green-600 mt-1">Calificación: {course.grade}/100</p>
                            </div>
                         </div>
                      ))}
                   </div>
                </section>
             </div>
           )}

           {activeTab === 'certificates' && (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {completedCourses.map((cert) => (
                  <div key={cert.id} className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
                      <div className="flex items-center gap-4">
                         <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600">
                            <Award size={24} />
                         </div>
                         <div>
                            <h3 className="font-bold text-gray-900">{cert.title}</h3>
                            <p className="text-sm text-gray-500">Otorgado el {cert.date}</p>
                         </div>
                      </div>
                      <div className="flex gap-3">
                         <Button variant="outline" size="sm" className="gap-2">
                            <Share2 size={16} /> Compartir
                         </Button>
                         <Button size="sm" className="gap-2 bg-blue-600">
                            <Download size={16} /> Descargar PDF
                         </Button>
                      </div>
                  </div>
               ))}
               {completedCourses.length === 0 && (
                 <div className="col-span-full py-12 text-center bg-white rounded-xl border border-dashed border-gray-300">
                    <Award size={48} className="mx-auto text-gray-300 mb-4" />
                    <p className="text-gray-500">Aún no tienes certificados. ¡Completa un curso para obtener uno!</p>
                 </div>
               )}
             </div>
           )}

           {activeTab === 'settings' && (
             <div className="max-w-2xl mx-auto space-y-8">
               <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                     <User size={20} className="text-blue-600" /> Información Personal
                  </h3>
                  <div className="space-y-4">
                     <div className="grid grid-cols-2 gap-4">
                        <div>
                           <label className="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                           <input type="text" defaultValue={currentUser?.name} className="w-full p-2 border rounded-lg text-sm" />
                        </div>
                        <div>
                           <label className="block text-sm font-medium text-gray-700 mb-1">Apellido</label>
                           <input type="text" defaultValue="Usuario" className="w-full p-2 border rounded-lg text-sm" />
                        </div>
                     </div>
                     <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input type="email" defaultValue={currentUser?.email} className="w-full p-2 border rounded-lg text-sm bg-gray-50" disabled />
                     </div>
                     <div className="pt-2">
                        <Button className="bg-[#0B3D91]">Guardar Cambios</Button>
                     </div>
                  </div>
               </div>

               <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                     <Lock size={20} className="text-blue-600" /> Seguridad
                  </h3>
                  <div className="space-y-4">
                     <Button variant="outline" className="w-full justify-start text-left">Cambiar Contraseña</Button>
                     <div className="flex items-center justify-between py-2">
                        <span className="text-sm font-medium text-gray-700">Autenticación de dos factores</span>
                        <div className="w-10 h-6 bg-gray-200 rounded-full relative cursor-pointer">
                           <div className="w-4 h-4 bg-white rounded-full absolute top-1 left-1 shadow-sm"></div>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                     <Bell size={20} className="text-blue-600" /> Preferencias
                  </h3>
                  <div className="space-y-4 divide-y divide-gray-100">
                     <div className="flex items-center justify-between py-2">
                        <span className="text-sm text-gray-700">Notificaciones por email</span>
                        <input type="checkbox" defaultChecked className="toggle" />
                     </div>
                     <div className="flex items-center justify-between py-2">
                        <span className="text-sm text-gray-700">Nuevos cursos recomendados</span>
                        <input type="checkbox" defaultChecked className="toggle" />
                     </div>
                     <div className="flex items-center justify-between py-2">
                        <div className="flex items-center gap-2">
                           <Moon size={16} className="text-gray-500" />
                           <span className="text-sm text-gray-700">Modo Oscuro</span>
                        </div>
                        <input type="checkbox" className="toggle" />
                     </div>
                  </div>
               </div>
             </div>
           )}
         </motion.div>
      </div>
      <Footer />
    </div>
  );
};

export default UserProfilePage;
