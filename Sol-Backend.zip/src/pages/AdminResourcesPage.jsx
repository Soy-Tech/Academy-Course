
import React, { useState } from 'react';
import { Plus, Search, Filter } from 'lucide-react';
import AdminLayout from '@/components/Admin/AdminLayout';
import ResourcesList from '@/components/Admin/ResourcesList';
import ResourceModal from '@/components/Admin/ResourceModal';
import { Button } from '@/components/ui/button';
import { useAdminResources } from '@/hooks/useAdminResources';

const AdminResourcesPage = () => {
  const { resources, addResource, updateResource, deleteResource } = useAdminResources();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentResource, setCurrentResource] = useState(null);
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredResources = resources.filter(res => {
    const matchesType = filterType === 'all' || res.tipo === filterType;
    const matchesStatus = filterStatus === 'all' || res.estado === filterStatus;
    const matchesSearch = res.nombre.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesStatus && matchesSearch;
  });

  const handleCreateNew = () => {
    setCurrentResource(null);
    setIsModalOpen(true);
  };

  const handleEdit = (resource) => {
    setCurrentResource(resource);
    setIsModalOpen(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('¿Estás seguro de eliminar este recurso?')) {
      deleteResource(id);
    }
  };

  const handleToggleStatus = (id) => {
    const resource = resources.find(r => r.id === id);
    if (resource) {
      updateResource(id, { estado: resource.estado === 'published' ? 'draft' : 'published' });
    }
  };

  const handleSaveResource = (resourceData) => {
    if (currentResource) {
      updateResource(currentResource.id, resourceData);
    } else {
      addResource(resourceData);
    }
    setIsModalOpen(false);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Gestión de Recursos</h1>
            <p className="text-gray-500 mt-1">Materiales complementarios para los cursos.</p>
          </div>
          <Button onClick={handleCreateNew} className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2">
            <Plus size={18} /> Nuevo Recurso
          </Button>
        </div>

        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col lg:flex-row gap-4 justify-between items-center">
          <div className="relative w-full lg:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Buscar recurso..."
              className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex flex-col sm:flex-row gap-2 w-full lg:w-auto">
            <div className="flex items-center gap-2">
              <Filter size={18} className="text-gray-400" />
              <select
                className="bg-gray-50 border border-gray-200 rounded-lg text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
              >
                <option value="all">Todos los tipos</option>
                <option value="pdf">PDF</option>
                <option value="video">Video</option>
                <option value="documento">Documento</option>
              </select>
            </div>
            <select
              className="bg-gray-50 border border-gray-200 rounded-lg text-sm px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <option value="all">Todos los estados</option>
              <option value="published">Publicado</option>
              <option value="draft">Borrador</option>
            </select>
          </div>
        </div>

        <ResourcesList 
          resources={filteredResources} 
          onEdit={handleEdit} 
          onDelete={handleDelete}
          onToggleStatus={handleToggleStatus}
        />

        <ResourceModal 
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          initialData={currentResource}
          onSave={handleSaveResource}
          title={currentResource ? 'Editar Recurso' : 'Nuevo Recurso'}
        />
      </div>
    </AdminLayout>
  );
};

export default AdminResourcesPage;
