
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { mockBlogPosts } from '@/data/mockBlog';
import { ArrowLeft, Calendar, User, Clock } from 'lucide-react';

const BlogDetailPage = () => {
  const { id } = useParams();
  const post = mockBlogPosts.find(p => p.id.toString() === id);

  if (!post) return <div className="text-center py-20">Artículo no encontrado</div>;

  return (
    <>
      <Helmet>
        <title>{post.title} - Blog Netcom</title>
        <meta name="description" content={post.excerpt} />
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <Link to="/blog" className="inline-flex items-center text-[#0B3D91] mb-8 hover:underline">
            <ArrowLeft size={16} className="mr-2" /> Volver al blog
          </Link>

          <article className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <img src={post.image} alt={post.title} className="w-full h-80 object-cover" />
            
            <div className="p-8 md:p-12">
              <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-6">
                <span className="flex items-center"><User size={16} className="mr-1"/> {post.author}</span>
                <span className="flex items-center"><Calendar size={16} className="mr-1"/> {post.date}</span>
                <span className="flex items-center"><Clock size={16} className="mr-1"/> {post.readTime}</span>
                <span className="bg-blue-100 text-[#0B3D91] px-2 py-0.5 rounded-full font-medium">{post.category}</span>
              </div>

              <h1 className="text-3xl md:text-5xl font-bold text-gray-900 mb-8">{post.title}</h1>
              
              <div className="prose prose-lg max-w-none text-gray-700">
                <p>{post.content}</p>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                <h3>Subtítulo de ejemplo</h3>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
              </div>
            </div>
          </article>

          <div className="mt-12 bg-white rounded-xl shadow p-8">
             <h3 className="text-2xl font-bold mb-4">Comentarios</h3>
             <textarea className="w-full border border-gray-300 rounded-lg p-4 mb-4 focus:ring-2 focus:ring-[#0B3D91] outline-none" placeholder="Escribe un comentario... (Funcionalidad Demo)" rows="3"></textarea>
             <button className="bg-[#0B3D91] text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-800 transition">Publicar comentario</button>
          </div>
        </div>
      </div>
    </>
  );
};

export default BlogDetailPage;
