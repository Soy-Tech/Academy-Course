
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import ResourceCard from '@/components/ResourceCard';
import PageBanner from '@/components/PageBanner';
import { Search, Filter, FolderOpen } from 'lucide-react';
import { mockResources } from '@/data/mockResources';

const ResourcesPage = () => {
  const [resources, setResources] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'Backend', 'Data', 'Cloud', 'Frontend', 'General', 'DevOps', 'Security'];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setResources(mockResources);
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  const filteredResources = resources.filter(resource => {
    const matchesSearch = resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          resource.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || resource.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const scrollToResources = () => {
    document.getElementById('resources-list').scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Recursos Gratuitos - Netcom Academy</title>
        <meta name="description" content="Accede a nuestra colección de recursos educativos gratuitos: guías, plantillas, tutoriales y más para potenciar tu carrera tecnológica." />
      </Helmet>

      <PageBanner 
        title="Recursos Gratuitos"
        subtitle="Accede a una colección curada de materiales educativos, guías y herramientas para potenciar tu aprendizaje tecnológico."
        backgroundImage="https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
        cta={{ label: "Explorar biblioteca", onClick: scrollToResources }}
        height="h-[350px] md:h-[450px]"
      />

      <div id="resources-list" className="min-h-screen bg-gray-50 py-16 md:py-24">
        <div className="container mx-auto px-4 max-w-[1200px]">
          
          {/* Controls */}
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-4 mb-10 items-center justify-between">
            <div className="relative w-full md:w-96 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-[#0B3D91] transition-colors" size={20} />
              <input
                type="text"
                placeholder="Buscar recursos por título..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0B3D91]/20 focus:border-[#0B3D91] transition-all text-sm font-medium"
              />
            </div>
            
            <div className="relative w-full md:w-auto">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" size={18} />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full md:w-64 pl-10 pr-10 py-3 bg-white border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0B3D91]/20 focus:border-[#0B3D91] cursor-pointer text-sm font-semibold text-gray-700 appearance-none hover:bg-gray-50 transition-colors capitalize"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>
                    {cat === 'all' ? 'Todas las categorías' : cat}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none border-l border-gray-200 pl-2">
                 <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
              </div>
            </div>
          </div>

          {/* Content */}
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-32">
              <div className="w-12 h-12 border-4 border-[#0B3D91]/30 border-t-[#0B3D91] rounded-full animate-spin mb-4"></div>
              <p className="text-gray-500 font-medium">Cargando biblioteca...</p>
            </div>
          ) : filteredResources.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredResources.map((resource, index) => (
                <ResourceCard key={resource.id} resource={resource} delay={index * 0.05} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-dashed border-gray-300 p-12 text-center">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
                <FolderOpen size={32} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">No se encontraron recursos</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                No hay materiales disponibles para la búsqueda "{searchTerm}" en la categoría seleccionada.
              </p>
              <button 
                onClick={() => {setSearchTerm(''); setSelectedCategory('all');}}
                className="mt-6 text-[#0B3D91] font-semibold hover:underline"
              >
                Ver todos los recursos
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default ResourcesPage;
