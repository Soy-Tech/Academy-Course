
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Mail, Lock, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import FormInput from '@/components/FormInput';
import FormButton from '@/components/FormButton';
import { getRoleDashboard } from '@/utils/roleRedirect';

const LoginPage = () => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  
  const { login } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (formData.email && formData.password) {
        // Authenticate with Supabase
        const { user } = await login(formData.email, formData.password);
        
        if (user) {
           toast({
            title: '¡Bienvenido!',
            description: `Sesión iniciada correctamente.`,
          });
          
          // Determine redirect
          const redirectUrl = searchParams.get('redirect');
          
          // Wait briefly to allow Context to refresh profile before redirecting
          // (though onAuthStateChange should handle this, a small delay ensures smoother UX)
          setTimeout(() => {
              navigate(redirectUrl || '/student/dashboard');
          }, 100);
        }
      } else {
        toast({ title: 'Error', description: 'Por favor completa todos los campos.', variant: 'destructive' });
      }
    } catch (error) {
      console.error(error);
      toast({ 
          title: 'Error de acceso', 
          description: error.message === 'Invalid login credentials' 
            ? 'Credenciales inválidas.' 
            : error.message, 
          variant: 'destructive' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Iniciar Sesión - Netcom Academy</title>
      </Helmet>

      <div className="min-h-screen flex bg-gray-50">
        {/* Left Side - Hero */}
        <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-[#0B3D91]">
          <div className="absolute inset-0 bg-gradient-to-br from-[#0B3D91] to-purple-900 opacity-90 z-10"></div>
          <div className="absolute inset-0 z-0">
             <img 
               src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2671&auto=format&fit=crop" 
               className="w-full h-full object-cover" 
               alt="Students"
             />
          </div>
          <div className="relative z-20 flex flex-col justify-center px-12 text-white h-full">
            <h1 className="text-5xl font-bold mb-6">Tu futuro digital comienza aquí.</h1>
            <p className="text-xl text-blue-100 max-w-md leading-relaxed">
              Únete a más de 10,000 estudiantes y domina las tecnologías más demandadas del mercado.
            </p>
            <div className="mt-12 space-y-4">
               <div className="flex items-center gap-3">
                 <CheckCircle className="text-[#CFAE70]" /> <span>Acceso ilimitado a cursos</span>
               </div>
               <div className="flex items-center gap-3">
                 <CheckCircle className="text-[#CFAE70]" /> <span>Certificados reconocidos</span>
               </div>
            </div>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="w-full lg:w-1/2 flex items-center justify-center p-6 lg:p-12 overflow-y-auto">
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full max-w-md my-8"
          >
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-[#0B3D91] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-900/20">
                <span className="text-white font-bold text-3xl">N</span>
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Bienvenido de nuevo</h2>
              <p className="text-gray-500">Ingresa tus credenciales para acceder</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <FormInput
                label="Correo electrónico"
                type="email"
                placeholder="nombre@ejemplo.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                icon={Mail}
                required
              />
              
              <FormInput
                label="Contraseña"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                icon={Lock}
                required
              />

              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="rounded border-gray-300 text-[#0B3D91] focus:ring-[#0B3D91]" />
                  <span className="text-gray-600">Recuérdame</span>
                </label>
                <Link to="/forgot-password" className="text-[#0B3D91] font-medium hover:underline">
                  ¿Olvidaste tu contraseña?
                </Link>
              </div>

              <FormButton type="submit" loading={isLoading}>
                Iniciar Sesión
              </FormButton>
            </form>

            <p className="mt-8 text-center text-gray-600">
              ¿No tienes una cuenta?{' '}
              <Link to="/signup" className="text-[#0B3D91] font-bold hover:underline">
                Regístrate gratis
              </Link>
            </p>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default LoginPage;
