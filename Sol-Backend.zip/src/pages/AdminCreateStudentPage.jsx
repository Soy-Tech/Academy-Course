
import React, { useState } from 'react';
import AdminLayout from '@/components/Admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { mockDb } from '@/data/mockDatabase';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { ROLES } from '@/utils/rolePermissions';

const AdminCreateStudentPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    temporaryPassword: '',
    startDate: '',
    courses: []
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    // Validation
    if(mockDb.users.getByEmail(formData.email)) {
      toast({ title: 'Error', description: 'El email ya existe.', variant: 'destructive' });
      setLoading(false);
      return;
    }

    try {
      // 1. Create User
      const newUser = mockDb.users.create({
        name: formData.name,
        email: formData.email,
        password: formData.temporaryPassword || 'temp1234',
        role: ROLES.STUDENT,
        userType: 'corporate',
        status: 'active',
        company: formData.company,
        avatar: formData.name.charAt(0).toUpperCase(),
        bio: `Estudiante corporativo de ${formData.company}`
      });

      // 2. Mock Email Notification
      console.log(`[EMAIL SERVICE] Sending corporate welcome email to ${newUser.email} with password ${newUser.password}`);

      // 3. Success Feedback
      toast({
        title: "Estudiante creado",
        description: "Se han enviado las credenciales por correo.",
      });
      navigate('/admin/users');
    } catch (error) {
      console.error(error);
      toast({ title: 'Error', description: 'No se pudo crear el usuario', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <AdminLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/admin/users')}>
            <ArrowLeft size={16} />
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Registrar Estudiante Corporativo</h1>
        </div>

        <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Nombre Completo</label>
              <input 
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Email Corporativo</label>
              <input 
                required
                type="email"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Empresa / Organización</label>
              <input 
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Contraseña Temporal</label>
              <input 
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="Generar automáticamente"
                value={formData.temporaryPassword}
                onChange={(e) => setFormData({...formData, temporaryPassword: e.target.value})}
              />
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => navigate('/admin/users')}>Cancelar</Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={loading}>
              {loading ? 'Creando...' : 'Registrar Estudiante'}
            </Button>
          </div>
        </form>
      </div>
    </AdminLayout>
  );
};

export default AdminCreateStudentPage;
