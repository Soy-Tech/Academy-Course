

import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Users, BookOpen, Linkedin, Twitter, Github, Globe, CheckCircle, Mail, UserPlus, MessageSquare, Award } from 'lucide-react';
import { mockInstructors } from '@/data/mockInstructors';
import { coursesData } from '@/data/coursesData';
import { mockReviews } from '@/data/mockReviews';
import CourseCard from '@/components/CourseCard';
import ReviewList from '@/components/Reviews/ReviewList';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import NotFoundPage from '@/pages/NotFoundPage';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const InstructorProfilePage = () => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('courses');
  const [isFollowing, setIsFollowing] = useState(false);
  const { toast } = useToast();

  // In a real app, you would fetch by ID. Here we simulate finding by ID or matching name partially
  const instructor = mockInstructors.find(i => i.id.toString() === id) || mockInstructors[0];

  if (!instructor) return <NotFoundPage />;

  const instructorCourses = coursesData.filter(c => instructor.courseIds.includes(c.id.toString()) || c.instructor === instructor.name);
  const instructorReviews = mockReviews.filter(r => instructorCourses.some(c => c.id.toString() === r.courseId));

  const handleFollow = () => {
    setIsFollowing(!isFollowing);
    toast({
      title: isFollowing ? "Unfollowed" : "Following",
      description: isFollowing ? `You are no longer following ${instructor.name}` : `You are now following ${instructor.name}`,
    });
  };

  const handleContact = () => {
    toast({
      title: "Contact Request Sent",
      description: "The instructor will receive your message shortly.",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Header />
      
      {/* Header Banner */}
      <div className="relative h-48 md:h-64 bg-gradient-to-r from-blue-900 to-indigo-900 overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
      </div>

      <div className="container mx-auto px-4 pb-12">
        <div className="relative -mt-16 md:-mt-20 mb-8 flex flex-col md:flex-row items-center md:items-end gap-6">
          {/* Avatar */}
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-white shadow-lg overflow-hidden bg-white z-10"
          >
            <img src={instructor.avatar} alt={instructor.name} className="w-full h-full object-cover" />
          </motion.div>
          
          {/* Info */}
          <div className="flex-1 text-center md:text-left mb-2">
            <h1 className="text-3xl font-bold text-gray-900 mb-1">{instructor.name}</h1>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-2">
              <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wide">
                {instructor.specialty}
              </span>
              <div className="flex gap-2 ml-2">
                {instructor.socialLinks.linkedin && <a href={instructor.socialLinks.linkedin} className="text-gray-400 hover:text-blue-600 transition-colors"><Linkedin size={18} /></a>}
                {instructor.socialLinks.twitter && <a href={instructor.socialLinks.twitter} className="text-gray-400 hover:text-blue-400 transition-colors"><Twitter size={18} /></a>}
                {instructor.socialLinks.github && <a href={instructor.socialLinks.github} className="text-gray-400 hover:text-gray-900 transition-colors"><Github size={18} /></a>}
              </div>
            </div>
            <p className="text-gray-600 max-w-xl mx-auto md:mx-0">{instructor.bio}</p>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mb-4 md:mb-6">
            <Button 
              onClick={handleFollow}
              variant={isFollowing ? "default" : "outline"}
              className={isFollowing ? "bg-blue-600 hover:bg-blue-700" : "border-blue-600 text-blue-600 hover:bg-blue-50"}
            >
              {isFollowing ? <CheckCircle size={18} className="mr-2" /> : <UserPlus size={18} className="mr-2" />}
              {isFollowing ? 'Following' : 'Follow'}
            </Button>
            <Button variant="secondary" onClick={handleContact} className="bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200">
              <MessageSquare size={18} className="mr-2" /> Contact
            </Button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-4 border-y border-gray-200 py-6 mb-8 bg-white rounded-lg shadow-sm">
          <div className="text-center border-r border-gray-100">
            <div className="flex items-center justify-center gap-1 font-bold text-xl text-gray-900">
              {instructor.rating} <Star size={18} className="text-yellow-400 fill-current" />
            </div>
            <p className="text-xs text-gray-500 uppercase tracking-wide">Instructor Rating</p>
          </div>
          <div className="text-center border-r border-gray-100">
            <div className="flex items-center justify-center gap-1 font-bold text-xl text-gray-900">
              {instructor.studentCount.toLocaleString()} <Users size={18} className="text-blue-500" />
            </div>
            <p className="text-xs text-gray-500 uppercase tracking-wide">Students</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 font-bold text-xl text-gray-900">
              {instructorCourses.length} <BookOpen size={18} className="text-indigo-500" />
            </div>
            <p className="text-xs text-gray-500 uppercase tracking-wide">Courses</p>
          </div>
        </div>

        {/* Tabs Content */}
        <div className="flex gap-6 border-b border-gray-200 mb-8 overflow-x-auto">
          {['courses', 'reviews', 'about'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-3 px-1 text-sm font-bold capitalize transition-all border-b-2 ${
                activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'courses' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {instructorCourses.length > 0 ? (
                  instructorCourses.map((course, idx) => (
                    <motion.div 
                      key={course.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                    >
                      <CourseCard course={course} />
                    </motion.div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-12 text-gray-500">
                    No courses available yet.
                  </div>
                )}
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="max-w-3xl">
                <h3 className="text-lg font-bold mb-6">Student Reviews</h3>
                <ReviewList reviews={instructorReviews} />
              </div>
            )}

            {activeTab === 'about' && (
              <div className="grid md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-8">
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold mb-4">About Me</h3>
                    <p className="text-gray-700 leading-relaxed mb-4">{instructor.fullBio || instructor.bio}</p>
                  </div>
                  
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold mb-4">Experience</h3>
                    <ul className="space-y-4">
                      {instructor.experience.map((exp, idx) => (
                        <li key={idx} className="flex gap-3">
                          <div className="w-2 h-2 mt-2 rounded-full bg-blue-500 shrink-0" />
                          <span className="text-gray-700">{exp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="space-y-8">
                  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold mb-4">Certifications</h3>
                    <ul className="space-y-3">
                      {instructor.certifications.map((cert, idx) => (
                        <li key={idx} className="flex items-center gap-3 text-sm text-gray-700">
                          <Award size={16} className="text-yellow-500" />
                          {cert}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
      <Footer />
    </div>
  );
};

export default InstructorProfilePage;
