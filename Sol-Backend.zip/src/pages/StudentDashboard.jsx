
import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, Clock, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

const StudentDashboard = () => {
  const { currentUser } = useAuth();
  
  const stats = [
    { label: 'Cursos en progreso', value: 3, icon: Clock, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Completados', value: 1, icon: Award, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Total horas', value: 12, icon: BookOpen, color: 'text-purple-600', bg: 'bg-purple-100' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pb-12">
      <div className="bg-[#0B3D91] pt-12 pb-24 px-6">
        <div className="container mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="text-3xl font-bold text-white mb-2">Hola, {currentUser?.name || 'Estudiante'}</h1>
            <p className="text-blue-200">
                Bienvenido a tu panel de aprendizaje. 
                {currentUser?.email && <span className="block text-xs mt-1 text-blue-300 opacity-70">({currentUser.email})</span>}
            </p>
          </motion.div>
        </div>
      </div>

      <div className="container mx-auto px-6 -mt-12">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl p-6 shadow-lg border border-gray-100"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 mb-1">{stat.label}</p>
                  <h3 className="text-3xl font-bold text-gray-900">{stat.value}</h3>
                </div>
                <div className={`p-3 rounded-xl ${stat.bg}`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="font-bold text-xl text-gray-900 mb-4">Mis Cursos Recientes</h2>
              <div className="space-y-4">
                 <div className="p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className="flex justify-between items-center">
                        <div>
                            <h3 className="font-bold text-gray-900">Desarrollo Web Full Stack</h3>
                            <p className="text-sm text-gray-500">Progreso: 45%</p>
                        </div>
                        <Button variant="ghost" size="sm">Continuar <ArrowRight size={16} className="ml-2"/></Button>
                    </div>
                 </div>
                 <div className="p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className="flex justify-between items-center">
                        <div>
                            <h3 className="font-bold text-gray-900">Introducción a Python</h3>
                            <p className="text-sm text-gray-500">Progreso: 12%</p>
                        </div>
                        <Button variant="ghost" size="sm">Continuar <ArrowRight size={16} className="ml-2"/></Button>
                    </div>
                 </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {/* Show "Become Instructor" button */}
            <div className="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-xl p-6 text-white shadow-lg">
              <h3 className="font-bold text-lg mb-2">¿Eres experto en algo?</h3>
              <p className="text-indigo-100 text-sm mb-4">Comparte tu conocimiento con la comunidad y genera ingresos.</p>
              <Link to="/instructor-application">
                <Button className="w-full bg-white text-indigo-700 hover:bg-indigo-50 border-0 font-bold">
                  Convertirme en Instructor
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
