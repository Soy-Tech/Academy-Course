
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { mockFAQs } from '@/data/mockFAQ';
import { Plus, Minus, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const FAQPage = () => {
  const [openId, setOpenId] = useState(null);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  const categories = ['all', ...new Set(mockFAQs.map(q => q.category))];

  const filtered = mockFAQs.filter(q => {
      const matchCat = filter === 'all' || q.category === filter;
      const matchSearch = q.question.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch;
  });

  return (
    <>
      <Helmet>
        <title>Preguntas Frecuentes - Netcom</title>
      </Helmet>

      <div className="bg-white min-h-screen py-16">
        <div className="container mx-auto px-4 max-w-4xl">
            <h1 className="text-4xl font-bold text-center text-[#0B3D91] mb-8">Preguntas Frecuentes</h1>
            
            <div className="flex flex-col md:flex-row gap-4 mb-8">
                <div className="relative flex-grow">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20}/>
                    <input 
                        type="text" 
                        placeholder="Buscar..." 
                        className="w-full pl-10 p-3 border rounded-lg"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2">
                    {categories.map(cat => (
                        <button 
                            key={cat} 
                            onClick={() => setFilter(cat)}
                            className={`px-4 py-2 rounded-full whitespace-nowrap ${filter === cat ? 'bg-[#0B3D91] text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                        >
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </button>
                    ))}
                </div>
            </div>

            <div className="space-y-4">
                {filtered.map(faq => (
                    <div key={faq.id} className="border rounded-xl overflow-hidden">
                        <button 
                            onClick={() => setOpenId(openId === faq.id ? null : faq.id)}
                            className="w-full flex justify-between items-center p-5 text-left bg-gray-50 hover:bg-gray-100 transition"
                        >
                            <span className="font-semibold text-lg text-gray-800">{faq.question}</span>
                            {openId === faq.id ? <Minus size={20}/> : <Plus size={20}/>}
                        </button>
                        <AnimatePresence>
                            {openId === faq.id && (
                                <motion.div 
                                    initial={{ height: 0 }} 
                                    animate={{ height: 'auto' }} 
                                    exit={{ height: 0 }} 
                                    className="overflow-hidden"
                                >
                                    <div className="p-5 bg-white text-gray-600 border-t">
                                        {faq.answer}
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                ))}
                {filtered.length === 0 && <p className="text-center text-gray-500 mt-8">No se encontraron resultados.</p>}
            </div>
        </div>
      </div>
    </>
  );
};

export default FAQPage;
