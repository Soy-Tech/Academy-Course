
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import useEmblaCarousel from 'embla-carousel-react';
import Autoplay from 'embla-carousel-autoplay';
import { Code, Brain, Shield, ArrowRight, Star, Award, Briefcase, Users, ChevronsRight } from 'lucide-react';
import { coursesData } from '@/data/coursesData';
import CourseCard from '@/components/CourseCard';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import PageBanner from '@/components/PageBanner';

const HomePage = () => {
  const [emblaRef] = useEmblaCarousel({ loop: true, align: 'start', slidesToScroll: 1 }, [Autoplay({ delay: 5000 })]);
  const [testimonialsRef] = useEmblaCarousel({ loop: true, align: 'start' }, [Autoplay()]);
  
  // Specific selection of featured courses based on requirement
  const featuredIds = ['full-stack-2025', 'react-pro', 'python-automation', 'ia-aplicada', 'power-bi'];
  const featuredCourses = coursesData.filter(c => featuredIds.includes(c.id));
  
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleAuthClick = (action) => {
    toast({
      title: '🚧 Funcionalidad en desarrollo',
      description: `La función de ${action} estará disponible pronto.`,
    });
  };

  const categories = [
    { name: 'Programación', icon: Code, levels: 'Principiante, Intermedio, Avanzado' },
    { name: 'Inteligencia Artificial', icon: Brain, levels: 'Principiante, Avanzado' },
    { name: 'Ciberseguridad', icon: Shield, levels: 'Intermedio, Avanzado' },
  ];

  const benefits = [
    { icon: Award, title: 'Certificados Digitales', description: 'Valida tus habilidades con certificados reconocidos.' },
    { icon: Briefcase, title: 'Proyectos Prácticos', description: 'Construye un portafolio sólido con proyectos reales.' },
    { icon: Users, title: 'Mentorías Personalizadas', description: 'Recibe guía de expertos de la industria.' },
    { icon: ChevronsRight, title: 'Comunidad Activa', description: 'Conecta y aprende con otros profesionales.' },
  ];

  const testimonials = [
    { name: 'María G.', role: 'Desarrolladora en Tech Solutions', text: 'Netcom transformó mi carrera. La calidad del contenido es excepcional y 100% práctico.' },
    { name: 'Carlos R.', role: 'Analista de Datos en DataCorp', text: 'Los instructores explican temas complejos de forma muy clara. Recomendado.' },
    { name: 'Ana M.', role: 'Especialista en Ciberseguridad en SecureNet', text: 'Gracias a Netcom, conseguí el trabajo de mis sueños en ciberseguridad.' },
    { name: 'David L.', role: 'Frontend Developer en Digital Co.', text: 'El curso de React es el mejor que he tomado. Aprendí técnicas que uso a diario.'},
    { name: 'Laura F.', role: 'Data Scientist en AI Innovations', text: 'Los proyectos me ayudaron a construir un portafolio que impresionó a los reclutadores.' },
  ];

  return (
    <>
      <Helmet>
        <title>Netcom - Academia Online de Tecnología | Cursos Prácticos</title>
        <meta name="description" content="Domina la tecnología con cursos prácticos y mentorías de expertos. Únete a Netcom y transforma tu futuro profesional." />
      </Helmet>

      <PageBanner 
        title="Aprende nuevas habilidades"
        subtitle="Cursos, rutas de aprendizaje y recursos para tu desarrollo profesional."
        cta={{ label: "Explorar cursos", onClick: () => navigate('/cursos') }}
        backgroundImage="https://images.unsplash.com/photo-1624388611710-bdf95023d1c2"
        height="h-[600px] md:h-[700px]"
      />

      {/* Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-6">
            {categories.map((cat, i) => (
              <motion.div key={cat.name}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}
                className="bg-gray-50 p-6 rounded-lg border border-gray-200 text-center hover:shadow-md hover:border-[#CFAE70] transition-all duration-300"
              >
                <div className="w-14 h-14 bg-[#0B3D91] rounded-full flex items-center justify-center mx-auto mb-4">
                  <cat.icon size={28} className="text-[#CFAE70]" />
                </div>
                <h3 className="text-xl font-bold text-[#0B3D91] mb-1">{cat.name}</h3>
                <p className="text-gray-500 text-sm mb-3">{cat.levels}</p>
                <Link to="/cursos" className="text-sm font-semibold text-[#0B3D91] hover:text-[#CFAE70] transition-colors inline-flex items-center gap-1">
                  Ver cursos <ArrowRight size={14} />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses Carousel */}
      <section className="py-16 overflow-hidden bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-8">
            <motion.h2 initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}
              className="text-2xl md:text-3xl font-bold text-[#1C1C1C]">
              Cursos Destacados
            </motion.h2>
            <Link to="/cursos" className="text-[#0B3D91] font-semibold hover:underline text-sm hidden md:block">
              Ver todos
            </Link>
          </div>
          
          <div className="cursor-grab active:cursor-grabbing" ref={emblaRef}>
            <div className="flex -ml-4 py-4">
              {featuredCourses.map(course => (
                <div key={course.id} className="flex-none w-full sm:w-1/2 md:w-1/3 lg:w-1/4 pl-4 min-w-0">
                  <CourseCard course={course} />
                </div>
              ))}
            </div>
          </div>
          
          <div className="text-center mt-6 md:hidden">
            <Link to="/cursos" className="btn-secondary py-2 px-6 text-sm">
              Ver todos los cursos
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, i) => (
              <motion.div key={benefit.title}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: i * 0.1 }}
                className="text-center"
              >
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <benefit.icon size={24} className="text-[#0B3D91]" />
                </div>
                <h3 className="text-lg font-bold text-[#1C1C1C] mb-2">{benefit.title}</h3>
                <p className="text-sm text-gray-600">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.h2 initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}
            className="text-2xl md:text-3xl font-bold text-[#1C1C1C] text-center mb-10">
            Estudiantes Satisfechos
          </motion.h2>
          <div className="overflow-hidden" ref={testimonialsRef}>
            <div className="flex">
              {testimonials.map((testimonial, i) => (
                <div key={i} className="flex-grow-0 flex-shrink-0 w-full md:w-1/2 lg:w-1/3 p-4">
                  <div className="bg-white p-6 rounded-lg border border-gray-100 shadow-sm h-full">
                    <div className="flex mb-3">
                      {[...Array(5)].map((_, i) => <Star key={i} size={16} className="text-[#CFAE70] fill-current" />)}
                    </div>
                    <p className="text-gray-700 mb-4 text-sm italic">"{testimonial.text}"</p>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                         <img className="w-full h-full object-cover" alt={testimonial.name} src={`https://api.dicebear.com/7.x/initials/svg?seed=${testimonial.name}`} />
                      </div>
                      <div>
                        <p className="font-bold text-sm text-[#0B3D91]">{testimonial.name}</p>
                        <p className="text-gray-500 text-xs">{testimonial.role}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* Final CTA */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl md:text-3xl font-bold text-[#0B3D91] mb-3">¿Listo para empezar?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-8">
              Únete a nuestra comunidad y da el siguiente paso en tu carrera.
            </p>
            <div className="max-w-md mx-auto">
              <div className="flex gap-2 p-1.5 bg-gray-100 rounded-lg mb-4">
                <input type="email" placeholder="Tu correo electrónico" className="w-full bg-transparent px-4 py-2 text-gray-800 focus:outline-none text-sm" />
                <Button onClick={() => handleAuthClick('registro')} className="btn-primary whitespace-nowrap text-sm">
                  Comenzar
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default HomePage;
