
import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Target, Briefcase, Rocket, TrendingUp, CheckCircle2, 
  BookOpen, Clock, Users, Award, Lock, ArrowRight, Play 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import PageBanner from '@/components/PageBanner';
import { learningPathsData } from '@/data/learningPathsData';
import { coursesData } from '@/data/coursesData';

const LearningPathDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const path = learningPathsData.find(p => p.id === id);

  useEffect(() => {
    if (!path) {
      // Optional: Navigate to 404 or list
    }
    window.scrollTo(0, 0);
  }, [path]);

  if (!path) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <h2 className="text-2xl font-bold mb-4">Ruta no encontrada</h2>
        <Button onClick={() => navigate('/learning-paths')}>Volver a Rutas</Button>
      </div>
    );
  }

  // Get full course objects for this path
  const pathCourses = path.courses.map(courseId => 
    coursesData.find(c => c.id === courseId)
  ).filter(Boolean); // Filter out any undefineds if data mismatch

  const iconMap = {
    'Alta Demanda': TrendingUp,
    'Versatilidad': Rocket,
    'Ecosistema': Briefcase,
    'Líder de Mercado': Award,
    'Salarios Altos': TrendingUp,
    'Comunidad': Users,
    'Autonomía': Target,
    'Visión Global': BookOpen,
    'Oportunidades': Rocket,
    'Futuro': Rocket,
    'Impacto': Target,
    'Innovación': BrainIcon => Rocket // Fallback
  };

  return (
    <>
      <Helmet>
        <title>{path.title} - Netcom Academy</title>
        <meta name="description" content={path.shortDescription} />
      </Helmet>

      {/* Section 1: Header Banner */}
      <PageBanner 
        title={path.title}
        subtitle={path.shortDescription}
        badges={[path.level, `${path.courses.length} Cursos`, path.duration]}
        cta={{ label: "Comenzar ruta ahora", onClick: () => document.getElementById('courses-list').scrollIntoView({ behavior: 'smooth' }) }}
        backgroundImage={path.image}
        height="h-[500px] md:h-[600px]"
      />

      {/* Section 2: Why Learn */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1C1C1C] mb-4">
              ¿Por qué aprender esta ruta?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              {path.description}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {path.whyLearn.map((item, index) => {
              const Icon = iconMap[item.title] || Target;
              return (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-gray-50 p-8 rounded-2xl border border-gray-100 hover:shadow-lg transition-all duration-300 text-center"
                >
                  <div className="w-16 h-16 bg-[#0B3D91]/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Icon size={32} className="text-[#0B3D91]" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Section 3: Courses Included */}
      <section id="courses-list" className="py-16 md:py-24 bg-gray-50">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-1.5 h-12 bg-[#CFAE70] rounded-full"></div>
            <h2 className="text-3xl font-bold text-[#1C1C1C]">
              Cursos incluidos en esta ruta
            </h2>
          </div>

          <div className="space-y-6">
            {pathCourses.map((course, index) => (
              <motion.div 
                key={course.id}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow flex flex-col md:flex-row gap-6 items-center"
              >
                {/* Course Thumbnail */}
                <div className="w-full md:w-48 h-32 flex-shrink-0 relative rounded-lg overflow-hidden group">
                  <img src={course.image} alt={course.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  <div className="absolute top-2 left-2 bg-black/60 text-white text-xs font-bold px-2 py-1 rounded backdrop-blur-sm">
                    Paso {index + 1}
                  </div>
                </div>

                {/* Course Info */}
                <div className="flex-grow text-center md:text-left">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{course.shortDescription}</p>
                  
                  <div className="flex flex-wrap justify-center md:justify-start gap-3 text-xs font-medium text-gray-500">
                    <span className="flex items-center bg-gray-100 px-2 py-1 rounded"><Clock size={12} className="mr-1"/> {course.duration}</span>
                    <span className="flex items-center bg-gray-100 px-2 py-1 rounded"><Users size={12} className="mr-1"/> {course.level}</span>
                    <span className="flex items-center bg-green-100 text-green-700 px-2 py-1 rounded border border-green-200"><CheckCircle2 size={12} className="mr-1"/> Incluido</span>
                  </div>
                </div>

                {/* Action */}
                <div className="flex-shrink-0 w-full md:w-auto">
                  <Link to={`/cursos/${course.id}`}>
                    <Button variant="outline" className="w-full border-[#0B3D91] text-[#0B3D91] hover:bg-[#0B3D91] hover:text-white transition-colors">
                      Ver Curso
                    </Button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 4: Learning Outcomes */}
      <section className="py-16 md:py-24 bg-white">
        <div className="container mx-auto px-4 max-w-6xl">
           <div className="grid md:grid-cols-2 gap-12 items-center">
             <div>
                <h2 className="text-3xl font-bold text-[#1C1C1C] mb-8">
                  Qué aprenderás al completar esta ruta
                </h2>
                <div className="grid gap-4">
                  {path.learningOutcomes.map((outcome, index) => (
                    <motion.div 
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-4 p-4 rounded-lg bg-gray-50 border border-gray-100"
                    >
                      <div className="mt-1 w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle2 size={14} className="text-green-600" />
                      </div>
                      <p className="text-gray-700 font-medium">{outcome}</p>
                    </motion.div>
                  ))}
                </div>
             </div>
             
             {/* Visual decoration */}
             <div className="relative h-[500px] hidden md:block rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1595763792403-e7e86ad94c4e" 
                  alt="Learning outcome" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B3D91]/80 to-transparent flex items-end p-8">
                  <div className="text-white">
                    <p className="text-2xl font-bold mb-2">Certifícate</p>
                    <p className="text-blue-100">Al completar todos los cursos, recibirás un certificado de especialización reconocido.</p>
                  </div>
                </div>
             </div>
           </div>
        </div>
      </section>

      {/* Section 5: Target Audience */}
      <section className="py-16 md:py-24 bg-[#0B3D91] text-white">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl font-bold mb-12">¿Para quién es esta ruta?</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            {path.targetAudience.map((audience, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-md p-8 rounded-2xl border border-white/20 hover:bg-white/20 transition-colors"
              >
                <div className="w-12 h-12 bg-[#CFAE70] rounded-full flex items-center justify-center mx-auto mb-4 text-[#0B3D91]">
                   <Users size={24} />
                </div>
                <h3 className="font-bold text-xl mb-2">{audience}</h3>
              </motion.div>
            ))}
          </div>

          <div className="mt-16 p-8 bg-white/5 rounded-3xl border border-white/10">
            <h3 className="text-2xl font-bold mb-4">¿Listo para comenzar tu transformación profesional?</h3>
            <p className="text-blue-100 mb-8 max-w-2xl mx-auto">
              Inscríbete hoy en el primer curso de la ruta y da el primer paso hacia tu nuevo futuro.
            </p>
            <Button 
              onClick={() => navigate(`/cursos/${pathCourses[0]?.id}`)}
              className="bg-[#CFAE70] hover:bg-[#b89a5f] text-[#0B3D91] font-bold py-6 px-10 text-lg rounded-xl shadow-lg hover:shadow-2xl transition-all hover:-translate-y-1"
            >
              Comenzar con el primer curso
              <Play className="ml-2 fill-current" size={20} />
            </Button>
          </div>
        </div>
      </section>
    </>
  );
};

export default LearningPathDetailPage;
