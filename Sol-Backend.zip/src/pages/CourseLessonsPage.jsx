
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Play, CheckCircle, Circle, Menu, X, ChevronLeft, ChevronRight, 
  FileText, Download, MessageSquare, MonitorPlay
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProgressBar from '@/components/UI/ProgressBar';
import ReviewList from '@/components/Reviews/ReviewList';
import ReviewForm from '@/components/Reviews/ReviewForm';

// Mock Data
const mockCourseData = {
  id: '1',
  title: 'Desarrollo Web Full Stack',
  progress: 35,
  modules: [
    {
      id: 'm1',
      title: 'Introducción al Desarrollo Web',
      lessons: [
        { id: 'l1', title: 'Bienvenida al curso', duration: '05:20', completed: true, type: 'video' },
        { id: 'l2', title: 'Cómo funciona la web', duration: '12:45', completed: true, type: 'video' },
        { id: 'l3', title: 'Configuración del entorno', duration: '15:30', completed: false, type: 'video' }
      ]
    },
    {
      id: 'm2',
      title: 'HTML5 & CSS3',
      lessons: [
        { id: 'l4', title: 'Estructura HTML', duration: '18:10', completed: false, type: 'video' },
        { id: 'l5', title: 'Estilos CSS básicos', duration: '20:00', completed: false, type: 'video' },
        { id: 'l6', title: 'Proyecto: Landing Page', duration: '45:00', completed: false, type: 'project' }
      ]
    }
  ]
};

const mockReviews = [
  { id: 1, user: { name: 'Juan Perez', avatar: 'J' }, rating: 5, date: 'Hace 2 días', comment: 'Excelente lección, muy clara.' },
  { id: 2, user: { name: 'Maria Garcia', avatar: 'M' }, rating: 4, date: 'Hace 5 días', comment: 'Buen contenido, pero el audio podría mejorar.' }
];

const CourseLessonsPage = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [activeLesson, setActiveLesson] = useState(mockCourseData.modules[0].lessons[0]);
  const [activeTab, setActiveTab] = useState('overview');

  const handleLessonChange = (lesson) => {
    setActiveLesson(lesson);
    if (window.innerWidth < 768) setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-screen bg-white overflow-hidden font-sans">
      {/* Sidebar */}
      <motion.div 
        className={`fixed inset-y-0 left-0 z-40 w-80 bg-gray-50 border-r border-gray-200 transform md:relative md:translate-x-0 transition-transform duration-300 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="h-full flex flex-col">
          <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-white">
            <h2 className="font-bold text-sm text-gray-800 line-clamp-1">{mockCourseData.title}</h2>
            <button onClick={() => setIsSidebarOpen(false)} className="md:hidden text-gray-500">
              <X size={20} />
            </button>
          </div>
          
          <div className="p-4 bg-white border-b border-gray-200">
            <div className="flex justify-between text-xs text-gray-500 mb-2">
              <span>Tu progreso</span>
              <span>{mockCourseData.progress}%</span>
            </div>
            <ProgressBar value={mockCourseData.progress} className="h-2" />
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            {mockCourseData.modules.map((module) => (
              <div key={module.id}>
                <h3 className="font-bold text-xs text-gray-500 uppercase tracking-wider mb-3">{module.title}</h3>
                <div className="space-y-1">
                  {module.lessons.map((lesson) => (
                    <button
                      key={lesson.id}
                      onClick={() => handleLessonChange(lesson)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors text-sm ${
                        activeLesson.id === lesson.id 
                          ? 'bg-blue-50 text-blue-700 font-medium' 
                          : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      {lesson.completed ? (
                        <CheckCircle size={16} className="text-green-500 flex-shrink-0" />
                      ) : (
                        <Circle size={16} className="text-gray-300 flex-shrink-0" />
                      )}
                      <span className="line-clamp-2 flex-1">{lesson.title}</span>
                      <span className="text-xs text-gray-400">{lesson.duration}</span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          <div className="p-4 border-t border-gray-200 bg-white">
            <Button variant="outline" className="w-full" onClick={() => navigate('/student/dashboard')}>
              <ChevronLeft size={16} className="mr-2" /> Volver al Dashboard
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Mobile Header */}
        <div className="md:hidden p-4 bg-white border-b border-gray-200 flex items-center justify-between">
          <button onClick={() => setIsSidebarOpen(true)} className="text-gray-700">
            <Menu size={24} />
          </button>
          <span className="font-bold text-gray-900 truncate ml-4">{activeLesson.title}</span>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Video Player */}
          <div className="w-full bg-black aspect-video relative group">
            <div className="absolute inset-0 flex items-center justify-center">
              <button className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform">
                <Play size={40} fill="currentColor" className="ml-2" />
              </button>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent text-white opacity-0 group-hover:opacity-100 transition-opacity">
               <div className="flex items-center gap-4">
                  <span className="font-mono text-sm">00:00 / {activeLesson.duration}</span>
                  <div className="h-1 bg-white/30 flex-1 rounded-full overflow-hidden">
                     <div className="h-full w-0 bg-red-600"></div>
                  </div>
               </div>
            </div>
          </div>

          {/* Lesson Content */}
          <div className="max-w-4xl mx-auto p-6 md:p-8">
            <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-8">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{activeLesson.title}</h1>
                <p className="text-gray-500">Módulo: Introducción al Desarrollo Web</p>
              </div>
              <Button className={activeLesson.completed ? "bg-green-100 text-green-700 hover:bg-green-200" : "bg-blue-600 text-white"}>
                 {activeLesson.completed ? "Completado" : "Marcar como visto"}
                 {activeLesson.completed && <CheckCircle size={16} className="ml-2" />}
              </Button>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-gray-200 mb-6">
              <button 
                onClick={() => setActiveTab('overview')}
                className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${activeTab === 'overview' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'}`}
              >
                Descripción
              </button>
              <button 
                onClick={() => setActiveTab('comments')}
                className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${activeTab === 'comments' ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500'}`}
              >
                Comentarios
              </button>
            </div>

            {activeTab === 'overview' ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                <div className="prose max-w-none text-gray-600">
                  <p>En esta lección aprenderemos los conceptos fundamentales para iniciar tu camino como desarrollador web.</p>
                  <p>Cubriremos los siguientes puntos:</p>
                  <ul className="list-disc pl-5 space-y-2 mt-2">
                    <li>Historia de la Web</li>
                    <li>Cliente vs Servidor</li>
                    <li>Herramientas necesarias</li>
                  </ul>
                </div>

                <div className="bg-blue-50 p-6 rounded-xl border border-blue-100">
                   <h3 className="font-bold text-blue-900 mb-4 flex items-center gap-2">
                     <FileText size={20} /> Recursos descargables
                   </h3>
                   <div className="space-y-2">
                      <a href="#" className="flex items-center justify-between p-3 bg-white rounded-lg border border-blue-200 hover:shadow-md transition-shadow group">
                         <span className="text-sm font-medium text-gray-700 group-hover:text-blue-600">Diapositivas de la lección.pdf</span>
                         <Download size={16} className="text-gray-400 group-hover:text-blue-600" />
                      </a>
                   </div>
                </div>
              </motion.div>
            ) : (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8">
                 <ReviewForm />
                 <ReviewList reviews={mockReviews} />
              </motion.div>
            )}
          </div>
        </div>

        {/* Navigation Footer */}
        <div className="p-4 border-t border-gray-200 bg-white flex justify-between items-center max-w-4xl mx-auto w-full">
            <Button variant="outline" className="gap-2">
               <ChevronLeft size={16} /> Anterior
            </Button>
            <Button className="gap-2 bg-blue-600 hover:bg-blue-700">
               Siguiente <ChevronRight size={16} />
            </Button>
        </div>
      </div>
    </div>
  );
};

export default CourseLessonsPage;
