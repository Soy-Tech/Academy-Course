
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ServerCrash, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ServerErrorPage = () => {
  const handleRetry = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4 font-sans">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center max-w-lg w-full bg-white p-12 rounded-3xl shadow-xl border border-gray-100"
      >
        <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-8">
          <ServerCrash size={48} className="text-red-500" />
        </div>
        
        <h1 className="text-6xl font-bold text-gray-900 mb-2">500</h1>
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">Server Error</h2>
        <p className="text-gray-500 mb-8 leading-relaxed">
          Something went wrong on our end. We're working on it. Please try refreshing the page or come back later.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button 
            onClick={handleRetry}
            className="w-full sm:w-auto h-12 bg-blue-600 hover:bg-blue-700 font-medium"
          >
            <RefreshCw size={18} className="mr-2" />
            Retry
          </Button>
          <Link to="/">
            <Button 
              variant="outline"
              className="w-full sm:w-auto h-12 font-medium"
            >
              <Home size={18} className="mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default ServerErrorPage;
