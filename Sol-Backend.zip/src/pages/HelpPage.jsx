
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { mockHelpGuides } from '@/data/mockHelp';
import { Book, LifeBuoy } from 'lucide-react';

const HelpPage = () => {
  return (
    <>
      <Helmet>
        <title>Centro de Ayuda - Netcom</title>
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-16">
        <div className="container mx-auto px-4 max-w-6xl">
            <div className="text-center mb-16">
                <LifeBuoy size={64} className="mx-auto text-[#CFAE70] mb-4"/>
                <h1 className="text-4xl font-bold text-[#0B3D91] mb-4">¿Cómo podemos ayudarte?</h1>
                <p className="text-xl text-gray-600">Explora nuestras guías y tutoriales</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {mockHelpGuides.map(guide => (
                    <Link key={guide.id} to={`/help/${guide.id}`} className="group bg-white p-6 rounded-xl shadow-sm hover:shadow-lg transition-all border border-gray-100">
                        <Book className="text-[#0B3D91] mb-4 group-hover:scale-110 transition-transform" size={32}/>
                        <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-[#0B3D91]">{guide.title}</h3>
                        <p className="text-gray-600 text-sm mb-4">{guide.description}</p>
                        <span className="text-xs font-semibold bg-gray-100 px-2 py-1 rounded text-gray-500">{guide.category}</span>
                    </Link>
                ))}
            </div>

            <div className="mt-16 text-center">
                <p className="text-gray-600 mb-4">¿No encuentras lo que buscas?</p>
                <div className="flex justify-center gap-4">
                    <Link to="/contact" className="text-[#0B3D91] font-bold hover:underline">Contáctanos</Link>
                    <span className="text-gray-300">|</span>
                    <Link to="/faq" className="text-[#0B3D91] font-bold hover:underline">Ver FAQ</Link>
                </div>
            </div>
        </div>
      </div>
    </>
  );
};

export default HelpPage;
