import React, { useState, useEffect, useMemo, Suspense } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Star, Clock, Globe, CheckCircle, PlayCircle, Lock, BookOpen, Users, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { coursesData } from '@/data/coursesData';
import Badge from '@/components/UI/Badge';
import { useCart } from '@/hooks/useCart';
import { LoadingSpinner } from '@/components/States/LoadingState';
import ErrorState from '@/components/States/ErrorState';
import LazyImage from '@/components/LazyImage';
import ScrollFadeIn from '@/components/ScrollFadeIn';

const CourseDetailPage = () => {
  const { id } = useParams();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Simulating fetch
    const timer = setTimeout(() => {
      const found = coursesData.find(c => c.id === id);
      setCourse(found);
      setLoading(false);
    }, 600);
    return () => clearTimeout(timer);
  }, [id]);

  const discountedPrice = useMemo(() => {
    if (!course) return null;
    const priceNum = typeof course.price === 'string' ? parseFloat(course.price.replace(/[^0-9.]/g, '')) : course.price;
    return (priceNum * 0.5).toFixed(2); // Mock discount logic
  }, [course]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><LoadingSpinner size="lg" text="Cargando curso..." /></div>;
  if (!course) return <div className="min-h-screen flex items-center justify-center"><ErrorState title="Curso no encontrado" /></div>;

  const handleEnroll = () => {
    addToCart({ 
      id: course.id, 
      title: course.title, 
      price: typeof course.price === 'string' ? parseFloat(course.price.replace(/[^0-9.]/g, '')) : course.price,
      image: course.image,
      quantity: 1 
    });
  };

  return (
    <div className="bg-white min-h-screen pb-20 font-sans">
      <Helmet>
        <title>{course.title} | Netcom Academy</title>
      </Helmet>

      <section className="relative bg-[#1a1a2e] text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent z-10" aria-hidden="true" />
        <LazyImage src={course.image} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30" containerClassName="absolute inset-0" />
        
        <div className="container mx-auto px-6 py-16 relative z-20">
          <div className="max-w-3xl">
            <div className="flex gap-2 mb-4">
              <Badge variant="primary">{course.category}</Badge>
              <Badge variant="outline" className="text-white border-white/30">{course.level}</Badge>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">{course.title}</h1>
            <p className="text-xl text-gray-200 mb-6 font-light">{course.shortDescription}</p>
            
            <div className="flex flex-wrap items-center gap-6 text-sm mb-8">
              <div className="flex items-center gap-1 text-yellow-400" aria-label={`Calificación: ${course.rating} de 5`}>
                <span className="font-bold text-lg">{course.rating}</span>
                <div className="flex" aria-hidden="true">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className={i < Math.floor(course.rating) ? "fill-current" : "text-gray-600"} />
                  ))}
                </div>
                <span className="text-gray-300 ml-1">({course.reviews} reseñas)</span>
              </div>
              <div className="flex items-center gap-1"><Users size={16} aria-hidden="true" /> {course.studentCount} estudiantes</div>
              <div className="flex items-center gap-1"><Globe size={16} aria-hidden="true" /> Español</div>
              <div className="flex items-center gap-1"><Clock size={16} aria-hidden="true" /> Última actualización: Oct 2023</div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 items-center p-6 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 md:hidden">
               <span className="text-3xl font-bold">{course.price}</span>
               <Button onClick={handleEnroll} className="w-full bg-[#CFAE70] hover:bg-[#b89a5f] text-black font-bold">
                 Añadir al Carrito
               </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-6 py-12 flex flex-col lg:flex-row gap-12">
        <main className="lg:w-2/3">
          <nav className="flex border-b border-gray-200 mb-8 overflow-x-auto" aria-label="Navegación del curso">
            {['overview', 'curriculum', 'instructor', 'reviews'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-6 py-3 font-medium text-sm capitalize whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === tab ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                aria-current={activeTab === tab ? 'page' : undefined}
              >
                {tab === 'overview' ? 'Descripción' : tab === 'curriculum' ? 'Contenido' : tab === 'instructor' ? 'Instructor' : 'Reseñas'}
              </button>
            ))}
          </nav>

          <ScrollFadeIn>
            <div className="space-y-8">
               <section aria-labelledby="learning-goals">
                 <h2 id="learning-goals" className="font-bold text-xl mb-4 text-gray-900">Lo que aprenderás</h2>
                 <div className="grid md:grid-cols-2 gap-3">
                   {[1,2,3,4].map((i) => (
                     <div key={i} className="flex items-start gap-2 text-sm text-gray-700">
                       <CheckCircle size={18} className="text-green-600 flex-shrink-0 mt-0.5" aria-hidden="true" />
                       <span>Dominar los conceptos fundamentales y avanzados de la materia.</span>
                     </div>
                   ))}
                 </div>
               </section>

               <section aria-labelledby="course-description">
                 <h2 id="course-description" className="font-bold text-xl mb-4 text-gray-900">Descripción del curso</h2>
                 <article className="prose text-gray-600 max-w-none">
                   <p>{course.fullDescription || course.description}</p>
                   <p className="mt-4">
                     Este curso está diseñado para llevarte desde los fundamentos hasta un nivel profesional.
                     A través de proyectos prácticos y ejemplos del mundo real, adquirirás las habilidades
                     necesarias para destacar en el mercado laboral actual.
                   </p>
                 </article>
               </section>

               <section aria-labelledby="course-content">
                  <h2 id="course-content" className="font-bold text-xl mb-4 text-gray-900">Contenido del curso</h2>
                  <div className="border border-gray-200 rounded-lg divide-y divide-gray-200">
                     {[1, 2, 3].map((mod) => (
                       <div key={mod} className="bg-white">
                          <button className="w-full px-6 py-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors text-left" aria-expanded="false">
                             <div className="flex items-center gap-3">
                               <span className="font-bold text-gray-700">Módulo {mod}: Fundamentos</span>
                             </div>
                             <span className="text-sm text-gray-500">3 clases • 45 min</span>
                          </button>
                          <div className="px-6 py-2">
                             {[1, 2].map(lesson => (
                                <div key={lesson} className="py-3 flex items-center justify-between text-sm group cursor-pointer hover:bg-gray-50 -mx-6 px-6">
                                   <div className="flex items-center gap-3 text-gray-600 group-hover:text-blue-600">
                                      <PlayCircle size={16} aria-hidden="true" />
                                      <span>Lección {mod}.{lesson}: Introducción al tema</span>
                                   </div>
                                   <div className="flex items-center gap-2">
                                     <span className="text-blue-600 text-xs font-semibold px-2 py-0.5 bg-blue-50 rounded">Vista previa</span>
                                     <span className="text-gray-400">15:00</span>
                                   </div>
                                </div>
                             ))}
                          </div>
                       </div>
                     ))}
                  </div>
               </section>
            </div>
          </ScrollFadeIn>
        </main>

        <aside className="lg:w-1/3">
           <div className="sticky top-24">
              <ScrollFadeIn direction="left">
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden hidden md:block">
                   <div className="p-1">
                     <LazyImage src={course.image} alt={course.title} className="w-full rounded-lg" />
                   </div>
                   <div className="p-6">
                      <div className="flex items-end gap-2 mb-4">
                         <span className="text-3xl font-bold text-gray-900">{typeof course.price === 'number' ? `$${course.price}` : course.price}</span>
                         {discountedPrice && (
                           <>
                             <span className="text-lg text-gray-400 line-through mb-1 opacity-70">399€</span>
                             <span className="text-sm font-semibold text-green-600 mb-1 ml-auto">50% DTO</span>
                           </>
                         )}
                      </div>
                      
                      <Button onClick={handleEnroll} className="w-full h-12 text-lg bg-[#0B3D91] hover:bg-[#092c69] font-bold mb-3">
                         Añadir al Carrito
                      </Button>
                      <Button variant="outline" className="w-full h-12 font-semibold">
                         Comprar ahora
                      </Button>
                      
                      <p className="text-xs text-center text-gray-500 mt-3">Garantía de devolución de 30 días</p>
                      
                      <div className="mt-6 space-y-3">
                         <h4 className="font-bold text-sm text-gray-900">Este curso incluye:</h4>
                         <div className="flex items-center gap-3 text-sm text-gray-600">
                            <PlayCircle size={16} aria-hidden="true" /> {course.duration} de video bajo demanda
                         </div>
                         <div className="flex items-center gap-3 text-sm text-gray-600">
                            <BookOpen size={16} aria-hidden="true" /> 12 recursos descargables
                         </div>
                         <div className="flex items-center gap-3 text-sm text-gray-600">
                            <Globe size={16} aria-hidden="true" /> Acceso de por vida
                         </div>
                         <div className="flex items-center gap-3 text-sm text-gray-600">
                            <Award size={16} aria-hidden="true" /> Certificado de finalización
                         </div>
                      </div>
                   </div>
                </div>
              </ScrollFadeIn>
           </div>
        </aside>
      </div>
    </div>
  );
};

export default CourseDetailPage;