
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';
import ProfileForm from '@/components/ProfileForm';
import { User, BookOpen, Award, TrendingUp } from 'lucide-react';

const ProfilePage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    coursesInProgress: 0,
    coursesCompleted: 0,
    totalPoints: 0,
    rank: 0
  });

  useEffect(() => {
    fetchProfile();
    fetchStats();
  }, [user]);

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const [progressData, rankingData] = await Promise.all([
        supabase
          .from('user_progress')
          .select('*')
          .eq('user_id', user.id),
        supabase
          .from('user_rankings')
          .select('*')
          .eq('user_id', user.id)
          .single()
      ]);

      const inProgress = progressData.data?.filter(p => p.progress_percentage < 100).length || 0;
      const completed = progressData.data?.filter(p => p.progress_percentage === 100).length || 0;

      setStats({
        coursesInProgress: inProgress,
        coursesCompleted: completed,
        totalPoints: rankingData.data?.points || 0,
        rank: rankingData.data?.rank || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0B3D91]"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Mi Perfil - Netcom Academy</title>
        <meta name="description" content="Gestiona tu perfil y configuración en Netcom Academy." />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Mi Perfil</h1>
            <p className="text-gray-600">Gestiona tu información personal y preferencias</p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1 space-y-6">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-xl shadow-md p-6"
              >
                <div className="text-center">
                  <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#0B3D91] to-[#CFAE70] flex items-center justify-center text-white text-4xl font-bold">
                    {profile?.name?.charAt(0) || 'U'}
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900">{profile?.name || 'Usuario'}</h2>
                  <p className="text-gray-600">{profile?.specialty || 'Especialidad no definida'}</p>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white rounded-xl shadow-md p-6 space-y-4"
              >
                <h3 className="font-semibold text-lg text-gray-900 mb-4">Estadísticas</h3>
                
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <BookOpen className="text-[#0B3D91]" size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Cursos en progreso</p>
                    <p className="text-xl font-bold text-gray-900">{stats.coursesInProgress}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                    <Award className="text-green-600" size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Cursos completados</p>
                    <p className="text-xl font-bold text-gray-900">{stats.coursesCompleted}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <TrendingUp className="text-[#CFAE70]" size={20} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Puntos totales</p>
                    <p className="text-xl font-bold text-gray-900">{stats.totalPoints}</p>
                  </div>
                </div>

                {stats.rank > 0 && (
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <User className="text-purple-600" size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Ranking</p>
                      <p className="text-xl font-bold text-gray-900">#{stats.rank}</p>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="lg:col-span-2"
            >
              <div className="bg-white rounded-xl shadow-md p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Información Personal</h2>
                <ProfileForm profile={profile} onUpdate={fetchProfile} />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProfilePage;
