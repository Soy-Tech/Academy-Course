
# Frontend Maintenance Guide

## 1. How to Add New Pages
1. **Create Component**: Create a new file in `src/pages/` (e.g., `NewPage.jsx`).
2. **Add Route**: Import the page in `src/App.jsx` and add a `<Route>` entry.
   - Use `<ProtectedRoute>` if auth is required.
   - Use `allowedRoles={[ROLES.ADMIN]}` for role-specific access.
3. **Add Navigation**: Update `src/components/Header.jsx` to include a link if needed.
4. **Follow System**: Use `PageBanner` for headers and `container` for layout.

## 2. How to Add New Components
1. **Directory**: Place in `src/components/` or `src/components/ui/` (for primitives).
2. **Structure**: 
   