
import { useContext } from 'react';
import { EnrollmentContext } from '@/contexts/EnrollmentContext';

export const useEnrollment = () => {
  const context = useContext(EnrollmentContext);
  if (!context) {
    throw new Error('useEnrollment must be used within an EnrollmentProvider');
  }
  return context;
};

export default useEnrollment;
