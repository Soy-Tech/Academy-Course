
import { useEffect, useState, useRef } from 'react';

const useIntersectionObserver = ({ 
  threshold = 0.1, 
  root = null, 
  rootMargin = '0px',
  freezeOnceVisible = true 
} = {}) => {
  const [isVisible, setIsVisible] = useState(false);
  const elementRef = useRef(null);

  useEffect(() => {
    const node = elementRef.current;
    if (!node) return;

    if (freezeOnceVisible && isVisible) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        const isIntersecting = entry.isIntersecting;
        if (isIntersecting) {
          setIsVisible(true);
          if (freezeOnceVisible) {
            observer.unobserve(node);
          }
        } else if (!freezeOnceVisible) {
          setIsVisible(false);
        }
      },
      { threshold, root, rootMargin }
    );

    observer.observe(node);

    return () => {
      if (node) observer.unobserve(node);
    };
  }, [threshold, root, rootMargin, freezeOnceVisible, isVisible]);

  return { elementRef, isVisible };
};

export default useIntersectionObserver;
