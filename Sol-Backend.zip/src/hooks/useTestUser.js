
import { useState, useEffect } from 'react';
import { ROLES } from '@/config/permissions';
import { logTestUser } from '@/utils/roleLogger';

const STORAGE_KEY = 'netcom_test_mode';

/**
 * Hook for managing development-only test users and role switching.
 * Strictly disabled in production builds.
 */
export const useTestUser = () => {
  const isDev = import.meta.env.DEV;
  const [testMode, setTestMode] = useState(false);
  const [testRole, setTestRole] = useState(null);

  useEffect(() => {
    if (!isDev) return;

    // Load initial state
    try {
      const stored = sessionStorage.getItem(STORAGE_KEY);
      if (stored) {
        const { active, role } = JSON.parse(stored);
        if (active && role) {
          setTestMode(true);
          setTestRole(role);
          logTestUser('Restored test session', { role });
        }
      }
    } catch (e) {
      console.error('Error loading test user state', e);
    }
  }, [isDev]);

  const switchTestRole = (role) => {
    if (!isDev) {
      console.warn('Test role switching is disabled in production');
      return;
    }

    if (!Object.values(ROLES).includes(role)) {
      console.error('Invalid test role requested:', role);
      return;
    }

    logTestUser('Switching to test role', { role });
    
    setTestMode(true);
    setTestRole(role);
    
    // Persist to session only
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
      active: true,
      role: role,
      timestamp: Date.now()
    }));
    
    // Force reload to apply changes cleanly if needed, 
    // or let contexts pick it up if they listen to storage/state
    window.location.reload(); 
  };

  const clearTestMode = () => {
    setTestMode(false);
    setTestRole(null);
    sessionStorage.removeItem(STORAGE_KEY);
    logTestUser('Test mode cleared');
    window.location.reload();
  };

  return {
    isDev,
    testMode,
    testRole,
    switchTestRole,
    clearTestMode
  };
};
