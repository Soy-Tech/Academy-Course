
import { useAuth } from '@/contexts/AuthContext';

export const usePermissions = () => {
  const { currentUser, hasPermission, hasRole } = useAuth();

  const hasAnyPermission = (permissions = []) => {
    if (!currentUser) return false;
    return permissions.some(permission => hasPermission(permission));
  };

  const hasAllPermissions = (permissions = []) => {
    if (!currentUser) return false;
    return permissions.every(permission => hasPermission(permission));
  };

  return {
    permissions: currentUser?.permissions || [],
    role: currentUser?.role || null,
    hasPermission,
    hasRole,
    hasAnyPermission,
    hasAllPermissions
  };
};

export default usePermissions;
