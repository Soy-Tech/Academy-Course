
import { useState, useEffect } from 'react';
import { courseStructureData } from '@/data/courseStructureData';

export const useCourseProgress = () => {
  // Store progress as: { [courseId]: { [lessonId]: boolean } }
  const [progressData, setProgressData] = useState(() => {
    try {
      // Load ALL progress
      const allProgress = {};
      Object.keys(courseStructureData).forEach(courseId => {
         const saved = localStorage.getItem(`courseProgress_${courseId}`);
         if (saved) {
           allProgress[courseId] = JSON.parse(saved);
         } else {
           allProgress[courseId] = {};
         }
      });
      return allProgress;
    } catch (error) {
      console.error('Error loading progress from localStorage', error);
      return {};
    }
  });

  const getCourseStructure = (courseId) => {
    return courseStructureData[courseId] || null;
  };

  const getLessonProgress = (courseId, lessonId) => {
    return progressData[courseId]?.[lessonId] || false;
  };

  const markLessonComplete = (courseId, lessonId, isComplete = true) => {
    setProgressData(prev => {
      const courseProgress = prev[courseId] || {};
      const updatedCourseProgress = { ...courseProgress, [lessonId]: isComplete };
      
      // Save specific course progress to localStorage
      localStorage.setItem(`courseProgress_${courseId}`, JSON.stringify(updatedCourseProgress));

      return {
        ...prev,
        [courseId]: updatedCourseProgress
      };
    });
  };

  const getCourseProgress = (courseId) => {
    const structure = getCourseStructure(courseId);
    if (!structure) return { completed: 0, total: 0, percentage: 0 };

    let totalLessons = 0;
    let completedLessons = 0;

    structure.modules.forEach(mod => {
      mod.lessons.forEach(lesson => {
        totalLessons++;
        if (getLessonProgress(courseId, lesson.id)) {
          completedLessons++;
        }
      });
    });

    const percentage = totalLessons === 0 ? 0 : Math.round((completedLessons / totalLessons) * 100);
    return { completed: completedLessons, total: totalLessons, percentage };
  };

  const getModuleProgress = (courseId, moduleId) => {
    const structure = getCourseStructure(courseId);
    if (!structure) return { completed: 0, total: 0, percentage: 0 };

    const module = structure.modules.find(m => m.id === moduleId);
    if (!module) return { completed: 0, total: 0, percentage: 0 };

    let total = module.lessons.length;
    let completed = 0;

    module.lessons.forEach(lesson => {
      if (getLessonProgress(courseId, lesson.id)) {
        completed++;
      }
    });

    const percentage = total === 0 ? 0 : Math.round((completed / total) * 100);
    return { completed, total, percentage };
  };

  const getNextLesson = (courseId, currentLessonId) => {
    const structure = getCourseStructure(courseId);
    if (!structure) return null;

    const allLessons = structure.modules.flatMap(m => m.lessons);
    const currentIndex = allLessons.findIndex(l => l.id === currentLessonId);
    
    if (currentIndex !== -1 && currentIndex < allLessons.length - 1) {
      return allLessons[currentIndex + 1];
    }
    return null;
  };

  const getPreviousLesson = (courseId, currentLessonId) => {
    const structure = getCourseStructure(courseId);
    if (!structure) return null;

    const allLessons = structure.modules.flatMap(m => m.lessons);
    const currentIndex = allLessons.findIndex(l => l.id === currentLessonId);
    
    if (currentIndex > 0) {
      return allLessons[currentIndex - 1];
    }
    return null;
  };

  return {
    getCourseStructure,
    getLessonProgress,
    markLessonComplete,
    getCourseProgress,
    getModuleProgress,
    getNextLesson,
    getPreviousLesson
  };
};

export default useCourseProgress;
