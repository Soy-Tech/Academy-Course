
import { useState, useEffect, useCallback } from 'react';
import { mockForumTopics, mockForumReplies, mockForumCategories, mockForumUsers } from '@/data/forumsData';
import { useAuth } from '@/contexts/AuthContext';

export const useForums = () => {
  const { currentUser } = useAuth();

  // Local state initialized from localStorage or mocks
  const [topics, setTopics] = useState(() => {
    try {
      const saved = localStorage.getItem('forum_topics');
      return saved ? JSON.parse(saved) : mockForumTopics;
    } catch (e) {
      console.error("Error loading topics from localStorage", e);
      return mockForumTopics;
    }
  });

  const [replies, setReplies] = useState(() => {
    try {
      const saved = localStorage.getItem('forum_replies');
      return saved ? JSON.parse(saved) : mockForumReplies;
    } catch (e) {
      console.error("Error loading replies from localStorage", e);
      return mockForumReplies;
    }
  });

  // Persistence effects
  useEffect(() => {
    localStorage.setItem('forum_topics', JSON.stringify(topics));
  }, [topics]);

  useEffect(() => {
    localStorage.setItem('forum_replies', JSON.stringify(replies));
  }, [replies]);

  // Data Getters
  const getUsers = useCallback(() => mockForumUsers, []);
  const getCategories = useCallback(() => mockForumCategories, []);
  
  const getUserById = useCallback((userId) => {
    return mockForumUsers.find(u => u.id === userId) || { name: 'Usuario', avatar: 'U', role: 'student' };
  }, []);

  const getTopics = useCallback((categoryId = null, sortBy = 'recent', searchTerm = '') => {
    let filtered = [...topics];

    // Filter by Category
    if (categoryId && categoryId !== 'all') {
      filtered = filtered.filter(t => t.categoryId === categoryId);
    }

    // Search Filter
    if (searchTerm) {
      const lowerTerm = searchTerm.toLowerCase();
      filtered = filtered.filter(t => 
        t.title.toLowerCase().includes(lowerTerm) || 
        t.content.toLowerCase().includes(lowerTerm) ||
        t.tags.some(tag => tag.toLowerCase().includes(lowerTerm))
      );
    }

    // Sorting
    switch (sortBy) {
      case 'recent':
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'popular':
        filtered.sort((a, b) => b.views - a.views);
        break;
      case 'unanswered':
        filtered = filtered.filter(t => {
            const topicReplies = replies.filter(r => r.topicId === t.id);
            return topicReplies.length === 0;
        });
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'solved':
        filtered = filtered.filter(t => t.isSolved);
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      default:
        break;
    }

    filtered.sort((a, b) => (b.isPinned === a.isPinned ? 0 : b.isPinned ? 1 : -1));

    return filtered;
  }, [topics, replies]);

  const getTopic = useCallback((topicId) => {
    return topics.find(t => t.id === topicId) || null;
  }, [topics]);

  const getReplies = useCallback((topicId) => {
    return replies
      .filter(r => r.topicId === topicId)
      .sort((a, b) => {
        if (a.isAccepted && !b.isAccepted) return -1;
        if (!a.isAccepted && b.isAccepted) return 1;
        return new Date(a.createdAt) - new Date(b.createdAt);
      });
  }, [replies]);

  // Actions
  const createTopic = (title, content, categoryId, tags = []) => {
    const newTopic = {
      id: `t-${Date.now()}`,
      title,
      content,
      authorId: currentUser?.id || 'u3',
      categoryId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      views: 0,
      isPinned: false,
      isSolved: false,
      tags
    };
    
    setTopics(prev => [newTopic, ...prev]);
    return newTopic;
  };

  const createReply = (topicId, content) => {
    const newReply = {
      id: `r-${Date.now()}`,
      topicId,
      authorId: currentUser?.id || 'u3',
      content,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      likes: 0,
      isAccepted: false
    };
    
    setReplies(prev => [...prev, newReply]);
    return newReply;
  };

  const incrementViews = (topicId) => {
    setTopics(prev => prev.map(t => 
      t.id === topicId ? { ...t, views: t.views + 1 } : t
    ));
  };

  return {
    getTopics,
    getTopic,
    getReplies,
    createTopic,
    createReply,
    getCategories,
    getUsers,
    getUserById,
    incrementViews
  };
};
