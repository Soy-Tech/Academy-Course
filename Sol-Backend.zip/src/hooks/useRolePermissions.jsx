
// Custom hook to check user permissions
// This hook will check against Supabase user metadata or a roles table

import { useAuth } from '@/hooks/useAuth';
import { ROLES, hasPermission } from '@/utils/rolePermissions';

export const useRolePermissions = () => {
  const { user } = useAuth();
  
  // Mock role extraction - in real app, get from user.app_metadata or user profile table
  const userRole = user?.role || ROLES.STUDENT; 

  const can = (permission) => {
    if (!user) return false;
    return hasPermission(userRole, permission);
  };

  const isAdmin = userRole === ROLES.ADMIN;
  const isInstructor = userRole === ROLES.INSTRUCTOR;
  const isStudent = userRole === ROLES.STUDENT;

  return {
    role: userRole,
    can,
    isAdmin,
    isInstructor,
    isStudent
  };
};

export default useRolePermissions;
