
import { useState, useEffect } from 'react';
import { mockAdminUsers } from '@/data/mockAdminUsers';
import { useToast } from '@/components/ui/use-toast';

export const useAdminUsers = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Simulate initial fetch with localStorage check
    setLoading(true);
    const storedUsers = localStorage.getItem('adminUsers');
    if (storedUsers) {
      setUsers(JSON.parse(storedUsers));
    } else {
      setUsers(mockAdminUsers);
      localStorage.setItem('adminUsers', JSON.stringify(mockAdminUsers));
    }
    setLoading(false);
  }, []);

  const saveUsers = (newUsers) => {
    setUsers(newUsers);
    localStorage.setItem('adminUsers', JSON.stringify(newUsers));
  };

  const addUser = (userData) => {
    const newUser = {
      id: Math.max(...users.map(u => u.id), 0) + 1,
      fechaRegistro: new Date().toISOString().split('T')[0],
      cursosAsignados: [],
      ...userData
    };
    saveUsers([newUser, ...users]);
    toast({ title: "Usuario creado", description: "El usuario ha sido añadido exitosamente." });
  };

  const updateUser = (id, updates) => {
    const updatedUsers = users.map(user => user.id === id ? { ...user, ...updates } : user);
    saveUsers(updatedUsers);
    toast({ title: "Usuario actualizado", description: "Los datos del usuario han sido guardados." });
  };

  const deleteUser = (id) => {
    const filteredUsers = users.filter(user => user.id !== id);
    saveUsers(filteredUsers);
    toast({ title: "Usuario eliminado", description: "El usuario ha sido eliminado del sistema.", variant: "destructive" });
  };

  return {
    users,
    loading,
    addUser,
    updateUser,
    deleteUser
  };
};

export default useAdminUsers;
