
import { useState, useEffect } from 'react';
import { mockAdminResources } from '@/data/mockAdminResources';
import { useToast } from '@/components/ui/use-toast';

export const useAdminResources = () => {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    const storedResources = localStorage.getItem('adminResources');
    if (storedResources) {
      setResources(JSON.parse(storedResources));
    } else {
      setResources(mockAdminResources);
      localStorage.setItem('adminResources', JSON.stringify(mockAdminResources));
    }
    setLoading(false);
  }, []);

  const saveResources = (newResources) => {
    setResources(newResources);
    localStorage.setItem('adminResources', JSON.stringify(newResources));
  };

  const addResource = (resourceData) => {
    const newResource = {
      id: Math.max(...resources.map(r => r.id), 0) + 1,
      fechaSubida: new Date().toISOString().split('T')[0],
      tamaño: `${Math.floor(Math.random() * 50) + 1} MB`, // Mock size
      ...resourceData
    };
    saveResources([newResource, ...resources]);
    toast({ title: "Recurso creado", description: "El recurso ha sido subido exitosamente." });
  };

  const updateResource = (id, updates) => {
    const updatedResources = resources.map(res => res.id === id ? { ...res, ...updates } : res);
    saveResources(updatedResources);
    toast({ title: "Recurso actualizado", description: "Los cambios han sido guardados." });
  };

  const deleteResource = (id) => {
    const filteredResources = resources.filter(res => res.id !== id);
    saveResources(filteredResources);
    toast({ title: "Recurso eliminado", description: "El recurso ha sido eliminado permanentemente.", variant: "destructive" });
  };

  return {
    resources,
    loading,
    addResource,
    updateResource,
    deleteResource
  };
};

export default useAdminResources;
