
import { useState, useCallback } from 'react';

export const useSearch = (items = [], searchFields = []) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredItems = useCallback(() => {
    if (!searchTerm) return items;

    const lowerTerm = searchTerm.toLowerCase();
    
    return items.filter((item) => {
      return searchFields.some((field) => {
        const value = item[field];
        if (value === null || value === undefined) return false;
        return String(value).toLowerCase().includes(lowerTerm);
      });
    });
  }, [items, searchTerm, searchFields]);

  return { 
    searchTerm, 
    setSearchTerm, 
    filteredItems: filteredItems() 
  };
};
