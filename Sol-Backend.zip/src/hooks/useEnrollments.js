
import { useState, useEffect } from 'react';
import { enrollmentService } from '@/services/enrollmentService';
import { useAuth } from '@/hooks/useAuth';

export const useEnrollments = () => {
  const { currentUser } = useAuth();
  const [enrollments, setEnrollments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEnrollments = async () => {
      if (!currentUser) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const data = await enrollmentService.getEnrollments();
        setEnrollments(data);
      } catch (err) {
        console.error('Error in useEnrollments:', err);
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchEnrollments();
  }, [currentUser]);

  return { enrollments, loading, error, setEnrollments };
};
