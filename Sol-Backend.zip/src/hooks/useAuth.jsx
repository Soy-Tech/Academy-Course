
// Hook Wrapper to allow switching between AuthContext and PreviewAuthContext dynamically
// This is necessary because useContext(AuthContext) requires the provider to be the specific one
// created by createContext(AuthContext).
// Since we have two separate contexts/providers, we need a unified hook.

import { useContext } from 'react';
import { AuthContext } from '@/contexts/AuthContext';
// We need to conditionally require or we can just assume App structure handles the Provider
// But wait, the hook 'useContext' needs the specific Context object.
// The best pattern here is for App.jsx to use the correct Provider, 
// and we use a SINGLE Context object but change the Provider implementation?
// OR, we make a unified hook that checks which context is available. 
// However, standard React Context doesn't support "optional" checking easily across unrelated contexts.

// STRATEGY ADJUSTMENT:
// Instead of creating a new "PreviewAuthContext" object, let's reuse the 'AuthContext' object
// but provide different values/implementations in a 'PreviewAuthProvider'.
// This way 'useAuth' (which uses AuthContext) works seamlessly.

import { AuthContext as RealAuthContext } from '@/contexts/AuthContext';
// This import is just the Context Object, which is what we need.

export const useAuth = () => {
  const context = useContext(RealAuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// We don't need to rewrite the Context definition, just the Provider implementation for Preview.
