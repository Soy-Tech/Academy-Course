
# Integration Checklist

## 1. Before Connecting Backend
- [ ] **API Definition**: Confirm all necessary endpoints exist (Auth, Courses, Users, Cart).
- [ ] **Data Structure**: Ensure API response format matches frontend expectations (or create adapters).
- [ ] **CORS**: Configure backend to accept requests from the frontend domain (localhost:3000 during dev).
- [ ] **Authentication**: Decide on JWT vs Session Cookies.
- [ ] **Permissions**: Verify backend RBAC logic matches frontend `src/config/permissions.js`.

## 2. During Integration
- [ ] **Auth Context**: Update `src/contexts/AuthContext.jsx` with real API calls.
- [ ] **Course Listing**: Replace `coursesData` in `CoursesPage.jsx` with API fetch.
- [ ] **Course Detail**: Replace data in `CourseDetailPage.jsx`.
- [ ] **Search/Filter**: Implement server-side filtering (pass query params to API) instead of client-side filtering in `CoursesPage`.
- [ ] **User Profile**: Fetch real user data in `UserProfilePage.jsx`.
- [ ] **Dashboards**: Connect Student/Instructor/Admin dashboards to real stats endpoints.
- [ ] **Forms**: Connect `ReviewForm`, `CheckoutPage`, and `OnboardingPage` to POST endpoints.
- [ ] **Error Handling**: Test 400, 401, 403, 404, 500 error responses and ensure UI handles them gracefully.

## 3. After Integration
- [ ] **Full Flow Test**: Register -> Login -> Search Course -> Add to Cart -> Checkout -> View in Dashboard.
- [ ] **Performance**: Verify API latency doesn't degrade UX (use skeletons while loading).
- [ ] **Mobile Test**: Ensure responsive layouts break gracefully with real (potentially variable length) content.
- [ ] **Security**: Verify tokens are stored securely and cleared on logout.
- [ ] **Accessibility**: Check that dynamic content updates are announced to screen readers (`aria-live`).
- [ ] **Images**: Verify all dynamic images load correctly via `LazyImage`.
