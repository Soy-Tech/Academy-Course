
# Quick Start Backend Guide for Netcom Academy

This guide outlines the critical requirements for the backend API to successfully integrate with the completed frontend.

## 1. Priority Endpoints
Implement these 5 areas first to unlock 90% of the application's functionality.

### A. Authentication
*The frontend relies on `AuthContext` which expects a user object and token.*

- **POST** `/api/auth/login`
  - Body: `{ "email": "user@test.com", "password": "..." }`
  - Response: `{ "token": "jwt_string", "user": { "id": 1, "name": "...", "role": "STUDENT", "avatar": "..." } }`
- **POST** `/api/auth/register`
  - Body: `{ "name": "...", "email": "...", "password": "..." }`
- **GET** `/api/auth/me`
  - Header: `Authorization: Bearer <token>`
  - Response: `{ "user": { ... } }`

### B. Courses
*Populates the Course Grid and Detail pages.*

- **GET** `/api/courses`
  - Query Params: `?search=...&category=...&level=...&page=1`
  - Response: `{ "data": [ ...courseObjects ], "meta": { "total": 100, "page": 1 } }`
- **GET** `/api/courses/:id`
  - Response: Full course object with modules and lessons.

### C. Course Progress (Student)
*Required for the Lesson View and Dashboard.*

- **GET** `/api/student/progress/:courseId`
  - Response: `{ "completedLessonIds": ["1-1", "1-2"], "percent": 15 }`
- **POST** `/api/student/progress`
  - Body: `{ "courseId": "...", "lessonId": "...", "completed": true }`

### D. Cart & Checkout
- **POST** `/api/orders`
  - Body: `{ "items": [{ "courseId": "1", "price": 99.99 }], "paymentMethod": "card", ... }`
  - Response: `{ "success": true, "orderId": "ORD-123" }`

## 2. Data Structures (JSON Schemas)

### User Object
