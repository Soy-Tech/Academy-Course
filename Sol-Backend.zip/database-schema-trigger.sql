
-- ==============================================================================
-- AUTOMATIC USER CREATION TRIGGER
-- ==============================================================================
-- This script sets up the logic to automatically create a public profile whenever
-- a new user registers via Supabase Auth.
--
-- Target Table: public.profiles (maps to 'users' requirement)
-- Trigger Source: auth.users
-- Default Role: 'student'
-- ==============================================================================

-- 1. Create the Function
-- This function runs with SECURITY DEFINER privileges (as the database owner)
-- to ensure it has permission to write to public.profiles regardless of RLS.

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  default_role_id UUID;
  user_full_name TEXT;
BEGIN
  -- Log the start of the trigger (visible in Supabase logs)
  RAISE LOG 'Trigger handle_new_user started for User ID: %', new.id;

  -- 1. Get the 'student' role ID
  -- We select into a variable to ensure the role exists
  SELECT id INTO default_role_id FROM public.roles WHERE name = 'student' LIMIT 1;

  -- Error handling: If role doesn't exist, log error (or default to null)
  IF default_role_id IS NULL THEN
      RAISE LOG 'Error: Default role "student" not found in roles table.';
      -- Optional: Create the role dynamically or fail. 
      -- For safety, we proceed but role_id will be null.
  END IF;

  -- 2. Extract metadata
  -- Handle cases where raw_user_meta_data might be null
  user_full_name := new.raw_user_meta_data->>'full_name';
  IF user_full_name IS NULL THEN
      user_full_name := new.email; -- Fallback to email as name
  END IF;

  -- 3. Insert into public.profiles
  INSERT INTO public.profiles (id, email, full_name, role_id)
  VALUES (
    new.id, 
    new.email, 
    user_full_name,
    default_role_id
  );

  RAISE LOG 'Successfully created profile for User ID: %', new.id;
  
  RETURN new;
EXCEPTION
  WHEN OTHERS THEN
    -- Capture any errors to prevent blocking the auth signup
    RAISE LOG 'Error in handle_new_user trigger: %', SQLERRM;
    RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Create the Trigger
-- Ensures the function runs after every successful insert into auth.users

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Verification Comment
COMMENT ON FUNCTION public.handle_new_user IS 'Automatically creates a public profile and assigns student role for new users.';
