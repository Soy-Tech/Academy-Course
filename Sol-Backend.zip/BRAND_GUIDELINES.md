
# Brand Guidelines: Netcom Academy

## 1. Brand Essence
**Netcom Academy** is the bridge between ambition and achievement. We are a modern educational platform that combines professional rigor with accessible learning paths.

### Voice & Tone
*   **Trustworthy:** We speak with authority but without arrogance.
*   **Inspiring:** We focus on what the user can *become*.
*   **Clear:** We avoid jargon unless teaching it. We value clarity over cleverness.
*   **Encouraging:** Learning is hard. We are the supportive mentor.

## 2. Visual Identity

### Logo Usage
*   **Concept:** A geometric "N" integrating an upward arrow or growth symbol.
*   **Clear Space:** Maintain a safety zone of 50% of the logo height on all sides.
*   **Minimum Size:** 32px height for digital rendering to ensure legibility.
*   **Monochrome:** Use solid white on dark backgrounds; solid black/blue on light media (print).

### Color Psychology
*   **Blue (#0052CC):** Chosen for its association with intelligence, stability, and technology. It reduces anxiety and promotes focus.
*   **Green (#10B981):** Represents growth, renewal, and "Go". Used to signal correct answers and successful enrollments.
*   **Warm Accents (Orange/Gold):** Used sparingly for "Hot" items, bestsellers, or urgent notifications.

### Imagery
*   **Style:** Authentic photography of people in learning environments (avoid over-staged stock photos).
*   **Diversity:** Represent a global student base across age, gender, and ethnicity.
*   **Screenshots:** When showing software, use clean, high-resolution captures with simplified UI if necessary.

## 3. Design Do's and Don'ts

| Do | Don't |
| :--- | :--- |
| **Do** use consistent spacing (multiples of 8px). | **Don't** eyeball margins or padding. |
| **Do** use the primary blue for the main action on a page. | **Don't** use primary blue for multiple competing buttons. |
| **Do** left-align text for readability. | **Don't** center-align long paragraphs of text. |
| **Do** provide alt text for all meaningful images. | **Don't** use images containing text (embedded text). |
| **Do** use 'Sora' for headings only. | **Don't** use 'Sora' for body text (readability issue). |

## 4. Component Personality
*   **Rounded Corners:** `8px` (`0.5rem`) is our standard radius. It feels friendly and modern, unlike the sharp `0px` edges of brutalist design or the fully round `999px` of playful apps.
*   **Shadows:** Soft, diffused shadows (`--shadow-md`). We avoid hard, dark drop shadows.
